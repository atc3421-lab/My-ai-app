import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configure Google OAuth Provider with Sheets and Drive Scopes
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive');

// Internal caching variables
let isSigningIn = false;
let cachedAccessToken: string | null = null;

/**
 * Initializes the auth listener to monitor sign-in status.
 * Reconnects if token already exists or notifies of offline status.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else {
        // If we have a user but no cached token, we can check if it is already in memory or force a re-login
        // We'll reset cached token to null and wait for an interactive session or trigger login.
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Trigger interactive Google Popup Sign-in
 */
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    if (!credential?.accessToken) {
      throw new Error('Failed to obtain Google access token from OAuth credential exchange.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Core Google Authentication Fail:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Get the cached access token in memory
 */
export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

/**
 * Logs the teacher out of the Google session
 */
export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

/**
 * Google Sheet Creation & Population Function
 * Creates a spreadsheet with a specific dynamic title, writes spreadsheet row array,
 * and styles it with clean headers.
 */
export const createSpreadsheet = async (
  accessToken: string,
  title: string,
  rows: any[][]
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> => {
  try {
    // 1. POST request to create Spreadsheet
    const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        properties: { title },
      }),
    });

    if (!createRes.ok) {
      const errText = await createRes.text();
      throw new Error(`Google Sheets Create Spreadsheet failed: ${errText}`);
    }

    const sheetData = await createRes.json();
    const spreadsheetId = sheetData.spreadsheetId;
    const spreadsheetUrl = sheetData.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    // 2. Fetch the sheet name (default is usually index 0, but retrieve just in case matching best practices)
    const firstSheetName = sheetData.sheets?.[0]?.properties?.title || 'Sheet1';
    const range = `${firstSheetName}!A1`;

    // 3. PUT request to write values with USER_ENTERED formatting
    const writeRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          range,
          majorDimension: 'ROWS',
          values: rows,
        }),
      }
    );

    if (!writeRes.ok) {
      const errText = await writeRes.text();
      throw new Error(`Google Sheets Population failed: ${errText}`);
    }

    return { spreadsheetId, spreadsheetUrl };
  } catch (err: any) {
    console.error('Error in createSpreadsheet:', err);
    throw err;
  }
};

/**
 * Google Drive Backup Function
 * Saves the entire application data array (JSON back-end mock representation)
 * safely onto the teacher's personal Google Drive in a dedicated text file format.
 */
export const backupToDrive = async (
  accessToken: string,
  dataPayload: any,
  filename: string
): Promise<{ fileId: string; webViewLink: string }> => {
  try {
    // 1. Create file metadata in Drive
    const metaRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: filename,
        mimeType: 'application/json',
        description: 'System state backup from School Notebook Audit & Syllabus Tracker.',
      }),
    });

    if (!metaRes.ok) {
      const errText = await metaRes.text();
      throw new Error(`Google Drive metadata creation failed: ${errText}`);
    }

    const fileMeta = await metaRes.json();
    const fileId = fileMeta.id;

    // 2. Upload media payload mapping to fileId in Drive
    const contentRes = await fetch(
      `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`,
      {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataPayload, null, 2),
      }
    );

    if (!contentRes.ok) {
      const errText = await contentRes.text();
      throw new Error(`Google Drive file uploading failed: ${errText}`);
    }

    // 3. Fetch webViewLink for direct quick click redirects
    const finalMetaRes = await fetch(
      `https://www.googleapis.com/drive/v3/files/${fileId}?fields=webViewLink`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    const finalMeta = await finalMetaRes.json();
    return {
      fileId,
      webViewLink: finalMeta.webViewLink || `https://drive.google.com/file/d/${fileId}/view`,
    };
  } catch (err: any) {
    console.error('Error in backupToDrive:', err);
    throw err;
  }
};

/**
 * Google Drive File Restoration Download
 * Downloads raw JSON from the backup file on Drive and translates it to applet state.
 */
export const restoreFromDrive = async (accessToken: string, fileId: string): Promise<any> => {
  try {
    const downloadRes = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!downloadRes.ok) {
      const errText = await downloadRes.text();
      throw new Error(`Google Drive Restore download failed: ${errText}`);
    }

    const payload = await downloadRes.json();
    return payload;
  } catch (err: any) {
    console.error('Error in restoreFromDrive:', err);
    throw err;
  }
};

/**
 * Lists relevant files (Spreadsheets and system JSON backups) inside Drive
 */
export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink: string;
  createdTime: string;
}

export const listDriveFiles = async (accessToken: string): Promise<DriveFileItem[]> => {
  try {
    const query = encodeURIComponent(
      "trashed = false and (mimeType = 'application/vnd.google-apps.spreadsheet' or name contains 'Notebook_Audit_Backup' or name contains 'Syllabus_Audit_Backup')"
    );
    const url = `https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=createdTime%20desc&fields=files(id,name,mimeType,webViewLink,createdTime)&pageSize=30`;

    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Google Drive listing failed: ${errText}`);
    }

    const data = await res.json();
    return data.files || [];
  } catch (err: any) {
    console.error('Error in listDriveFiles:', err);
    throw err;
  }
};
