import React, { useState } from 'react';
import { SchoolClass, ClassStudent } from '../types';
import { 
  Users, 
  UserPlus, 
  Plus, 
  Trash2, 
  Edit2, 
  Search, 
  Hash, 
  Layers, 
  AlertCircle,
  Sparkles,
  School,
  Check
} from 'lucide-react';

interface ClassRosterManagerProps {
  classes: SchoolClass[];
  onAddClass: (name: string, grade: string) => void;
  onDeleteClass: (classId: string) => void;
  onAddStudent: (classId: string, name: string, rollNumber: string) => void;
  onRemoveStudent: (classId: string, studentId: string) => void;
  onEditStudent: (classId: string, studentId: string, name: string, rollNumber: string) => void;
  onClearAllStudents: () => void;
  onBulkImportStudents: (classId: string, names: string[]) => void;
}

export default function ClassRosterManager({
  classes,
  onAddClass,
  onDeleteClass,
  onAddStudent,
  onRemoveStudent,
  onEditStudent,
  onClearAllStudents,
  onBulkImportStudents
}: ClassRosterManagerProps) {
  
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  
  // Bulk Import States
  const [bulkInput, setBulkInput] = useState('');
  const [showBulkImport, setShowBulkImport] = useState(false);

  // Class Creation States
  const [newClassName, setNewClassName] = useState('');
  const [newClassGrade, setNewClassGrade] = useState('6');
  const [showAddClass, setShowAddClass] = useState(false);

  // Custom iframe-safe confirmation & toast states
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);
  const [showWipeSuccess, setShowWipeSuccess] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showNotification = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ message: msg, type });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Student Creation States
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentRoll, setNewStudentRoll] = useState('');
  const [studentError, setStudentError] = useState('');

  // Editing Student States
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [editingRoll, setEditingRoll] = useState('');

  const activeClass = classes.find(c => c.id === selectedClassId) || classes[0];

  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;
    onAddClass(newClassName.trim(), newClassGrade);
    setNewClassName('');
    setShowAddClass(false);
  };

  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    setStudentError('');

    if (!activeClass) {
      setStudentError('Please select or create a class first.');
      return;
    }
    if (!newStudentName.trim() || !newStudentRoll.trim()) {
      setStudentError('Please fill in student name and roll number.');
      return;
    }

    // Check duplicate roll number
    const rollExists = activeClass.students.some(s => s.rollNumber === newStudentRoll.trim());
    if (rollExists) {
      setStudentError(`Roll number ${newStudentRoll} already exists in this class.`);
      return;
    }

    onAddStudent(activeClass.id, newStudentName.trim(), newStudentRoll.trim());
    setNewStudentName('');
    setNewStudentRoll('');
  };

  const startEditStudent = (student: ClassStudent) => {
    setEditingStudentId(student.id);
    setEditingName(student.name);
    setEditingRoll(student.rollNumber);
  };

  const saveEditStudent = (studentId: string) => {
    if (!activeClass) return;
    if (!editingName.trim() || !editingRoll.trim()) return;

    // Check duplicate roll number in other students
    const duplicate = activeClass.students.some(
      s => s.id !== studentId && s.rollNumber === editingRoll.trim()
    );
    if (duplicate) {
      showNotification(`Roll number ${editingRoll} is already taken.`, 'error');
      return;
    }

    onEditStudent(activeClass.id, studentId, editingName.trim(), editingRoll.trim());
    setEditingStudentId(null);
  };

  // Safe Fallback
  if (!activeClass && classes.length > 0) {
    setSelectedClassId(classes[0].id);
  }

  return (
    <div id="class_roster_manager" className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative">
      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-[9999] bg-slate-900/95 border border-indigo-500/30 text-white px-5 py-4 rounded-2xl shadow-2xl flex items-center gap-3">
          {toast.type === 'success' ? (
            <div className="w-5 h-5 bg-emerald-500/25 rounded-full border border-emerald-500/30 text-emerald-400 font-bold flex items-center justify-center text-[10px]">✓</div>
          ) : (
            <div className="w-5 h-5 bg-rose-500/25 rounded-full border border-rose-500/30 text-rose-400 font-bold flex items-center justify-center text-[10px]">!</div>
          )}
          <div className="text-xs font-bold whitespace-pre-line leading-relaxed">{toast.message}</div>
          <button onClick={() => setToast(null)} className="ml-2 text-slate-500 hover:text-white font-extrabold cursor-pointer text-xs">×</button>
        </div>
      )}
      
      {/* Left Column: Classes List */}
      <div className="lg:col-span-4 space-y-4">
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-extrabold text-white text-base flex items-center gap-2">
              <School className="w-5 h-5 text-indigo-400" />
              <span>Classes & Grades</span>
            </h3>
            <span className="text-[10px] uppercase font-bold bg-white/10 text-slate-300 px-2.5 py-0.5 rounded-full border border-white/5">
              {classes.length} total
            </span>
          </div>

          {/* Quick Add Class Button */}
          {!showAddClass ? (
            <button
              onClick={() => setShowAddClass(true)}
              className="w-full mb-3 py-2.5 px-4 bg-white/5 border border-dashed border-white/10 hover:border-indigo-500 hover:bg-indigo-500/10 text-slate-300 hover:text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4 text-indigo-400" /> Add New Class
            </button>
          ) : (
            <form onSubmit={handleCreateClass} className="bg-white/5 p-4 rounded-xl border border-white/10 mb-3 space-y-3">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Class Name</label>
                <input
                  type="text"
                  placeholder="e.g., Grade 6-A"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-950 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-bold text-white placeholder-slate-500"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Grade Level</label>
                  <select
                    value={newClassGrade}
                    onChange={(e) => setNewClassGrade(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg font-bold text-white focus:outline-none focus:border-indigo-500"
                  >
                    {[1,2,3,4,5,6,7,8,9,10,11,12].map(g => (
                      <option key={g} value={g.toString()} className="bg-slate-950 text-white">Grade {g}</option>
                    ))}
                  </select>
                </div>
                <div className="flex items-end gap-1.5">
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm shadow-indigo-500/20"
                  >
                    Create
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAddClass(false)}
                    className="py-2.5 px-3 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs font-bold border border-white/5 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* List of Classes */}
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
            {classes.map(cls => (
              <div
                key={cls.id}
                onClick={() => setSelectedClassId(cls.id)}
                className={`py-3 px-4 rounded-xl cursor-pointer border transition-all flex items-center justify-between group ${
                  (activeClass && activeClass.id === cls.id)
                    ? 'bg-indigo-500/10 border-indigo-500/30 text-white font-bold shadow-md'
                    : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${
                    (activeClass && activeClass.id === cls.id) ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 border border-white/5'
                  }`}>
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold">{cls.name}</span>
                    <span className="text-[10px] text-slate-400 font-semibold">Grade {cls.grade} &bull; {cls.students.length} students</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Do you really want to delete class ${cls.name}? All students nested within will be deleted too.`)) {
                        onDeleteClass(cls.id);
                        if (selectedClassId === cls.id && classes.length > 1) {
                          setSelectedClassId(classes.filter(c => c.id !== cls.id)[0].id);
                        }
                      }
                    }}
                    className="p-1 text-slate-400 hover:text-rose-450 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                    title="Delete Class"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            ))}

            {classes.length === 0 && (
              <div className="text-center py-10">
                <AlertCircle className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                <p className="text-slate-400 text-xs font-medium">No school classes added yet.</p>
              </div>
            )}
          </div>

          {/* Wipe All Students Button */}
          {classes.some(c => c.students.length > 0) && (
            <div className="mt-4 p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 shadow-xl space-y-3">
              <div className="text-[10px] text-slate-400 font-extrabold flex items-center gap-1.5 uppercase tracking-wide">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>Roster Reset Utility</span>
              </div>
              
              {!showWipeConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowWipeConfirm(true)}
                  className="w-full py-2.5 px-4 bg-rose-500/10 hover:bg-rose-600 border border-rose-500/25 hover:border-transparent text-rose-300 hover:text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Trash2 className="w-4 h-4 text-rose-450 group-hover:text-white" /> 
                  <span>Wipe All Class Rosters</span>
                </button>
              ) : (
                <div className="p-3 bg-rose-950/40 rounded-xl border border-rose-500/25 space-y-3 animate-fade-in">
                  <p className="text-[11px] text-rose-200 leading-relaxed font-bold">
                    Are you absolutely sure? This will permanently remove all student rosters and notebook scores from all classes.
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setShowWipeConfirm(false)}
                      className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-extrabold text-[11px] rounded-lg transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onClearAllStudents();
                        setShowWipeConfirm(false);
                        setShowWipeSuccess(true);
                        setTimeout(() => setShowWipeSuccess(false), 5000);
                      }}
                      className="py-1.5 px-3 bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-[11px] rounded-lg transition-colors cursor-pointer shadow-md shadow-rose-600/20"
                    >
                      Yes, Wipe All Roster
                    </button>
                  </div>
                </div>
              )}

              {showWipeSuccess && (
                <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-bold rounded-xl text-center animate-fade-in flex items-center justify-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                  All class rosters cleared successfully!
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Column: Students list in active class */}
      <div className="lg:col-span-8 space-y-4">
        {activeClass ? (
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10 shadow-2xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-4">
              <div>
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wide">Viewing Class Roster</span>
                <h3 className="font-extrabold text-white text-lg flex items-center gap-2 mt-0.5">
                  {activeClass.name} Student Directory
                </h3>
              </div>

              {/* Compact quick add & bulk toggle inline */}
              <div className="flex flex-wrap items-center gap-3">
                <form onSubmit={handleCreateStudent} className="flex items-center gap-2">
                  <div className="w-16">
                    <input
                      type="text"
                      placeholder="Roll No"
                      value={newStudentRoll}
                      onChange={(e) => setNewStudentRoll(e.target.value)}
                      className="w-full text-xs p-2 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-center font-bold text-white placeholder-slate-500"
                      required
                    />
                  </div>
                  <div className="w-40">
                    <input
                      type="text"
                      placeholder="Student full name"
                      value={newStudentName}
                      onChange={(e) => setNewStudentName(e.target.value)}
                      className="w-full text-xs p-2 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-medium text-white placeholder-slate-500"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer shadow-md shadow-indigo-500/10"
                  >
                    <UserPlus className="w-3.5 h-3.5" /> Add Single
                  </button>
                </form>

                <button
                  type="button"
                  onClick={() => setShowBulkImport(!showBulkImport)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer border ${
                    showBulkImport 
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/25' 
                      : 'bg-white/5 hover:bg-white/10 text-slate-350 border-white/10'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Bulk Paste</span>
                </button>
              </div>
            </div>

            {/* BULK IMPORT CARD CONTENT */}
            {showBulkImport && (
              <div className="bg-slate-950/60 border border-white/10 p-5 rounded-2xl mb-5 space-y-4">
                <div>
                  <h4 className="font-extrabold text-white text-sm flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Bulk Paste Student Roster</span>
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Paste student names. Enter one student's full name per line (e.g., AGRAWAL SHRADDHA ESHWAR).
                    They will automatically get sequential roll numbers starting from the next available number.
                  </p>
                </div>
                <textarea
                  rows={8}
                  placeholder={`AGRAWAL SHRADDHA ESHWAR
AGRAWAL YUVRAJ GANESH
AVHAD ANVIKA SACHIN`}
                  value={bulkInput}
                  onChange={(e) => setBulkInput(e.target.value)}
                  className="w-full text-xs p-3 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-mono text-white placeholder-slate-600 block"
                />
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 font-bold">
                    Detected: <strong className="text-emerald-400">{bulkInput.split('\n').filter(line => line.trim()).length}</strong> names
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const lines = bulkInput.split('\n').map(l => l.trim()).filter(l => l.length > 0);
                        if (lines.length === 0) {
                          showNotification('Please enter at least one student name.', 'error');
                          return;
                        }
                        onBulkImportStudents(activeClass.id, lines);
                        setBulkInput('');
                        setShowBulkImport(false);
                      }}
                      className="py-2 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
                    >
                      Import & Append
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowBulkImport(false)}
                      className="py-2 px-3 bg-white/5 hover:bg-white/10 text-slate-350 rounded-xl text-xs font-bold transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            {studentError && (
              <div className="p-3 bg-rose-500/10 text-rose-300 text-xs font-medium rounded-xl flex items-center gap-2 mb-3 border border-rose-500/20">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{studentError}</span>
              </div>
            )}

            {/* Students Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 uppercase font-extrabold text-[10px] tracking-wider pb-2">
                    <th className="py-3 px-4 max-w-[80px]">Roll No</th>
                    <th className="py-3 px-4">Student Name</th>
                    <th className="py-3 px-4 text-center">Reference ID</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {activeClass.students
                    .sort((a, b) => a.rollNumber.localeCompare(b.rollNumber, undefined, {numeric: true}))
                    .map((student) => (
                      <tr key={student.id} className="hover:bg-white/5 transition-colors group">
                        
                        {/* Roll Number Column */}
                        <td className="py-3 px-4 font-black text-white max-w-[80px]">
                          {editingStudentId === student.id ? (
                            <input
                              type="text"
                              value={editingRoll}
                              onChange={(e) => setEditingRoll(e.target.value)}
                              className="w-14 p-1 border border-white/20 bg-slate-900 rounded focus:outline-none focus:border-indigo-500 font-bold text-center text-white"
                            />
                          ) : (
                            <span className="bg-white/10 text-slate-300 font-bold px-2 py-0.5 rounded-md border border-white/5">
                              {student.rollNumber}
                            </span>
                          )}
                        </td>

                        {/* Student Name */}
                        <td className="py-3 px-4 font-semibold text-slate-200">
                          {editingStudentId === student.id ? (
                            <input
                              type="text"
                              value={editingName}
                              onChange={(e) => setEditingName(e.target.value)}
                              className="w-full p-1 border border-white/20 bg-slate-900 rounded focus:outline-none focus:border-indigo-500 font-medium text-white"
                            />
                          ) : (
                            <span className="text-slate-100 text-xs">{student.name}</span>
                          )}
                        </td>

                        {/* Ref ID */}
                        <td className="py-3 px-4 text-center font-mono text-[10px] text-slate-500">
                          {student.id}
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                            {editingStudentId === student.id ? (
                              <div className="flex gap-1">
                                <button
                                  onClick={() => saveEditStudent(student.id)}
                                  className="p-1 px-2.5 bg-emerald-600 text-white rounded hover:bg-emerald-500 transition-colors text-[10px] font-bold inline-flex items-center gap-0.5 cursor-pointer"
                                  title="Save Changes"
                                >
                                  <Check className="w-3 h-3" /> Save
                                </button>
                                <button
                                  onClick={() => setEditingStudentId(null)}
                                  className="p-1 px-2.5 bg-white/10 text-slate-300 rounded hover:bg-white/20 transition-colors text-[10px] font-bold cursor-pointer"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => startEditStudent(student)}
                                  className="p-1 text-slate-400 hover:text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors cursor-pointer"
                                  title="Edit Name/Roll"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`Remove ${student.name} from this class roster? All student notebook checking records will be wiped permanently.`)) {
                                      onRemoveStudent(activeClass.id, student.id);
                                    }
                                  }}
                                  className="p-1 text-slate-400 hover:text-rose-450 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                                  title="Delete Student"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>
                        </td>

                      </tr>
                    ))}

                  {activeClass.students.length === 0 && (
                    <tr>
                      <td colSpan={4} className="text-center py-12 text-slate-400">
                        <Users className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                        <p className="text-xs font-bold text-slate-300">Roster Is Empty</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">Use the form above to add students to {activeClass.name}.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-500">
              <span>Always maintain unique Roll Numbers for each student.</span>
              <span>Total Active Roster: <strong className="text-white font-bold">{activeClass.students.length} Students</strong></span>
            </div>
          </div>
        ) : (
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-10 border border-white/10 shadow-2xl text-center">
            <School className="w-12 h-12 text-slate-500 mx-auto mb-3" />
            <p className="text-white text-sm font-bold">No Active Class Selected</p>
            <p className="text-slate-450 text-xs mt-1">Please create a school class first in the left panel to register students.</p>
          </div>
        )}
      </div>

    </div>
  );
}
