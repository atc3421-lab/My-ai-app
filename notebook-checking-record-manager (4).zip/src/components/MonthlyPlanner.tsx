import React, { useState, useEffect } from 'react';
import { SchoolClass, MonthlyTask, UserSession } from '../types';
import { 
  Calendar, 
  BookOpen, 
  Plus, 
  Trash2, 
  Sliders, 
  FileText, 
  Target, 
  ArrowRight,
  Clock,
  Sparkles,
  AlertCircle,
  Award,
  GraduationCap,
  AlertTriangle
} from 'lucide-react';
import { TeacherAllotment, getSubjectsForGrade } from '../data/teacherData';

import { OFFICIAL_SYLLABUS_BANK } from '../data/officialSyllabus';

interface MonthlyPlannerProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  onAddTask: (task: Omit<MonthlyTask, 'id'>) => void;
  onDeleteTask: (taskId: string) => void;
  onClearSyllabusTasks?: (classId: string | 'all', month: string) => void;
  subjects: string[];
  onAddSubject: (subject: string) => void;
  allotments: TeacherAllotment[];
  syllabusBank?: { [grade: string]: any[] };
  onUpdateSyllabusBank?: (bank: { [grade: string]: any[] }) => void;
  currentUser?: UserSession | null;
}

export default function MonthlyPlanner({
  classes,
  tasks,
  onAddTask,
  onDeleteTask,
  onClearSyllabusTasks,
  subjects,
  onAddSubject,
  allotments,
  syllabusBank = OFFICIAL_SYLLABUS_BANK,
  onUpdateSyllabusBank,
  currentUser
}: MonthlyPlannerProps) {
  
  // Helper to match class name to allotment grade
  const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
    if (!className || !allotmentGrade) return false;
    const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
    const c1 = clean(className);
    const c2 = clean(allotmentGrade);
    return c1 === c2;
  };

  // Helper to check if subject is assigned to teacher
  const isSubjectAssignedToTeacher = (className: string, subjectName: string, teacherName: string): boolean => {
    const allotment = allotments?.find(
      a => isClassMatchAllotment(className, a.grade)
    );
    if (!allotment) return false;
    const assigned = allotment.subjects[subjectName];
    if (!assigned) return false;
    const clean = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    return clean(assigned).includes(clean(teacherName)) || clean(teacherName).includes(clean(assigned));
  };

  // Find which classes are allotted to the teacher
  const allowedClasses = currentUser && currentUser.role === 'teacher'
    ? classes.filter(classe => {
        const allotment = allotments.find(a => isClassMatchAllotment(classe.name, a.grade));
        if (!allotment) return false;
        
        const clean = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
        const isClassTeacher = allotment.classTeacher && clean(allotment.classTeacher).includes(clean(currentUser.name));
        const teachesSomeSubject = Object.values(allotment.subjects).some(tName => 
          tName && (clean(tName).includes(clean(currentUser.name)) || clean(currentUser.name).includes(clean(tName)))
        );
        return isClassTeacher || teachesSomeSubject;
      })
    : classes;

  // --- IN-APP IFRAME-SAFE DIALOG & TOAST STATES ---
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    description: string;
    confirmText: string;
    cancelText?: string;
    isDangerous?: boolean;
    onAction: () => void;
  } | null>(null);

  const [toast, setToast] = useState<{
    text: string;
    type: 'success' | 'amber' | 'rose' | 'indigo';
  } | null>(null);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const showToast = (text: string, type: 'success' | 'amber' | 'rose' | 'indigo' = 'success') => {
    setToast({ text, type });
  };

  // Filtering States
  const [filterClassId, setFilterClassId] = useState<string>(() => {
    return allowedClasses[0]?.id || 'all';
  });
  const [filterMonth, setFilterMonth] = useState<string>('June 2026');
  const [showMyPlansOnly, setShowMyPlansOnly] = useState<boolean>(currentUser?.role === 'teacher');

  // New Subject creation States
  const [newSubject, setNewSubject] = useState('');
  const [showAddSubject, setShowAddSubject] = useState(false);

  // New Task creation Form States
  const [showAddTask, setShowAddTask] = useState(false);
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [selectedSubject, setSelectedSubject] = useState<string>(subjects[0] || '');
  const [selectedMonth, setSelectedMonth] = useState<string>('June 2026');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDesc, setTaskDesc] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('2026-04-25');
  const [syllabusViewerOpen, setSyllabusViewerOpen] = useState(false);
  const [activeSyllabusGrade, setActiveSyllabusGrade] = useState("Grade I");

  // Standard months list
  const months = ['April 2026', 'June 2026', 'July 2026', 'August 2026', 'September 2026'];

  // Match class name to roman numeral grade key in syllabus bank
  const getSyllabusGradeKey = (className: string): string => {
    // e.g., "Grade I Orchid" -> "Grade I", "Grade VI Tulip" -> "Grade VI", "Grade V O" -> "Grade V"
    const cleaned = className.replace('Grade ', '').trim();
    const parts = cleaned.split(' ');
    if (parts.length > 0) {
      return `Grade ${parts[0]}`; // e.g. "Grade V"
    }
    return 'Grade V';
  };

  // Look up allocated teacher based on grade name and subject name
  const getAllocatedTeacher = (classIdOrName: string, subjectName: string): string => {
    let nameToQuery = classIdOrName;
    const foundClass = classes.find(c => c.id === classIdOrName);
    if (foundClass) {
      nameToQuery = foundClass.name;
    }
    const allotment = allotments.find(a => isClassMatchAllotment(nameToQuery, a.grade));
    if (allotment) {
      return allotment.subjects[subjectName] || allotment.classTeacher || 'Staff Teacher';
    }
    return 'Staff Teacher';
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim() || !selectedClassId || !selectedSubject || !selectedMonth) {
      showToast('Please fill in all task fields.', 'amber');
      return;
    }

    onAddTask({
      classId: selectedClassId,
      subject: selectedSubject,
      month: selectedMonth,
      title: taskTitle.trim(),
      description: taskDesc.trim(),
      dueDate: taskDueDate
    });

    // Reset fields
    setTaskTitle('');
    setTaskDesc('');
    setShowAddTask(false);
    showToast('Successfully added new task plan!', 'success');
  };

  const handleCreateSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim()) return;
    if (subjects.includes(newSubject.trim())) {
      showToast('Subject already exists', 'amber');
      return;
    }
    onAddSubject(newSubject.trim());
    setSelectedSubject(newSubject.trim());
    setNewSubject('');
    setShowAddSubject(false);
    showToast(`Added subject "${newSubject.trim()}" successfully!`, 'success');
  };

  // Get tasks filtered by the current selection
  const filteredTasks = tasks.filter(task => {
    const classMatch = filterClassId === 'all' || task.classId === filterClassId;
    const monthMatch = task.month === filterMonth;
    
    if (currentUser?.role === 'teacher' && showMyPlansOnly) {
      // Find matching class name
      const targetClass = classes.find(c => c.id === task.classId);
      if (!targetClass) return false;
      
      const isAllocated = isSubjectAssignedToTeacher(targetClass.name, task.subject, currentUser.name);
      
      // Also check if they are the classTeacher of that class
      const classAllotment = allotments.find(a => isClassMatchAllotment(targetClass.name, a.grade));
      const clean = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
      const uNameClean = clean(currentUser.name);
      const isClassTeacher = classAllotment && classAllotment.classTeacher 
        ? (clean(classAllotment.classTeacher).includes(uNameClean) || uNameClean.includes(clean(classAllotment.classTeacher))) 
        : false;
      
      return classMatch && monthMatch && (isAllocated || isClassTeacher);
    }
    
    return classMatch && monthMatch;
  });

  // Organize filtered tasks by subjects
  const tasksBySubject = subjects.reduce((acc, sub) => {
    acc[sub] = filteredTasks.filter(t => t.subject === sub);
    return acc;
  }, {} as Record<string, MonthlyTask[]>);

  // Auto-seed real monthly plans from OFFICIAL_SYLLABUS_BANK configuration
  const handleAutoSeedSyllabus = (targetClassId: string, month: string) => {
    if (!targetClassId) return;
    const targetClass = classes.find(c => c.id === targetClassId);
    if (!targetClass) return;

    setConfirmModal({
      title: "Confirm Auto-Seeding",
      description: `Do you want to auto-seed actual, official curriculum check checkmarks for ${targetClass.name} for ${month} from the SIS Syllabus Bank?`,
      confirmText: "Yes, Seed Tasks",
      onAction: () => {
        const gradeKey = getSyllabusGradeKey(targetClass.name);
        const allowed = getSubjectsForGrade(gradeKey);
        const curriculum = (syllabusBank[gradeKey] || [])
          .filter(sub => sub.topics && sub.topics.length > 0)
          .filter(sub => allowed.includes(sub.subject));

        if (curriculum && curriculum.length > 0) {
          let count = 0;
          curriculum.forEach((item, index) => {
            // Pre-seed 3 main academic subjects to avoid overloading, or seed all
            const belongsToOurSubjects = subjects.some(s => s.toLowerCase() === item.subject.toLowerCase());
            
            // Ensure we add the subject to registry if not already present, so it shows up in dashboard
            if (!belongsToOurSubjects) {
              onAddSubject(item.subject);
            }

            onAddTask({
              classId: targetClassId,
              subject: item.subject,
              month: month,
              title: item.topics[0] || `Review Check 1`,
              description: item.topics.slice(1).join(" | ") || `Submission & verification of notebook logs.`,
              dueDate: getOffsetDate(10 + index * 3)
            });
            count++;
          });
          showToast(`Successfully auto-populated ${count} real notebook checking tasks for ${targetClass.name} aligned with the ${gradeKey} official curriculum syllabus!`, 'success');
        } else {
          // Fallback to standard generic tasks if no curriculum found
          const sampleTasks = [
            {
              classId: targetClassId,
              subject: 'Math',
              month: month,
              title: 'Algebra Review and Notebook Submission',
              description: 'Check exercises formulation and homework worksheets.',
              dueDate: getOffsetDate(10)
            },
            {
              classId: targetClassId,
              subject: 'Science',
              month: month,
              title: 'Syllabus Chapter Diagrams Record',
              description: 'Check labeled diagrams and worksheet annotations.',
              dueDate: getOffsetDate(15)
            }
          ];
          sampleTasks.forEach(st => onAddTask(st));
          showToast(`Seeded default backup tasks for ${targetClass.name}!`, 'indigo');
        }
      }
    });
  };

  function getOffsetDate(days: number) {
    const baseDate = new Date();
    baseDate.setDate(baseDate.getDate() + days);
    return baseDate.toISOString().split('T')[0];
  }

  const handleClearSyllabus = () => {
    if (filterClassId === 'all') {
      const targetTasks = tasks.filter(t => t.month === filterMonth);
      if (targetTasks.length === 0) {
        showToast(`There are no school tasks assigned for the month of ${filterMonth}.`, 'indigo');
        return;
      }
      setConfirmModal({
        title: "Remove All Monthly Syllabus Tasks",
        description: `Are you sure you want to REMOVE ALL syllabus tasks (${targetTasks.length} plans) for ALL classes in the month of ${filterMonth}? This is irreversible and will reset progress charts.`,
        confirmText: "Yes, Clear All Tasks",
        isDangerous: true,
        onAction: () => {
          onClearSyllabusTasks && onClearSyllabusTasks('all', filterMonth);
          showToast(`Successfully removed all syllabus tasks for ${filterMonth}.`, 'rose');
        }
      });
    } else {
      const selectedClassName = classes.find(c => c.id === filterClassId)?.name || 'this class';
      const targetTasks = tasks.filter(t => t.classId === filterClassId && t.month === filterMonth);
      if (targetTasks.length === 0) {
        showToast(`There are no tasks assigned with ${selectedClassName} for the month of ${filterMonth}.`, 'indigo');
        return;
      }
      setConfirmModal({
        title: "Remove Syllabus Tasks",
        description: `Are you sure you want to REMOVE all ${targetTasks.length} syllabus tasks for ${selectedClassName} in ${filterMonth}?`,
        confirmText: "Yes, Remove Syllabus",
        isDangerous: true,
        onAction: () => {
          onClearSyllabusTasks && onClearSyllabusTasks(filterClassId, filterMonth);
          showToast(`Successfully removed ${selectedClassName} syllabus/tasks for ${filterMonth}.`, 'rose');
        }
      });
    }
  };

  return (
    <div id="monthly_planner" className="space-y-6">
      
      {/* Read-Only Reference Console indicator banner for Faculty/Teacher login */}
      {currentUser?.role === 'teacher' && (
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950/20 border border-indigo-500/10 rounded-2xl p-4.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-indigo-500/10 text-indigo-300 rounded-xl shrink-0 mt-0.5 sm:mt-0">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5 matches-title">
                Read-Only Reference Console
              </h4>
              <p className="text-slate-355 text-[11px] mt-0.5 font-medium leading-relaxed">
                You are logged in as a faculty member (<span className="text-indigo-300 font-bold">{currentUser.name}</span>). This planner serves as your syllabus guideline reference. Task creation and configuration edits are managed by the school administration.
              </p>
            </div>
          </div>
          <div className="text-[10px] bg-slate-800/60 text-slate-300 px-3 py-1.5 rounded-xl border border-white/5 self-start sm:self-auto font-bold uppercase tracking-wider">
            Reference Mode
          </div>
        </div>
      )}

      {/* Search Filter Head and Control Room */}
      <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 self-stretch md:self-auto">
          <div className="p-2.5 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-white text-sm">Monthly Syllabus Filters</h3>
            <p className="text-slate-350 text-xs">Isolate monthly notebook tasks by grade and semester month</p>
            {currentUser?.role === 'teacher' && (
              <div className="mt-2.5 flex items-center">
                <span className="text-[10px] font-black tracking-wider text-indigo-400 uppercase select-none bg-indigo-505/10 px-2 py-0.5 rounded border border-indigo-500/20">
                  Reflecting Allotted Classes & Subjects of Ms/Mr {currentUser.name}
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Class Filter */}
          <div className="flex-1 min-w-[140px] md:flex-initial">
            <select
              value={filterClassId}
              onChange={(e) => setFilterClassId(e.target.value)}
              className="w-full text-xs p-2 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-slate-100"
            >
              <option value="all" className="bg-slate-950 text-white">
                {currentUser?.role === 'teacher' ? 'All My Classes' : 'All Classes'}
              </option>
              {allowedClasses.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-950 text-white">{c.name}</option>
              ))}
            </select>
          </div>

          {/* Month Filter */}
          <div className="flex-1 min-w-[140px] md:flex-initial">
            <select
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="w-full text-xs p-2 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-slate-100"
            >
              {months.map(m => (
                <option key={m} value={m} className="bg-slate-950 text-white">{m}</option>
              ))}
            </select>
          </div>

          {/* Seed syllabus button */}
          {currentUser?.role === 'admin' && filterClassId !== 'all' && (
            <button
              onClick={() => handleAutoSeedSyllabus(filterClassId, filterMonth)}
              type="button"
              className="px-3 py-2 bg-white/5 hover:bg-emerald-500/10 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-white/10 cursor-pointer shadow-sm"
              title="Auto-Populate Plan"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Auto-Seed Tasks</span>
            </button>
          )}

          {/* Browse Syllabus Button */}
          <button
            onClick={() => setSyllabusViewerOpen(!syllabusViewerOpen)}
            type="button"
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all inline-flex items-center gap-1.5 cursor-pointer ${
              syllabusViewerOpen 
                ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' 
                : 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>Syllabus Bank</span>
          </button>

          {/* Remove Monthly Syllabus Button */}
          {currentUser?.role === 'admin' && (
            <button
              onClick={handleClearSyllabus}
              type="button"
              className="px-3.5 py-2 bg-red-950/40 border border-red-500/20 hover:border-red-500/50 hover:bg-red-500/10 text-red-300 hover:text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Remove all syllabus tasks for the currently selected filter options"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>{filterClassId === 'all' ? `Clear All ${filterMonth}` : 'Remove Syllabus'}</span>
            </button>
          )}

          {/* Blue Create Task Button */}
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setShowAddTask(true)}
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-500/10 transition-all inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Task Plan
            </button>
          )}
        </div>
      </div>

      {/* DETAILED INTERACTIVE SYLLABUS DIRECTORY BANK */}
      {syllabusViewerOpen && (() => {
        const gradeList = Object.keys(syllabusBank);
        const allowed = getSubjectsForGrade(activeSyllabusGrade);
        const selectedCurriculum = (syllabusBank[activeSyllabusGrade] || [])
          .filter(sub => sub.topics && sub.topics.length > 0)
          .filter(sub => allowed.includes(sub.subject));

        return (
          <div className="bg-slate-950/80 border border-emerald-500/20 backdrop-blur-xl rounded-2xl p-5 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-sm">Official Samata International Curriculum Registry</h4>
                  <p className="text-slate-400 text-[11px]">Direct syllabus reference compiled for June Academic Session</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5 flex-wrap">
                {/* Restore Default button */}
                {currentUser?.role === 'admin' && (
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmModal({
                        title: "Restore Default Syllabus Bank",
                        description: "Are you sure you want to restore the entire official syllabus bank database? This will overwrite your customized syllabus data.",
                        confirmText: "Yes, Restore Defaults",
                        onAction: () => {
                          if (onUpdateSyllabusBank) {
                            onUpdateSyllabusBank(OFFICIAL_SYLLABUS_BANK);
                            showToast("Syllabus bank restored to factory defaults!", "success");
                          }
                        }
                      });
                    }}
                    className="text-slate-300 hover:text-white text-xs font-bold bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 px-2.5 py-1.5 rounded-lg cursor-pointer transition-all"
                  >
                    Restore Defaults
                  </button>
                )}

                {/* Delete/Wipe entire database button */}
                {currentUser?.role === 'admin' && (
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmModal({
                        title: "Wipe Entire Syllabus Bank",
                        description: "Are you sure you want to delete ALL data from the Syllabus Bank? This resolves all grade references to empty and cannot be undone (unless you restore defaults later).",
                        confirmText: "Yes, Delete All Data",
                        isDangerous: true,
                        onAction: () => {
                          if (onUpdateSyllabusBank) {
                            onUpdateSyllabusBank({});
                            showToast("Successfully cleared all syllabus bank data!", "rose");
                          }
                        }
                      });
                    }}
                    className="text-red-300 hover:text-white text-xs font-bold bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 px-2.5 py-1.5 rounded-lg cursor-pointer transition-all"
                  >
                    Wipe Syllabus Bank
                  </button>
                )}

                <button 
                  onClick={() => setSyllabusViewerOpen(false)}
                  className="text-slate-400 hover:text-white text-xs font-bold bg-white/5 hover:bg-white/10 px-2.5 py-1.5 rounded-lg cursor-pointer transition-all"
                >
                  Hide Registry
                </button>
              </div>
            </div>

            {/* Selector list for Grades with Delete Grade Button */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/10">
              {gradeList.map(grade => (
                <div key={grade} className="flex items-center gap-1 bg-white/5 pr-1.5 rounded-lg shrink-0">
                  <button
                    type="button"
                    onClick={() => setActiveSyllabusGrade(grade)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
                      activeSyllabusGrade === grade 
                        ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/10' 
                        : 'text-slate-300 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {grade}
                  </button>
                  {currentUser?.role === 'admin' && (
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmModal({
                          title: `Delete Grade Data: ${grade}`,
                          description: `Are you sure you want to delete all syllabus data for "${grade}" from the registry?`,
                          confirmText: "Delete Grade",
                          isDangerous: true,
                          onAction: () => {
                            const copy = {...syllabusBank};
                            delete copy[grade];
                            if (onUpdateSyllabusBank) {
                              onUpdateSyllabusBank(copy);
                              // Set active grade to another one
                              const keys = Object.keys(copy);
                              if (keys.length > 0) {
                                setActiveSyllabusGrade(keys[0]);
                              }
                              showToast(`Deleted all registry references for ${grade}`, 'rose');
                            }
                          }
                        });
                      }}
                      className="p-1 hover:bg-red-500/20 text-slate-400 hover:text-red-400 rounded cursor-pointer leading-none text-xs"
                      title="Delete this entire Grade's syllabus"
                    >
                      ✕
                    </button>
                  )}
                </div>
              ))}
              {gradeList.length === 0 && (
                <div className="text-xs text-slate-500 py-1.5 font-semibold">
                  Syllabus Bank is entirely empty. Click "Restore Defaults" above to reload curriculum plans!
                </div>
              )}
            </div>

            {/* Display of Subject Cards in beautiful Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 pt-1">
              {selectedCurriculum.map((sub, idx) => (
                <div key={idx} className="bg-white/5 border border-white/5 rounded-xl p-3.5 space-y-2 relative">
                  <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
                    <span className="font-extrabold text-indigo-300 text-xs">{sub.subject}</span>
                    {currentUser?.role === 'admin' && (
                      <button
                        type="button"
                        onClick={() => {
                          setConfirmModal({
                            title: `Delete Subject Syllabus: ${sub.subject}`,
                            description: `Are you sure you want to delete "${sub.subject}" from "${activeSyllabusGrade}" syllabus database?`,
                            confirmText: "Delete Subject",
                            isDangerous: true,
                            onAction: () => {
                              const copy = {...syllabusBank};
                              if (copy[activeSyllabusGrade]) {
                                copy[activeSyllabusGrade] = copy[activeSyllabusGrade].filter(s => s.subject !== sub.subject);
                                if (onUpdateSyllabusBank) {
                                  onUpdateSyllabusBank(copy);
                                  showToast(`Deleted subject "${sub.subject}" from ${activeSyllabusGrade}`, 'rose');
                                }
                              }
                            }
                          });
                        }}
                        className="text-slate-500 hover:text-red-400 p-1 rounded hover:bg-red-500/10 cursor-pointer transition-colors"
                        title="Delete Subject"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <ul className="space-y-1">
                    {sub.topics.map((t, tIdx) => (
                      <li key={tIdx} className="text-[11px] text-slate-300 flex items-start justify-between gap-1">
                        <div className="flex items-start gap-1">
                          <span className="text-emerald-400 text-xs leading-none mt-0.5">•</span>
                          <span className="leading-normal font-medium">{t}</span>
                        </div>
                        {currentUser?.role === 'admin' && (
                          <button
                            type="button"
                            onClick={() => {
                              const copy = {...syllabusBank};
                              if (copy[activeSyllabusGrade]) {
                                copy[activeSyllabusGrade] = copy[activeSyllabusGrade].map(s => {
                                    if (s.subject === sub.subject) {
                                      return {
                                        ...s,
                                        topics: s.topics.filter(tp => tp !== t)
                                      };
                                    }
                                    return s;
                                  });
                                if (onUpdateSyllabusBank) {
                                  onUpdateSyllabusBank(copy);
                                  showToast(`Deleted topic from "${sub.subject}"`, 'rose');
                                }
                              }
                            }}
                            className="text-[10px] text-slate-500 hover:text-red-400 px-1 hover:bg-red-500/10 rounded cursor-pointer leading-none"
                            title="Delete this topic"
                          >
                            ✕
                          </button>
                        )}
                      </li>
                    ))}
                    {sub.topics.length === 0 && (
                      <li className="text-[10px] text-slate-500 italic">No topics registered.</li>
                    )}
                  </ul>
                </div>
              ))}
            </div>
            
            <div className="bg-white/5 rounded-xl p-3 text-[10px] text-slate-400 flex flex-col sm:flex-row sm:items-center sm:justify-between border border-white/5 gap-2">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Use the <strong>"Add Task Plan"</strong> form directly and choose this grade to dynamically click-to-fill these lessons into interactive student ledger sheets!</span>
              </span>
              {currentUser?.role === 'admin' && (
                <button 
                  type="button"
                  onClick={() => {
                    const subjectName = prompt("Enter new subject name for " + activeSyllabusGrade);
                    if (!subjectName) return;
                    const topicsInput = prompt("Enter topics (comma separated) for " + subjectName);
                    if (!topicsInput) return;
                    const topicsList = topicsInput.split(",").map(x => x.trim()).filter(Boolean);
                    
                    const copy = {...syllabusBank};
                    if (!copy[activeSyllabusGrade]) {
                      copy[activeSyllabusGrade] = [];
                    }
                    copy[activeSyllabusGrade].push({
                      subject: subjectName,
                      topics: topicsList
                    });
                    if (onUpdateSyllabusBank) {
                      onUpdateSyllabusBank(copy);
                      showToast(`Successfully added "${subjectName}" syllabus card to ${activeSyllabusGrade}!`, 'success');
                    }
                  }}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold cursor-pointer transition-colors shrink-0"
                >
                  + Add Custom Subject/Topics
                </button>
              )}
            </div>
          </div>
        );
      })()}

      {/* Task Creation Modal/Form Dropdown */}
      {showAddTask && (
        <div className="bg-white/5 border border-indigo-500/20 backdrop-blur-xl p-6 rounded-2xl shadow-2xl animate-fade-in space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <h4 className="font-extrabold text-white text-sm flex items-center gap-2">
              <Calendar className="w-4.5 h-4.5 text-indigo-400" />
              <span>Configure Notebook/Worksheet Submission Task</span>
            </h4>
            <button 
              onClick={() => setShowAddTask(false)} 
              className="text-xs text-slate-400 hover:text-white font-bold cursor-pointer"
            >
              Close
            </button>
          </div>

          <form onSubmit={handleCreateTask} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">Target Class</label>
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-bold"
                required
              >
                <option value="" className="bg-slate-950 text-white">-- Choose Class --</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id} className="bg-slate-950 text-white">{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-bold uppercase text-slate-400">Subject</label>
                <button
                  type="button"
                  onClick={() => setShowAddSubject(!showAddSubject)}
                  className="text-[9px] text-indigo-400 hover:text-indigo-300 hover:underline font-bold"
                >
                  {showAddSubject ? 'Cancel' : '+ Add New Subject'}
                </button>
              </div>

              {showAddSubject ? (
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="Subject Name"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="flex-1 text-xs p-2.5 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-white placeholder-slate-500"
                  />
                  <button
                    onClick={handleCreateSubject}
                    type="button"
                    className="p-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Add
                  </button>
                </div>
              ) : (
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-bold"
                  required
                >
                  <option value="" className="bg-slate-950 text-white">-- Choose Subject --</option>
                  {(() => {
                    const targetClass = classes.find(c => c.id === selectedClassId);
                    const gradeName = targetClass ? targetClass.name : 'Grade V';
                    const allowedSubs = getSubjectsForGrade(gradeName);
                    return subjects.filter(sub => allowedSubs.includes(sub));
                  })().map(sub => (
                    <option key={sub} value={sub} className="bg-slate-950 text-white">
                      {sub === "SS" ? "S.S (Social Science)" : sub === "Computer" ? "Computer (IT)" : sub}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">Month Semester</label>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-bold"
                required
              >
                {months.map(m => (
                  <option key={m} value={m} className="bg-slate-950 text-white">{m}</option>
                ))}
              </select>
            </div>

            {/* Dynamic Allotted Teacher Information Badge */}
            {(() => {
              const currentClassObj = classes.find(c => c.id === selectedClassId);
              if (!currentClassObj || !selectedSubject) return null;
              const teacherName = getAllocatedTeacher(selectedClassId, selectedSubject);
              return (
                <div className="md:col-span-3 bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-950/40 border border-indigo-500/20 rounded-xl p-3 flex items-center gap-3">
                  <div className="p-1.5 bg-indigo-500/10 text-indigo-300 rounded-lg">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <div className="text-xs">
                    <span className="text-slate-400 font-medium">Allotted Subject Teacher: </span>
                    <strong className="text-white bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-md ml-1">{teacherName}</strong>
                  </div>
                </div>
              );
            })()}

            {/* DIRECT SYLLABUS TOPIC DROP-DOWN SELECTOR */}
            {(() => {
              const currentClassObj = classes.find(c => c.id === selectedClassId);
              if (!currentClassObj || !selectedSubject) return null;
              const matchedGradeKey = getSyllabusGradeKey(currentClassObj.name);
              const gradeSyllabus = syllabusBank[matchedGradeKey] || [];
              const syncItem = gradeSyllabus.find(
                s => s.subject.toLowerCase() === selectedSubject.toLowerCase() ||
                     (selectedSubject.toLowerCase() === 'math' && s.subject.toLowerCase() === 'math') ||
                     (selectedSubject.toLowerCase() === 'science' && s.subject.toLowerCase() === 'science') ||
                     s.subject.toLowerCase().includes(selectedSubject.toLowerCase()) ||
                     selectedSubject.toLowerCase().includes(s.subject.toLowerCase())
              );
              const syllabusTopicsList = syncItem ? syncItem.topics : [];

              return (
                <div className="md:col-span-3 space-y-1 bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-3.5">
                  <label className="block text-[11px] font-bold uppercase text-emerald-400 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Select Topic Directly from Official Syllabus Bank ({matchedGradeKey})</span>
                  </label>
                  <select
                    className="w-full text-xs p-2.5 bg-slate-950 border border-emerald-500/20 text-white rounded-xl focus:outline-none focus:border-emerald-500 font-bold"
                    onChange={(e) => {
                      const sel = e.target.value;
                      if (sel) {
                        setTaskTitle(sel);
                        setTaskDesc(`Official Syllabus Notebook check: "${sel}". Teachers will evaluate detailed answers, neatness of rough-work, annotations, checklist indices, and give constructive feedback.`);
                      }
                    }}
                    required
                  >
                    <option value="" className="text-slate-400">-- Choose Topic directly from Syllabus Bank --</option>
                    {syllabusTopicsList.map((t, idx) => (
                      <option key={idx} value={t} className="bg-slate-950 text-white">
                        {t}
                      </option>
                    ))}
                    {syllabusTopicsList.length === 0 && (
                      <option disabled className="text-slate-500">No official curriculum topics registered for this subject.</option>
                    )}
                  </select>
                </div>
              );
            })()}

            <div className="md:col-span-2">
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">Task Title</label>
              <input
                type="text"
                placeholder="e.g., Integer Operations Submission (Ex 1.1 - 1.4)"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-950 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-bold placeholder-slate-500"
                required
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">Checking Due Date</label>
              <input
                type="date"
                value={taskDueDate}
                onChange={(e) => setTaskDueDate(e.target.value)}
                className="w-full text-xs p-2 bg-slate-950 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-bold placeholder-slate-500"
                required
              />
            </div>

            <div className="md:col-span-3">
              <label className="block text-[11px] font-bold uppercase text-slate-400 mb-1">Task Guidelines & Notes (Shown to Parents/Students)</label>
              <textarea
                rows={2}
                placeholder="List completed exercise chapters, page numbers, and presentation guidelines teachers want checked..."
                value={taskDesc}
                onChange={(e) => setTaskDesc(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-950 border border-white/10 text-white rounded-xl focus:outline-none focus:border-indigo-500 font-medium placeholder-slate-500"
              />
            </div>

            {/* CURRICULUM SYLLABUS RECOMMENDATION ENGINE */}
            {(() => {
              const currentClassObj = classes.find(c => c.id === selectedClassId);
              const matchedGradeKey = currentClassObj ? getSyllabusGradeKey(currentClassObj.name) : '';
              const gradeSyllabus = matchedGradeKey ? syllabusBank[matchedGradeKey] : null;

              const matchingSyllabusItem = gradeSyllabus?.find(
                item => item.subject.toLowerCase() === selectedSubject.toLowerCase() ||
                        (selectedSubject.toLowerCase() === 'math' && item.subject.toLowerCase() === 'math') ||
                        (selectedSubject.toLowerCase() === 'science' && item.subject.toLowerCase() === 'science') ||
                        (selectedSubject.toLowerCase() === 'ss' && item.subject.toLowerCase() === 's.s.') ||
                        (selectedSubject.toLowerCase() === 'computer' && item.subject.toLowerCase() === 'computer') ||
                        (selectedSubject.toLowerCase() === 'it' && item.subject.toLowerCase() === 'it') ||
                        item.subject.toLowerCase().includes(selectedSubject.toLowerCase()) ||
                        selectedSubject.toLowerCase().includes(item.subject.toLowerCase())
              );

              if (!matchingSyllabusItem) return null;

              return (
                <div className="md:col-span-3 bg-slate-950/60 border border-emerald-500/20 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>SIS Syllabus Guidelines recommendation for {matchedGradeKey} • {matchingSyllabusItem.subject}</span>
                    </span>
                    <span className="text-[9px] text-slate-400">Select a lesson unit to auto-fill checking form</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {matchingSyllabusItem.topics.map((topic, tIdx) => (
                      <button
                        key={tIdx}
                        type="button"
                        onClick={() => {
                          setTaskTitle(topic.split(":")[1]?.trim() || topic.split("-")[1]?.trim() || topic);
                          setTaskDesc(`Notebook verification of the official textbook unit: ${topic}. Verify student answers, text activities, spelling corrections and teacher's remarks.`);
                        }}
                        className="text-[10px] font-semibold text-slate-100 bg-white/5 border border-white/10 hover:border-emerald-500/30 hover:bg-emerald-500/10 hover:text-white px-2.5 py-1.5 rounded-lg text-left transition-all cursor-pointer leading-tight max-w-full"
                      >
                        {topic}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })()}

            {selectedClassId && selectedSubject && (
              <div className="md:col-span-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-3 flex items-center gap-2 text-xs text-indigo-300">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                <span>
                  Designated Subject Teacher: <strong className="text-white font-extrabold">{getAllocatedTeacher(selectedClassId, selectedSubject)}</strong> will be assigned to review this ledger.
                </span>
              </div>
            )}

            <div className="md:col-span-3 flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowAddTask(false)}
                className="px-4 py-2 text-slate-300 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold transition-all cursor-pointer border border-white/5"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-indigo-500/20"
              >
                Add to Syllabus Plan
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Grid: Render Syllabus grouped by Subject block */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {(() => {
          if (filterClassId !== 'all') {
            const targetClass = classes.find(c => c.id === filterClassId);
            if (targetClass) {
              const allowedSubs = getSubjectsForGrade(targetClass.name);
              let baseSubs = subjects.filter(sub => allowedSubs.includes(sub));
              if (currentUser?.role === 'teacher') {
                baseSubs = baseSubs.filter(sub => isSubjectAssignedToTeacher(targetClass.name, sub, currentUser.name));
              }
              return baseSubs;
            }
          }
          if (currentUser?.role === 'teacher') {
            return subjects.filter(sub => {
              return allowedClasses.some(c => isSubjectAssignedToTeacher(c.name, sub, currentUser.name));
            });
          }
          return subjects;
        })().map(subject => {
          const subjectTasks = tasksBySubject[subject] || [];
          if (subjectTasks.length === 0 && filterClassId === 'all') {
            // Skip empty subject rows when showing everything, to keep it clean, unless there are direct filters
            return null;
          }

          return (
            <div key={subject} className="bg-white/5 border border-white/10 rounded-2xl p-5 backdrop-blur-md shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-indigo-500/10 text-indigo-300 rounded-lg border border-indigo-500/15">
                      <BookOpen className="w-4.5 h-4.5" />
                    </span>
                    <h4 className="font-extrabold text-white text-sm tracking-tight">
                      {subject === "SS" ? "S.S (Social Science)" : subject === "Computer" ? "Computer (IT)" : subject}
                    </h4>
                  </div>
                  <span className="text-[10px] uppercase font-bold bg-white/10 text-indigo-350 px-2 py-0.5 rounded-full border border-white/5">
                    {subjectTasks.length} plan{subjectTasks.length !== 1 ? 's' : ''}
                  </span>
                </div>

                {/* Subtask components in that subject card */}
                <div className="space-y-3.5">
                  {subjectTasks.map(task => {
                    const targetClass = classes.find(c => c.id === task.classId);
                    return (
                      <div 
                        key={task.id} 
                        className="p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 transition-all text-xs relative group flex flex-col justify-between gap-2.5"
                      >
                        <div>
                          <div className="flex justify-between items-start gap-1">
                            <span className="font-bold text-slate-100 text-xs group-hover:text-white leading-tight">
                              {task.title}
                            </span>
                            {currentUser?.role === 'admin' && (
                              <button
                                onClick={() => {
                                  setConfirmModal({
                                    title: "Delete Syllabus Plan",
                                    description: `Are you sure you want to delete syllabus task "${task.title}"? This resolves all student checking logs for this plan.`,
                                    confirmText: "Yes, Delete",
                                    isDangerous: true,
                                    onAction: () => {
                                      onDeleteTask(task.id);
                                      showToast(`Successfully deleted plan: "${task.title}"`, 'rose');
                                    }
                                  });
                                }}
                                className="text-slate-400 hover:text-rose-400 p-0.5 rounded-md hover:bg-rose-500/10 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity shrink-0 cursor-pointer"
                                title="Delete Plan"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>

                          <p className="text-slate-400 text-[11px] mt-1 leading-relaxed font-medium">
                            {task.description || 'No additional guidelines written.'}
                          </p>

                          {/* Display Allocated Subject Teacher */}
                          {targetClass && (
                            <div className="mt-2 flex items-center gap-1 text-[10px] text-slate-300 bg-white/5 border border-white/5 px-2 py-0.5 rounded-lg w-fit">
                              <Award className="w-3 h-3 text-indigo-400 shrink-0" />
                              <span>Teacher: <strong className="text-white font-bold">{getAllocatedTeacher(targetClass.id, task.subject)}</strong></span>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-center text-[10px] text-slate-450 mt-1 border-t border-white/10 pt-2 shrink-0 font-semibold">
                          <span className="flex items-center gap-1 font-bold text-indigo-300 bg-indigo-500/10 px-1.5 py-0.5 rounded-md border border-indigo-500/20">
                            <Target className="w-3 h-3" />
                            {targetClass ? targetClass.name : 'Unknown Class'}
                          </span>
                          
                          <span className="flex items-center gap-1 font-semibold text-slate-400">
                            <Clock className="w-3 h-3 text-amber-400" />
                            Due: <strong className="text-slate-300 font-bold">{new Date(task.dueDate).toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric'})}</strong>
                          </span>
                        </div>
                      </div>
                    );
                  })}

                  {subjectTasks.length === 0 && (
                    <div className="py-8 text-center text-slate-400 border border-dashed border-white/10 rounded-xl bg-white/5">
                      <FileText className="w-7 h-7 mx-auto text-slate-500 mb-1" />
                      <p className="text-[11px] font-bold">No tasks proposed</p>
                      <p className="text-[9px] text-slate-500 mt-0.5">Nothing defined for {filterMonth}.</p>
                    </div>
                  )}
                </div>
              </div>

              {subjectTasks.length > 0 && (
                <div className="mt-4 pt-3 border-t border-white/10 text-right">
                  <span className="text-[9px] text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer">
                    Click records tab above to check these student notebooks
                  </span>
                </div>
              )}
            </div>
          );
        })}

        {subjects.length === 0 && (
          <div className="col-span-2 text-center py-16 bg-white/5 border border-white/10 rounded-2xl shadow-xl">
            <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-2" />
            <p className="text-white text-base font-bold">No Subjects Registered</p>
            <p className="text-slate-400 text-xs mt-1">Add subjects first in the adding workflow to start planning tasks.</p>
          </div>
        )}
      </div>

      {/* Toast Alert Banner */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-sm p-4 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl flex items-center gap-3 animate-fade-in">
          {toast.type === 'success' && (
            <div className="p-1 px-1.5 bg-emerald-500/10 text-emerald-300 rounded-lg text-xs font-bold leading-none shrink-0 border border-emerald-500/20">
              OK
            </div>
          )}
          {toast.type === 'rose' && (
            <div className="p-1 px-1.5 bg-rose-500/10 text-rose-300 rounded-lg text-xs font-bold leading-none shrink-0 border border-rose-500/20">
              DEL
            </div>
          )}
          {toast.type === 'amber' && (
            <div className="p-1 px-1.5 bg-amber-500/10 text-amber-300 rounded-lg text-xs font-bold leading-none shrink-0 border border-amber-500/20">
              WARN
            </div>
          )}
          {toast.type === 'indigo' && (
            <div className="p-1 px-1.5 bg-indigo-500/10 text-indigo-300 rounded-lg text-xs font-bold leading-none shrink-0 border border-indigo-500/20">
              INFO
            </div>
          )}
          <span className="text-xs font-bold text-white leading-snug">{toast.text}</span>
          <button onClick={() => setToast(null)} className="ml-auto text-slate-500 hover:text-white font-black text-xs cursor-pointer">✕</button>
        </div>
      )}

      {/* Confirmation Modal Overlays */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-white/10 max-w-md w-full rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-start gap-3">
              <span className={`p-2 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20 shrink-0 ${confirmModal.isDangerous ? 'bg-red-500/10 text-red-300 border-red-500/20' : ''}`}>
                <AlertCircle className="w-5 h-5" />
              </span>
              <div>
                <h4 className="text-white font-extrabold text-sm">{confirmModal.title}</h4>
                <p className="text-slate-300 text-xs mt-1.5 leading-relaxed font-semibold">{confirmModal.description}</p>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-white/5">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-extrabold rounded-lg text-xs cursor-pointer transition-colors"
              >
                {confirmModal.cancelText || "Cancel"}
              </button>
              <button
                onClick={() => {
                  confirmModal.onAction();
                  setConfirmModal(null);
                }}
                className={`px-4.5 py-2 text-white font-black rounded-lg text-xs cursor-pointer transition-all shadow-md ${confirmModal.isDangerous ? 'bg-red-600 hover:bg-red-500 shadow-red-600/10' : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/10'}`}
              >
                {confirmModal.confirmText}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
