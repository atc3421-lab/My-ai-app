import React, { useState } from 'react';
import { SchoolClass, MonthlyTask, CheckingRecord, NotebookStatus, AcademicTest, StudentTestMark } from '../types';
import { 
  Search, 
  UserSquare, 
  GraduationCap, 
  BookOpen, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  HelpCircle,
  FileText,
  Printer,
  ChevronRight,
  TrendingUp,
  HeartHandshake,
  Award
} from 'lucide-react';

interface ParentStudentLookupProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  tests?: AcademicTest[];
  testMarks?: StudentTestMark[];
}

export default function ParentStudentLookup({
  classes,
  tasks,
  records,
  tests = [],
  testMarks = []
}: ParentStudentLookupProps) {
  
  // Selection States
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');

  const activeClass = classes.find(c => c.id === selectedClassId);
  
  // Filter students matching query
  const filteredStudents = activeClass
    ? activeClass.students.filter(student => 
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        student.rollNumber.includes(searchQuery)
      )
    : [];

  const activeStudent = activeClass?.students.find(s => s.id === selectedStudentId);

  // Calculate stats for the selected student
  const studentTasks = activeClass ? tasks.filter(t => t.classId === activeClass.id) : [];
  
  const studentRecordsWithTasks = studentTasks.map(task => {
    const record = records.find(r => r.studentId === selectedStudentId && r.taskId === task.id);
    return {
      task,
      record: record || { status: 'unchecked' as NotebookStatus, notes: '', lastUpdatedAt: '' }
    };
  });

  const studentTests = activeClass ? tests.filter(t => t.classId === activeClass.id) : [];
  const testScoresWithTests = studentTests.map(test => {
    const match = testMarks.find(m => m.testId === test.id && m.studentId === selectedStudentId);
    return {
      test,
      score: match ? match.marksObtained : '',
      isAbsent: match ? match.isAbsent : false,
      remarks: match ? match.remarks : ''
    };
  });

  const checkedCount = studentRecordsWithTasks.filter(item => item.record.status === 'checked').length;
  const incompleteCount = studentRecordsWithTasks.filter(item => item.record.status === 'incomplete').length;
  const missingCount = studentRecordsWithTasks.filter(item => item.record.status === 'missing').length;
  const uncheckedCount = studentRecordsWithTasks.length - (checkedCount + incompleteCount + missingCount);
  const completionRate = studentRecordsWithTasks.length > 0 ? Math.round((checkedCount / studentRecordsWithTasks.length) * 100) : 0;

  const getStatusBadge = (status: NotebookStatus) => {
    switch (status) {
      case 'checked':
        return (
          <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[10px] font-bold rounded-lg flex items-center gap-1.5 backdrop-blur-sm">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Checked & Verified
          </span>
        );
      case 'incomplete':
        return (
          <span className="px-2.5 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/20 text-[10px] font-bold rounded-lg flex items-center gap-1.5 backdrop-blur-sm">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" /> Incomplete / Redo Required
          </span>
        );
      case 'missing':
        return (
          <span className="px-2.5 py-1 bg-rose-500/10 text-rose-300 border border-rose-500/20 text-[10px] font-bold rounded-lg flex items-center gap-1.5 backdrop-blur-sm">
            <XCircle className="w-3.5 h-3.5 text-rose-400" /> Missing / Did Not Submit
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 bg-white/5 text-slate-400 border border-white/10 text-[10px] font-bold rounded-lg flex items-center gap-1.5 backdrop-blur-sm">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" /> Not Checked Yet
          </span>
        );
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="parent_student_lookup_view" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Left Column: Student lookup filters */}
      <div className="lg:col-span-4 space-y-4 print:hidden">
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl space-y-4">
          <div className="flex items-center gap-2">
            <UserSquare className="w-5 h-5 text-indigo-400" />
            <h3 className="font-extrabold text-white text-sm">Parent Query Portal</h3>
          </div>
          <p className="text-slate-350 text-xs leading-relaxed">
            Parents and students can track real-time notebook submission status here by selecting class and searching student roster name.
          </p>

          <div className="space-y-3">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Select class</label>
              <select
                value={selectedClassId}
                onChange={(e) => {
                  setSelectedClassId(e.target.value);
                  setSelectedStudentId(''); // reset student
                }}
                className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-white"
              >
                {classes.map(c => (
                  <option key={c.id} value={c.id} className="bg-slate-950 text-white">{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Type student name or Roll</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g. Watson..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-white placeholder-slate-500 pl-8"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-3 space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
            {filteredStudents.map(student => (
              <div
                key={student.id}
                onClick={() => setSelectedStudentId(student.id)}
                className={`p-2.5 rounded-xl cursor-pointer border text-xs transition-all flex items-center justify-between ${
                  selectedStudentId === student.id
                    ? 'bg-indigo-600 border-indigo-500 text-white font-bold'
                    : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${selectedStudentId === student.id ? 'bg-white/20 text-white' : 'bg-white/10 text-slate-300'}`}>
                    Roll {student.rollNumber}
                  </span>
                  <span>{student.name}</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-60" />
              </div>
            ))}

            {filteredStudents.length === 0 && (
              <p className="text-slate-500 text-xs text-center py-4">No student matched search.</p>
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Student detailed Report Card */}
      <div className="lg:col-span-8">
        {activeStudent ? (
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10 shadow-2xl space-y-6 print:border-0 print:shadow-none">
            
            {/* Report Header card info */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-500/10 text-indigo-300 rounded-2xl border border-indigo-500/20">
                  <GraduationCap className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-indigo-400">Student Notebook Performance Portfolio</span>
                  <h3 className="font-extrabold text-white text-xl mt-0.5">{activeStudent.name}</h3>
                  <p className="text-xs text-slate-400 mt-0.5 font-medium">
                    Class: <span className="text-white font-bold">{activeClass?.name}</span> • Roll No: <span className="text-white font-bold">{activeStudent.rollNumber}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 print:hidden">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-2 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white text-xs font-bold rounded-xl transition-all inline-flex justify-center items-center gap-1.5 border border-white/10 cursor-pointer shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5 text-indigo-400" /> Print Report Card
                </button>
              </div>
            </div>

            {/* Overall visual statistics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              
              <div className="p-4 bg-white/5 border border-white/10 rounded-2xl text-center backdrop-blur-md">
                <span className="block text-[10px] uppercase font-bold text-slate-400">Completion Index</span>
                <span className="block text-3xl font-black text-white mt-1">{completionRate}%</span>
                <span className="block text-[9px] text-slate-500 mt-0.5 font-bold">Weighted submissions</span>
              </div>

              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-center backdrop-blur-md">
                <span className="block text-[10px] uppercase font-bold text-emerald-400">Total Checked</span>
                <span className="block text-3xl font-black text-emerald-300 mt-1">{checkedCount}</span>
                <span className="block text-[9px] text-emerald-400/80 mt-0.5 font-bold">Verified & signed</span>
              </div>

              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-center backdrop-blur-md">
                <span className="block text-[10px] uppercase text-amber-400 font-bold">Needs Correction</span>
                <span className="block text-3xl font-black text-amber-300 mt-1">{incompleteCount}</span>
                <span className="block text-[9px] text-amber-500/80 mt-0.5 font-bold">Recheck requested</span>
              </div>

              <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-center backdrop-blur-md">
                <span className="block text-[10px] uppercase font-bold text-rose-400">Outstanding Book</span>
                <span className="block text-3xl font-black text-rose-300 mt-1">{missingCount}</span>
                <span className="block text-[9px] text-rose-550 mt-0.5 font-bold">No submission</span>
              </div>

            </div>

            {/* Progress and status message bar */}
            <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl flex items-start gap-3">
              <div className="p-1 bg-indigo-600 text-white rounded-lg mt-0.5 shadow-md">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="text-xs font-semibold">
                <p className="font-bold text-white">Real-time Checking Progress Insights</p>
                <p className="text-slate-300 mt-0.5 leading-relaxed">
                  {completionRate === 100 
                    ? `Brilliant! ${activeStudent.name} has submitted all journals on time, fully verified by the respective teachers, scoring a flawless 100% submission rating.`
                    : `${activeStudent.name} has registered ${checkedCount} checked and verified notebooks out of ${studentRecordsWithTasks.length} total monthly tasks. Please support them in resolving the remaining ${incompleteCount + missingCount} pending assignments.`
                  }
                </p>
              </div>
            </div>

            {/* Checklist items list */}
            <div className="space-y-4">
              <h4 className="font-extrabold text-white text-sm flex items-center gap-2">
                <BookOpen className="w-4.5 h-4.5 text-indigo-400" />
                <span>Assigned Monthly Notebook checking tasks</span>
              </h4>

              <div className="divide-y divide-white/5 border border-white/10 rounded-xl overflow-hidden shadow-2xl bg-white/5">
                {studentRecordsWithTasks.map(({ task, record }, idx) => (
                  <div key={task.id || idx} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/5 transition-all">
                    
                    <div className="max-w-xl">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-white/10 text-indigo-300 border border-white/5 font-extrabold rounded text-[9px] uppercase">
                          {task.subject}
                        </span>
                        <span className="text-[10px] text-slate-450 font-bold">Due {new Date(task.dueDate).toLocaleDateString()}</span>
                      </div>
                      
                      <h5 className="font-bold text-white text-xs mt-1 leading-tight">{task.title}</h5>
                      <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed font-medium">{task.description}</p>
                      
                      {/* Note left by teacher */}
                      {record.notes && (
                        <div className="mt-2 text-[10px] text-slate-350 border-l-2 border-indigo-400 pl-2 py-0.5 italic bg-indigo-500/5 max-w-lg">
                          <strong className="text-indigo-300 not-italic font-bold">Teacher Remarks:</strong> "{record.notes}"
                        </div>
                      )}
                    </div>

                    <div className="self-start sm:self-auto shrink-0">
                      {getStatusBadge(record.status)}
                    </div>

                  </div>
                ))}

                {studentRecordsWithTasks.length === 0 && (
                  <p className="text-slate-500 text-xs text-center py-8">No monthly tasks registered for this class.</p>
                )}
              </div>
            </div>

            {/* Graded Test Scorecard Section */}
            <div className="space-y-4">
              <h4 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Award className="w-4.5 h-4.5 text-indigo-400" />
                <span>Syllabus Graded Tests Scorecard</span>
              </h4>

              <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden shadow-2xl divide-y divide-white/5">
                {testScoresWithTests.map(({ test, score, isAbsent, remarks }, idx) => {
                  const percent = !isAbsent && score !== '' ? Math.round((Number(score) / test.maxMarks) * 100) : 0;

                  return (
                    <div key={test.id || idx} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/5 transition-all">
                      <div className="max-w-xl">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-extrabold rounded text-[9px] uppercase">
                            {test.subject}
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">Conducted: {new Date(test.testDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                        </div>
                        
                        <h5 className="font-bold text-white text-xs mt-1 leading-tight">{test.testName}</h5>
                        {remarks && (
                          <p className="text-slate-400 text-[10px] mt-1 font-medium bg-white/5 px-2.5 py-1 rounded inline-block">Remarks: <span className="text-slate-200 italic">"{remarks}"</span></p>
                        )}
                      </div>

                      <div className="self-start sm:self-auto shrink-0 flex items-center gap-3">
                        {isAbsent ? (
                          <span className="px-2.5 py-1 bg-rose-500/10 text-rose-300 border border-rose-500/20 text-[10px] font-bold rounded-lg uppercase">
                            Absent
                          </span>
                        ) : score !== '' ? (
                          <div className="flex items-center gap-2 bg-slate-900 border border-white/10 rounded-xl p-2 font-mono">
                            <span className="text-sm font-black text-white">{score}</span>
                            <span className="text-[10px] text-slate-500">/ {test.maxMarks}</span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              percent >= 80 ? 'bg-emerald-500/15 text-emerald-400' :
                              percent >= 60 ? 'bg-indigo-500/15 text-indigo-400' :
                              percent >= 35 ? 'bg-amber-500/15 text-amber-400' :
                              'bg-rose-500/15 text-rose-400'
                            }`}>
                              {percent}%
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-500 italic font-semibold">Not graded yet</span>
                        )}
                      </div>
                    </div>
                  );
                })}

                {testScoresWithTests.length === 0 && (
                  <p className="text-slate-400 text-xs text-center py-6 font-semibold">No syllabus evaluation tests registered yet for this class.</p>
                )}
              </div>
            </div>

            {/* Advisory signature */}
            <div className="border-t border-white/5 pt-5 flex items-center justify-between text-[11px] text-slate-500 font-semibold">
              <span className="flex items-center gap-1"><HeartHandshake className="w-3.5 h-3.5 text-pink-500" /> Education is a collaborative effort.</span>
              <span>Updated in real-time by school faculty.</span>
            </div>

          </div>
        ) : (
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-12 border border-white/10 shadow-2xl text-center">
            <UserSquare className="w-14 h-14 text-slate-500 mx-auto mb-3 animate-pulse" />
            <h4 className="font-extrabold text-white text-sm">Awaiting Student Query</h4>
            <p className="text-slate-400 text-xs mt-1 max-w-sm mx-auto font-medium">
              Please select a class on the left panel and click on any student to view their certified, printable Notebook Check-off Report Card.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
