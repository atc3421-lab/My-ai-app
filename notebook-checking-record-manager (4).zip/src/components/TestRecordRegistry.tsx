import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { 
  SchoolClass, 
  MonthlyTask, 
  AcademicTest, 
  StudentTestMark,
  UserSession,
  ManagementReview
} from '../types';
import { 
  Award, 
  Plus, 
  Trash2, 
  Calendar, 
  BookOpen, 
  User, 
  Check, 
  ChevronRight, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  FileCheck, 
  X,
  PlusCircle,
  Hash,
  FileText,
  Printer,
  Download
} from 'lucide-react';
import { OFFICIAL_SYLLABUS_BANK, APRIL_SYLLABUS_BANK, JUNE_SYLLABUS_BANK } from '../data/officialSyllabus';
import { TeacherAllotment, getSubjectsForGrade } from '../data/teacherData';

interface TestRecordRegistryProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  tests: AcademicTest[];
  testMarks: StudentTestMark[];
  onAddTest: (test: AcademicTest) => void;
  onDeleteTest: (testId: string) => void;
  onUpdateMarks: (testId: string, marks: StudentTestMark[]) => void;
  allotments: TeacherAllotment[];
  syllabusBank?: { [grade: string]: any[] };
  currentUser: UserSession | null;
  managementReviews?: ManagementReview[];
}

export default function TestRecordRegistry({
  classes,
  tasks,
  tests,
  testMarks,
  onAddTest,
  onDeleteTest,
  onUpdateMarks,
  allotments,
  syllabusBank = OFFICIAL_SYLLABUS_BANK,
  currentUser,
  managementReviews
}: TestRecordRegistryProps) {
  
  // Resolve correct syllabus bank depending on month
  const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
    if (!allotTeacher || !userTeacher) return false;
    const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const cleanAllot = cleanStr(allotTeacher);
    const cleanUser = cleanStr(userTeacher);
    if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
    
    const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
    const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    
    for (const allotW of allotWords) {
      for (const userW of userWords) {
        if (allotW.includes(userW) || userW.includes(allotW)) return true;
      }
    }
    return false;
  };

  const getSyllabusBankForMonth = (monthStr: string) => {
    const m = monthStr.toLowerCase();
    if (m.includes('april')) return APRIL_SYLLABUS_BANK;
    if (m.includes('june')) return JUNE_SYLLABUS_BANK;
    return (syllabusBank && Object.keys(syllabusBank).length > 0 ? syllabusBank : OFFICIAL_SYLLABUS_BANK);
  };

  // Helper to match class name to allotment grade
  const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
    if (!className || !allotmentGrade) return false;
    const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
    const c1 = clean(className);
    const c2 = clean(allotmentGrade);
    return c1 === c2;
  };

  // Helper to check if subject is assigned to teacher
  const isSubjectAssignedToTeacher = (className: string, subjectName: string, teacherName: string): boolean => {
    const allotment = allotments?.find(
      a => isClassMatchAllotment(className, a.grade)
    );
    if (!allotment) return false;
    const assigned = allotment.subjects[subjectName];
    return isTeacherNameMatched(assigned, teacherName);
  };

  // Allowed Classes for Faculty vs Admin
  const allowedClasses = currentUser && currentUser.role === 'teacher'
    ? classes.filter(c => {
        const allotment = allotments?.find(
          a => isClassMatchAllotment(c.name, a.grade)
        );
        if (!allotment) return false;
        if (isTeacherNameMatched(allotment.classTeacher, currentUser.name)) return true;
        return Object.values(allotment.subjects || {}).some(tName => 
          isTeacherNameMatched(tName, currentUser.name)
        );
      })
    : classes;

  // Selection states
  const [selectedClassId, setSelectedClassId] = useState<string>(() => {
    if (currentUser?.role === 'teacher') {
      const allowed = classes.filter(c => {
        const allotment = allotments?.find(
          a => isClassMatchAllotment(c.name, a.grade)
        );
        if (!allotment) return false;
        if (isTeacherNameMatched(allotment.classTeacher, currentUser.name)) return true;
        return Object.values(allotment.subjects || {}).some(tName => 
          isTeacherNameMatched(tName, currentUser.name)
        );
      });
      return allowed[0]?.id || '';
    }
    return classes[0]?.id || '';
  });
  const [activeTestId, setActiveTestId] = useState<string>('');
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showNotification = (msg: string, type: 'success' | 'error' = 'success') => {
    // Attempt standard alert if permitted, but never throw exceptions if blocked
    try {
      console.log(`[Notification] ${type.toUpperCase()}: ${msg}`);
    } catch (e) {}
    setToast({ message: msg, type });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Sync selectedClassId with allowedClasses if it's invalid
  React.useEffect(() => {
    if (allowedClasses.length > 0) {
      if (!selectedClassId || !allowedClasses.some(c => c.id === selectedClassId)) {
        setSelectedClassId(allowedClasses[0].id);
      }
    }
  }, [allowedClasses, selectedClassId]);
  
  // Helper to resolve Roman syllabus grade keys
  const getSyllabusGradeKey = (className: string): string => {
    const cleaned = className.replace('Grade ', '').trim();
    const parts = cleaned.split(' ');
    if (parts.length > 0) {
      return `Grade ${parts[0]}`;
    }
    return 'Grade V';
  };

  // Helper to lookup allotted teacher
  const getAssignedTeacher = (classId: string, subjectName: string): string => {
    const foundClass = classes.find(c => c.id === classId);
    if (!foundClass) return 'Staff Teacher';
    const allotment = allotments.find(
      a => isClassMatchAllotment(foundClass.name, a.grade)
    );
    if (allotment) {
      return allotment.subjects[subjectName] || allotment.classTeacher || 'Staff Teacher';
    }
    return 'Staff Teacher';
  };

  // New Test Creation state
  const [showAddTest, setShowAddTest] = useState(false);
  const [newTestClassId, setNewTestClassId] = useState('');
  const [associatedTaskId, setAssociatedTaskId] = useState('');
  const [testName, setTestName] = useState('');
  const [testDate, setTestDate] = useState('2026-04-30');
  const [maxMarks, setMaxMarks] = useState<number>(100); // Customizable marks scale
  const [customSubject, setCustomSubject] = useState('Math');
  const [customMonth, setCustomMonth] = useState('June 2026');
  const [testToDelete, setTestToDelete] = useState<AcademicTest | null>(null);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [printError, setPrintError] = useState<string | null>(null);
  const [filterMonth, setFilterMonth] = useState<string>('June 2026'); // Default to active June month

  // Sync new test class with active selection when opened
  React.useEffect(() => {
    if (showAddTest) {
      const initialClassId = selectedClassId || allowedClasses[0]?.id || '';
      setNewTestClassId(initialClassId);
      
      const targetObj = classes.find(c => c.id === initialClassId);
      if (targetObj) {
        const gkey = getSyllabusGradeKey(targetObj.name);
        const bankToUse = getSyllabusBankForMonth(customMonth);
        const rawSubjectsList = bankToUse[gkey] || [];
        const allowedList = getSubjectsForGrade(gkey || '');
        const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
        const filteredSubjectsList = currentUser && currentUser.role === 'teacher'
          ? subjectsList.filter(item => isSubjectAssignedToTeacher(targetObj.name, item.subject, currentUser.name))
          : subjectsList;

        if (filteredSubjectsList.length > 0) {
          setCustomSubject(filteredSubjectsList[0].subject);
          if (filteredSubjectsList[0].topics.length > 0) {
            setTestName(filteredSubjectsList[0].topics[0]);
          }
        }
      }
    }
  }, [showAddTest, customMonth]);

  // Load students for active selected test evaluation
  const activeTest = tests.find(t => t.id === activeTestId);
  const activeTestClass = activeTest ? classes.find(c => c.id === activeTest.classId) : null;
  const activeTestStudents = activeTestClass ? activeTestClass.students : [];

  // Listen to browser-level print events to make sure the print preview layout is forced visible 
  // in the React state lifecycle during the browser print command, ensuring zero blank pages.
  React.useEffect(() => {
    const handleBeforePrint = () => {
      if (activeTest) {
        setShowPrintModal(true);
      }
    };
    window.addEventListener('beforeprint', handleBeforePrint);
    return () => {
      window.removeEventListener('beforeprint', handleBeforePrint);
    };
  }, [activeTest]);

  // Local state for updating marks in real-time before clicking "Save Ledger"
  const [localMarks, setLocalMarks] = useState<Record<string, { marks: number | ''; isAbsent: boolean; remarks: string }>>({});

  // Active class-filtered tasks for pre-filling syllabus chapters
  const classSyllabusTasks = tasks.filter(t => t.classId === (newTestClassId || selectedClassId));

  // Initialize marks editing state when a test is selected
  const handleSelectTest = (testId: string) => {
    setActiveTestId(testId);
    const testItem = tests.find(t => t.id === testId);
    if (testItem) {
      const marksState: Record<string, { marks: number | ''; isAbsent: boolean; remarks: string }> = {};
      
      // Grab existing marks
      const relevantMarks = testMarks.filter(m => m.testId === testId);
      
      // Look up target class
      const targetClass = classes.find(c => c.id === testItem.classId);
      if (targetClass) {
        targetClass.students.forEach(st => {
          const match = relevantMarks.find(m => m.studentId === st.id);
          marksState[st.id] = {
            marks: match ? match.marksObtained : '',
            isAbsent: match ? match.isAbsent : false,
            remarks: match ? match.remarks : ''
          };
        });
      }
      setLocalMarks(marksState);
    }
  };

  // Sync / saving edited marks state
  const handleSaveMarksLedger = () => {
    if (currentUser?.role === 'management') return;
    if (!activeTest) return;
    
    // Check for validation errors (e.g. marks > maxMarks)
    const errs: string[] = [];
    Object.entries(localMarks).forEach(([sid, unknownRec]) => {
      const record = unknownRec as { marks: number | ''; isAbsent: boolean; remarks: string };
      const studentName = activeTestStudents.find(s => s.id === sid)?.name || 'Student';
      if (!record.isAbsent && record.marks !== '') {
        const numeric = Number(record.marks);
        if (isNaN(numeric) || numeric < 0 || numeric > activeTest.maxMarks) {
          errs.push(`${studentName}: Score must be between 0 and ${activeTest.maxMarks}.`);
        }
      }
    });

    if (errs.length > 0) {
      showNotification(`Correction required before persisting:\n` + errs.join('\n'), 'error');
      return;
    }

    const payload: StudentTestMark[] = Object.entries(localMarks).map(([studentId, unknownRec]) => {
      const record = unknownRec as { marks: number | ''; isAbsent: boolean; remarks: string };
      return {
        id: `${activeTest.id}_${studentId}`,
        testId: activeTest.id,
        studentId,
        marksObtained: record.isAbsent ? '' : record.marks,
        isAbsent: record.isAbsent,
        remarks: record.remarks,
        lastUpdatedAt: new Date().toISOString()
      };
    });

    onUpdateMarks(activeTest.id, payload);
    showNotification('Academic marks ledger updated and archived successfully!', 'success');
  };

  // Generate beautiful printable layout for PDF/Print options
  const handlePrintPDF = () => {
    if (!activeTest) return;
    setShowPrintModal(true);
  };

  // Generate tabbed CSV format for immediate Microsoft Excel consumption
  const handleDownloadExcel = () => {
    if (!activeTest) return;
    const teacherName = getAssignedTeacher(activeTest.classId, activeTest.subject);
    
    const headers = ["Roll Number", "Student Name", "Marks Obtained", "Max Marks", "Status", "Remarks"];
    const rows = activeTestStudents.map(student => {
      const rowState = { marks: '', isAbsent: false, remarks: '', ...(localMarks[student.id] || {}) } as { marks: number | ''; isAbsent: boolean; remarks: string };
      const score = rowState.isAbsent ? "Absent" : (rowState.marks === '' ? '--' : rowState.marks);
      const status = rowState.isAbsent ? "Absent" : "Present";
      return [
        student.rollNumber,
        student.name,
        score,
        activeTest.maxMarks,
        status,
        rowState.remarks || ''
      ];
    });
    
    const csvContent = [
      [`SAMATA INTERNATIONAL SCHOOL - SCHOLASTIC MARKS EVALUATION REGISTRY`],
      [`Class / Section:`, activeTestClass?.name || ''],
      [`Evaluation Chapter Test:`, activeTest.testName],
      [`Subject:`, activeTest.subject],
      [`Conducted Date:`, new Date(activeTest.testDate).toLocaleDateString()],
      [`Allotted Teacher:`, teacherName],
      [], // spacer
      headers,
      ...rows
    ].map(e => e.map(val => {
      const strVal = String(val);
      // Escape commas and double quotes correctly
      if (strVal.includes(",") || strVal.includes('"') || strVal.includes("\n")) {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
      return strVal;
    }).join(",")).join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Marks_Sheet_${activeTestClass?.name.replace(/\s+/g, '_')}_${activeTest.subject}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Pre-seed mock / simulated marks for demonstration
  const handleSeedMockScores = () => {
    if (!activeTest) return;
    const mocked: typeof localMarks = {};
    activeTestStudents.forEach(st => {
      // 8% chance to be absent
      const isAbsent = Math.random() < 0.08;
      let marks: number | '' = '';
      if (!isAbsent) {
        // High cluster of marks in the 70% to 100% of max marks
        const minVal = Math.floor(activeTest.maxMarks * 0.5);
        const maxVal = activeTest.maxMarks;
        marks = Math.floor(Math.random() * (maxVal - minVal + 1)) + minVal;
      }
      
      const remarksList = ['Excellent answers', 'Shown improvement', 'Neat rough-work', 'Good conceptual grasp', 'Needs oral follow-up', 'Solid understanding', 'Outstanding performance'];
      const remarks = !isAbsent && marks !== '' && Number(marks) > (activeTest.maxMarks * 0.8) 
        ? remarksList[Math.floor(Math.random() * remarksList.length)] 
        : (isAbsent ? 'Absent for evaluation' : 'Completed check');

      mocked[st.id] = {
        marks,
        isAbsent,
        remarks
      };
    });
    setLocalMarks(mocked);
  };

  // Handle syllabus task selection to auto-populate test information
  const handleSyllabusTaskSelect = (taskId: string) => {
    setAssociatedTaskId(taskId);
    const selectedTask = tasks.find(t => t.id === taskId);
    if (selectedTask) {
      setCustomSubject(selectedTask.subject);
      setCustomMonth(selectedTask.month);
      // Clean up title somewhat for test name
      const simplifiedTitle = selectedTask.title.replace('Notebook', '').replace('Check', '').trim();
      setTestName(`Syllabus Evaluation: ${simplifiedTitle}`);
    }
  };

  // Create Test
  const handleCreateTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser?.role === 'management') return;
    if (!newTestClassId) {
      showNotification('Please choose a class.', 'error');
      return;
    }
    if (!testName.trim()) {
      showNotification('Please specify a evaluation test name.', 'error');
      return;
    }
    if (isNaN(maxMarks) || maxMarks <= 0) {
      showNotification('Please specify a valid maximum score scale greater than 0.', 'error');
      return;
    }

    const newTest: AcademicTest = {
      id: 'test_' + Date.now(),
      classId: newTestClassId,
      subject: customSubject,
      month: customMonth,
      taskId: associatedTaskId,
      testName: testName.trim(),
      testDate,
      maxMarks
    };

    onAddTest(newTest);
    setShowAddTest(false);
    
    // Reset inputs
    setTestName('');
    setAssociatedTaskId('');
    setCustomSubject('Mathematics');
    
    // Instantly select the newly created test
    setTimeout(() => {
      handleSelectTest(newTest.id);
    }, 100);
  };

  // Filter tests by selected class, month and teacher allotment constraints
  const filteredTests = tests.filter(t => {
    if (t.classId !== selectedClassId) return false;
    if (filterMonth !== 'all' && t.month !== filterMonth) return false;
    if (currentUser && currentUser.role === 'teacher') {
      const targetClass = classes.find(c => c.id === t.classId);
      if (!targetClass) return false;
      return isSubjectAssignedToTeacher(targetClass.name, t.subject, currentUser.name);
    }
    return true;
  });

  // Stats calculation for active selected test
  const calculateTestStats = (testId: string) => {
    const scores = testMarks.filter(m => m.testId === testId && !m.isAbsent && m.marksObtained !== '');
    const currentTest = tests.find(t => t.id === testId);
    if (!currentTest || scores.length === 0) return { avg: 0, high: 0, low: 0, count: 0, passRate: 0, absent: 0 };
    
    const count = scores.length;
    const sum = scores.reduce((acc, curr) => acc + Number(curr.marksObtained), 0);
    const avg = Math.round((sum / count) * 10) / 10;
    const numericScores = scores.map(s => Number(s.marksObtained));
    const high = Math.max(...numericScores);
    const low = Math.min(...numericScores);
    
    // Passing threshold is 35% of max marks
    const passThreshold = currentTest.maxMarks * 0.35;
    const passes = scores.filter(s => Number(s.marksObtained) >= passThreshold).length;
    const passRate = Math.round((passes / count) * 100);

    const matchMarksList = testMarks.filter(m => m.testId === testId);
    const absent = matchMarksList.filter(m => m.isAbsent).length;

    return { avg, high, low, count, passRate, absent };
  };

  const hasFilledMarks = Object.values(localMarks).some(
    m => m && (m.isAbsent || (m.marks !== undefined && m.marks !== ''))
  );

  return (
    <div id="school_academic_test_hub" className="space-y-6">
      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-[9999] bg-slate-900/95 border border-indigo-500/30 text-white px-5 py-4 rounded-2xl shadow-2xl flex items-center gap-3">
          {toast.type === 'success' ? (
            <div className="w-5 h-5 bg-emerald-500/25 rounded-full border border-emerald-500/30 text-emerald-400 font-bold flex items-center justify-center text-[10px]">✓</div>
          ) : (
            <div className="w-5 h-5 bg-rose-500/25 rounded-full border border-rose-500/30 text-rose-400 font-bold flex items-center justify-center text-[10px]">!</div>
          )}
          <div className="text-xs font-bold whitespace-pre-line leading-relaxed">{toast.message}</div>
          <button onClick={() => setToast(null)} className="ml-2 text-slate-500 hover:text-white font-extrabold cursor-pointer text-xs">×</button>
        </div>
      )}

      {currentUser?.role === 'management' && (
        <div className="bg-sky-500/10 border border-sky-500/25 text-sky-200 px-4 py-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold leading-relaxed no-print">
          <span>🛡️</span>
          <div>
            <strong>Management Read-Only Audit Mode:</strong> You are auditing this evaluation scorebook. Score modifications, test entries additions, and record deletions are disabled. Submit reviews in the <strong>'Management Verification'</strong> panel.
          </div>
        </div>
      )}
      
      {/* HEADER EXPLANATION */}
      <div className="bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-950/40 border border-indigo-500/20 rounded-3xl p-6 relative overflow-hidden backdrop-blur-xl no-print">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-[80px] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-2.5 py-1 rounded-full uppercase font-bold tracking-wider">
              Scholastic Assessment
            </span>
            <h2 className="text-xl md:text-2xl font-black text-white leading-tight">Syllabus Evaluation & Test Register</h2>
            <p className="text-slate-400 text-xs md:text-sm max-w-2xl font-medium">
              Validate student performance and manage test scorebooks. Teachers can create custom scale tests of 10 to 30 marks linked directly to active monthly chapter schedules.
            </p>
          </div>
          {currentUser?.role !== 'management' && (
            <button
              onClick={() => {
                setNewTestClassId(selectedClassId);
                setShowAddTest(true);
              }}
              type="button"
              className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs px-5 py-3 rounded-xl shadow-lg shadow-indigo-500/10 flex items-center gap-2 self-start md:self-center cursor-pointer transition-all hover:-translate-y-0.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create evaluation Chapter Test</span>
            </button>
          )}
        </div>
      </div>

      {/* CREATE NEW TEST FORM POPUP */}
      {showAddTest && (
        <form onSubmit={handleCreateTest} className="bg-slate-950 border border-indigo-500/30 rounded-2xl p-5 shadow-2xl space-y-4 animate-fade-in relative no-print">
          <button 
            type="button"
            onClick={() => setShowAddTest(false)}
            className="absolute top-4 right-4 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 p-1.5 rounded-lg transition-all"
          >
            <X className="w-4 h-4" />
          </button>
          
          <div className="flex items-center gap-2 pb-2 border-b border-white/10">
            <Award className="w-5 h-5 text-indigo-400" />
            <h4 className="font-extrabold text-white text-sm">Schedule Syllabus Evaluation Test</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {/* Target Class */}
            <div className="space-y-1.5 animate-fade-in">
              <label className="text-[10px] uppercase font-bold text-slate-400">Target Class</label>
              <select
                value={newTestClassId}
                onChange={(e) => {
                  const cid = e.target.value;
                  setNewTestClassId(cid);
                  // Grab first subject from new class
                  const targetObj = classes.find(c => c.id === cid);
                  if (targetObj) {
                    const gkey = getSyllabusGradeKey(targetObj.name);
                    const bankToUse = getSyllabusBankForMonth(customMonth);
                    const rawSubjectsList = bankToUse[gkey] || [];
                    const allowedList = getSubjectsForGrade(gkey || '');
                    const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                    const filteredSubjectsList = currentUser && currentUser.role === 'teacher'
                      ? subjectsList.filter(item => isSubjectAssignedToTeacher(targetObj.name, item.subject, currentUser.name))
                      : subjectsList;

                    if (filteredSubjectsList.length > 0) {
                      setCustomSubject(filteredSubjectsList[0].subject);
                      if (filteredSubjectsList[0].topics.length > 0) {
                        setTestName(filteredSubjectsList[0].topics[0]);
                      }
                    }
                  }
                }}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
              >
                {allowedClasses.map(c => (
                  <option key={c.id} value={c.id} className="bg-slate-950 text-white">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Target Month Dropdown */}
            <div className="space-y-1.5 animate-fade-in">
              <label className="text-[10px] uppercase font-bold text-slate-400">Target Month</label>
              <select
                value={customMonth}
                onChange={(e) => {
                  const newMonth = e.target.value;
                  setCustomMonth(newMonth);

                  // Update default testDate based on selected month to match that month
                  if (newMonth === "April 2026") {
                    setTestDate("2026-04-25");
                  } else if (newMonth === "June 2026") {
                    setTestDate("2026-06-25");
                  } else if (newMonth === "July 2026") {
                    setTestDate("2026-07-25");
                  } else if (newMonth === "August 2026") {
                    setTestDate("2026-08-25");
                  }

                  // Grab first subject from current class with new month's syllabus
                  const targetObj = classes.find(c => c.id === newTestClassId);
                  if (targetObj) {
                    const gkey = getSyllabusGradeKey(targetObj.name);
                    const bankToUse = getSyllabusBankForMonth(newMonth);
                    const rawSubjectsList = bankToUse[gkey] || [];
                    const allowedList = getSubjectsForGrade(gkey || '');
                    const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                    const filteredSubjectsList = currentUser && currentUser.role === 'teacher'
                      ? subjectsList.filter(item => isSubjectAssignedToTeacher(targetObj.name, item.subject, currentUser.name))
                      : subjectsList;

                    if (filteredSubjectsList.length > 0) {
                      setCustomSubject(filteredSubjectsList[0].subject);
                      if (filteredSubjectsList[0].topics.length > 0) {
                        setTestName(filteredSubjectsList[0].topics[0]);
                      }
                    }
                  }
                }}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
              >
                <option value="April 2026" className="bg-slate-950 text-white">April 2026</option>
                <option value="June 2026" className="bg-slate-950 text-white">June 2026</option>
                <option value="July 2026" className="bg-slate-950 text-white">July 2026</option>
                <option value="August 2026" className="bg-slate-950 text-white">August 2026</option>
              </select>
            </div>

            {/* Subject Dropdown directly from Grade Syllabus */}
            <div className="space-y-1.5 animate-fade-in">
              <label className="text-[10px] uppercase font-bold text-slate-400">Curriculum Subject</label>
              <select
                value={customSubject}
                onChange={(e) => {
                  const subj = e.target.value;
                  setCustomSubject(subj);
                  // Preset first topic
                  const targetObj = classes.find(c => c.id === newTestClassId);
                  if (targetObj) {
                    const gkey = getSyllabusGradeKey(targetObj.name);
                    const bankToUse = getSyllabusBankForMonth(customMonth);
                    const rawSubjectsList = bankToUse[gkey] || [];
                    const allowedList = getSubjectsForGrade(gkey || '');
                    const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                    const found = subjectsList.find(s => s.subject === subj);
                    if (found && found.topics.length > 0) {
                      setTestName(found.topics[0]);
                    }
                  }
                }}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer animate-fade-in"
              >
                {(() => {
                  const targetObj = classes.find(c => c.id === newTestClassId);
                  const gkey = targetObj ? getSyllabusGradeKey(targetObj.name) : 'Grade I';
                  const bankToUse = getSyllabusBankForMonth(customMonth);
                  const rawSubjectsList = bankToUse[gkey] || [];
                  const allowedList = getSubjectsForGrade(gkey || '');
                  const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                  const filteredSubjectsList = currentUser && currentUser.role === 'teacher' && targetObj
                    ? subjectsList.filter(item => isSubjectAssignedToTeacher(targetObj.name, item.subject, currentUser.name))
                    : subjectsList;

                  return filteredSubjectsList.map(item => (
                    <option key={item.subject} value={item.subject} className="bg-slate-950 text-white">
                      {item.subject === "SS" ? "S.S (Social Science)" : item.subject === "Computer" ? "Computer (IT)" : item.subject}
                    </option>
                  ));
                })()}
              </select>
            </div>

            {/* Customizable Max Score Scale */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] uppercase font-bold text-slate-400">Max Score Scale</label>
                <span className="text-xs font-black text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-md">Teacher Configured</span>
              </div>
              <div className="flex gap-2">
                <input 
                  type="number"
                  min="1"
                  max="5000"
                  placeholder="e.g. 50, 100, 25, 10"
                  value={maxMarks || ''}
                  onChange={(e) => {
                    const parsed = parseInt(e.target.value, 10);
                    setMaxMarks(isNaN(parsed) ? 0 : parsed);
                  }}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-black text-white focus:outline-none focus:border-indigo-500 transition-all font-sans"
                />
              </div>
              <p className="text-[9px] text-slate-450 mt-1 font-semibold leading-relaxed">
                Enter any assessment maximum score (e.g. 10, 25, 50, 80, 100 etc.). The evaluation page and score cards will dynamically adapt to this scale.
              </p>
            </div>

            {/* AUTOMATED ALLOTMENT TEACHER BANNER */}
            {(() => {
              const teacherName = getAssignedTeacher(newTestClassId, customSubject);
              return (
                <div className="md:col-span-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl px-4 py-3 flex items-center justify-between text-xs animate-fade-in">
                  <span className="text-slate-400 font-bold flex items-center gap-2">
                    <User className="w-4.5 h-4.5 text-indigo-400" />
                    <span>Allotted Subject Teacher:</span>
                  </span>
                  <span className="text-white font-black bg-indigo-500/25 border border-indigo-500/30 px-3 py-1 rounded-lg">
                    {teacherName}
                  </span>
                </div>
              );
            })()}

            {/* SELECT SYLLABUS TOPIC DIRECT DROPDOWN */}
            <div className="md:col-span-4 space-y-1.5 animate-fade-in bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
              <label className="text-[10px] uppercase font-extrabold text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Choose Topic directly from Approved Syllabus Bank</span>
              </label>
              <select
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
                className="w-full bg-slate-950 border border-emerald-500/30 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-emerald-500 transition-all cursor-pointer text-emerald-300"
                required
              >
                <option value="">-- Click to choose topics filtered as per subject below --</option>
                {(() => {
                  const targetObj = classes.find(c => c.id === newTestClassId);
                  if (!targetObj) return null;
                  const gkey = getSyllabusGradeKey(targetObj.name);
                  const bankToUse = getSyllabusBankForMonth(customMonth);
                  const rawSubjectsList = bankToUse[gkey] || [];
                  const allowedList = getSubjectsForGrade(gkey || '');
                  const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                  const matchedSub = subjectsList.find(s => s.subject.toLowerCase() === customSubject.toLowerCase());
                  if (!matchedSub) return <option disabled>No topics registered for this subject</option>;
                  return matchedSub.topics.map((topicStr, topicIdx) => (
                    <option key={topicIdx} value={topicStr} className="bg-slate-950 text-white font-medium text-xs">
                      {topicStr}
                    </option>
                  ));
                })()}
              </select>
            </div>

            {/* Test Name (Prefilled and customizable) */}
            <div className="md:col-span-3 space-y-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-400">Chapter Test Name / Description</label>
              <input
                type="text"
                placeholder="e.g. Chapter 1 Basics Diagnostic Exam"
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-medium text-white focus:outline-none focus:border-indigo-500 transition-all placeholder:text-slate-600"
                required
              />
            </div>

            {/* Test Conducted Date */}
            <div className="md:col-span-1 space-y-1.5">
              <label className="text-[10px] uppercase font-bold text-slate-400">Conducted Date</label>
              <input
                type="date"
                value={testDate}
                onChange={(e) => {
                  const newDt = e.target.value;
                  setTestDate(newDt);
                  
                  try {
                    const parsedDate = new Date(newDt);
                    if (!isNaN(parsedDate.getTime())) {
                      const mName = parsedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                      setCustomMonth(mName);
                      
                      // Pre-fill subject and topic based on new month
                      const targetObj = classes.find(c => c.id === newTestClassId);
                      if (targetObj) {
                        const gkey = getSyllabusGradeKey(targetObj.name);
                        const bankToUse = getSyllabusBankForMonth(mName);
                        const rawSubjectsList = bankToUse[gkey] || [];
                        const allowedList = getSubjectsForGrade(gkey || '');
                        const subjectsList = rawSubjectsList.filter(item => allowedList.includes(item.subject));
                        const filteredSubjectsList = currentUser && currentUser.role === 'teacher'
                          ? subjectsList.filter(item => isSubjectAssignedToTeacher(targetObj.name, item.subject, currentUser.name))
                          : subjectsList;

                        if (filteredSubjectsList.length > 0) {
                          const hasCurrentSub = filteredSubjectsList.some(item => item.subject === customSubject);
                          const activeSub = hasCurrentSub ? customSubject : filteredSubjectsList[0].subject;
                          setCustomSubject(activeSub);
                          
                          const matchedSubObj = filteredSubjectsList.find(item => item.subject === activeSub);
                          if (matchedSubObj && matchedSubObj.topics.length > 0) {
                            setTestName(matchedSubObj.topics[0]);
                          }
                        }
                      }
                    }
                  } catch (err) {
                    console.error("Error setting custom month from date", err);
                  }
                }}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
                required
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 border-t border-white/10 pt-4">
            <button
              onClick={() => setShowAddTest(false)}
              type="button"
              className="bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/10 cursor-pointer transition-all"
            >
              Add Evaluation Register
            </button>
          </div>
        </form>
      )}

      {/* TWO COLUMNS LAYOUT: TEST LIST VS SCORING CENTER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: ACTIVE TESTS LIST & SELECTOR */}
        <div className="lg:col-span-4 space-y-4 no-print">
          
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5 space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="font-extrabold text-xs uppercase text-slate-300 tracking-wider">Evaluation Registry</h3>
              <span className="text-[10px] text-slate-500 font-bold">{filteredTests.length} tests sched/logged</span>
            </div>

            {/* Class selection dropdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[9px] uppercase font-bold text-slate-500">Filter Class Scoresheet</label>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    setActiveTestId(''); // clear test display
                  }}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
                >
                  {allowedClasses.map(c => (
                    <option key={c.id} value={c.id} className="bg-slate-950 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Month selection dropdown */}
              <div className="space-y-1">
                <label className="text-[9px] uppercase font-bold text-slate-500">Filter Month</label>
                <select
                  value={filterMonth}
                  onChange={(e) => {
                    setFilterMonth(e.target.value);
                    setActiveTestId(''); // clear test display
                  }}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
                >
                  <option value="all" className="bg-slate-950 text-white">All Months</option>
                  <option value="April 2026" className="bg-slate-950 text-white">April 2026</option>
                  <option value="June 2026" className="bg-slate-950 text-white">June 2026</option>
                  <option value="July 2026" className="bg-slate-950 text-white">July 2026</option>
                  <option value="August 2026" className="bg-slate-950 text-white">August 2026</option>
                </select>
              </div>
            </div>
          </div>

          {/* LIST CARD HOLDER */}
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-white/10">
            {filteredTests.length === 0 ? (
              <div className="bg-white/5 rounded-xl p-6 text-center border border-dashed border-white/10 space-y-1.5">
                <BookOpen className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400 font-semibold">No tests declared for this class</p>
                <p className="text-[10px] text-slate-500 max-w-xs mx-auto">
                  Tapping "Create evaluation Chapter Test" above permits scheduling score metrics from 10 to 30 marks centered on actual curriculum syllabus plans.
                </p>
              </div>
            ) : (
              filteredTests.map(test => {
                const stats = calculateTestStats(test.id);
                const isSelected = activeTestId === test.id;

                return (
                  <div
                    key={test.id}
                    onClick={() => handleSelectTest(test.id)}
                    className={`p-4 rounded-xl border transition-all text-left cursor-pointer relative group ${
                      isSelected 
                        ? 'bg-indigo-500/10 border-indigo-500/40 text-white shadow-md' 
                        : 'bg-white/5 border-white/5 hover:border-white/15 text-slate-300 hover:text-white'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-1">
                      <div className="space-y-1 max-w-[80%]">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {test.subject}
                          </span>
                          <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300">
                            {test.maxMarks} Marks Scale
                          </span>
                        </div>
                        <h4 className="font-bold text-xs line-clamp-2 leading-tight">{test.testName}</h4>
                        <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          <span>Teacher: <strong className="text-slate-300 font-bold">{getAssignedTeacher(test.classId, test.subject)}</strong></span>
                        </div>
                      </div>
                      {currentUser?.role !== 'management' && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setTestToDelete(test);
                          }}
                          className="text-slate-400 hover:text-rose-400 p-1.5 bg-white/5 hover:bg-rose-500/15 rounded-lg transition-all cursor-pointer inline-flex items-center"
                          title="Delete this test & score history"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="flex items-center justify-between border-t border-white/5 pt-2.5 mt-2.5 text-[10px] text-slate-400">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{new Date(test.testDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      </div>
                      
                      {stats.count > 0 ? (
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">Avg: {stats.avg}/{test.maxMarks}</span>
                          <span className="text-indigo-300 font-semibold">Pass: {stats.passRate}%</span>
                        </div>
                      ) : (
                        <span className="text-rose-400/90 font-medium">Pending Entry</span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: SCORING / MARKS LEDGER INPUT SHEET */}
        <div className="lg:col-span-8 print:col-span-12 print:w-full">
          
          {!activeTest ? (
            <div className="bg-white/5 border border-white/10 rounded-2xl p-12 text-center h-full flex flex-col justify-center items-center space-y-3">
              <Award className="w-12 h-12 text-indigo-500/20" />
              <div className="space-y-1 max-w-md">
                <h4 className="text-sm font-extrabold text-white">Syllabus Evaluation Scorebook</h4>
                <p className="text-xs text-slate-400">
                  Select a registered evaluation test on the left to review class scorecard entries, mark students as absent, record grades out of the custom configured max scale, and write comments.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 md:p-6 space-y-6 animate-fade-in relative">
              
              {/* TOP ANALYTICS & QUICK ACTIONS */}
              <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-5 gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded font-black tracking-wider uppercase">
                    Class {activeTestClass?.name} Graded Ledger Sheet
                  </span>
                  <h3 className="text-base font-black text-white">{activeTest.testName}</h3>
                  <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-slate-400">
                    <span className="font-semibold text-slate-300">Scale: {activeTest.maxMarks} Max Marks</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      {new Date(activeTest.testDate).toLocaleDateString()}
                    </span>
                    <span>•</span>
                    <span className="text-indigo-400 font-bold">Teacher Assignment: {getAssignedTeacher(activeTest.classId, activeTest.subject)}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 no-print">
                  <button
                    type="button"
                    onClick={handleSeedMockScores}
                    className="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-[11px] px-3.5 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-all cursor-pointer"
                    title="Simulate / Quick Fill randomized demonstration grades"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Quick Autofill Grades</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const initial: typeof localMarks = {};
                      activeTestStudents.forEach(st => {
                        initial[st.id] = { marks: '', isAbsent: false, remarks: '' };
                      });
                      setLocalMarks(initial);
                    }}
                    className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-bold text-[11px] px-3 py-1.5 rounded-xl inline-flex items-center transition-all cursor-pointer"
                  >
                    Reset Blank
                  </button>

                  {hasFilledMarks && (
                    <>
                      <button
                        type="button"
                        onClick={handlePrintPDF}
                        className="bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 font-black text-[11px] px-3.5 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-all cursor-pointer animate-fade-in"
                        title="Print syllabus progress reports or Save as physical PDF document"
                      >
                        <Printer className="w-3.5 h-3.5 text-sky-400" />
                        <span>Print / PDF</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleDownloadExcel}
                        className="bg-yellow-500/15 hover:bg-yellow-500/25 border border-yellow-500/30 text-yellow-300 font-black text-[11px] px-3.5 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-all cursor-pointer animate-fade-in"
                        title="Download standard tabular ledger for MS Excel, Apple Numbers, or Google Sheets"
                      >
                        <Download className="w-3.5 h-3.5 text-yellow-400" />
                        <span>Download Excel</span>
                      </button>
                    </>
                  )}

                  {currentUser?.role !== 'management' && (
                    <button
                      type="button"
                      onClick={() => setTestToDelete(activeTest)}
                      className="bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/35 text-rose-300 hover:text-rose-200 font-bold text-[11px] px-3 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-all cursor-pointer"
                      title="Delete this test & score history permanently"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                      <span>Delete Test & Scores</span>
                    </button>
                  )}
                </div>
              </div>

              {/* BENTO STATS BLOCK */}
              {(() => {
                const stats = calculateTestStats(activeTest.id);
                return (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/60 p-4 border border-white/5 rounded-2xl">
                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Class Average</span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-lg font-black text-white">{stats.count > 0 ? stats.avg : 'N/A'}</span>
                        <span className="text-[10px] text-slate-500">/ {activeTest.maxMarks}</span>
                      </div>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Performance Rank</span>
                      <div className="flex items-center gap-1.5">
                        {stats.count > 0 && stats.avg >= (activeTest.maxMarks * 0.6) ? (
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" /> Proficient
                          </span>
                        ) : stats.count > 0 ? (
                          <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                            <TrendingDown className="w-3.5 h-3.5 text-amber-400" /> Average
                          </span>
                        ) : (
                          <span className="text-xs font-medium text-slate-400">Waiting Entries</span>
                        )}
                      </div>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Pass Rate (≥35%)</span>
                      <span className="text-sm font-black text-indigo-300 block">{stats.count > 0 ? `${stats.passRate}%` : 'N/A'}</span>
                    </div>

                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Absent Count</span>
                      <span className="text-sm font-black text-rose-300 block">{stats.absent} Pupils</span>
                    </div>
                  </div>
                );
              })()}

              {/* STUDENT GRADE-ROLL SHEET */}
              <div className="border border-white/5 rounded-2xl overflow-hidden bg-slate-950/20 max-h-[720px] sm:max-h-[800px] overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                <table className="w-full text-left font-sans border-collapse">
                  <thead>
                    <tr className="bg-white/5 border-b border-white/10 font-bold text-[10px] text-slate-400 uppercase tracking-wider">
                      <th className="py-1.5 px-3 sm:py-2 w-12 text-center">Roll</th>
                      <th className="py-1.5 px-2 sm:py-2">Student Name</th>
                      <th className="py-1.5 px-2 sm:py-2 w-28 sm:w-36 text-center">Marks ({activeTest.maxMarks})</th>
                      <th className="py-1.5 px-2 sm:py-2 w-16 text-center">Absent</th>
                      <th className="py-1.5 px-2 sm:py-2">Grading Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeTestStudents.map(student => {
                      const rowState = { marks: '', isAbsent: false, remarks: '', ...(localMarks[student.id] || {}) } as { marks: number | ''; isAbsent: boolean; remarks: string };
                      const scoreExceededError = !rowState.isAbsent && rowState.marks !== '' && Number(rowState.marks) > activeTest.maxMarks;

                      return (
                        <tr 
                          key={student.id} 
                          className={`border-b border-white/5 text-xs transition-colors hover:bg-white/5 ${
                            rowState.isAbsent ? 'bg-rose-500/5 text-slate-500' : ''
                          }`}
                        >
                          {/* Roll no */}
                          <td className="py-1 px-3 sm:py-2 font-mono font-bold text-[10px] sm:text-[11px] text-slate-400 text-center">
                            {student.rollNumber}
                          </td>

                          {/* Student name */}
                          <td className="py-1 px-2 sm:py-2 font-semibold text-slate-200">
                            <span className="whitespace-nowrap truncate text-[10px] sm:text-xs max-w-[85px] sm:max-w-none block" title={student.name}>
                              {student.name}
                            </span>
                          </td>

                          {/* Evaluation Number Input */}
                          <td className="py-1 px-2 sm:py-2">
                            <div className="flex items-center justify-center relative">
                              <input
                                type="number"
                                min="0"
                                max={activeTest.maxMarks}
                                disabled={rowState.isAbsent}
                                placeholder="--"
                                value={rowState.isAbsent ? '' : (rowState.marks ?? '')}
                                onChange={(e) => {
                                  const val = e.target.value === '' ? '' : Math.min(Number(e.target.value), 100); // safety
                                  setLocalMarks(prev => ({
                                    ...prev,
                                    [student.id]: {
                                      ...prev[student.id],
                                      marks: val,
                                      isAbsent: false
                                    }
                                  }));
                                }}
                                className={`w-16 sm:w-20 bg-slate-950/80 border text-center text-xs font-black py-1 focus:outline-none rounded-lg leading-none ${
                                  rowState.isAbsent 
                                    ? 'border-white/5 text-slate-600 cursor-not-allowed bg-white/5' 
                                    : scoreExceededError 
                                      ? 'border-rose-500 text-rose-400 shadow-md shadow-rose-500/10' 
                                      : 'border-white/10 text-emerald-400 focus:border-emerald-500'
                                }`}
                              />
                            </div>
                            {scoreExceededError && (
                              <div className="text-[9px] text-rose-400 text-center font-bold mt-0.5">Exceeds max {activeTest.maxMarks}!</div>
                            )}
                          </td>

                          {/* Absent checkbox flag */}
                          <td className="py-1 px-2 sm:py-2 text-center">
                            <input
                              type="checkbox"
                              checked={rowState.isAbsent}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                setLocalMarks(prev => ({
                                  ...prev,
                                  [student.id]: {
                                    ...prev[student.id],
                                    isAbsent: checked,
                                    marks: checked ? '' : ''
                                  }
                                }));
                              }}
                              className="w-3.5 h-3.5 text-indigo-500 bg-white/5 border border-white/10 rounded cursor-pointer accent-rose-500"
                            />
                          </td>

                          {/* Performance comments / review */}
                          <td className="py-1 px-2 sm:py-2">
                            <input
                              type="text"
                              placeholder="Notes or exam remarks..."
                              value={rowState.remarks ?? ''}
                              onChange={(e) => {
                                const text = e.target.value;
                                setLocalMarks(prev => ({
                                  ...prev,
                                  [student.id]: {
                                    ...prev[student.id],
                                    remarks: text
                                  }
                                }));
                              }}
                              className="w-full bg-transparent border-b border-transparent hover:border-white/10 focus:border-indigo-500 text-[10px] text-slate-300 focus:outline-none transition-all placeholder:text-slate-700 py-0.5 font-semibold"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* BOTTOM ACTIONS BAR */}
              <div className="flex items-center justify-between border-t border-white/10 pt-4 flex-wrap gap-4 no-print">
                <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Always check scores correspond strictly with students' physical tests paper sheets</span>
                </div>
                
                <div className="flex items-center gap-2.5 flex-wrap">
                  {hasFilledMarks && (
                    <div className="flex items-center gap-2 animate-fade-in">
                      <button
                        type="button"
                        onClick={handlePrintPDF}
                        className="bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-300 font-black text-xs px-4 py-3 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer hover:-translate-y-0.5"
                        title="Print syllabus progress reports or Save as physical PDF document"
                      >
                        <Printer className="w-4 h-4 text-sky-400" />
                        <span>Print Report / PDF</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleDownloadExcel}
                        className="bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/30 text-yellow-300 font-black text-xs px-4 py-3 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer hover:-translate-y-0.5"
                        title="Download scorecard for Excel spreadsheet editing"
                      >
                        <Download className="w-4 h-4 text-yellow-400" />
                        <span>Download Excel Sheet</span>
                      </button>
                    </div>
                  )}

                  {currentUser?.role !== 'management' ? (
                    <button
                      type="button"
                      onClick={handleSaveMarksLedger}
                      className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-lg shadow-indigo-500/15 flex items-center gap-2 cursor-pointer transition-all hover:-translate-y-0.5"
                    >
                      <FileCheck className="w-4 h-4" /> Save Scorebook Records
                    </button>
                  ) : (
                    <div className="bg-sky-500/15 border border-sky-500/25 text-sky-300 font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 leading-none">
                      <span>🛡️</span>
                      <span>Read-Only Audit Mode (Scores Saved)</span>
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}
        </div>

      </div>

      {/* BEAUTIFUL CUSTOM CONFIRM DELETION MODAL */}
      {testToDelete && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in text-left no-print">
          <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2 bg-rose-500/15 rounded-xl">
                <Trash2 className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-white text-base">Unreversible Action</h3>
            </div>
            
            <div className="space-y-2">
              <p className="text-xs text-slate-300 leading-relaxed">
                Are you sure you want to permanently delete the test record <strong className="text-white">"{testToDelete.testName}"</strong>? This will wipe all graded student scores in this book and cannot be undone.
              </p>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setTestToDelete(null)}
                className="bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer transition-all"
              >
                No, Keep Record
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteTest(testToDelete.id);
                  if (activeTestId === testToDelete.id) {
                    setActiveTestId('');
                  }
                  setTestToDelete(null);
                }}
                className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-rose-600/20 cursor-pointer transition-all"
              >
                Yes, Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
      {/* PREMIUM INTERACTIVE PRINT/PDF PREVIEW SHEET MODAL */}
      {activeTest && (
        (() => {
          const isInsideIframe = typeof window !== 'undefined' && window.self !== window.top;
          
          const testTeacher = getAssignedTeacher(activeTest.classId, activeTest.subject);
          const activeReview = managementReviews?.find(r => {
            const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
            const cleanTeacher = cleanStr(testTeacher);
            const reviewTeacherClean = cleanStr(r.teacherName);
            const isTeacherMatch = reviewTeacherClean === cleanTeacher || 
                                   reviewTeacherClean.includes(cleanTeacher) || 
                                   cleanTeacher.includes(reviewTeacherClean);
            return isTeacherMatch && r.month === activeTest.month && r.isVerified;
          });
          
          const totalStudentsCount = activeTestStudents.length;
          const halfIndex = Math.ceil(totalStudentsCount / 2);
          const firstHalf = activeTestStudents.slice(0, halfIndex);
          const secondHalf = activeTestStudents.slice(halfIndex);

          return createPortal(
            <div className={`print-modal-overlay fixed inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-start overflow-y-auto p-4 md:p-8 z-50 animate-fade-in text-left ${showPrintModal ? '' : 'hidden-preview'}`}>
              
              {/* Action Header bar inside modal on-screen */}
              <div className="print-modal-buttons w-full max-w-4xl bg-slate-900 border border-white/10 rounded-2xl p-4 mb-6 flex flex-col gap-4 no-print shadow-xl">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-sky-500/10 text-sky-400 rounded-lg">
                      <Printer className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-white text-sm">Marks Ledger Print Preview</h3>
                      <p className="text-[10px] text-slate-400">Review final layout sheet. Triggers your standard system print dialogue.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          setPrintError(null);
                          window.focus();
                          window.print();
                        } catch (e: any) {
                          console.error("Print blocked in sandbox iframe:", e);
                          setPrintError("Browser security blocked native printing inside this developer preview frame.");
                        }
                      }}
                      className="bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-sky-500/15 flex items-center gap-1.5 transition-all cursor-pointer hover:-translate-y-0.5"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Confirm Print / PDF</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setPrintError(null);
                        setShowPrintModal(false);
                      }}
                      className="bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer transition-all"
                    >
                      Close Preview
                    </button>
                  </div>
                </div>

                {isInsideIframe && (
                  <div className="text-[11px] text-amber-305 bg-amber-500/10 border border-amber-500/25 p-3 rounded-xl flex items-start gap-2.5 leading-relaxed">
                    <span className="text-sm">💡</span>
                    <div>
                      <strong>Interactive Sandbox Note:</strong> Standard print triggers may be blocked inside nested nested browser previews. For 100% reliable printing or PDF export, click the <strong>'Open in a New Tab'</strong> button in the upper header, then click print!
                    </div>
                  </div>
                )}

                {printError && (
                  <div className="text-[11px] text-rose-300 bg-rose-500/10 border border-rose-500/25 p-3 rounded-xl flex items-start gap-2.5">
                    <span className="text-sm">⚠️</span>
                    <div>
                      <strong>Print Action Blocked:</strong> {printError} please try launching in a standalone tab!
                    </div>
                  </div>
                )}
              </div>

              {/* Realistic white paper sheet preview - Split in Page 1 and Page 2 */}
              <div className="w-full flex flex-col items-center gap-8 no-print-gap">
                {/* PAGE 1 OF 2 */}
                <div className={`printable-paper-sheet w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl relative border border-slate-200 ${
                  firstHalf.length > 38 ? 'ultra-dense-layout' :
                  firstHalf.length > 28 ? 'super-dense-layout' :
                  firstHalf.length > 18 ? 'dense-layout' : 'p-8 md:p-12'
                } mb-8 print:mb-0`}>
              
                  {/* Header / Letterhead */}
                  <div className="border-b-2 border-dashed border-slate-300 pb-4 mb-6 flex items-center justify-between">
                    <div>
                      <h1 className="text-xl md:text-2xl font-black text-slate-950 tracking-tight leading-tight">SAMATA INTERNATIONAL SCHOOL</h1>
                      <p className="text-[10px] md:text-xs text-slate-500 font-medium">Affiliated to CBSE Board • Kokamthan, Kopargaon Motorway, MH</p>
                    </div>
                    <div className="bg-slate-100 border border-slate-300 text-[10px] font-black text-slate-700 px-3 py-1 rounded-md uppercase tracking-wider">
                      Evaluation Scorebook
                    </div>
                  </div>

                  {/* Title */}
                  <div className="text-center mb-6">
                    <h2 className="text-lg font-extrabold text-slate-900 tracking-tight uppercase">ACADEMIC WORKLIST CLASS MARKS SHEET</h2>
                    <p className="text-[11px] text-slate-500 font-medium mt-0.5">Approved Syllabus Chapter Evaluation Ledger (Page 1 of 2)</p>
                  </div>

                  {/* Metadata Information Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 mb-4">
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Class / Section</span>
                      <span className="text-xs font-black text-slate-900">{activeTestClass?.name || 'Class N/A'}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Syllabus Subject</span>
                      <span className="text-xs font-black text-slate-900">{activeTest.subject}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Curriculum Month</span>
                      <span className="text-xs font-black text-slate-900">{activeTest.month}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Conducted Date</span>
                      <span className="text-xs font-black text-slate-900">
                        {new Date(activeTest.testDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6">
                    <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Chapter / Syllabus Topic Evaluated</span>
                    <span className="text-xs md:text-sm font-black text-blue-700 mt-0.5 block">{activeTest.testName}</span>
                  </div>

                  {/* Stats Dashboard */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                    {(() => {
                      const stats = calculateTestStats(activeTest.id);
                      return (
                        <>
                          <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                            <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Max Score Scale</span>
                            <span className="text-sm font-black text-indigo-700">{activeTest.maxMarks} Marks</span>
                          </div>
                          <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                            <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Class Average</span>
                            <span className="text-sm font-black text-slate-900">{stats.count > 0 ? `${stats.avg} / ${activeTest.maxMarks}` : 'N/A'}</span>
                          </div>
                          <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                            <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Pass Rate</span>
                            <span className="text-sm font-black text-green-700">{stats.count > 0 ? `${stats.passRate}%` : 'N/A'}</span>
                          </div>
                          <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                            <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Total Strength</span>
                            <span className="text-sm font-black text-slate-800">{activeTestStudents.length} Students <span className="text-[10px] text-slate-400 font-normal">({stats.absent} Abs)</span></span>
                          </div>
                        </>
                      );
                    })()}
                  </div>

                  {/* Main Score Sheet Table - Page 1 */}
                  <div className="overflow-x-auto border border-slate-200 rounded-xl mb-4">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-200">
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Roll No</th>
                          <th className="py-2.5 px-4 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[40%] border-r border-slate-200">Student Name</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[18%] text-center border-r border-slate-200">Marks Obtained</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[12%] text-center border-r border-slate-200">Percentage</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Status</th>
                          <th className="py-2.5 px-4 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[20%]">Grading Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {firstHalf.map(student => {
                          const rowState = { marks: '', isAbsent: false, remarks: '', ...(localMarks[student.id] || {}) } as { marks: number | ''; isAbsent: boolean; remarks: string };
                          const scoreStr = rowState.isAbsent ? 'Absent' : (rowState.marks === '' ? '--' : `${rowState.marks} / ${activeTest.maxMarks}`);
                          const pctStr = (!rowState.isAbsent && rowState.marks !== '') 
                            ? `${Math.round((Number(rowState.marks) / activeTest.maxMarks) * 100)}%` 
                            : '--';
                          const statusStr = rowState.isAbsent ? 'ABSENT' : 'PRESENT';
                          
                          return (
                            <tr key={student.id} className="hover:bg-slate-50/50">
                              <td className="py-2 px-3 font-bold text-slate-600 font-mono text-center border-r border-slate-100">{student.rollNumber}</td>
                              <td className="py-2 px-4 font-bold text-slate-800 border-r border-slate-100">
                                <span className="whitespace-nowrap truncate text-[10px] sm:text-xs max-w-[85px] sm:max-w-none block" title={student.name}>
                                  {student.name}
                                </span>
                              </td>
                              <td className={`py-2 px-3 font-extrabold text-center border-r border-slate-100 ${rowState.isAbsent ? 'text-red-600' : 'text-slate-900'}`}>{scoreStr}</td>
                              <td className="py-2 px-3 font-bold text-slate-700 text-center border-r border-slate-100">{pctStr}</td>
                              <td className="py-2 px-3 text-center border-r border-slate-100">
                                <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                                  rowState.isAbsent ? 'bg-red-100 text-red-700 animate-pulse' : 'bg-green-100 text-green-700'
                                }`}>
                                  {statusStr}
                                </span>
                              </td>
                              <td className="py-2 px-4 text-xs text-slate-500 italic font-semibold">{rowState.remarks || '--'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Page 1 Footer */}
                  <div className="flex justify-between items-center mt-auto pt-4 text-[10px] text-slate-400 font-bold border-t border-slate-100">
                    <span>SAMATA INTERNATIONAL SCHOOL • Copy of Marks Registry</span>
                    <span>Page 1 of 2 (Students 1 - {halfIndex})</span>
                  </div>

                </div>

                {/* PAGE 2 OF 2 */}
                <div className={`printable-paper-sheet w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl relative border border-slate-200 ${
                  secondHalf.length > 38 ? 'ultra-dense-layout' :
                  secondHalf.length > 28 ? 'super-dense-layout' :
                  secondHalf.length > 18 ? 'dense-layout' : 'p-8 md:p-12'
                } mb-8 print:mb-0`}>
              
                  {/* Header / Letterhead */}
                  <div className="border-b-2 border-dashed border-slate-300 pb-4 mb-6 flex items-center justify-between">
                    <div>
                      <h1 className="text-xl md:text-2xl font-black text-slate-950 tracking-tight leading-tight">SAMATA INTERNATIONAL SCHOOL</h1>
                      <p className="text-[10px] md:text-xs text-slate-500 font-medium">Affiliated to CBSE Board • Kokamthan, Kopargaon Motorway, MH</p>
                    </div>
                    <div className="bg-slate-100 border border-slate-300 text-[10px] font-black text-slate-700 px-3 py-1 rounded-md uppercase tracking-wider">
                      Evaluation Scorebook
                    </div>
                  </div>

                  {/* Title */}
                  <div className="text-center mb-6">
                    <h2 className="text-lg font-extrabold text-slate-900 tracking-tight uppercase">ACADEMIC WORKLIST CLASS MARKS SHEET</h2>
                    <p className="text-[11px] text-slate-500 font-medium mt-0.5">Approved Syllabus Chapter Evaluation Ledger (Page 2 of 2)</p>
                  </div>

                  {/* Metadata Information Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 mb-4">
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Class / Section</span>
                      <span className="text-xs font-black text-slate-900">{activeTestClass?.name || 'Class N/A'}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Syllabus Subject</span>
                      <span className="text-xs font-black text-slate-900">{activeTest.subject}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Curriculum Month</span>
                      <span className="text-xs font-black text-slate-900">{activeTest.month}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Conducted Date</span>
                      <span className="text-xs font-black text-slate-900">
                        {new Date(activeTest.testDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                  </div>

                  {/* Main Score Sheet Table - Page 2 */}
                  <div className="overflow-x-auto border border-slate-200 rounded-xl mb-4">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-200">
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Roll No</th>
                          <th className="py-2.5 px-4 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[40%] border-r border-slate-200">Student Name</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[18%] text-center border-r border-slate-200">Marks Obtained</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[12%] text-center border-r border-slate-200">Percentage</th>
                          <th className="py-2.5 px-3 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Status</th>
                          <th className="py-2.5 px-4 font-bold text-slate-700 text-[10px] uppercase tracking-wider w-[20%]">Grading Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {secondHalf.map(student => {
                          const rowState = { marks: '', isAbsent: false, remarks: '', ...(localMarks[student.id] || {}) } as { marks: number | ''; isAbsent: boolean; remarks: string };
                          const scoreStr = rowState.isAbsent ? 'Absent' : (rowState.marks === '' ? '--' : `${rowState.marks} / ${activeTest.maxMarks}`);
                          const pctStr = (!rowState.isAbsent && rowState.marks !== '') 
                            ? `${Math.round((Number(rowState.marks) / activeTest.maxMarks) * 100)}%` 
                            : '--';
                          const statusStr = rowState.isAbsent ? 'ABSENT' : 'PRESENT';
                          
                          return (
                            <tr key={student.id} className="hover:bg-slate-50/50">
                              <td className="py-2 px-3 font-bold text-slate-600 font-mono text-center border-r border-slate-100">{student.rollNumber}</td>
                              <td className="py-2 px-4 font-bold text-slate-800 border-r border-slate-100">
                                <span className="whitespace-nowrap truncate text-[10px] sm:text-xs max-w-[85px] sm:max-w-none block" title={student.name}>
                                  {student.name}
                                </span>
                              </td>
                              <td className={`py-2 px-3 font-extrabold text-center border-r border-slate-100 ${rowState.isAbsent ? 'text-red-600' : 'text-slate-900'}`}>{scoreStr}</td>
                              <td className="py-2 px-3 font-bold text-slate-700 text-center border-r border-slate-100">{pctStr}</td>
                              <td className="py-2 px-3 text-center border-r border-slate-100">
                                <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                                  rowState.isAbsent ? 'bg-red-100 text-red-700 animate-pulse' : 'bg-green-100 text-green-700'
                                }`}>
                                  {statusStr}
                                </span>
                              </td>
                              <td className="py-2 px-4 text-xs text-slate-500 italic font-semibold">{rowState.remarks || '--'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Footer Signature Blocks */}
                  <div className="grid grid-cols-3 gap-6 pt-6 mt-auto border-t border-dashed border-slate-200 text-center">
                    <div>
                      <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider">
                        {testTeacher}
                      </div>
                      <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">ALLOTTED SUBJECT TEACHER</div>
                    </div>
                    <div className="relative">
                      {activeReview && (
                        <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                          <div className="border-2 border-double border-indigo-600/75 text-indigo-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[4deg] bg-white/95 scale-90 shadow-sm leading-tight">
                            <div className="text-[6px] border-b border-indigo-600/75 pb-0.5 leading-none">★ AUDITOR PORTFOLIO ★</div>
                            <div className="text-[8px] font-extrabold my-0.5 leading-none">VP AUDIT PASSED</div>
                            <div className="text-[6px] border-t border-indigo-600/75 pt-0.5 mt-0.5 leading-none">
                              {activeReview.verifiedAt || 'VERIFIED'}
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider">
                        {activeReview ? '✓ AUDIT VERIFIED' : 'REGISTRY VERIFIED'}
                      </div>
                      <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">REGISTRY CONTROLLER DATE</div>
                    </div>
                    <div className="relative">
                      {activeReview && (
                        <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                          <div className="border-2 border-double border-rose-600/75 text-rose-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[-3deg] bg-white/95 scale-90 shadow-sm leading-tight">
                            <div className="text-[6px] border-b border-rose-600/75 pb-0.5 leading-none">★ SAMATA INT. SCHOOL ★</div>
                            <div className="text-[8px] font-extrabold my-0.5 leading-none">PRINCIPAL APPROVED</div>
                            <div className="text-[6px] border-t border-rose-600/75 pt-0.5 mt-0.5 leading-none">
                              {activeReview.verifiedBy.replace(/\s*\(Academic Audit\)/g, '')}
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider">
                        {activeReview ? '✓ APPROVED ONLINE' : 'PRINCIPAL SEAL & SIGN'}
                      </div>
                      <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">SAMATA INTERNATIONAL SCHOOL</div>
                    </div>
                  </div>

                  {/* Page 2 Footer */}
                  <div className="flex justify-between items-center mt-4 pt-2 text-[10px] text-slate-400 font-bold border-t border-slate-100">
                    <span>SAMATA INTERNATIONAL SCHOOL • Copy of Marks Registry</span>
                    <span>Page 2 of 2 (Students {halfIndex + 1} - {totalStudentsCount})</span>
                  </div>

                </div>
              </div>
        </div>,
        document.body
      );
    })()
  )}

    </div>
  );
}
