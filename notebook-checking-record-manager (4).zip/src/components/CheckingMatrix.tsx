import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { SchoolClass, MonthlyTask, CheckingRecord, NotebookStatus, UserSession, ManagementReview } from '../types';
import { TeacherAllotment } from '../data/teacherData';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XOctagon, 
  HelpCircle, 
  Search, 
  User, 
  MessageSquare, 
  ChevronRight, 
  Sparkles, 
  FolderCheck,
  Download,
  Maximize2,
  Trash2,
  LayoutGrid,
  CheckSquare,
  Clock,
  Lock,
  Bell,
  Calendar,
  Printer,
  CloudUpload,
  Check,
  RefreshCw
} from 'lucide-react';

interface CheckingMatrixProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  onUpdateRecord: (studentId: string, taskId: string, status: NotebookStatus, notes: string) => void;
  onClearRecord: (studentId: string, taskId: string) => void;
  onUpdateMultipleRecords?: (updates: { studentId: string; taskId: string; status: NotebookStatus; notes: string }[]) => void;
  onClearMultipleRecords?: (clears: { studentId: string; taskId: string }[]) => void;
  allotments: TeacherAllotment[];
  currentUser: UserSession | null;
  statusFilter?: 'all' | 'checked' | 'incomplete' | 'missing' | 'pending' | 'unchecked';
  onStatusFilterChange?: (filter: 'all' | 'checked' | 'incomplete' | 'missing' | 'pending' | 'unchecked') => void;
  onSyncWithServer?: () => Promise<void>;
  managementReviews?: ManagementReview[];
}

export default function CheckingMatrix({
  classes,
  tasks,
  records,
  onUpdateRecord,
  onClearRecord,
  onUpdateMultipleRecords,
  onClearMultipleRecords,
  allotments,
  currentUser,
  statusFilter,
  onStatusFilterChange,
  onSyncWithServer,
  managementReviews
}: CheckingMatrixProps) {
  
  const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
    if (!allotTeacher || !userTeacher) return false;
    const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const cleanAllot = cleanStr(allotTeacher);
    const cleanUser = cleanStr(userTeacher);
    if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
    
    const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
    const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    
    for (const allotW of allotWords) {
      for (const userW of userWords) {
        if (allotW.includes(userW) || userW.includes(allotW)) return true;
      }
    }
    return false;
  };

  // Safe Cell Record Finder
  const getCellRecord = (studentId: string, taskId: string) => {
    return records.find(r => r.studentId === studentId && r.taskId === taskId) || {
      status: 'unchecked' as NotebookStatus,
      notes: ''
    };
  };

  // Real-time Save & Sync state feedback
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('saved');
  const [lastSaved, setLastSaved] = useState<string>('');
  const [isManualSyncing, setIsManualSyncing] = useState<boolean>(false);

  const handleSaveAndSyncAll = async () => {
    setIsManualSyncing(true);
    setSaveStatus('saving');
    
    try {
      // Execute the real parent sync to transfer all local checked records to the server database
      if (onSyncWithServer) {
        await onSyncWithServer();
      }
      
      setSaveStatus('saved');
      setLastSaved(new Date().toLocaleTimeString());
      
      // Dispatch sync events to alert offline worker and database providers
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('storage'));
        // Custom broadcast for any other listening views
        window.dispatchEvent(new CustomEvent('notebook-sync-complete', {
          detail: { timestamp: new Date().toISOString() }
        }));
      }
    } catch (err) {
      console.error("[Manual Sync] Synchronization process aborted due to network issue:", err);
    } finally {
      setIsManualSyncing(false);
    }
  };

  React.useEffect(() => {
    setSaveStatus('saving');
    const timer = setTimeout(() => {
      setSaveStatus('saved');
      setLastSaved(new Date().toLocaleTimeString());
    }, 450);
    return () => clearTimeout(timer);
  }, [records]);

  // Active simulated clock day (defaults to 25 of the month representing active data entry / approach date)
  const [simulatedDay, setSimulatedDay] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  const handleSimulatedDayChange = (day: number) => {
    setSimulatedDay(day);
    localStorage.setItem('nb_audit_simulated_day', day.toString());
    window.dispatchEvent(new Event('storage'));
  };

  React.useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('nb_audit_simulated_day');
      if (saved) {
        const val = parseInt(saved);
        if (val !== simulatedDay) {
          setSimulatedDay(val);
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [simulatedDay]);

  // Helper to match class name to allotment grade
  const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
    if (!className || !allotmentGrade) return false;
    const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
    const c1 = clean(className);
    const c2 = clean(allotmentGrade);
    return c1 === c2;
  };

  // Filtering states
  const [selectedClassId, setSelectedClassId] = useState<string>(() => {
    const saved = localStorage.getItem('nb_matrix_selected_class_id');
    if (saved && classes.some(c => c.id === saved)) {
      if (currentUser?.role === 'teacher') {
        const allowed = classes.filter(c => {
          const allotment = allotments?.find(
            a => isClassMatchAllotment(c.name, a.grade)
          );
          if (!allotment) return false;
          if (isTeacherNameMatched(allotment.classTeacher, currentUser.name)) return true;
          return Object.values(allotment.subjects || {}).some(tName => 
            isTeacherNameMatched(tName, currentUser.name)
          );
        });
        if (allowed.some(c => c.id === saved)) return saved;
      } else {
        return saved;
      }
    }
    if (currentUser?.role === 'teacher') {
      const allowed = classes.filter(c => {
        const allotment = allotments?.find(
          a => isClassMatchAllotment(c.name, a.grade)
        );
        if (!allotment) return false;
        if (isTeacherNameMatched(allotment.classTeacher, currentUser.name)) return true;
        return Object.values(allotment.subjects || {}).some(tName => 
          isTeacherNameMatched(tName, currentUser.name)
        );
      });
      return allowed[0]?.id || '';
    }
    return classes[0]?.id || '';
  });
  const [selectedSubject, setSelectedSubject] = useState<string>(() => {
    return localStorage.getItem('nb_matrix_selected_subject') || 'Math';
  });
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    return localStorage.getItem('nb_audit_selected_month') || 'June 2026';
  });
  
  // Search
  const [searchQuery, setSearchQuery] = useState('');

  // Fallback local status filter
  const [localStatusFilter, setLocalStatusFilter] = useState<'all' | 'checked' | 'incomplete' | 'missing' | 'pending' | 'unchecked'>('all');
  const activeStatusFilter = statusFilter !== undefined ? statusFilter : localStatusFilter;
  const handleStatusFilterChange = (val: 'all' | 'checked' | 'incomplete' | 'missing' | 'pending' | 'unchecked') => {
    if (onStatusFilterChange) {
      onStatusFilterChange(val);
    } else {
      setLocalStatusFilter(val);
    }
  };
  
  // View types: 'matrix' (desk) or 'card' (swipeable mobile checks)
  const [viewType, setViewType] = useState<'matrix' | 'focused'>('matrix');
  const [focusedTaskId, setFocusedTaskId] = useState<string>('');

  // Selected cell for commenting
  const [commentingCell, setCommentingCell] = useState<{ studentId: string; taskId: string } | null>(null);
  const [tempNotes, setTempNotes] = useState('');

  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [printError, setPrintError] = useState<string | null>(null);

  const [selectedTeacherPrint, setSelectedTeacherPrint] = useState<string>('Current Selection');
  const [selectedPrintMonth, setSelectedPrintMonth] = useState<string>(selectedMonth);
  const [printLayoutDensity, setPrintLayoutDensity] = useState<'normal' | 'dense'>('dense');

  React.useEffect(() => {
    setSelectedPrintMonth(selectedMonth);
  }, [selectedMonth]);

  // Get unique teachers list for printing
  const getTeachersList = () => {
    const list = new Set<string>();
    allotments.forEach(allot => {
      Object.values(allot.subjects || {}).forEach(teacherName => {
        if (teacherName && teacherName.trim()) {
          list.add(teacherName.replace(/\.$/, '').trim());
        }
      });
    });
    return Array.from(list).sort();
  };

  // Find all allotments to print based on selected teacher and month
  const getPagesToPrint = () => {
    if (selectedTeacherPrint === 'Current Selection') {
      return [{
        classObj: activeClass,
        subject: selectedSubject,
        teacher: getAssignedTeacher(activeClass.id, selectedSubject)
      }];
    }
    
    const teachers = selectedTeacherPrint === 'All Teachers' 
      ? getTeachersList() 
      : [selectedTeacherPrint];
      
    const pages: { classObj: SchoolClass; subject: string; teacher: string }[] = [];
    
    teachers.forEach(teacher => {
      allotments.forEach(allot => {
        Object.entries(allot.subjects || {}).forEach(([subjectName, tName]) => {
          if (isTeacherNameMatched(tName, teacher)) {
            const matchedClass = classes.find(c => isClassMatchAllotment(c.name, allot.grade));
            if (matchedClass) {
              pages.push({
                classObj: matchedClass,
                subject: subjectName,
                teacher: tName
              });
            }
          }
        });
      });
    });
    
    return pages;
  };

  const allAvailableMonths = Array.from(new Set(tasks.map(t => t.month))).sort();

  // Helper to lookup allotted teacher
  const getAssignedTeacher = (classId: string, subjectName: string): string => {
    const foundClass = classes.find(c => c.id === classId);
    if (!foundClass) return 'Staff Teacher';
    const allotment = allotments.find(
      a => isClassMatchAllotment(foundClass.name, a.grade)
    );
    if (allotment) {
      return allotment.subjects[subjectName] || allotment.classTeacher || 'Staff Teacher';
    }
    return 'Staff Teacher';
  };

  // Helper to check if subject is assigned to teacher
  const isSubjectAssignedToTeacher = (className: string, subjectName: string, teacherName: string): boolean => {
    const allotment = allotments?.find(
      a => isClassMatchAllotment(className, a.grade)
    );
    if (!allotment) return false;
    const assigned = allotment.subjects[subjectName];
    return isTeacherNameMatched(assigned, teacherName);
  };

  // Allowed Classes for Faculty vs Admin
  const allowedClasses = currentUser && currentUser.role === 'teacher'
    ? classes.filter(c => {
        const allotment = allotments?.find(
          a => isClassMatchAllotment(c.name, a.grade)
        );
        if (!allotment) return false;
        if (isTeacherNameMatched(allotment.classTeacher, currentUser.name)) return true;
        return Object.values(allotment.subjects || {}).some(tName => 
          isTeacherNameMatched(tName, currentUser.name)
        );
      })
    : classes;

  // Sync selectedClassId with allowedClasses if it's invalid
  React.useEffect(() => {
    if (allowedClasses.length > 0) {
      if (!selectedClassId || !allowedClasses.some(c => c.id === selectedClassId)) {
        setSelectedClassId(allowedClasses[0].id);
      }
    }
  }, [allowedClasses, selectedClassId]);

  const activeClass = classes.find(c => c.id === selectedClassId);

  // Derive unique list of subjects and months from total tasks list
  const activeClassTasks = tasks.filter(t => t.classId === selectedClassId);
  const classSubjects = Array.from(new Set(activeClassTasks.map(t => t.subject)));
  const classMonths = Array.from(new Set(activeClassTasks.map(t => t.month)));

  // Filter subjects for teachers
  const allowedSubjects = currentUser && currentUser.role === 'teacher' && activeClass
    ? classSubjects.filter(sub => isSubjectAssignedToTeacher(activeClass.name, sub, currentUser.name))
    : classSubjects;

  // Fallbacks if current subject or month is not active in this class
  React.useEffect(() => {
    if (allowedSubjects.length > 0 && !allowedSubjects.includes(selectedSubject)) {
      setSelectedSubject(allowedSubjects[0]);
      localStorage.setItem('nb_matrix_selected_subject', allowedSubjects[0]);
    }
    if (classMonths.length > 0 && !classMonths.includes(selectedMonth)) {
      setSelectedMonth(classMonths[0]);
      localStorage.setItem('nb_audit_selected_month', classMonths[0]);
    }
  }, [selectedClassId, activeClassTasks, allowedSubjects, classMonths, selectedSubject, selectedMonth]);

  // Tasks corresponding to the selected Class + Subject + Month
  const currentTasks = tasks.filter(t => 
    t.classId === selectedClassId && 
    t.subject === selectedSubject && 
    t.month === selectedMonth
  );

  // Initialize focused task
  React.useEffect(() => {
    if (currentTasks.length > 0) {
      setFocusedTaskId(currentTasks[0].id);
    } else {
      setFocusedTaskId('');
    }
  }, [selectedClassId, selectedSubject, selectedMonth, tasks]);

  if (!activeClass) {
    return (
      <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-8 border border-white/10 text-center shadow-lg">
        <FolderCheck className="w-12 h-12 text-slate-400 mx-auto mb-3" />
        <p className="text-white text-base font-extrabold">Rosters Missing</p>
        <p className="text-slate-400 text-xs mt-1">Please create a class and register students to access the checking matrix.</p>
      </div>
    );
  }

  // Filter students in directory based on search query and status filters
  const filteredStudents = activeClass.students.filter(student => {
    // Search match
    const matchesSearch = student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          student.rollNumber.includes(searchQuery);
    if (!matchesSearch) return false;

    // Status filter match
    if (activeStatusFilter === 'all') return true;

    // Check records for this student and current tasks
    if (currentTasks.length === 0) {
      return activeStatusFilter === 'unchecked';
    }

    const studentRecords = currentTasks.map(t => getCellRecord(student.id, t.id));

    if (activeStatusFilter === 'checked') {
      return studentRecords.some(r => r.status === 'checked');
    }
    if (activeStatusFilter === 'incomplete') {
      return studentRecords.some(r => r.status === 'incomplete');
    }
    if (activeStatusFilter === 'missing') {
      return studentRecords.some(r => r.status === 'missing');
    }
    if (activeStatusFilter === 'pending') {
      return studentRecords.some(r => r.status === 'incomplete' || r.status === 'missing');
    }
    if (activeStatusFilter === 'unchecked') {
      return studentRecords.some(r => r.status === 'unchecked');
    }

    return true;
  });

  // Status helper renderer
  const getStatusConfig = (status: NotebookStatus) => {
    switch (status) {
      case 'checked':
        return { 
          icon: <CheckCircle2 className="w-2 h-2 sm:w-4 sm:h-4 text-emerald-400 fill-emerald-500/10 shrink-0" />, 
          bg: 'bg-emerald-500/10 border-emerald-500/15 hover:bg-emerald-500/20', 
          text: 'text-emerald-300',
          label: 'Checked'
        };
      case 'incomplete':
        return { 
          icon: <AlertTriangle className="w-2 h-2 sm:w-4 sm:h-4 text-amber-400 fill-amber-500/10 shrink-0" />, 
          bg: 'bg-amber-500/10 border-amber-500/15 hover:bg-amber-500/20', 
          text: 'text-amber-300',
          label: 'Incomplete'
        };
      case 'missing':
        return { 
          icon: <XOctagon className="w-2 h-2 sm:w-4 sm:h-4 text-rose-400 fill-rose-500/10 shrink-0" />, 
          bg: 'bg-rose-500/10 border-rose-500/15 hover:bg-rose-500/20', 
          text: 'text-rose-300',
          label: 'Missing'
        };
      default:
        return { 
          icon: <HelpCircle className="w-2 h-2 sm:w-4 sm:h-4 text-slate-500 shrink-0" />, 
          bg: 'bg-white/5 border-white/5 hover:bg-white/10', 
          text: 'text-slate-400', 
          label: 'Pending'
        };
    }
  };

  // Cycle status on cell click
  const handleCellClickStatusCycle = (studentId: string, taskId: string) => {
    if (currentUser?.role === 'management') return;
    const record = getCellRecord(studentId, taskId);
    let nextStatus: NotebookStatus = 'unchecked';
    
    if (record.status === 'unchecked') nextStatus = 'checked';
    else if (record.status === 'checked') nextStatus = 'incomplete';
    else if (record.status === 'incomplete') nextStatus = 'missing';
    else if (record.status === 'missing') nextStatus = 'unchecked';

    onUpdateRecord(studentId, taskId, nextStatus, record.notes || '');
  };

  // Open Notes Modal
  const editRemarks = (studentId: string, taskId: string, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent cycling status
    const record = getCellRecord(studentId, taskId);
    setCommentingCell({ studentId, taskId });
    setTempNotes(record.notes || '');
  };

  const saveRemarks = () => {
    if (currentUser?.role === 'management') return;
    if (!commentingCell) return;
    const record = getCellRecord(commentingCell.studentId, commentingCell.taskId);
    onUpdateRecord(commentingCell.studentId, commentingCell.taskId, record.status, tempNotes);
    setCommentingCell(null);
  };

  // Mass Mark Action
  const handleMassAction = (taskId: string, targetStatus: NotebookStatus) => {
    if (currentUser?.role === 'management') return;
    const task = currentTasks.find(t => t.id === taskId);
    if (!task) return;

    if (confirm(`Bulk action: Mark ALL students for task "${task.title}" as ${targetStatus.toUpperCase()}?`)) {
      filteredStudents.forEach(student => {
        const record = getCellRecord(student.id, taskId);
        onUpdateRecord(student.id, taskId, targetStatus, record.notes || '');
      });
    }
  };

  // Export class report to CSV file
  const handleCSVExport = () => {
    if (currentTasks.length === 0) {
      alert('No monthly syllabus tasks found for this configuration to generate a report.');
      return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    // Title header
    csvContent += `Notebook Checking Report - ${activeClass.name} - ${selectedSubject} - ${selectedMonth}\n\n`;
    // Table Headers
    const headers = ["Roll No", "Student Name", ...currentTasks.map(t => `"${t.title}"`), "Completion Rate %"];
    csvContent += headers.join(",") + "\n";

    // Rows
    activeClass.students.forEach(student => {
      let score = 0;
      const rowData = [
        student.rollNumber,
        `"${student.name}"`
      ];

      currentTasks.forEach(task => {
        const rec = getCellRecord(student.id, task.id);
        rowData.push(`"${rec.status.toUpperCase()}${rec.notes ? ` - ${rec.notes}` : ''}"`);
        if (rec.status === 'checked') score++;
      });

      const pct = currentTasks.length > 0 ? Math.round((score / currentTasks.length) * 100) : 0;
      rowData.push(`${pct}%`);
      csvContent += rowData.join(",") + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `notebook_checking_${selectedClassId}_${selectedSubject.toLowerCase().replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export ALL school levels data to CSV / Excel
  const handleFullSchoolCSVExport = () => {
    let csvContent = "\ufeff"; // BOM for Excel UTF-8 compliance
    csvContent += "Class,Roll No,Student Name,Subject,Month,Task Title,Checking Status,Teacher Remarks\n";

    classes.forEach(clazz => {
      clazz.students.forEach(student => {
        const classTasks = tasks.filter(t => t.classId === clazz.id);
        classTasks.forEach(task => {
          const rec = getCellRecord(student.id, task.id);
          const status = rec.status ? rec.status.toUpperCase() : "UNCHECKED";
          // Escape quotes in student remarks
          const notes = rec.notes ? rec.notes.replace(/"/g, '""') : "";
          const escapedSubject = task.subject.replace(/"/g, '""');
          const escapedTitle = task.title.replace(/"/g, '""');
          
          csvContent += `"${clazz.name}","${student.rollNumber}","${student.name}","${escapedSubject}","${task.month}","${escapedTitle}","${status}","${notes}"\n`;
        });
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `samata_notebook_audit_full_school_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="checking_record_matrix" className="space-y-6">

      {currentUser?.role === 'management' && (
        <div className="bg-sky-500/10 border border-sky-500/25 text-sky-200 px-4 py-3 rounded-2xl flex items-center gap-2.5 text-xs font-bold leading-relaxed no-print">
          <span>🛡️</span>
          <div>
            <strong>Management Read-Only Audit Mode:</strong> You are auditing this notebook checking matrix. Click-to-cycle statuses, bulk modifications, and remarks logs edits are disabled. Submit reviews in the <strong>'Management Verification'</strong> panel.
          </div>
        </div>
      )}

      {/* 🔔 DEADLINE ALERT BANNER */}
      {(() => {
        const banner = (() => {
          if (simulatedDay <= 24) {
            const daysLeft = 25 - simulatedDay;
            return {
              phase: 'Syllabus Planner Progress Phase',
              status: `${daysLeft} Day${daysLeft === 1 ? '' : 's'} Left`,
              badgeColor: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
              bgGradient: 'from-indigo-950/40 via-slate-900/40 to-slate-950/40 border-indigo-500/20',
              title: 'Syllabus Completion Deadline is Approaching!',
              description: `All subject teachers must finish syllabus planning and log completed chapters by the 25th at 23:59. You have ${daysLeft} day${daysLeft === 1 ? '' : 's'} remaining to complete logging of the active June 2026 course chapters.`,
              nudgeText: 'Please review your Lesson Journals and click cells to cycle student work corrections.',
              icon: <Clock className="w-5 h-5 text-indigo-400 animate-pulse" />
            };
          } else if (simulatedDay === 25) {
            return {
              phase: 'SYLLABUS COMPLETION DEADLINE TODAY',
              status: 'ACTION REQUIRED TODAY',
              badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30 animate-pulse',
              bgGradient: 'from-rose-950/40 via-slate-900/40 to-slate-950/40 border-rose-500/40 shadow-rose-500/5',
              title: '🚨 CRITICAL SYLLABUS DEADLINE LOCKOUT!',
              description: 'Today is the 25th! Syllabus completion recording closes tonight. Teachers must log teaching progress for all subjects now.',
              nudgeText: 'Action required: Complete all logs in detail. Post-25th entries of teaching logs are blocked for audit.',
              icon: <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
            };
          } else if (simulatedDay >= 25 && simulatedDay <= 28) {
            const daysLeft = 28 - simulatedDay;
            return {
              phase: 'DATA ENTRY ACTIVE WINDOW',
              status: daysLeft === 0 ? 'CLOSES TONIGHT' : `${daysLeft} Day${daysLeft === 1 ? '' : 's'} Left`,
              badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30 animate-pulse',
              bgGradient: 'from-amber-950/40 via-slate-900/40 to-slate-950/40 border-amber-500/40 shadow-amber-500/5',
              title: '⚡ Marks & Notebook Correction Updates Open!',
              description: `Active entries window (25th-28th). You have ${daysLeft === 0 ? 'LESS THAN A DAY' : `${daysLeft} day${daysLeft === 1 ? '' : 's'}`} remaining to update Unit Test evaluation metrics and log notebook check status registers.`,
              nudgeText: 'All subject teachers must input results. Data entry closes on the 28th for administrative management reviews.',
              icon: <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
            };
          } else {
            const daysLeft = 30 - simulatedDay;
            return {
              phase: 'MANAGEMENT REVIEW PERIOD',
              status: 'ENTRIES LOCKED - AUDIT STAGE',
              badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
              bgGradient: 'from-emerald-950/40 via-slate-900/40 to-slate-950/40 border-emerald-500/20',
              title: '🔒 Quality Verification Audit in Progress',
              description: 'The entries window has locked. Management is currently reviewing syllabus delivery metrics and student workbook checking registers.',
              nudgeText: 'Read-only alignment: Principals endorsement clears grade allotments and publishes progress reports.',
              icon: <Lock className="w-5 h-5 text-emerald-400" />
            };
          }
        })();

        return (
          <div className={`bg-gradient-to-r ${banner.bgGradient} border rounded-3xl p-5 relative overflow-hidden shadow-xl leading-relaxed animate-fade-in`}>
            <div className="absolute top-0 right-0 h-32 w-32 bg-white/2 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div className="flex items-start gap-3.5">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10 shrink-0">
                  {banner.icon}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                      {banner.phase}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wide border ${banner.badgeColor}`}>
                      {banner.status}
                    </span>
                  </div>
                  <h4 className="text-white text-sm font-black tracking-tight">{banner.title}</h4>
                  <p className="text-slate-300 text-xs mt-1 max-w-3xl leading-relaxed font-medium">
                    {banner.description}
                  </p>
                  <p className="text-slate-400 text-[11px] mt-2 italic flex items-center gap-1.5 font-sans">
                    <Bell className="w-3.5 h-3.5 shrink-0" />
                    <span>{banner.nudgeText}</span>
                  </p>
                </div>
              </div>

              {/* Simulation controller widget inside the warning banner */}
              <div className="shrink-0 bg-slate-950/80 border border-white/5 p-4 rounded-2xl flex flex-col items-center min-w-[210px] gap-2">
                <div className="text-center">
                  <span className="text-[9px] text-slate-550 font-black block uppercase tracking-wider">
                    Calendar Simulator
                  </span>
                  <span className="text-xs font-black text-indigo-300 block mt-0.5">
                    {selectedMonth.split(' ')[0]} {simulatedDay}, {selectedMonth.split(' ')[1]}
                  </span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="30" 
                  value={simulatedDay}
                  onChange={(e) => handleSimulatedDayChange(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 bg-slate-900 rounded-lg appearance-none h-1.5 cursor-pointer focus:outline-none" 
                />
                <div className="flex items-center justify-between w-full text-[8.5px] text-slate-500 font-bold px-1">
                  <span>Day 1</span>
                  <span>Day 25 (Due)</span>
                  <span>Day 30</span>
                </div>
                
                <div className="flex flex-col items-center w-full border-t border-white/5 pt-1.5 mt-0.5 gap-1">
                  <span className="text-[8px] text-slate-500 font-black uppercase tracking-wider">
                    Today: {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                  <button 
                    onClick={() => handleSimulatedDayChange(new Date().getDate())}
                    className="text-[8px] font-bold text-indigo-300 hover:text-indigo-200 transition-colors bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer uppercase"
                  >
                    📍 Use Today's Day
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* FILTER CONTROL PANEL */}
      <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10 shadow-2xl space-y-4">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="font-extrabold text-white text-base mb-1 flex flex-wrap items-center gap-2">
              <span>Notebook Audit Matrix</span>
              <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold border transition-all duration-350 flex items-center gap-1.5 ${
                saveStatus === 'saving'
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30 animate-pulse'
                  : 'bg-emerald-555/15 text-emerald-405 border-emerald-500/25 shadow-[0_0_6px_rgba(16,185,129,0.15)]'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${saveStatus === 'saving' ? 'bg-amber-400 animate-ping' : 'bg-emerald-450 animate-pulse'}`} />
                <span>{saveStatus === 'saving' ? 'Saving changes to cloud...' : 'All changes saved & synced'}</span>
              </span>
            </h3>
            <p className="text-slate-350 text-xs flex flex-wrap items-center gap-2">
              <span>Real-time digital record sheet. No manual saving required. Clicking any cell updates record instantly.</span>
              <span className="text-emerald-450 font-black bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/15">Auto-Save Enabled</span>
              {lastSaved && <span className="text-slate-450 text-[10px] bg-white/5 px-1.5 py-0.2 rounded border border-white/5">Synced at: {lastSaved}</span>}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewType('matrix')}
              className={`p-2 px-3 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                viewType === 'matrix' 
                  ? 'bg-white/10 border-white/15 text-white shadow-md' 
                  : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Spreadsheet Matrix
            </button>
            <button
              onClick={() => setViewType('focused')}
              className={`p-2 px-3 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer ${
                viewType === 'focused' 
                  ? 'bg-white/10 border-white/15 text-white shadow-md' 
                  : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Maximize2 className="w-3.5 h-3.5" /> Speed Grading Cards
            </button>
            <button
              onClick={handleCSVExport}
              className="p-2 px-3 bg-white/5 text-slate-300 rounded-xl hover:bg-white/10 text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-white/10 cursor-pointer shadow-sm"
              title="Download Current Class Sheet"
            >
              <Download className="w-3.5 h-3.5" /> Class CSV
            </button>

            <button
              onClick={() => setShowPrintModal(true)}
              className="p-2 px-3 bg-sky-600/15 border border-sky-500/25 text-sky-300 rounded-xl hover:bg-sky-600/25 text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-sm animate-fade-in"
              title="Print notebook checking report card or Save as physical PDF document"
            >
              <Printer className="w-3.5 h-3.5 text-sky-400" /> Print / PDF
            </button>
          </div>
        </div>

        {/* Dropdowns panel */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 bg-white/5 p-4 rounded-xl border border-white/10">
          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Grade Class</label>
            <select
              value={selectedClassId}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedClassId(val);
                localStorage.setItem('nb_matrix_selected_class_id', val);
              }}
              className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-bold text-slate-100"
            >
              {allowedClasses.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-950 text-white">{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Subject</label>
            <select
              value={selectedSubject}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedSubject(val);
                localStorage.setItem('nb_matrix_selected_subject', val);
              }}
              className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-bold text-slate-100"
            >
              {allowedSubjects.length > 0 ? (
                allowedSubjects.map(sub => (
                  <option key={sub} value={sub} className="bg-slate-950 text-white">
                    {sub === "SS" ? "S.S (Social Science)" : sub === "Computer" ? "Computer (IT)" : sub}
                  </option>
                ))
              ) : (
                <option value="Math" className="bg-slate-950 text-white">Math</option>
              )}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Checking Period</label>
            <select
              value={selectedMonth}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedMonth(val);
                localStorage.setItem('nb_audit_selected_month', val);
              }}
              className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-bold text-slate-100"
            >
              {classMonths.length > 0 ? (
                classMonths.map(m => (
                  <option key={m} value={m} className="bg-slate-950 text-white">{m}</option>
                ))
              ) : (
                <option value="April 2026" className="bg-slate-950 text-white">April 2026</option>
              )}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Status Filter</label>
            <select
              value={activeStatusFilter}
              onChange={(e) => handleStatusFilterChange(e.target.value as any)}
              className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-semibold text-slate-100"
            >
              <option value="all" className="bg-slate-950 text-white">All Records</option>
              <option value="checked" className="bg-slate-955 text-emerald-400 font-bold">Checked</option>
              <option value="incomplete" className="bg-slate-955 text-amber-400 font-bold">Incomplete</option>
              <option value="missing" className="bg-slate-955 text-rose-450 font-bold">Missing / Absent</option>
              <option value="pending" className="bg-slate-955 text-rose-300 font-extrabold">⚠️ Pending (Incomplete/Missing)</option>
              <option value="unchecked" className="bg-slate-955 text-slate-400">Unchecked</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Search Students</label>
            <div className="relative">
              <input
                type="text"
                placeholder="Roster search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-900 border border-white/10 rounded-lg focus:outline-none focus:border-indigo-500 font-bold text-slate-100 pl-8 placeholder-slate-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>

      </div>

      {/* MATRIX AND CARDS CONTAINER */}
      {currentTasks.length === 0 ? (
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-12 border border-white/10 shadow-2xl text-center">
          <FolderCheck className="w-14 h-14 text-indigo-400/80 mx-auto mb-3" />
          <h4 className="font-bold text-white text-base">No Task Plans for current selection</h4>
          <p className="text-slate-400 text-xs mt-1 max-w-md mx-auto">
            You haven't defined any notebook checking goals for <strong className="text-slate-200">{selectedClassId ? classes.find(c=>c.id === selectedClassId)?.name : 'selected class'}</strong> in <strong className="text-slate-200">{selectedSubject}</strong> during <strong className="text-slate-200">{selectedMonth}</strong>.
          </p>
          <div className="mt-5">
            <span className="text-xs text-indigo-300 font-bold border border-indigo-400/30 rounded-lg bg-indigo-500/10 p-2.5 px-4 cursor-pointer hover:bg-indigo-500/20 transition-all">
              Go to Monthly Planner tab to create checking tasks
            </span>
          </div>
        </div>
      ) : (
        <>
          {/* TASK COMPLETION PROGRESS OVERVIEW */}
          <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1 px-2.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded-full text-[10px] uppercase font-black tracking-widest flex items-center gap-1.5 shadow-sm">
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Submission Progress Tracker</span>
                </div>
              </div>
              <span className="text-[10px] text-slate-400 font-bold block">
                Class Size: {activeClass.students.length} Students
              </span>
            </div>

            <div className={`grid grid-cols-1 ${currentTasks.length === 1 ? 'md:grid-cols-1' : currentTasks.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-2 xl:grid-cols-3'} gap-4`}>
              {currentTasks.map(task => {
                const totalCount = activeClass.students.length;
                const checkedCount = activeClass.students.filter(student => getCellRecord(student.id, task.id).status === 'checked').length;
                const incompleteCount = activeClass.students.filter(student => getCellRecord(student.id, task.id).status === 'incomplete').length;
                const missingCount = activeClass.students.filter(student => getCellRecord(student.id, task.id).status === 'missing').length;
                const uncheckedCount = totalCount - checkedCount - incompleteCount - missingCount;

                const checkedPct = totalCount > 0 ? Math.round((checkedCount / totalCount) * 100) : 0;
                const incompletePct = totalCount > 0 ? Math.round((incompleteCount / totalCount) * 100) : 0;
                const missingPct = totalCount > 0 ? Math.round((missingCount / totalCount) * 100) : 0;

                return (
                  <div key={task.id} className="relative p-4 bg-slate-950/40 hover:bg-slate-950/60 border border-white/5 rounded-xl transition-all space-y-3 shadow-md group/prog">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h4 className="font-bold text-white text-xs truncate max-w-[190px] md:max-w-[240px]" title={task.title}>
                          {task.title}
                        </h4>
                        <p className="text-[10px] text-slate-400 font-medium lowercase">
                          Due: {new Date(task.dueDate).toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric'})}
                        </p>
                      </div>
                      
                      <div className="text-right">
                        <span className="text-sm font-black text-emerald-400 font-mono tracking-tight">{checkedPct}%</span>
                        <span className="block text-[9px] text-slate-400 font-semibold font-medium">Checked</span>
                      </div>
                    </div>

                    {/* Progress Bar Stack */}
                    <div className="space-y-1.5">
                      {/* Visual segment progress bar */}
                      <div className="w-full h-2.5 bg-white/5 rounded-full overflow-hidden flex border border-white/5 shadow-inner">
                        <div 
                          className="bg-emerald-500 transition-all duration-500 ease-out shadow-[0_0_8px_rgba(16,185,129,0.3)]"
                          style={{ width: `${checkedPct}%` }}
                          title={`Checked: ${checkedPct}%`}
                        />
                        <div 
                          className="bg-amber-400 transition-all duration-500 ease-out"
                          style={{ width: `${incompletePct}%` }}
                          title={`Incomplete: ${incompletePct}%`}
                        />
                        <div 
                          className="bg-rose-500 transition-all duration-500 ease-out"
                          style={{ width: `${missingPct}%` }}
                          title={`Missing: ${missingPct}%`}
                        />
                      </div>

                      {/* Small counter elements */}
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          <span>Checked: <strong className="text-emerald-300">{checkedCount}</strong></span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                          <span>Incomplete: <strong className="text-amber-300">{incompleteCount}</strong></span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                          <span>Missing: <strong className="text-rose-300">{missingCount}</strong></span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {viewType === 'matrix' ? (
            /* ================= SPREADSHEET MATRIX VIEW ================= */
            <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
              
              <div className="p-4 bg-white/5 border-b border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-semibold text-slate-300">
                <div className="flex flex-wrap items-center gap-2">
                  <Sparkles className="w-4.5 h-4.5 text-amber-400 shrink-0" />
                  <span>Click any cell to cycle notebook statuses:</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-350 text-[10px] rounded font-black">✓ Checked</span>
                  <span className="text-slate-500 text-[10px]">➜</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 text-amber-350 text-[10px] rounded font-black">⚠ Incomplete</span>
                  <span className="text-slate-500 text-[10px]">➜</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-500/10 border border-rose-500/20 text-rose-350 text-[10px] rounded font-black">✗ Absent/Missing</span>
                  <span className="text-slate-500 text-[10px]">➜</span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-white/5 border border-white/10 text-slate-400 text-[10px] rounded">Not Checked</span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold bg-slate-950/40 px-2.5 py-1.5 rounded-lg border border-white/5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <span>Dynamic Auto-Saving Active</span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 bg-white/5 text-slate-400 uppercase text-[8px] sm:text-[10px] font-semibold tracking-wider">
                      <th className="py-1.5 px-1 sm:py-4.5 sm:px-4 text-center w-8 sm:w-16 sticky left-0 bg-slate-920 border-r border-white/10 text-slate-350 z-20">Roll</th>
                      <th className="py-1.5 px-1 sm:py-4.5 sm:px-4 text-left w-20 sm:w-60 sticky left-8 sm:left-16 bg-slate-920 border-r border-white/15 text-slate-300 shadow-md z-20">Student</th>
                      
                      {/* Dynamic Month task columns headers */}
                      {currentTasks.map(task => (
                        <th key={task.id} className="py-1.5 px-1 sm:py-4.5 sm:px-4 text-center min-w-[50px] sm:min-w-[110px] border-r border-white/10">
                          <div className="space-y-0.5 sm:space-y-1">
                            <span className="block text-white text-[9px] sm:text-xs font-extrabold truncate max-w-[42px] sm:max-w-[100px]" title={task.title}>
                              {task.title}
                            </span>
                            <span className="block text-[7.5px] sm:text-[9.5px] text-slate-400 lowercase font-medium">
                              Due: {new Date(task.dueDate).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                            </span>
                            
                            {/* Mass complete & status selection widget (as drawn by user!) */}
                            <div className="pt-2 flex flex-col items-center justify-center gap-1 bg-slate-950/25 p-1 sm:p-2 rounded-xl border border-white/5 mt-1.5 z-10 relative">
                              <button 
                                onClick={() => {
                                  if (currentUser?.role === 'management') return;
                                  const allChecked = filteredStudents.length > 0 && filteredStudents.every(student => getCellRecord(student.id, task.id).status === 'checked');
                                  const targetStatus: NotebookStatus = allChecked ? 'unchecked' : 'checked';
                                  
                                  if (onUpdateMultipleRecords) {
                                    const updates = filteredStudents.map(student => {
                                      const record = getCellRecord(student.id, task.id);
                                      return {
                                        studentId: student.id,
                                        taskId: task.id,
                                        status: targetStatus,
                                        notes: record.notes || ''
                                      };
                                    });
                                    onUpdateMultipleRecords(updates);
                                  } else {
                                    filteredStudents.forEach(student => {
                                      const record = getCellRecord(student.id, task.id);
                                      onUpdateRecord(student.id, task.id, targetStatus, record.notes || '');
                                    });
                                  }
                                }}
                                className={`w-8 h-8 sm:w-10 sm:h-10 border-2 rounded-lg flex items-center justify-center transition-all cursor-pointer shadow-md ${
                                  filteredStudents.length > 0 && filteredStudents.every(student => getCellRecord(student.id, task.id).status === 'checked')
                                    ? 'border-emerald-500 bg-emerald-500/25 text-emerald-400 group-hover:bg-emerald-500/35 shadow-[0_0_8px_rgba(16,185,129,0.25)]'
                                    : 'border-slate-500/60 bg-slate-900/90 text-slate-500 hover:border-slate-300 hover:bg-slate-850'
                                }`}
                                title="Master check-off toggle (Tick all student notebooks as Checked)"
                              >
                                {filteredStudents.length > 0 && filteredStudents.every(student => getCellRecord(student.id, task.id).status === 'checked') ? (
                                  <Check className="w-5 h-5 sm:w-6 sm:h-6 stroke-[3.5] text-emerald-400" />
                                ) : (
                                  <div className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 rounded bg-transparent border border-slate-500/60" />
                                )}
                              </button>
                              
                              <span className="block text-[7px] sm:text-[8px] text-slate-350 uppercase tracking-widest font-black leading-none mt-0.5">
                                Tick All
                              </span>

                              {/* Simple dropdown to bulk select checked/unchecked/incomplete/missing (pending) */}
                              <select 
                                onChange={(e) => {
                                  if (currentUser?.role === 'management') return;
                                  const val = e.target.value;
                                  if (!val) return;

                                  if (val === 'reset') {
                                    if (onClearMultipleRecords) {
                                      onClearMultipleRecords(filteredStudents.map(student => ({ studentId: student.id, taskId: task.id })));
                                    } else {
                                      filteredStudents.forEach(student => onClearRecord(student.id, task.id));
                                    }
                                  } else {
                                    if (onUpdateMultipleRecords) {
                                      const updates = filteredStudents.map(student => {
                                        const record = getCellRecord(student.id, task.id);
                                        return {
                                          studentId: student.id,
                                          taskId: task.id,
                                          status: val as NotebookStatus,
                                          notes: record.notes || ''
                                        };
                                      });
                                      onUpdateMultipleRecords(updates);
                                    } else {
                                      filteredStudents.forEach(student => {
                                        const record = getCellRecord(student.id, task.id);
                                        onUpdateRecord(student.id, task.id, val as NotebookStatus, record.notes || '');
                                      });
                                    }
                                  }
                                  e.target.value = '';
                                }}
                                className="w-full text-[7.5px] sm:text-[9.5px] p-0.5 sm:p-1 bg-slate-900 border border-white/10 rounded cursor-pointer text-center font-bold text-slate-300 mt-1 focus:outline-none focus:border-indigo-505"
                                defaultValue=""
                              >
                                <option value="" disabled>Bulk Set ↓</option>
                                <option value="checked">✓ Checked</option>
                                <option value="unchecked">○ Reset (o)</option>
                                <option value="incomplete">⚠ Incomplete</option>
                                <option value="missing">✗ Absent / Missing</option>
                                <option value="reset">🗑 Clear All</option>
                              </select>
                            </div>
                          </div>
                        </th>
                      ))}
                      
                      <th className="py-1 px-0.5 sm:py-4.5 sm:px-4 text-center w-10 sm:w-16 text-[7.5px] sm:text-[10px]">Comp %</th>
                    </tr>
                  </thead>
                  
                  <tbody className="divide-y divide-white/10">
                    {filteredStudents.map((student) => {
                      // Calc percentage for single student
                      let studentCheckedCount = 0;
                      currentTasks.forEach(t => {
                        const rec = getCellRecord(student.id, t.id);
                        if (rec.status === 'checked') studentCheckedCount++;
                      });
                      const studentPct = currentTasks.length > 0 ? Math.round((studentCheckedCount / currentTasks.length) * 100) : 0;

                      return (
                        <tr key={student.id} className="hover:bg-white/5 transition-colors">
                          {/* Roll Number (Fixed left) */}
                          <td className="py-1 px-1 sm:py-3 sm:px-4 text-center font-extrabold text-slate-450 text-[8px] sm:text-xs sticky left-0 bg-[#0f172a] border-r border-white/10 z-10">
                            {student.rollNumber}
                          </td>

                          {/* Student Name (Fixed left) */}
                          <td className="py-1 px-1 sm:py-3 sm:px-4 font-bold text-white text-[8px] sm:text-xs sticky left-8 sm:left-16 bg-[#0f172a] border-r border-white/15 shadow-md z-10 w-24 sm:w-60">
                            <div className="flex items-center gap-0.5">
                              <User className="w-2 h-2 sm:w-3.5 sm:h-3.5 text-slate-455 shrink-0" />
                              <span className="whitespace-nowrap truncate font-bold leading-tight uppercase text-left text-[7.5px] sm:text-xs max-w-[80px] sm:max-w-none block">{student.name}</span>
                            </div>
                          </td>

                          {/* Dynamic Task Cell columns */}
                          {currentTasks.map(task => {
                            const record = getCellRecord(student.id, task.id);
                            const cfg = getStatusConfig(record.status);
                            
                            return (
                              <td 
                                key={task.id} 
                                className={`p-0.5 text-center border-r border-white/10 ${cfg.bg} cursor-pointer transition-all relative group/cell`}
                                onClick={() => handleCellClickStatusCycle(student.id, task.id)}
                              >
                                <div className="flex flex-col items-center justify-center min-h-[18px] sm:min-h-[42px] py-0.5 sm:py-1">
                                  {cfg.icon}
                                  <span className={`text-[10px] sm:text-[12.5px] font-black mt-0.5 sm:mt-1 tracking-tight sm:tracking-normal ${cfg.text}`}>{cfg.label}</span>
                                  
                                  {/* Note/remarks snippet */}
                                  {record.notes && (
                                    <span className="text-[6.5px] sm:text-[8.5px] text-slate-350 italic max-w-[44px] sm:max-w-[100px] truncate block px-0.5 mt-0.5 font-medium">
                                      "{record.notes}"
                                    </span>
                                  )}

                                  {/* Hover overlay button to write memo */}
                                  <button
                                    onClick={(e) => editRemarks(student.id, task.id, e)}
                                    className="absolute bottom-0.5 right-0.5 p-0.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-755 border border-white/10 rounded opacity-0 group-hover/cell:opacity-100 transition-opacity"
                                    title="Add remarks / notes"
                                  >
                                    <MessageSquare className="w-2.5 h-2.5" />
                                  </button>
                                </div>
                              </td>
                            );
                          })}

                          {/* Progress bar and numeric rate */}
                          <td className="py-1 px-0.5 sm:py-3 sm:px-4 text-center w-10 sm:w-16">
                            <span className={`text-[7px] sm:text-xs font-black px-1 py-0.5 rounded-md border ${
                              studentPct >= 100 ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' :
                              studentPct >= 50 ? 'bg-amber-500/10 border-amber-500/20 text-amber-300' : 'bg-white/5 border-white/10 text-slate-400'
                            }`}>
                              {studentPct}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}

                    {filteredStudents.length === 0 && (
                      <tr>
                        <td colSpan={currentTasks.length + 3} className="text-center py-16 text-slate-450 bg-white/5">
                          <Search className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                          <p className="text-xs font-bold">No students found matching your roster filter</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Grid Legends */}
              <div className="p-4 bg-white/5 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-300 font-medium">
                <div className="flex flex-wrap items-center gap-4">
                  <span className="font-extrabold text-slate-405">STATUS GLOSSARY:</span>
                  <span className="flex items-center gap-1 text-emerald-300"><CheckCircle2 className="w-4 h-4 text-emerald-400" /> Checked</span>
                  <span className="flex items-center gap-1 text-amber-300"><AlertTriangle className="w-4 h-4 text-amber-400" /> Incomplete</span>
                  <span className="flex items-center gap-1 text-rose-300"><XOctagon className="w-4 h-4 text-rose-400" /> Missing / Absent</span>
                  <span className="flex items-center gap-1 text-slate-400"><HelpCircle className="w-4 h-4 text-slate-500" /> Not Checked</span>
                </div>
                <div>
                  <span>Checked count: <strong className="text-white">
                    {records.filter(r => currentTasks.map(t=>t.id).includes(r.taskId) && r.status === 'checked').length}
                  </strong> records</span>
                </div>
              </div>

            </div>
          ) : (
            /* ================= SPEED GRADING CARDS VIEW ================= */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Selector task columns */}
              <div className="lg:col-span-4 space-y-3">
                <div className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-md shadow-xl">
                  <h4 className="font-extrabold text-xs uppercase tracking-wide text-indigo-300 mb-3">Tasks In Focus</h4>
                  
                  <div className="space-y-1.5">
                    {currentTasks.map(task => (
                      <div
                        key={task.id}
                        onClick={() => setFocusedTaskId(task.id)}
                        className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex flex-col justify-between ${
                          focusedTaskId === task.id
                            ? 'bg-indigo-500/20 text-white shadow-md border-indigo-500/40 font-bold'
                            : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/5'
                        }`}
                      >
                        <span className="font-extrabold leading-tight">{task.title}</span>
                        <span className={`text-[9px] mt-1.5 font-medium ${focusedTaskId === task.id ? 'text-indigo-200' : 'text-slate-400'}`}>
                          Due: {new Date(task.dueDate).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right list grading cards */}
              <div className="lg:col-span-8">
                {focusedTaskId ? (
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md shadow-2xl space-y-4">
                    <div className="border-b border-white/10 pb-3 flex flex-wrap justify-between items-center bg-white/5 -mx-6 -mt-6 p-4 rounded-t-2xl gap-2 pt-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] uppercase font-bold text-indigo-300">Class Progress Grading</span>
                          <span className="text-[9px] text-emerald-400 font-extrabold tracking-normal uppercase bg-emerald-500/10 px-2 py-0.5 border border-emerald-500/20 rounded-full animate-pulse">Auto-Saving Active</span>
                        </div>
                        <h4 className="font-extrabold text-white text-sm mt-0.5">
                          {currentTasks.find(t=>t.id === focusedTaskId)?.title}
                        </h4>
                      </div>
                      <span className="text-xs bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 px-3 py-1 rounded-full font-bold">
                        {currentTasks.find(t=>t.id === focusedTaskId)?.subject}
                      </span>
                    </div>

                    <p className="text-slate-350 text-xs italic">
                      "{currentTasks.find(t=>t.id === focusedTaskId)?.description}"
                    </p>

                    {/* Students list cards vertical, easy tap checking buttons */}
                    <div className="space-y-3.5 max-h-[720px] sm:max-h-[800px] overflow-y-auto pr-1">
                      {filteredStudents.map(student => {
                        const record = getCellRecord(student.id, focusedTaskId);
                        
                        return (
                          <div 
                            key={student.id} 
                            className={`p-4 rounded-xl border transition-all grid grid-cols-1 md:grid-cols-12 gap-3 items-center ${
                              record.status === 'checked' ? 'bg-emerald-500/10 border-emerald-500/25' :
                              record.status === 'incomplete' ? 'bg-amber-500/10 border-amber-500/25' :
                              record.status === 'missing' ? 'bg-rose-500/10 border-rose-500/25' : 'bg-white/5 border-white/5 hover:border-white/10 text-slate-300'
                            }`}
                          >
                            <div className="md:col-span-4">
                              <span className="bg-white/10 border border-white/15 text-slate-300 font-bold px-1.5 py-0.5 rounded text-[10px] mr-2">
                                Roll {student.rollNumber}
                              </span>
                              <strong className="text-white font-extrabold text-xs">{student.name}</strong>
                              
                              {/* inline commenting trigger */}
                              <div className="mt-1.5 flex items-center gap-1">
                                <MessageSquare className="w-3.5 h-3.5 text-slate-450" />
                                {commentingCell && commentingCell.studentId === student.id && commentingCell.taskId === focusedTaskId ? (
                                  <div className="flex gap-1 w-full">
                                    <input
                                      type="text"
                                      value={tempNotes}
                                      onChange={(e) => setTempNotes(e.target.value)}
                                      className="text-[10px] p-1 border border-white/15 bg-slate-950 text-white rounded bg-white max-w-[150px] focus:outline-none focus:border-indigo-500 font-semibold"
                                      placeholder="Remarks note..."
                                    />
                                    <button onClick={saveRemarks} className="p-1 bg-indigo-600 text-white font-bold rounded text-[9px] px-1.5 cursor-pointer">Save</button>
                                  </div>
                                ) : (
                                  <span 
                                    onClick={(e) => editRemarks(student.id, focusedTaskId, e)}
                                    className="text-[10px] text-slate-400 hover:text-indigo-400 cursor-pointer italic font-medium"
                                  >
                                    {record.notes ? `"${record.notes}"` : '✍️ Write remarks/notes...'}
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Status Buttons Grade */}
                            <div className="md:col-span-8 flex flex-wrap gap-2 justify-end">
                              <button
                                onClick={() => {
                                  onUpdateRecord(student.id, focusedTaskId, 'checked', record.notes);
                                }}
                                className={`px-3.5 py-1.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                  record.status === 'checked'
                                    ? 'bg-emerald-600 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-emerald-500/10 text-slate-300 hover:text-white border border-white/10'
                                }`}
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" /> Checked
                              </button>
                              <button
                                onClick={() => {
                                  onUpdateRecord(student.id, focusedTaskId, 'incomplete', record.notes);
                                }}
                                className={`px-3.5 py-1.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                  record.status === 'incomplete'
                                    ? 'bg-amber-500 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-amber-500/10 text-slate-300 hover:text-white border border-white/10'
                                }`}
                              >
                                <AlertTriangle className="w-3.5 h-3.5" /> Incomplete
                              </button>
                              <button
                                onClick={() => {
                                  onUpdateRecord(student.id, focusedTaskId, 'missing', record.notes);
                                }}
                                className={`px-3.5 py-1.5 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                                  record.status === 'missing'
                                    ? 'bg-rose-600 text-white shadow-md'
                                    : 'bg-white/5 hover:bg-rose-500/10 text-slate-300 hover:text-white border border-white/10'
                                }`}
                              >
                                <XOctagon className="w-3.5 h-3.5" /> Absent/Missing
                              </button>
                              {record.status !== 'unchecked' && (
                                <button
                                  onClick={() => {
                                    onClearRecord(student.id, focusedTaskId);
                                  }}
                                  className="px-2.5 py-1.5 bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg text-[10px] cursor-pointer"
                                  title="Reset status"
                                >
                                  Undo Check
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-10 backdrop-blur-md text-center text-slate-400">
                    Choose a task on the left panel to begin speed grading.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* PERSISTENT ACTIONS BAR (SAVE & SYNC + PRINT PDF) AT DOWN OF ALL RECORDS */}
          <div className="bg-slate-900/90 border border-white/10 p-5 rounded-2xl backdrop-blur-xl flex flex-col md:flex-row items-center justify-between gap-4 mt-8 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
                <CloudUpload className="w-5 h-5 text-indigo-400 animate-pulse" />
              </div>
              <div className="text-left">
                <p className="text-xs font-extrabold text-white">Central Operations Sync Engine</p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Notebook statuses list auto-saves instantly. You can also explicitly save and cache copies on other devices.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
              {/* Consistently synced feedback info */}
              {lastSaved && (
                <span className="text-[10px] text-slate-450 font-bold bg-white/5 px-3 py-1.5 rounded-xl border border-white/5">
                  Last synced: <span className="text-emerald-400 font-extrabold">{lastSaved}</span>
                </span>
              )}

              {/* Explicit Save & Sync Button */}
              <button
                onClick={handleSaveAndSyncAll}
                className={`py-3 px-5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer border select-none w-full sm:w-auto justify-center ${
                  isManualSyncing
                    ? 'bg-amber-500/15 border-amber-500/35 text-amber-400 animate-pulse shadow-md shadow-amber-500/5'
                    : 'bg-indigo-600 hover:bg-indigo-505 border-indigo-500/30 text-white shadow-xl shadow-indigo-500/15 active:scale-95'
                }`}
                title="Explicitly save and synchronize notebook updates with school database"
              >
                {isManualSyncing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                    <span>Synchronizing Records...</span>
                  </>
                ) : (
                  <>
                    <CloudUpload className="w-4 h-4 text-white/90" />
                    <span>Save & Sync Records</span>
                  </>
                )}
              </button>

              {/* Print / PDF Button at bottom */}
              <button
                onClick={() => setShowPrintModal(true)}
                className="py-3 px-5 bg-sky-600 hover:bg-sky-505 text-white rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shadow-xl shadow-sky-500/15 w-full sm:w-auto justify-center border border-sky-500/30 active:scale-95"
                title="Generate and print PDF checklist report"
              >
                <Printer className="w-4 h-4 text-white/95" />
                <span>Print PDF Report</span>
              </button>
            </div>
          </div>
        </>
      )}

      {/* CORE MODAL DIALOGS REMARKS */}
      {commentingCell && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900/90 border border-white/10 backdrop-blur-xl rounded-2xl max-w-sm w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-white text-base">Add Teacher Remarks Note</h4>
              <button onClick={() => setCommentingCell(null)} className="text-slate-400 hover:text-white text-xs cursor-pointer">Close</button>
            </div>
            
            <div>
              <p className="text-[11px] text-slate-400 mb-2 font-medium">
                This note is bound to the checking cell and visible inside parent query terminals.
              </p>
              <textarea
                rows={3}
                placeholder="e.g. Needs recalculating on Ex 2.3. Submit rewrite by tomorrow."
                value={tempNotes}
                onChange={(e) => setTempNotes(e.target.value)}
                className="w-full text-xs p-3 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-medium text-white"
              />
            </div>

            <div className="flex gap-2 justify-end pt-2">
              <button
                onClick={() => setCommentingCell(null)}
                className="px-4 py-2 bg-white/5 border border-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={saveRemarks}
                className="px-4.5 py-2 bg-indigo-600 text-white border border-indigo-500/20 hover:bg-indigo-500 rounded-xl text-xs font-bold cursor-pointer shadow-lg shadow-indigo-500/20"
              >
                Save Comment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PREMIUM INTERACTIVE PRINT/PDF PREVIEW SHEET MODAL */}
      {showPrintModal && (
        (() => {
          const isInsideIframe = typeof window !== 'undefined' && window.self !== window.top;
          const pagesToPrint = getPagesToPrint();

          return createPortal(
            <div className="fixed inset-0 z-50 flex flex-col md:flex-row bg-slate-950/90 backdrop-blur-md overflow-y-auto print-modal-overlay animate-fade-in text-left">
              
              {/* SIDEBAR CONTROL CENTER - HIDDEN IN PRINT */}
              <div className="w-full md:w-80 bg-slate-900 border-b md:border-b-0 md:border-r border-white/10 p-5 space-y-6 shrink-0 no-print text-left flex flex-col justify-between">
                <div className="space-y-6">
                  <div className="space-y-1">
                    <span className="px-2 py-0.5 bg-sky-500/10 text-sky-400 border border-sky-500/20 rounded text-[9px] font-black uppercase tracking-wider">
                      Audit Portfolio
                    </span>
                    <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                      <Printer className="w-4 h-4 text-sky-400" />
                      <span>Notebook Audit Registry</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Generate print-perfect A4 ledger pages grouped by teacher. Optimized for single-page printing.
                    </p>
                  </div>

                  {/* Teacher Selector */}
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Audited Teacher</label>
                      <div className="relative">
                        <select
                          value={selectedTeacherPrint}
                          onChange={(e) => setSelectedTeacherPrint(e.target.value)}
                          className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500 appearance-none cursor-pointer font-bold"
                        >
                          <option value="Current Selection">Current Selection Only</option>
                          <option value="All Teachers">All Teachers (Individual Pages)</option>
                          {getTeachersList().map(t => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                        <span className="absolute right-3 top-2.5 text-slate-500 text-xs pointer-events-none">▼</span>
                      </div>
                    </div>

                    {/* Quick Switch Teacher Chips */}
                    <div className="space-y-1.5">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block">Quick Switch</label>
                      <div className="flex flex-wrap gap-1.5 max-h-[120px] overflow-y-auto pr-1">
                        <button
                          type="button"
                          onClick={() => setSelectedTeacherPrint('Current Selection')}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                            selectedTeacherPrint === 'Current Selection'
                              ? 'bg-sky-500/10 text-sky-400 border-sky-500/20 font-extrabold'
                              : 'bg-slate-950/40 text-slate-400 hover:text-white border-white/5'
                          }`}
                        >
                          Current
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedTeacherPrint('All Teachers')}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                            selectedTeacherPrint === 'All Teachers'
                              ? 'bg-sky-500/10 text-sky-400 border-sky-500/20 font-extrabold'
                              : 'bg-slate-950/40 text-slate-400 hover:text-white border-white/5'
                          }`}
                        >
                          All Teachers
                        </button>
                        {getTeachersList().map(t => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => setSelectedTeacherPrint(t)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border truncate max-w-[120px] ${
                              selectedTeacherPrint === t
                                ? 'bg-sky-500/10 text-sky-400 border-sky-500/20 font-extrabold'
                                : 'bg-slate-950/40 text-slate-400 hover:text-white border-white/5'
                            }`}
                            title={t}
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Month Selector */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Syllabus Month</label>
                    <div className="relative">
                      <select
                        value={selectedPrintMonth}
                        onChange={(e) => setSelectedPrintMonth(e.target.value)}
                        className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500 appearance-none cursor-pointer font-bold"
                      >
                        {allAvailableMonths.map(m => (
                          <option key={m} value={m}>{m}</option>
                        ))}
                      </select>
                      <span className="absolute right-3 top-2.5 text-slate-500 text-xs pointer-events-none">▼</span>
                    </div>
                  </div>

                  {/* Print Layout Density */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Print Density</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPrintLayoutDensity('normal')}
                        className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                          printLayoutDensity === 'normal'
                            ? 'bg-sky-500/10 text-sky-400 border-sky-500/20 font-extrabold'
                            : 'bg-slate-950 border-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        Normal
                      </button>
                      <button
                        type="button"
                        onClick={() => setPrintLayoutDensity('dense')}
                        className={`px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                          printLayoutDensity === 'dense'
                            ? 'bg-sky-500/10 text-sky-400 border-sky-500/20 font-extrabold'
                            : 'bg-slate-950 border-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        Dense
                      </button>
                    </div>
                  </div>

                  {isInsideIframe && (
                    <div className="text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/20 p-3 rounded-xl leading-relaxed">
                      <strong>Sandbox Notice:</strong> Standard print triggers may be blocked inside browser previews. Click <strong>'Open in a New Tab'</strong> in the top header for reliable printing!
                    </div>
                  )}

                  {printError && (
                    <div className="text-[10px] text-rose-300 bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl">
                      <strong>Print Blocked:</strong> {printError}
                    </div>
                  )}
                </div>

                <div className="pt-4 space-y-2 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => {
                      try {
                        setPrintError(null);
                        window.focus();
                        window.print();
                      } catch (e: any) {
                        console.error("Print blocked:", e);
                        setPrintError("Iframe blocked native printing. Please launch standalone.");
                      }
                    }}
                    className="w-full bg-sky-500 hover:bg-sky-600 text-slate-950 font-black py-2.5 px-4 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-sky-500/10"
                  >
                    <Printer className="w-4 h-4" /> Trigger Print / PDF
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPrintError(null);
                      setShowPrintModal(false);
                    }}
                    className="w-full bg-slate-950 hover:bg-slate-900 border border-white/5 text-slate-400 hover:text-white py-2 px-4 rounded-xl text-xs font-bold cursor-pointer transition-all text-center"
                  >
                    Close Preview
                  </button>
                </div>
              </div>

              {/* PRINTABLE PREVIEW SHEET CANVAS */}
              <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center bg-slate-900/60 print:bg-white print:p-0 print:block print:overflow-visible print:w-full print:h-auto print:flex-none">
                
                {/* Screen Banner - Hidden in Print */}
                <div className="w-full max-w-[210mm] mb-4 bg-slate-950 border border-sky-500/10 p-3 rounded-2xl flex items-center justify-between gap-3 text-left no-print">
                  <div>
                    <h4 className="text-xs font-black text-white">Active Print Preview Area (A4 Portrait Format)</h4>
                    <p className="text-[10px] text-slate-400">Shows exactly what will appear on the physical A4 paper page sheet layout.</p>
                  </div>
                  <div className="bg-sky-500/10 border border-sky-500/20 text-sky-400 font-extrabold text-[9px] px-2 py-0.5 rounded">
                    {pagesToPrint.length} pages total
                  </div>
                </div>

                <div className="space-y-6 print:space-y-0 print:block print:overflow-visible print:w-full print:h-auto">
                  {pagesToPrint.map((page, pIdx) => {
                    const { classObj, subject, teacher } = page;
                    
                    const activeReview = managementReviews?.find(r => {
                      const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
                      const cleanTeacher = cleanStr(teacher);
                      const reviewTeacherClean = cleanStr(r.teacherName);
                      const isTeacherMatch = reviewTeacherClean === cleanTeacher || 
                                             reviewTeacherClean.includes(cleanTeacher) || 
                                             cleanTeacher.includes(reviewTeacherClean);
                      return isTeacherMatch && r.month === selectedPrintMonth && r.isVerified;
                    });
                    
                    const allotmentTasks = tasks.filter(t => 
                      t.classId === classObj.id && 
                      t.subject === subject && 
                      t.month === selectedPrintMonth
                    );
                    
                    const allotmentStudents = classObj.students;
                    
                    // Calculate statistics
                    let pageChecked = 0;
                    let pageIncomplete = 0;
                    let pageMissing = 0;
                    
                    allotmentStudents.forEach(student => {
                      allotmentTasks.forEach(task => {
                        const rec = getCellRecord(student.id, task.id);
                        if (rec.status === 'checked') pageChecked++;
                        else if (rec.status === 'incomplete') pageIncomplete++;
                        else if (rec.status === 'missing') pageMissing++;
                      });
                    });
                    
                    const pageCheckOps = allotmentStudents.length * allotmentTasks.length;
                    const pageRate = pageCheckOps > 0 ? Math.round((pageChecked / pageCheckOps) * 100) : 0;
                    
                    const halfIdx = Math.ceil(allotmentStudents.length / 2);
                    const firstHalf = allotmentStudents.slice(0, halfIdx);
                    const secondHalf = allotmentStudents.slice(halfIdx);
                    
                    return (
                      <React.Fragment key={`${classObj.id}_${subject}_${pIdx}`}>
                        {/* PAGE 1 */}
                        <div className={`printable-paper-sheet w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl relative border border-slate-200 ${
                          printLayoutDensity === 'dense' ? 'dense-layout' : ''
                        } mb-8 print:mb-0`}>
                          
                          {/* Header / Letterhead */}
                          <div className="border-b-2 border-dashed border-slate-300 pb-4 mb-6 flex items-center justify-between">
                            <div>
                              <h1 className="text-xl md:text-2xl font-black text-slate-950 tracking-tight leading-tight">SAMATA INTERNATIONAL SCHOOL</h1>
                              <p className="text-[10px] md:text-xs text-slate-500 font-medium font-bold">Affiliated to CBSE Board • Kokamthan, Kopargaon Motorway, MH</p>
                            </div>
                            <div className="bg-slate-100 border border-slate-300 text-[10px] font-black text-slate-700 px-3 py-1 rounded-md uppercase tracking-wider font-bold">
                              Notebook Audit Ledger
                            </div>
                          </div>

                          {/* Title */}
                          <div className="text-center mb-6">
                            <h2 className="text-lg font-extrabold text-slate-900 tracking-tight uppercase">STUDENT PORTFOLIO NOTEBOOK CHECK-OFF REGISTRY</h2>
                            <p className="text-[11px] text-slate-500 font-medium font-bold mt-0.5">Approved Syllabus Monthly Checking Progress Report (Page 1 of 2)</p>
                          </div>

                          {/* Metadata Information Grid */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 mb-4">
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Class / Section</span>
                              <span className="text-xs font-black text-slate-900">{classObj.name}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Syllabus Subject</span>
                              <span className="text-xs font-black text-slate-900">{subject}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Curriculum Month</span>
                              <span className="text-xs font-black text-slate-900">{selectedPrintMonth}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Audit Date</span>
                              <span className="text-xs font-black text-slate-900">
                                {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                              </span>
                            </div>
                          </div>

                          {/* Stats Dashboard */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                            <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Check Completion</span>
                              <span className="text-sm font-black text-indigo-700">{pageRate}%</span>
                            </div>
                            <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Checked/Certified</span>
                              <span className="text-sm font-black text-emerald-700">{pageChecked} / {pageCheckOps}</span>
                            </div>
                            <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Pending Corrections</span>
                              <span className="text-sm font-black text-amber-600">{pageIncomplete}</span>
                            </div>
                            <div className="bg-white border border-slate-200 rounded-xl p-3 text-center">
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-1">Missing Tasks</span>
                              <span className="text-sm font-black text-rose-600">{pageMissing}</span>
                            </div>
                          </div>

                          {/* Main Score Sheet Table - Page 1 */}
                          <div className="overflow-x-auto border border-slate-200 rounded-xl mb-4">
                            {allotmentTasks.length === 0 ? (
                              <div className="p-8 text-center text-slate-400 italic text-xs">
                                No notebook checking tasks found for this class and subject in {selectedPrintMonth}.
                              </div>
                            ) : (
                              <table className="w-full text-left text-[13px] border-collapse">
                                <thead>
                                  <tr className="bg-slate-100 border-b border-slate-200 font-bold">
                                    <th className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Roll No</th>
                                    <th className="py-2 px-4 font-bold text-slate-705 text-[13px] uppercase tracking-wider w-[25%] border-r border-slate-200">Student Name</th>
                                    {allotmentTasks.map(task => (
                                      <th key={task.id} className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider text-center border-r border-slate-200">
                                        {task.title}
                                      </th>
                                    ))}
                                    <th className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider text-center w-[15%]">Progress</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {firstHalf.map(student => {
                                    let studentCheckedCount = 0;
                                    allotmentTasks.forEach(t => {
                                      const rec = getCellRecord(student.id, t.id);
                                      if (rec.status === 'checked') studentCheckedCount++;
                                    });
                                    const studentPct = allotmentTasks.length > 0 ? Math.round((studentCheckedCount / allotmentTasks.length) * 100) : 0;
                                    
                                    return (
                                      <tr key={student.id} className="hover:bg-slate-50/50">
                                        <td className="py-2 px-3 font-bold text-slate-600 font-mono text-center text-[13px] border-r border-slate-200">{student.rollNumber}</td>
                                        <td className="py-2 px-4 font-bold text-slate-800 text-[13px] border-r border-slate-200 font-bold">{student.name}</td>
                                        {allotmentTasks.map(task => {
                                          const record = getCellRecord(student.id, task.id);
                                          return (
                                            <td key={task.id} className="py-2 px-3 text-center border-r border-slate-200">
                                              <div className="font-extrabold text-[13px] leading-tight">
                                                <span className={`inline-block px-2 py-0.5 rounded text-[11px] uppercase tracking-wider font-extrabold mb-1 ${
                                                  record.status === 'checked' ? 'bg-emerald-100 text-emerald-700' :
                                                  record.status === 'incomplete' ? 'bg-amber-100 text-amber-700' :
                                                  record.status === 'missing' ? 'bg-rose-100 text-rose-700' :
                                                  'bg-slate-100 text-slate-500'
                                                }`}>
                                                  {record.status === 'checked' ? 'Checked' :
                                                   record.status === 'incomplete' ? 'Incomplete' :
                                                   record.status === 'missing' ? 'Missing' : 'Unchecked'}
                                                </span>
                                                {record.notes && (
                                                  <div className="text-[11px] text-slate-500 font-semibold italic mt-0.5 block max-w-[150px] mx-auto text-center">
                                                    "{record.notes}"
                                                  </div>
                                                )}
                                              </div>
                                            </td>
                                          );
                                        })}
                                        <td className="py-2 px-3 text-center font-bold text-slate-700 text-[13px]">{studentPct}%</td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            )}
                          </div>

                          {/* Page 1 Footer */}
                          <div className="flex justify-between items-center mt-auto pt-4 text-[10px] text-slate-400 font-bold border-t border-slate-100">
                            <span>SAMATA INTERNATIONAL SCHOOL • Copy of Record Sheet</span>
                            <span>Page 1 of 2 (Students 1 - {halfIdx})</span>
                          </div>
                        </div>

                        {/* PAGE 2 */}
                        <div className={`printable-paper-sheet w-full max-w-4xl bg-white text-slate-900 rounded-2xl shadow-2xl relative border border-slate-200 ${
                          printLayoutDensity === 'dense' ? 'dense-layout' : ''
                        } mb-8 print:mb-0`}>
                          
                          {/* Header / Letterhead */}
                          <div className="border-b-2 border-dashed border-slate-300 pb-4 mb-6 flex items-center justify-between">
                            <div>
                              <h1 className="text-xl md:text-2xl font-black text-slate-950 tracking-tight leading-tight">SAMATA INTERNATIONAL SCHOOL</h1>
                              <p className="text-[10px] md:text-xs text-slate-500 font-medium font-bold">Affiliated to CBSE Board • Kokamthan, Kopargaon Motorway, MH</p>
                            </div>
                            <div className="bg-slate-100 border border-slate-300 text-[10px] font-black text-slate-700 px-3 py-1 rounded-md uppercase tracking-wider font-bold">
                              Notebook Audit Ledger
                            </div>
                          </div>

                          {/* Title */}
                          <div className="text-center mb-6">
                            <h2 className="text-lg font-extrabold text-slate-900 tracking-tight uppercase">STUDENT PORTFOLIO NOTEBOOK CHECK-OFF REGISTRY</h2>
                            <p className="text-[11px] text-slate-500 font-medium font-bold mt-0.5">Approved Syllabus Monthly Checking Progress Report (Page 2 of 2)</p>
                          </div>

                          {/* Metadata Information Grid */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 mb-4">
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Class / Section</span>
                              <span className="text-xs font-black text-slate-900">{classObj.name}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Syllabus Subject</span>
                              <span className="text-xs font-black text-slate-900">{subject}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Curriculum Month</span>
                              <span className="text-xs font-black text-slate-900">{selectedPrintMonth}</span>
                            </div>
                            <div>
                              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">Audit Date</span>
                              <span className="text-xs font-black text-slate-900">
                                {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                              </span>
                            </div>
                          </div>

                          {/* Main Score Sheet Table - Page 2 */}
                          <div className="overflow-x-auto border border-slate-200 rounded-xl mb-4">
                            {allotmentTasks.length === 0 ? (
                              <div className="p-8 text-center text-slate-400 italic text-xs">
                                No notebook checking tasks found for this class and subject in {selectedPrintMonth}.
                              </div>
                            ) : (
                              <table className="w-full text-left text-[13px] border-collapse">
                                <thead>
                                  <tr className="bg-slate-100 border-b border-slate-200 font-bold">
                                    <th className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider w-[10%] text-center border-r border-slate-200">Roll No</th>
                                    <th className="py-2 px-4 font-bold text-slate-705 text-[13px] uppercase tracking-wider w-[25%] border-r border-slate-200">Student Name</th>
                                    {allotmentTasks.map(task => (
                                      <th key={task.id} className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider text-center border-r border-slate-200">
                                        {task.title}
                                      </th>
                                    ))}
                                    <th className="py-2 px-3 font-bold text-slate-705 text-[13px] uppercase tracking-wider text-center w-[15%]">Progress</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {secondHalf.map(student => {
                                    let studentCheckedCount = 0;
                                    allotmentTasks.forEach(t => {
                                      const rec = getCellRecord(student.id, t.id);
                                      if (rec.status === 'checked') studentCheckedCount++;
                                    });
                                    const studentPct = allotmentTasks.length > 0 ? Math.round((studentCheckedCount / allotmentTasks.length) * 100) : 0;
                                    
                                    return (
                                      <tr key={student.id} className="hover:bg-slate-50/50">
                                        <td className="py-2 px-3 font-bold text-slate-600 font-mono text-center text-[13px] border-r border-slate-200">{student.rollNumber}</td>
                                        <td className="py-2 px-4 font-bold text-slate-800 text-[13px] border-r border-slate-200 font-bold">{student.name}</td>
                                        {allotmentTasks.map(task => {
                                          const record = getCellRecord(student.id, task.id);
                                          return (
                                            <td key={task.id} className="py-2 px-3 text-center border-r border-slate-200">
                                              <div className="font-extrabold text-[13px] leading-tight">
                                                <span className={`inline-block px-2 py-0.5 rounded text-[11px] uppercase tracking-wider font-extrabold mb-1 ${
                                                  record.status === 'checked' ? 'bg-emerald-100 text-emerald-700' :
                                                  record.status === 'incomplete' ? 'bg-amber-100 text-amber-700' :
                                                  record.status === 'missing' ? 'bg-rose-100 text-rose-700' :
                                                  'bg-slate-100 text-slate-500'
                                                }`}>
                                                  {record.status === 'checked' ? 'Checked' :
                                                   record.status === 'incomplete' ? 'Incomplete' :
                                                   record.status === 'missing' ? 'Missing' : 'Unchecked'}
                                                </span>
                                                {record.notes && (
                                                  <div className="text-[11px] text-slate-500 font-semibold italic mt-0.5 block max-w-[150px] mx-auto text-center">
                                                    "{record.notes}"
                                                  </div>
                                                )}
                                              </div>
                                            </td>
                                          );
                                        })}
                                        <td className="py-2 px-3 text-center font-bold text-slate-700 text-[13px]">{studentPct}%</td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            )}
                          </div>

                          {/* Footer Signature Blocks */}
                          <div className="grid grid-cols-3 gap-6 pt-6 mt-auto border-t border-dashed border-slate-200 text-center">
                            <div>
                              <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider font-bold">
                                {teacher}
                              </div>
                              <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">ALLOTTED SUBJECT TEACHER</div>
                            </div>
                            <div className="relative">
                              {activeReview && (
                                <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                                  <div className="border-2 border-double border-indigo-600/75 text-indigo-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[4deg] bg-white/95 scale-90 shadow-sm leading-tight">
                                    <div className="text-[6px] border-b border-indigo-600/75 pb-0.5 leading-none">★ AUDITOR PORTFOLIO ★</div>
                                    <div className="text-[8px] font-extrabold my-0.5 leading-none">VP AUDIT PASSED</div>
                                    <div className="text-[6px] border-t border-indigo-600/75 pt-0.5 mt-0.5 leading-none">
                                      {activeReview.verifiedAt || 'VERIFIED'}
                                    </div>
                                  </div>
                                </div>
                              )}
                              <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider font-bold">
                                {activeReview ? '✓ AUDIT VERIFIED' : 'PORTFOLIO INSPECTED'}
                              </div>
                              <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">REGISTRY CONTROLLER DATE</div>
                            </div>
                            <div className="relative">
                              {activeReview && (
                                <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                                  <div className="border-2 border-double border-rose-600/75 text-rose-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[-3deg] bg-white/95 scale-90 shadow-sm leading-tight">
                                    <div className="text-[6px] border-b border-rose-600/75 pb-0.5 leading-none">★ SAMATA INT. SCHOOL ★</div>
                                    <div className="text-[8px] font-extrabold my-0.5 leading-none">PRINCIPAL APPROVED</div>
                                    <div className="text-[6px] border-t border-rose-600/75 pt-0.5 mt-0.5 leading-none">
                                      {activeReview.verifiedBy.replace(/\s*\(Academic Audit\)/g, '')}
                                    </div>
                                  </div>
                                </div>
                              )}
                              <div className="border-t border-slate-300 pt-2 font-bold text-slate-700 text-[10px] uppercase tracking-wider font-bold">
                                {activeReview ? '✓ APPROVED ONLINE' : 'PRINCIPAL SEAL & SIGN'}
                              </div>
                              <div className="text-[8px] text-slate-400 mt-0.5 font-bold uppercase">SAMATA INTERNATIONAL SCHOOL</div>
                            </div>
                          </div>

                          {/* Page 2 Footer */}
                          <div className="flex justify-between items-center mt-4 pt-2 text-[10px] text-slate-400 font-bold border-t border-slate-100">
                            <span>SAMATA INTERNATIONAL SCHOOL • Copy of Record Sheet</span>
                            <span>Page 2 of 2 (Students {halfIdx + 1} - {allotmentStudents.length})</span>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            </div>,
            document.body
          );
        })()
      )}

    </div>
  );
}
