import React, { useState } from 'react';
import { SchoolClass, MonthlyTask, CheckingRecord, ActivityLog } from '../types';
import { 
  BookOpen, 
  Users, 
  CheckCircle2, 
  AlertTriangle, 
  XOctagon, 
  HelpCircle, 
  GraduationCap, 
  Calendar,
  Layers,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface DashboardStatsProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  activityLogs: ActivityLog[];
  onSelectTab: (tab: string) => void;
  onQuickLocate: (classId: string, subject: string) => void;
  onSelectPendingIssues?: () => void;
}

export default function DashboardStats({ 
  classes, 
  tasks, 
  records, 
  activityLogs, 
  onSelectTab,
  onQuickLocate,
  onSelectPendingIssues
}: DashboardStatsProps) {
  
  // Basic counts
  const totalClasses = classes.length;
  const totalStudents = classes.reduce((sum, cls) => sum + cls.students.length, 0);
  const totalTasks = tasks.length;
  const uniqueSubjects = Array.from(new Set(tasks.map(t => t.subject)));
  const totalSubjectsCount = uniqueSubjects.length || 4; // fallback

  // Resolve total possible checking opportunities
  // A checking cell is created for each student in a class times each task assigned to that class
  let totalTiedCells = 0;
  const cellStatusCounts = {
    checked: 0,
    incomplete: 0,
    missing: 0,
    unchecked: 0
  };

  classes.forEach(schoolClass => {
    const classTasks = tasks.filter(t => t.classId === schoolClass.id);
    const studentCount = schoolClass.students.length;
    totalTiedCells += classTasks.length * studentCount;

    classTasks.forEach(task => {
      schoolClass.students.forEach(student => {
        const key = `${student.id}_${task.id}`;
        const record = records.find(r => r.studentId === student.id && r.taskId === task.id);
        const status = record ? record.status : 'unchecked';
        cellStatusCounts[status]++;
      });
    });
  });

  const checkedCount = cellStatusCounts.checked;
  const incompleteCount = cellStatusCounts.incomplete;
  const missingCount = cellStatusCounts.missing;
  const uncheckedCount = totalTiedCells - (checkedCount + incompleteCount + missingCount);
  const checkedPercentage = totalTiedCells > 0 ? Math.round((checkedCount / totalTiedCells) * 100) : 0;
  const incompletePercentage = totalTiedCells > 0 ? Math.round((incompleteCount / totalTiedCells) * 100) : 0;
  const missingPercentage = totalTiedCells > 0 ? Math.round((missingCount / totalTiedCells) * 100) : 0;
  const uncheckedPercentage = totalTiedCells > 0 ? Math.round((uncheckedCount / totalTiedCells) * 100) : 0;

  // Let's calculate Class-wise completion rates
  const classCompletionRates = classes.map(cls => {
    const classTasks = tasks.filter(t => t.classId === cls.id);
    const studentsInClass = cls.students;
    let totalPossible = classTasks.length * studentsInClass.length;
    let totalChecked = 0;

    classTasks.forEach(task => {
      studentsInClass.forEach(student => {
        const record = records.find(r => r.studentId === student.id && r.taskId === task.id);
        if (record && record.status === 'checked') {
          totalChecked++;
        }
      });
    });

    return {
      className: cls.name,
      classId: cls.id,
      tasksCount: classTasks.length,
      studentsCount: studentsInClass.length,
      percentage: totalPossible > 0 ? Math.round((totalChecked / totalPossible) * 100) : 0,
      totalChecked,
      totalPossible
    };
  });

  // Calculate Subject-wise completion rates
  const subjectCompletionRates = uniqueSubjects.map(sub => {
    let totalPossible = 0;
    let totalChecked = 0;

    const subTasks = tasks.filter(t => t.subject === sub);
    subTasks.forEach(task => {
      const cls = classes.find(c => c.id === task.classId);
      if (cls) {
        totalPossible += cls.students.length;
        cls.students.forEach(student => {
          const record = records.find(r => r.studentId === student.id && r.taskId === task.id);
          if (record && record.status === 'checked') {
            totalChecked++;
          }
        });
      }
    });

    return {
      subject: sub,
      percentage: totalPossible > 0 ? Math.round((totalChecked / totalPossible) * 100) : 0,
      totalChecked,
      totalPossible,
      taskCount: subTasks.length
    };
  });

  // List students with incomplete or missing notebooks (needs attention)
  // Let's group by student and calculate their stats
  const studentsNeedsAttention = classes.flatMap(cls => {
    const classTasks = tasks.filter(t => t.classId === cls.id);
    if (classTasks.length === 0) return [];

    return cls.students.map(student => {
      let incomplete = 0;
      let missing = 0;
      let total = classTasks.length;

      const items: { taskTitle: string; subject: string; status: 'incomplete' | 'missing'; notes: string }[] = [];

      classTasks.forEach(task => {
        const record = records.find(r => r.studentId === student.id && r.taskId === task.id);
        if (record) {
          if (record.status === 'incomplete') {
            incomplete++;
            items.push({ taskTitle: task.title, subject: task.subject, status: 'incomplete', notes: record.notes });
          } else if (record.status === 'missing') {
            missing++;
            items.push({ taskTitle: task.title, subject: task.subject, status: 'missing', notes: record.notes });
          }
        }
      });

      return {
        student,
        className: cls.name,
        classId: cls.id,
        incomplete,
        missing,
        totalIssues: incomplete + missing,
        items
      };
    }).filter(s => s.totalIssues > 0);
  })
  .sort((a, b) => b.totalIssues - a.totalIssues)
  .slice(0, 5); // top 5 with errors

  const [viewMode, setViewMode] = useState<'simple' | 'detailed'>('simple');

  return (
    <div id="stats_dashboard_view" className="space-y-5">
      
      {/* Visual Quality Dashboard Mode Switcher */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between bg-white/5 border border-white/10 p-3 rounded-2xl backdrop-blur-xl">
        <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5 px-1">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span>Dashboard Quality Mode:</span>
        </div>
        <div className="flex bg-slate-900 border border-white/10 p-1 rounded-xl w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setViewMode('simple')}
            className={`flex-1 sm:flex-initial px-4 py-1.5 text-xs font-extrabold rounded-lg transition-all cursor-pointer text-center ${
              viewMode === 'simple'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Simple Checklist
          </button>
          <button
            type="button"
            onClick={() => setViewMode('detailed')}
            className={`flex-1 sm:flex-initial px-4 py-1.5 text-xs font-extrabold rounded-lg transition-all cursor-pointer text-center ${
              viewMode === 'detailed'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Advanced Analytics
          </button>
        </div>
      </div>

      {viewMode === 'simple' ? (
        <div className="space-y-5 animate-fade-in">
          {/* Top Banner Info */}
          <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-6 text-white shadow-2xl overflow-hidden relative">
            <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-500/10 rounded-full -mr-16 -mt-16 blur-2xl pointer-events-none" />
            <div className="absolute left-1/3 bottom-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/10 rounded-full text-[10px] sm:text-xs font-semibold w-fit mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-300 animate-pulse" />
                  <span className="text-slate-205">Syllabus-Checked Admin Desk</span>
                </div>
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white leading-tight">
                  Notebook Audit Dashboard
                </h1>
                <p className="text-slate-350 text-xs leading-relaxed max-w-xl font-medium">
                  Track student progress in real-time across all academic grades. Feed notebook submission data, update student statuses instantly, and audit syllabus plans monthly. (Created By Xpert3421)
                </p>
              </div>
              <div className="grid grid-cols-2 divide-x divide-white/10 bg-white/5 border border-white/10 backdrop-blur-md rounded-xl p-3 sm:p-4 gap-2 sm:gap-4 w-full lg:w-auto shadow-lg">
                <div className="text-center px-1 sm:px-2">
                  <span className="block text-[10px] sm:text-[11px] uppercase tracking-wide text-indigo-300 font-bold leading-none">Checking State</span>
                  <span className="block text-xl sm:text-3xl font-black text-white mt-1.5">{checkedPercentage}%</span>
                  <span className="block text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase mt-1 leading-none">Verified Checked</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (onSelectPendingIssues) {
                      onSelectPendingIssues();
                    } else {
                      onSelectTab('records');
                    }
                  }}
                  className="text-center px-1 sm:px-2 group hover:bg-white/5 active:scale-95 transition-all cursor-pointer rounded-lg border border-transparent hover:border-white/5 focus:outline-none"
                  title="Click to view pending issues in check matrix"
                >
                  <span className="block text-[10px] sm:text-[11px] uppercase tracking-wide text-rose-300 font-extrabold leading-none group-hover:text-rose-200">Action Needed</span>
                  <span className="block text-xl sm:text-3xl font-black text-rose-455 mt-1.5">{(incompleteCount + missingCount)}</span>
                  <span className="block text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase mt-1 leading-none group-hover:underline">Pending Issues</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="space-y-2.5">
            <h2 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">Quick Navigation Hub</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <button
                type="button"
                onClick={() => onSelectTab('records')}
                className="bg-white/5 hover:bg-white/10 border border-white/10 p-4 sm:p-5 rounded-2xl text-left transition-all hover:scale-[1.01] hover:shadow-xl group cursor-pointer focus:outline-none"
              >
                <div className="p-2.5 bg-indigo-500/15 text-indigo-300 border border-indigo-500/10 rounded-xl w-fit group-hover:bg-indigo-500/25 transition-colors">
                  <CheckCircle2 className="w-5 h-5 text-indigo-450" />
                </div>
                <h4 className="font-extrabold text-white text-xs sm:text-sm mt-3.5 leading-none">Record Notebook Checks</h4>
                <p className="text-slate-400 text-[11px] mt-2 leading-relaxed font-semibold">Open the live record matrix to check student submissions and write feedback remarks.</p>
              </button>

              <button
                type="button"
                onClick={() => onSelectTab('tests')}
                className="bg-white/5 hover:bg-white/10 border border-white/10 p-4 sm:p-5 rounded-2xl text-left transition-all hover:scale-[1.01] hover:shadow-xl group cursor-pointer focus:outline-none"
              >
                <div className="p-2.5 bg-emerald-500/15 text-emerald-300 border border-emerald-500/10 rounded-xl w-fit group-hover:bg-emerald-500/25 transition-colors">
                  <GraduationCap className="w-5 h-5 text-emerald-450" />
                </div>
                <h4 className="font-extrabold text-white text-xs sm:text-sm mt-3.5 leading-none">Syllabus Tests Registry</h4>
                <p className="text-slate-400 text-[11px] mt-2 leading-relaxed font-semibold">Manage monthly diagnostic exams, syllabus test marks, and student achievements.</p>
              </button>

              <button
                type="button"
                onClick={() => onSelectTab('plans')}
                className="bg-white/5 hover:bg-white/10 border border-white/10 p-4 sm:p-5 rounded-2xl text-left transition-all hover:scale-[1.01] hover:shadow-xl group cursor-pointer focus:outline-none"
              >
                <div className="p-2.5 bg-sky-500/15 text-sky-300 border border-sky-500/10 rounded-xl w-fit group-hover:bg-sky-500/25 transition-colors">
                  <Calendar className="w-5 h-5 text-sky-455" />
                </div>
                <h4 className="font-extrabold text-white text-xs sm:text-sm mt-3.5 leading-none">Monthly Syllabus Bank</h4>
                <p className="text-slate-400 text-[11px] mt-2 leading-relaxed font-semibold">Auto-seed official school curriculum checkmarks or custom lesson schedules.</p>
              </button>

              <button
                type="button"
                onClick={() => onSelectTab('lookup')}
                className="bg-white/5 hover:bg-white/10 border border-white/10 p-4 sm:p-5 rounded-2xl text-left transition-all hover:scale-[1.01] hover:shadow-xl group cursor-pointer focus:outline-none"
              >
                <div className="p-2.5 bg-purple-500/15 text-purple-300 border border-purple-500/10 rounded-xl w-fit group-hover:bg-purple-500/25 transition-colors">
                  <Users className="w-5 h-5 text-purple-450" />
                </div>
                <h4 className="font-extrabold text-white text-xs sm:text-sm mt-3.5 leading-none">Student & Parent Portal</h4>
                <p className="text-slate-400 text-[11px] mt-2 leading-relaxed font-semibold">Direct search roll number to download instant checked portfolio logs for families.</p>
              </button>
            </div>
          </div>

          {/* Quick Stats overview: Progress list & Feed */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 sm:p-6 shadow-xl flex flex-col justify-between">
              <div>
                <h3 className="font-extrabold text-white text-xs sm:text-sm uppercase tracking-wider mb-2 text-indigo-300 leading-none">Class Submission Portfolios</h3>
                <p className="text-slate-400 text-[11px] mb-4">Completed notebook review tasks aggregated per grade</p>

                <div className="space-y-4">
                  {classCompletionRates.map((cls, idx) => (
                    <div key={cls.classId || idx} className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] sm:text-xs text-slate-205 font-bold">
                        <span>{cls.className}</span>
                        <span className="text-slate-400 text-[10px] sm:text-[11px]">
                          {cls.totalChecked}/{cls.totalPossible} checked ({cls.percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden flex border border-white/5">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            cls.percentage >= 80 ? 'bg-emerald-400' :
                            cls.percentage >= 50 ? 'bg-amber-400' : 'bg-indigo-400'
                          }`} 
                          style={{ width: `${cls.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}

                  {classCompletionRates.length === 0 && (
                    <p className="text-slate-400 text-xs text-center py-6">No tasks assigned to classes yet.</p>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 sm:p-6 shadow-xl flex flex-col justify-between">
              <div>
                <h3 className="font-extrabold text-white text-xs sm:text-sm uppercase tracking-wider mb-2 text-emerald-400 leading-none">Recent Activity Logs</h3>
                <p className="text-slate-400 text-[11px] mb-4">Latest live audits recorded by the evaluation team</p>

                <div className="space-y-3.5">
                  {activityLogs.slice(0, 3).map((log, idx) => (
                    <div key={log.id || idx} className="flex gap-2.5 text-xs leading-relaxed items-start">
                      <div className="mt-1 shrink-0">
                        <span className="w-1.5 h-1.5 bg-emerald-450 rounded-full inline-block" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-slate-300 text-[11px] font-semibold break-words">
                          <strong className="text-white font-extrabold">{log.studentName}</strong>'s {log.subject} marked <span className="text-emerald-400 font-extrabold">{log.status}</span>
                        </p>
                        <p className="text-[10px] text-slate-405 font-semibold mt-0.5">
                          {log.className} • {log.taskTitle}
                        </p>
                      </div>
                    </div>
                  ))}

                  {activityLogs.length === 0 && (
                    <p className="text-slate-500 text-[11px] font-semibold text-center py-6">No checks recorded recently.</p>
                  )}
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-white/5 text-right shrink-0">
                <button
                  type="button"
                  onClick={() => setViewMode('detailed')}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-extrabold hover:underline cursor-pointer focus:outline-none"
                >
                  View full expanded analytical metrics →
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-5 animate-fade-in">
          {/* Top Banner Info */}
          <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900/60 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-6 text-white shadow-2xl overflow-hidden relative">
            <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-500/10 rounded-full -mr-16 -mt-16 blur-2xl pointer-events-none" />
            <div className="absolute left-1/3 bottom-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/10 rounded-full text-[10px] sm:text-xs font-semibold w-fit mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                  <span className="text-slate-200 font-semibold">Academic Year 2026 Admin Dashboard</span>
                </div>
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white leading-tight">Notebook Checking & Monthly Plan Tracker</h1>
                <p className="text-slate-350 text-xs leading-relaxed max-w-xl font-medium">
                  Track student progress in real-time across all academic grades. Feed notebook submission data, update student statuses instantly, and audit syllabus plans monthly. (Created By Xpert3421)
                </p>
              </div>
              <div className="grid grid-cols-2 divide-x divide-white/10 bg-white/5 border border-white/10 backdrop-blur-md rounded-xl p-3 sm:p-4 gap-2 sm:gap-4 w-full lg:w-auto shadow-lg">
                <div className="text-center px-1 sm:px-2">
                  <span className="block text-[10px] sm:text-[11px] uppercase tracking-wide text-indigo-300 font-bold">Checking Status</span>
                  <span className="block text-xl sm:text-3xl font-black text-white mt-1.5">{checkedPercentage}%</span>
                  <span className="block text-[10px] text-slate-400 font-semibold uppercase mt-1 leading-none">Verified Checked</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (onSelectPendingIssues) {
                      onSelectPendingIssues();
                    } else {
                      onSelectTab('records');
                    }
                  }}
                  className="text-center px-1 sm:px-2 group hover:bg-white/5 active:scale-95 transition-all cursor-pointer rounded-lg border border-transparent hover:border-white/5 focus:outline-none"
                  title="Click to view pending issues in check matrix"
                >
                  <span className="block text-[10px] sm:text-[11px] uppercase tracking-wide text-rose-300 font-extrabold group-hover:text-rose-200">Action Required</span>
                  <span className="block text-xl sm:text-3xl font-black text-rose-455 mt-1.5">{(incompleteCount + missingCount)}</span>
                  <span className="block text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase mt-1 leading-none group-hover:underline">Pending Issues</span>
                </button>
              </div>
            </div>
          </div>

          {/* Grid Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Total Classes */}
            <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-4 sm:p-5 rounded-2xl flex items-center justify-between hover:bg-white/8 hover:border-white/15 transition-all shadow-lg min-w-0">
              <div className="min-w-0 flex-1">
                <span className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider block truncate">Total Classes</span>
                <span className="text-2xl sm:text-3xl font-black text-white mt-1 block leading-none">{totalClasses}</span>
                <button 
                  onClick={() => onSelectTab('classes')}
                  className="mt-2.5 text-[10px] sm:text-xs text-indigo-400 hover:text-indigo-300 font-bold inline-flex items-center gap-1 hover:underline text-left focus:outline-none"
                >
                  Manage <ArrowRight className="w-3 h-3 animate-pulse" />
                </button>
              </div>
              <div className="p-2 sm:p-3 bg-indigo-500/10 text-indigo-300 border border-indigo-500/15 rounded-xl shadow-inner shrink-0 ml-2">
                <Layers className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
            </div>

            {/* Enrollments */}
            <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-4 sm:p-5 rounded-2xl flex items-center justify-between hover:bg-white/8 hover:border-white/15 transition-all shadow-lg min-w-0">
              <div className="min-w-0 flex-1">
                <span className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider block truncate">Total Students</span>
                <span className="text-2xl sm:text-3xl font-black text-white mt-1 block leading-none">{totalStudents}</span>
                <span className="text-[9px] sm:text-[10px] text-slate-455 block mt-2 font-medium truncate">Roster columns</span>
              </div>
              <div className="p-2 sm:p-3 bg-emerald-500/10 text-emerald-300 border border-emerald-500/15 rounded-xl shadow-inner shrink-0 ml-2">
                <Users className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
            </div>

        {/* Subjects & Plans */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-5 rounded-2xl flex items-center justify-between hover:bg-white/8 hover:border-white/15 transition-all shadow-lg">
          <div>
            <span className="text-xs font-semibold text-slate-450 uppercase tracking-wider block">Total Subjects</span>
            <span className="text-3xl font-extrabold text-white mt-1 block">{totalSubjectsCount}</span>
            <button 
              onClick={() => onSelectTab('plans')}
              className="mt-2 text-xs text-emerald-400 hover:text-emerald-300 font-bold inline-flex items-center gap-1 hover:underline"
            >
              Verify Plans <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="p-3 bg-teal-500/10 text-teal-300 border border-teal-500/15 rounded-xl shadow-inner">
            <BookOpen className="w-6 h-6" />
          </div>
        </div>

        {/* Tasks Checklist */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-5 rounded-2xl flex items-center justify-between hover:bg-white/8 hover:border-white/15 transition-all shadow-lg">
          <div>
            <span className="text-xs font-semibold text-slate-450 uppercase tracking-wider block">Active Month Tasks</span>
            <span className="text-3xl font-extrabold text-white mt-1 block">{totalTasks}</span>
            <span className="text-xs text-slate-450 block mt-2 font-medium">Target checking milestones</span>
          </div>
          <div className="p-3 bg-rose-500/10 text-rose-300 border border-rose-500/15 rounded-xl shadow-inner">
            <Calendar className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Stats Charts/Ratios Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Core Percentage Breakdown */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base mb-1">Notebook Submission Breakdown</h3>
            <p className="text-slate-400 text-xs mb-4">Percentage allocation based on all eligible student columns</p>

            {/* Circular Gauge or Stacked bar */}
            <div className="flex items-center justify-center py-6">
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90">
                  <circle
                    cx="72"
                    cy="72"
                    r="60"
                    className="stroke-white/10 fill-none"
                    strokeWidth="12"
                  />
                  {/* Dynamic offsets for stack ring */}
                  <circle
                    cx="72"
                    cy="72"
                    r="60"
                    className="stroke-emerald-400 fill-none transition-all duration-500"
                    strokeWidth="12"
                    strokeDasharray={`${2 * Math.PI * 60}`}
                    strokeDashoffset={`${2 * Math.PI * 60 * (1 - checkedPercentage / 100)}`}
                  />
                </svg>
                <div className="absolute text-center">
                  <span className="block text-3xl font-black text-white">{checkedPercentage}%</span>
                  <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Checked</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2 mt-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full inline-block" />
                Checked ({checkedCount})
              </span>
              <span className="text-white font-bold">{checkedPercentage}%</span>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-amber-400 rounded-full inline-block" />
                Incomplete ({incompleteCount})
              </span>
              <span className="text-white font-bold">{incompletePercentage}%</span>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-rose-500 rounded-full inline-block" />
                Missing / Absent ({missingCount})
              </span>
              <span className="text-white font-bold">{missingPercentage}%</span>
            </div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-white/10 rounded-full inline-block border border-white/20" />
                Unchecked ({uncheckedCount})
              </span>
              <span className="text-white font-bold">{uncheckedPercentage}%</span>
            </div>
          </div>
        </div>

        {/* Class Completion Leaderboard */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base mb-1">Class-wise Submission Rates</h3>
            <p className="text-slate-400 text-xs mb-4">Aggregated completions based on assigned monthly checklists</p>

            <div className="space-y-4">
              {classCompletionRates.map((cls, idx) => (
                <div key={cls.classId || idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-200">
                    <span className="font-bold">{cls.className}</span>
                    <span className="text-slate-400 text-[11px] font-medium">
                      {cls.totalChecked}/{cls.totalPossible} checked ({cls.percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-white/10 h-2.5 rounded-full overflow-hidden flex border border-white/5">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        cls.percentage >= 80 ? 'bg-emerald-400' :
                        cls.percentage >= 50 ? 'bg-amber-400' : 'bg-indigo-400'
                      }`} 
                      style={{ width: `${cls.percentage}%` }}
                    />
                  </div>
                </div>
              ))}

              {classCompletionRates.length === 0 && (
                <p className="text-slate-450 text-xs text-center py-8">No tasks created yet to generate class-level analytics.</p>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10">
            <button 
              onClick={() => onSelectTab('records')}
              className="w-full py-2 bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold rounded-lg border border-white/10 transition-colors inline-flex justify-center items-center gap-1.5 cursor-pointer shadow-md"
            >
              Go to Real-time Checking Matrix <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Subject-wise Completion Rates */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-white text-base mb-1">Subject Completion Status</h3>
            <p className="text-slate-400 text-xs mb-4">Analyzing which subject is on target vs falling behind</p>

            <div className="space-y-4">
              {subjectCompletionRates.map((sub, idx) => (
                <div key={sub.subject || idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-200">
                    <span className="font-bold">{sub.subject}</span>
                    <span className="text-slate-400 text-[11px]">
                      {sub.percentage}% complete ({sub.taskCount} task{sub.taskCount !== 1 ? 's' : ''})
                    </span>
                  </div>
                  <div className="w-full bg-white/10 h-2.5 rounded-full overflow-hidden flex border border-white/5">
                    <div 
                      className={`h-full rounded-full transition-all duration-400 ${
                        sub.percentage >= 75 ? 'bg-teal-400' : 'bg-indigo-400'
                      }`} 
                      style={{ width: `${sub.percentage}%` }}
                    />
                  </div>
                  <div className="flex justify-end">
                    <button 
                      onClick={() => {
                        const taskWithSubject = tasks.find(t => t.subject === sub.subject);
                        if (taskWithSubject) {
                          onQuickLocate(taskWithSubject.classId, sub.subject);
                        } else {
                          onSelectTab('records');
                        }
                      }}
                      className="text-[9px] text-indigo-300 hover:text-indigo-200 hover:underline cursor-pointer"
                    >
                      Quick-open checking matrix
                    </button>
                  </div>
                </div>
              ))}

              {subjectCompletionRates.length === 0 && (
                <p className="text-slate-450 text-xs text-center py-8">No monthly planner data has been loaded or created.</p>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 text-[11px] text-slate-400 text-center font-medium">
            Calculated instantly as records change.
          </div>
        </div>

      </div>

      {/* Bottom Section: Active Issues vs Live Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Urgent Followup Desk */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-xl lg:col-span-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-extrabold text-white text-base">Critical Student Checkups</h3>
              <span className="px-2 py-0.5 bg-rose-500/10 border border-rose-500/20 text-rose-300 text-[10px] font-bold rounded-full">
                Attention Required
              </span>
            </div>
            <p className="text-slate-400 text-xs mb-4">Students with highest counted incomplete or missing tasks in their plan</p>

            <div className="space-y-3.5">
              {studentsNeedsAttention.map((sa, idx) => (
                <div key={sa.student.id || idx} className="p-3 bg-white/5 hover:bg-white/8 rounded-xl transition-colors border border-white/5">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-xs font-bold text-white">{sa.student.name}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-medium">{sa.className} • Roll No: {sa.student.rollNumber}</p>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-right">
                      {sa.missing > 0 && (
                        <span className="px-1.5 py-0.5 bg-rose-500/15 border border-rose-500/25 text-rose-300 rounded text-[9px] flex items-center gap-0.5">
                          <XOctagon className="w-2.5 h-2.5" /> {sa.missing} Missing
                        </span>
                      )}
                      {sa.incomplete > 0 && (
                        <span className="px-1.5 py-0.5 bg-amber-500/15 border border-amber-500/25 text-amber-300 rounded text-[9px] flex items-center gap-0.5">
                          <AlertTriangle className="w-2.5 h-2.5" /> {sa.incomplete} Incomplete
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Detailed list of issues for that student */}
                  <div className="mt-2 pt-2 border-t border-white/5 space-y-1">
                    {sa.items.map((it, itemIdx) => (
                      <div key={itemIdx} className="flex justify-between text-[10px] text-slate-300 font-medium">
                        <span>
                          <strong className="text-slate-450">[{it.subject}]</strong> {it.taskTitle}
                        </span>
                        <span className="text-slate-400 max-w-[200px] truncate block italic">
                          {it.notes ? `"${it.notes}"` : 'No teacher remarks.'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {studentsNeedsAttention.length === 0 && (
                <div className="text-center py-10">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
                  <p className="text-slate-200 font-bold text-xs">All Notebooks Perfect!</p>
                  <p className="text-slate-450 text-[10px] mt-1">No incomplete or missing records in the database.</p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10">
            <button 
              onClick={() => onSelectTab('lookup')}
              className="w-full text-center text-xs text-indigo-300 hover:text-indigo-2 w font-medium cursor-pointer"
            >
              Open student lookup portal to share status with students/parents
            </button>
          </div>
        </div>

        {/* Real-time Checking Feed */}
        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 shadow-xl lg:col-span-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-extrabold text-white text-base">Real-time Activity Stream</h3>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-450 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
              </span>
            </div>
            <p className="text-slate-400 text-xs mb-4">Live feedback log as the team inspects homework notebooks</p>

            <div className="space-y-4">
              {activityLogs.slice(0, 5).map((log, idx) => (
                <div key={log.id || idx} className="flex gap-3 text-xs leading-relaxed items-start">
                  <div className="mt-0.5">
                    {log.status === 'checked' ? (
                      <span className="p-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 rounded-full inline-block">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </span>
                    ) : log.status === 'incomplete' ? (
                      <span className="p-1 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-full inline-block">
                        <AlertTriangle className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="p-1 bg-rose-500/10 text-rose-300 border border-rose-500/20 rounded-full inline-block">
                        <XOctagon className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                  <div>
                    <p className="text-slate-300 font-medium">
                      <strong className="text-white font-bold">{log.studentName}</strong>'s 
                      {' '}<span className="text-slate-400 font-semibold">{log.subject}</span> notebook was marked{' '}
                      <span className={`font-extrabold ${
                        log.status === 'checked' ? 'text-emerald-400' :
                        log.status === 'incomplete' ? 'text-amber-400' : 'text-rose-400'
                      }`}>{log.status}</span>.
                    </p>
                    <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-medium">
                      <span>{log.className} • {log.taskTitle}</span>
                      <span>•</span>
                      <span>{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </p>
                  </div>
                </div>
              ))}

              {activityLogs.length === 0 && (
                <p className="text-slate-455 text-xs text-center py-10">No recent submissions logs. Check the records tab to start marking!</p>
              )}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
            <span className="text-[10px] text-slate-400 font-medium">Showing last 5 activity updates</span>
            <button 
              onClick={() => onSelectTab('records')}
              className="text-xs text-indigo-300 hover:text-indigo-200 font-bold hover:underline cursor-pointer"
            >
              Start Recording
            </button>
          </div>
        </div>

      </div>
      </div>
      )}

    </div>
  );
}
