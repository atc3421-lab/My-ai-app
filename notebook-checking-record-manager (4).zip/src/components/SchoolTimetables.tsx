import React, { useState, useMemo } from 'react';
import { 
  Calendar, 
  Clock, 
  Search, 
  BookOpen, 
  GraduationCap, 
  Layers, 
  Grid3X3, 
  User, 
  Coffee, 
  Bell, 
  ArrowRightLeft,
  Flame,
  CheckCircle,
  HelpCircle,
  ClipboardList
} from 'lucide-react';
import { 
  generateFullSchoolTimetables, 
  getTeacherWeeklyTimetable, 
  resolveTeacherForSubject,
  ClassTimetable,
  TimetableSlot,
  TeacherAgendaSlot
} from '../data/timetableData';

interface SchoolTimetablesProps {
  allotments: any[];
  currentUser: {
    username: string;
    name: string;
    role: 'admin' | 'teacher' | 'management';
  } | null;
}

export default function SchoolTimetables({ allotments, currentUser }: SchoolTimetablesProps) {
  // Extract clean unique list of teachers from allotments
  const uniqueTeachers = useMemo(() => {
    const list = new Set<string>();
    allotments.forEach((allot: any) => {
      if (allot.classTeacher) {
        const ct = allot.classTeacher.trim();
        if (ct && ct !== '—' && ct !== '-') {
          list.add(ct);
        }
      }
      if (allot.subjects) {
        Object.values(allot.subjects).forEach((val: any) => {
          if (typeof val === 'string') {
            const trimmed = val.trim();
            if (trimmed && trimmed !== '—' && trimmed !== '-') {
              list.add(trimmed);
            }
          }
        });
      }
    });
    return Array.from(list).sort();
  }, [allotments]);

  const [selectedClassId, setSelectedClassId] = useState<string>('class_vi_o');
  const [selectedTeacherName, setSelectedTeacherName] = useState<string>('');
  const [viewStyle, setViewStyle] = useState<'grid' | 'timeline'>('grid');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Tab within timetables: "Teacher-wise" vs "School-wide"
  const [timetableSubTab, setTimetableSubTab] = useState<'my_agenda' | 'school_grid'>('my_agenda');

  // Generate full structural data
  const schoolTimetables = useMemo(() => {
    return generateFullSchoolTimetables(allotments);
  }, [allotments]);

  // Selected Class Timetable object
  const selectedClassTimetable = useMemo(() => {
    return schoolTimetables.find(t => t.classId === selectedClassId) || schoolTimetables[0];
  }, [schoolTimetables, selectedClassId]);

  // Initialize selectedTeacherName on load or when role changes
  React.useEffect(() => {
    if (currentUser?.role === 'teacher') {
      setSelectedTeacherName(currentUser.name);
    } else if (uniqueTeachers.length > 0) {
      // Default admin to the first teacher in alphabetical order
      setSelectedTeacherName(uniqueTeachers[0]);
    }
  }, [currentUser, uniqueTeachers]);

  // Generate teacher agenda
  const teacherAgenda = useMemo(() => {
    if (!selectedTeacherName) return null;
    return getTeacherWeeklyTimetable(selectedTeacherName, allotments, schoolTimetables);
  }, [selectedTeacherName, allotments, schoolTimetables]);

  // Determine if selected teacher is a class teacher of any grade
  const classTeacherOf = useMemo(() => {
    if (!selectedTeacherName) return null;
    const match = allotments.find(allot => allot.classTeacher === selectedTeacherName);
    return match ? match.grade : null;
  }, [allotments, selectedTeacherName]);

  // Set default view on load
  React.useEffect(() => {
    if (currentUser?.role === 'teacher') {
      setTimetableSubTab('my_agenda');
    } else {
      setTimetableSubTab('school_grid');
    }
  }, [currentUser]);

  // Full-School Slot Search
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    
    const results: {
      className: string;
      classId: string;
      day: string;
      periodNo: number;
      time: string;
      subject: string;
      teacher: string;
    }[] = [];

    const query = searchQuery.toLowerCase().trim();

    schoolTimetables.forEach(t => {
      t.periods.forEach(p => {
        Object.entries(p.subjects).forEach(([day, rawSub]) => {
          if (!rawSub) return;
          const subject = String(rawSub);
          const teacher = resolveTeacherForSubject(t.className, subject, allotments);
          if (
            subject.toLowerCase().includes(query) || 
            teacher.toLowerCase().includes(query)
          ) {
            results.push({
              className: t.className,
              classId: t.classId,
              day,
              periodNo: p.periodNo,
              time: p.time,
              subject,
              teacher
            });
          }
        });
      });
    });

    return results;
  }, [schoolTimetables, searchQuery, allotments]);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="space-y-6">
      
      {/* Header Banner Section */}
      <div className="bg-gradient-to-r from-indigo-950/40 via-slate-900/45 to-indigo-950/40 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xl">
        <div className="space-y-1.5">
          <span className="text-[10px] text-indigo-400 font-black tracking-wider uppercase bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full inline-block">
            📅 Academic Scheduling Hub
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight">Time Table & Lecture Planner Register</h2>
          <p className="text-xs text-slate-300 font-semibold max-w-xl">
            Live integration containing the full 27 school grades schedules. Cross-matches raw periods with active dynamic subject teacher allotments.
          </p>
        </div>

        {/* Timetable main sub-tab switcher */}
        {currentUser?.role !== 'teacher' && (
          <div className="flex gap-2 bg-slate-950 p-1.5 rounded-xl border border-white/5 self-start md:self-auto shadow-inner">
            <button
              onClick={() => setTimetableSubTab('my_agenda')}
              className={`py-2 px-4 rounded-lg text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                timetableSubTab === 'my_agenda' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" /> Teacher-wise Timetables
            </button>

            <button
              onClick={() => setTimetableSubTab('school_grid')}
              className={`py-2 px-4 rounded-lg text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                timetableSubTab === 'school_grid' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" /> Whole School Timetables
            </button>
          </div>
        )}
      </div>

      {/* VIEW A: TEACHER-WISE TIMETABLE SHEET IN SCHOOL GRID FORMAT */}
      {timetableSubTab === 'my_agenda' && selectedTeacherName && teacherAgenda && (
        <div className="space-y-6">
          
          {/* Teacher Selector & Layout Control Center */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950/25 to-slate-900 border border-white/10 rounded-2xl p-5 backdrop-blur-md shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="space-y-1.5 max-w-md">
              <label className="text-[10px] uppercase font-black tracking-widest text-indigo-400 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" /> Faculty Timetable lookup
              </label>
              <h3 className="text-base font-black text-white tracking-tight">Teacher-wise Schedule Monitor</h3>
              <p className="text-xs text-slate-450 font-medium">
                Review complete lecture allocations and recess intervals formatted as an academic school timetable.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {/* Teacher selector dropdown */}
              <div className="flex flex-col space-y-1">
                <span className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Select Teacher</span>
                {currentUser?.role === 'teacher' ? (
                  <div className="bg-slate-950 border border-indigo-505/20 rounded-xl px-4 py-2.5 text-xs font-bold text-indigo-400 bg-indigo-500/5 select-none min-w-[200px]">
                    Ms/Mr {currentUser.name}
                  </div>
                ) : (
                  <select
                    value={selectedTeacherName}
                    onChange={(e) => setSelectedTeacherName(e.target.value)}
                    className="bg-slate-950 border border-white/10 rounded-xl px-3.5 py-2 text-xs font-black text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer font-sans min-w-[200px]"
                  >
                    {uniqueTeachers.map(t => (
                      <option key={t} value={t} className="bg-slate-950 text-white">
                        {t}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* View layout style toggle */}
              <div className="flex flex-col space-y-1">
                <span className="text-[9px] uppercase font-bold text-slate-450 tracking-wider">Format Style</span>
                <div className="flex bg-slate-950 p-1 rounded-xl border border-white/5">
                  <button
                    onClick={() => setViewStyle('grid')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                      viewStyle === 'grid' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Grid3X3 className="w-3 h-3" /> Grid Form
                  </button>
                  <button
                    onClick={() => setViewStyle('timeline')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                      viewStyle === 'timeline' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <ClipboardList className="w-3 h-3" /> Day-wise Cards
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Workload Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden flex items-center gap-4 shadow-xl">
              <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded-xl">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] text-slate-455 uppercase font-black tracking-wider block leading-none mb-1">Faculty Member</span>
                <span className="text-base font-black text-white block truncate max-w-[200px]">{selectedTeacherName}</span>
                <span className="text-[10px] text-indigo-300 block font-bold mt-0.5">
                  {classTeacherOf ? `Class Teacher: ${classTeacherOf}` : 'Subject Instructor'}
                </span>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden flex items-center gap-4 shadow-xl">
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded-xl">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] text-slate-455 uppercase font-black tracking-wider block leading-none mb-1">Weekly Direct Lectures</span>
                <span className="text-xl font-black text-white">
                  {Object.values(teacherAgenda).flat().length} Sessions / Week
                </span>
                <span className="text-[10px] text-emerald-300 block font-semibold mt-0.5">Resolved from active allocations</span>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden flex items-center gap-4 shadow-xl">
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded-xl">
                <Flame className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] text-slate-455 uppercase font-black tracking-wider block leading-none mb-1">Daily Load Factor</span>
                <span className="text-base font-black text-white">
                  {(Object.values(teacherAgenda).flat().length / 6).toFixed(1)} Periods / Day
                </span>
                <span className="text-[10px] text-amber-300 block font-semibold mt-0.5">Average of Monday-Saturday cycle</span>
              </div>
            </div>

          </div>

          {/* VIEW STYLE A: THE REQUESTED HIGH-FIDELITY SCHOOL TIMETABLE GRID FORMAT */}
          {viewStyle === 'grid' && (
            <div className="bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl shadow-2xl p-5 space-y-4">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4">
                <div className="space-y-1">
                  <h3 className="text-base font-black text-white tracking-tight flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                    Teacher Weekly Lecture Grid & Schedule
                  </h3>
                  <p className="text-[11px] font-bold text-indigo-350 uppercase tracking-wider">
                    School Format representing standard class-period divisions for <span className="text-white font-black underline">{selectedTeacherName}</span>
                  </p>
                </div>
                <div className="bg-white/5 border border-white/10 text-slate-400 font-mono text-[10px] px-2.5 py-1 rounded-lg">
                  Load status: {Object.values(teacherAgenda).flat().length > 30 ? '🔥 High workload' : '✅ Balanced workload'}
                </div>
              </div>

              {/* Grid representation table container */}
              <div className="overflow-x-auto rounded-xl border border-white/5 shadow-inner">
                <table className="w-full text-left border-collapse min-w-[750px]">
                  <thead>
                    <tr className="bg-slate-950/90 text-[10px] text-slate-450 font-black uppercase tracking-widest border-b border-white/10">
                      <th className="py-3 px-4 w-32 border-r border-white/5">Lectures & Recess</th>
                      <th className="py-3 px-3 text-center">Monday</th>
                      <th className="py-3 px-3 text-center">Tuesday</th>
                      <th className="py-3 px-3 text-center">Wednesday</th>
                      <th className="py-3 px-3 text-center">Thursday</th>
                      <th className="py-3 px-3 text-center">Friday</th>
                      <th className="py-3 px-3 text-center">Saturday</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-white/5 bg-slate-900/10">
                    
                    {/* Row 1: Assembly */}
                    <tr className="bg-amber-500/5 hover:bg-amber-500/10 transition-all">
                      <td className="py-2 px-4 font-mono font-bold text-[10px] text-amber-300 border-r border-white/5">
                        <span className="block text-[8px] uppercase tracking-wider text-amber-500 font-sans">8.30 am to 8.50 am</span>
                        Assembly Hour
                      </td>
                      <td colSpan={6} className="text-center py-2 px-4 text-amber-200/90 text-[10px] font-semibold tracking-wider uppercase bg-amber-500/5 italic">
                        ✨ {classTeacherOf 
                          ? `Class Assembly Lead duty in your classroom: Grade ${classTeacherOf}` 
                          : 'Morning Prayers & General Student Assembly Supervision Support'}
                      </td>
                    </tr>

                    {/* Row 2: Meditation / Roll Call */}
                    <tr className="bg-indigo-500/5 hover:bg-indigo-500/10 transition-all">
                      <td className="py-2 px-4 font-mono font-bold text-[10px] text-indigo-300 border-r border-white/5">
                        <span className="block text-[8px] uppercase tracking-wider text-indigo-500 font-sans">8.50 am to 8.55 am</span>
                        Meditation
                      </td>
                      <td colSpan={6} className="text-center py-2 px-4 text-indigo-200/90 text-[10px] font-semibold tracking-wider bg-indigo-500/5">
                        🧘 {classTeacherOf 
                          ? `Meditation & Classroom Morning Roll Call at Grade ${classTeacherOf}` 
                          : 'Classroom Supervision & Administrative Roll Call reviews'}
                      </td>
                    </tr>

                    {/* Periods row generation */}
                    {(() => {
                      // Lookup cells mapping helper
                      const isClassPrimary = (className: string) => {
                        const match = schoolTimetables.find(ct => ct.className === className);
                        if (match) return match.isPrimary;
                        return className.startsWith("Grade I ") || 
                               className.startsWith("Grade II ") || 
                               className.startsWith("Grade III ") || 
                               className.startsWith("Grade IV ") || 
                               className.startsWith("Grade V ");
                      };

                      const getLectureForSlot = (day: string, rowType: 'period' | 'b5_or_pl' | 'b6_or_p5' | 'sl_or_p6', periodNo?: number) => {
                        const dayLectures = teacherAgenda[day] || [];
                        
                        if (rowType === 'period') {
                          return dayLectures.find(l => l.periodNo === periodNo);
                        }
                        
                        if (rowType === 'b5_or_pl') {
                          // Senior P5
                          return dayLectures.find(l => l.periodNo === 5 && !isClassPrimary(l.className));
                        }
                        
                        if (rowType === 'b6_or_p5') {
                          // Senior P6 or Primary P5
                          return dayLectures.find(l => 
                            (l.periodNo === 6 && !isClassPrimary(l.className)) ||
                            (l.periodNo === 5 && isClassPrimary(l.className))
                          );
                        }
                        
                        if (rowType === 'sl_or_p6') {
                          // Primary P6
                          return dayLectures.find(l => l.periodNo === 6 && isClassPrimary(l.className));
                        }
                        
                        return undefined;
                      };

                      const renderTdCell = (day: string, rowType: 'period' | 'b5_or_pl' | 'b6_or_p5' | 'sl_or_p6', periodNo?: number) => {
                        const item = getLectureForSlot(day, rowType, periodNo);
                        if (item) {
                          return (
                            <td key={day} className="p-3 border-r border-white/5 bg-indigo-500/5 hover:bg-indigo-500/10 transition-all font-sans relative">
                              <div className="flex flex-col items-center justify-center text-center space-y-1">
                                <span className="text-xs font-black text-white">
                                  {item.className.replace("Grade ", "Gr. ")}
                                </span>
                                <span className="text-[10px] bg-indigo-500/20 border border-indigo-500/20 text-indigo-300 font-extrabold px-1.5 py-0.5 rounded uppercase leading-none">
                                  {item.subject}
                                </span>
                              </div>
                            </td>
                          );
                        }

                        // Label recess days nicely or display simple dashes
                        if (rowType === 'b5_or_pl' && day !== 'Saturday') {
                          return (
                            <td key={day} className="p-3 border-r border-white/5 text-center text-emerald-400 bg-emerald-500/[0.02]">
                              <div className="text-[9px] font-bold uppercase tracking-wider text-emerald-450 flex flex-col items-center justify-center">
                                <span className="text-emerald-500 text-[10px]">🍱</span> Pri. Recess
                              </div>
                            </td>
                          );
                        }

                        if (rowType === 'sl_or_p6' && day !== 'Saturday') {
                          return (
                            <td key={day} className="p-3 border-r border-white/5 text-center text-emerald-400 bg-emerald-500/[0.02]">
                              <div className="text-[9px] font-bold uppercase tracking-wider text-emerald-450 flex flex-col items-center justify-center">
                                <span className="text-emerald-500 text-[10px]">🍱</span> Sen. Recess
                              </div>
                            </td>
                          );
                        }

                        // Sat for primary has no periods at all - show quiet off
                        if (day === 'Saturday' && (rowType === 'b5_or_pl' || rowType === 'sl_or_p6')) {
                          return (
                            <td key={day} className="p-3 border-r border-white/5 text-center text-slate-650 font-bold bg-slate-950/20">
                              —
                            </td>
                          );
                        }

                        return (
                          <td key={day} className="p-3 border-r border-white/5 text-center text-slate-650 font-bold hover:bg-white/[0.01] transition-all">
                            —
                          </td>
                        );
                      };

                      return (
                        <>
                          {/* P1 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 1</span>
                              8.55 am - 9.30 am
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 1))}
                          </tr>

                          {/* P2 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 2</span>
                              9.30 am - 10.10 am
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 2))}
                          </tr>

                          {/* Fruit Break */}
                          <tr className="bg-rose-500/5 hover:bg-rose-500/10 transition-all">
                            <td className="py-2.5 px-4 font-mono font-bold text-[10px] text-rose-300 border-r border-white/5">
                              <span className="block text-[8px] uppercase tracking-wider text-rose-500 font-sans">10.10 am - 10.25 am</span>
                              Fruit Break
                            </td>
                            <td colSpan={6} className="text-center py-1.5 px-3 text-rose-250 font-black tracking-widest text-[9px] bg-rose-500/5 uppercase">
                              🍉 FRUIT BREAK & STAFF NUTRITIONAL INTERVAL (15 mins)
                            </td>
                          </tr>

                          {/* P3 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 3</span>
                              10.25 am - 11.05 am
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 3))}
                          </tr>

                          {/* P4 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 4</span>
                              11.05 am - 11.45 am
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 4))}
                          </tr>

                          {/* Time Block: 11.45 am - 12.25 pm */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[11px] leading-tight mb-0.5">Sen P5 / Pri Lun</span>
                              11.45 am - 12.25 pm
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'b5_or_pl'))}
                          </tr>

                          {/* Time Block: 12.25 pm - 1.05 pm */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[11px] leading-tight mb-0.5">Sen P6 / Pri P5</span>
                              12.25 pm - 1.05 pm
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'b6_or_p5'))}
                          </tr>

                          {/* Time Block: 1.05 pm - 1.45 pm */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[11px] leading-tight mb-0.5">Sen Lun / Pri P6</span>
                              1.05 pm - 1.45 pm
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'sl_or_p6'))}
                          </tr>

                          {/* P7 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 7</span>
                              1.45 pm - 2.20 pm
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 7))}
                          </tr>

                          {/* P8 */}
                          <tr className="hover:bg-white/[0.01] transition-all">
                            <td className="py-3 px-4 font-mono font-bold text-[11px] text-indigo-400 border-r border-white/5">
                              <span className="block font-sans font-black text-white text-[12px]">Period 8</span>
                              2.20 pm - 2.55 pm
                            </td>
                            {daysOfWeek.map(day => renderTdCell(day, 'period', 8))}
                          </tr>
                        </>
                      );
                    })()}

                    {/* Exit Prep */}
                    <tr className="bg-slate-900/60 hover:bg-slate-900/80 transition-all">
                      <td className="py-2.5 px-4 font-mono font-bold text-[10px] text-slate-400 border-r border-white/5">
                        <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-sans">2.55 pm to 3.00 pm</span>
                        Exit Prep hour
                      </td>
                      <td colSpan={6} className="text-center py-2 px-4 text-slate-350 font-bold tracking-wider uppercase text-[10px] italic">
                        🚍 Student Attendance Check & Bus Boarding Escort supervision (All staff)
                      </td>
                    </tr>

                  </tbody>
                </table>
              </div>

              {/* Informative Grid Legend */}
              <div className="bg-slate-950/55 rounded-xl p-3 border border-white/5 text-[10px] text-slate-400 flex flex-wrap gap-x-6 gap-y-2 font-mono items-center">
                <span className="font-bold uppercase text-slate-305 shrink-0">ℹ️ Teacher-wise Timetable Legend:</span>
                <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-indigo-500/10 border border-indigo-500/25" /> Active Assigned Class Lecture</span>
                <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-emerald-500/[0.03] border border-emerald-500/10" /> Grade Lunch Break interval</span>
                <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-rose-500/5 border border-rose-500/15" /> Nutritional Fruit Recess</span>
                <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-amber-500/5 border border-amber-500/15" /> Lead assemblies</span>
              </div>

            </div>
          )}

          {/* VIEW STYLE B: THE ORIGINAL DAY-WISE CARDS LIST VIEW */}
          {viewStyle === 'timeline' && (
            <div className="space-y-4">
              <span className="text-xs font-black text-indigo-350 tracking-wider uppercase block bg-indigo-500/5 py-1 px-3 border border-indigo-500/10 rounded-lg inline-block">
                📆 Day-By-Day Scheduled Lectures Matrix for {selectedTeacherName}
              </span>
              
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                {daysOfWeek.map(day => {
                  const dayLectures = teacherAgenda[day] || [];
                  const isSaturday = day === 'Saturday';

                  return (
                    <div 
                      key={day} 
                      className="bg-white/5 border border-white/10 rounded-2xl p-5 backdrop-blur-xl shadow-xl space-y-4 hover:border-white/15 transition-all"
                    >
                      {/* Day Title and Badge */}
                      <div className="flex items-center justify-between border-b border-white/5 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full bg-indigo-400 shadow-md shadow-indigo-500/30" />
                          <h3 className="font-extrabold text-white text-base tracking-tight">{day}</h3>
                        </div>
                        
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          dayLectures.length > 0 
                            ? 'bg-emerald-500/15 text-emerald-350 border border-emerald-500/25' 
                            : 'bg-slate-900 text-slate-450'
                        }`}>
                          {dayLectures.length} Lectures Scheduled
                        </span>
                      </div>

                      {/* Timeline List */}
                      {dayLectures.length > 0 ? (
                        <div className="space-y-3 pt-1">
                          {dayLectures.map((item, idx) => (
                            <div 
                              key={idx} 
                              className="bg-slate-900/40 hover:bg-slate-900/70 border border-white/5 hover:border-white/10 rounded-xl p-3.5 transition-all flex items-center justify-between gap-3 relative overflow-hidden"
                            >
                              <div className="flex items-center gap-3">
                                <div className="h-9 w-9 bg-indigo-500/15 border border-indigo-500/20 rounded-lg flex items-center justify-center font-mono font-bold text-xs text-indigo-350">
                                  P{item.periodNo}
                                </div>
                                <div className="space-y-0.5">
                                  <span className="text-xs font-black text-white flex items-center gap-1.5">
                                    {item.className}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-bold block bg-white/5 border border-white/5 rounded px-1.5 py-0.5 inline-block">
                                    Subject: <span className="text-white font-black">{item.subject}</span>
                                  </span>
                                </div>
                              </div>

                              {/* Chronological Clock */}
                              <div className="text-right flex flex-col items-end gap-1 font-mono text-[11px] text-slate-350 font-semibold">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                                  {item.time}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-8 text-center bg-slate-900/20 border border-dashed border-white/5 rounded-xl space-y-1.5">
                          <Coffee className="w-8 h-8 text-slate-500 mx-auto" />
                          <p className="text-xs text-slate-400 font-bold">No active lectures scheduled</p>
                          <p className="text-[10px] text-slate-550">
                            {isSaturday ? 'Seniors/Primary Classes are off or assigned to self-studies.' : 'Great! A free day or preparation leave.'}
                          </p>
                        </div>
                      )}

                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      )}

      {/* VIEW B: SCHOOLD-WIDE TIMETABLE VIEWER */}
      {timetableSubTab === 'school_grid' && (
        <div className="space-y-6">
          
          {/* Selector & Search Utilities Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* 1. Selection Class dropdown */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-md shadow-xl flex flex-col justify-center space-y-2">
              <label className="text-[10px] uppercase font-black tracking-wider text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-400" /> Choose Class & Division
              </label>
              
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
              >
                {schoolTimetables.map(ct => (
                  <option key={ct.classId} value={ct.classId} className="bg-slate-950 text-white">
                    {ct.className} (CT: {ct.classTeacher || 'Not Assigned'})
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Interactive Search Tool */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 backdrop-blur-md shadow-xl flex flex-col justify-center space-y-2 lg:col-span-2">
              <label className="text-[10px] uppercase font-black tracking-wider text-slate-400 flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-indigo-400" /> Search School Timetables
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Type a teacher name (e.g. Mr. Akshay) or subject (e.g. Math, SS) to trace active periods..."
                  className="w-full bg-slate-900 border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs font-bold text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-all"
                />
                <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              </div>
            </div>

          </div>

          {/* SEARCH RESULTS VIEW */}
          {searchQuery.trim().length > 0 && (
            <div className="bg-indigo-500/5 border border-indigo-500/25 rounded-2xl p-5 space-y-3 backdrop-blur-xl shadow-xl max-h-[350px] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-indigo-500/10 pb-2">
                <h4 className="text-xs font-black text-indigo-350 uppercase tracking-widest flex items-center gap-2">
                  🔍 Tracer Results for: "{searchQuery}"
                </h4>
                <span className="text-[10px] bg-indigo-500/15 text-indigo-300 font-bold px-2 py-0.5 rounded-full border border-indigo-500/20">
                  {searchResults.length} Match-slots Detected
                </span>
              </div>

              {searchResults.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {searchResults.map((res, idx) => (
                    <div 
                      key={idx} 
                      className="bg-slate-950/70 border border-white/5 rounded-xl p-3 text-xs flex flex-col justify-between space-y-2 hover:border-indigo-550 transition-all shadow-inner"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[10px] text-slate-400 font-bold block">{res.className}</span>
                          <span className="font-extrabold text-white text-sm">{res.subject}</span>
                        </div>
                        <span className="text-[10px] bg-white/5 border border-white/5 font-black text-slate-350 px-2 py-0.5 rounded uppercase">
                          {res.day}
                        </span>
                      </div>

                      <div className="flex items-center justify-between border-t border-white/5 pt-2 text-[10px] font-mono">
                        <span className="text-indigo-400 font-black">Period {res.periodNo} ({res.time})</span>
                        <span className="text-emerald-350 font-bold flex items-center gap-1 mt-0.5">
                          <User className="w-3 h-3 shrink-0" />
                          {res.teacher}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 text-center py-4 font-bold">
                  No matching slots found anywhere in school schedules for "{searchQuery}".
                </p>
              )}
            </div>
          )}

          {/* PHYSICAL-GRADE EXCEL TIMETABLE GRID SHEET */}
          <div className="bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl shadow-2xl p-5 space-y-4">
            
            {/* Summary Grade Ribbon bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/5 pb-4">
              <div className="space-y-1">
                <h3 className="text-lg font-black text-white tracking-tight flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-emerald-400" />
                  Weekly Timetable for {selectedClassTimetable.className}
                </h3>
                <p className="text-[11px] font-bold text-indigo-350 uppercase tracking-widest shrink-0">
                  Class Teacher: <span className="text-white font-black">{selectedClassTimetable.classTeacher || 'None Assigned'}</span>
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] bg-white/5 border border-white/10 text-slate-300 font-bold px-2.5 py-1 rounded-lg">
                  {selectedClassTimetable.isPrimary ? '🎒 Primary Schedule System (I-V)' : '🎓 Senior Schedule System (VI-X)'}
                </span>
                <span className="text-[10px] bg-slate-900 border border-white/5 text-slate-400 font-bold px-2.5 py-1 rounded-lg">
                  Total load: {selectedClassTimetable.isPrimary ? '40 Periods' : '48 Periods'}
                </span>
              </div>
            </div>

            {/* Main Timetable Structure View Grid */}
            <div className="overflow-x-auto rounded-xl border border-white/5 shadow-inner">
              <table className="w-full text-left border-collapse min-w-[700px]">
                
                {/* Headers */}
                <thead>
                  <tr className="bg-slate-950/80 text-[10px] text-slate-400 font-black uppercase tracking-wider border-b border-white/10">
                    <th className="py-3 px-4 w-28">P. No / Time</th>
                    <th className="py-3 px-4">Monday</th>
                    <th className="py-3 px-4">Tuesday</th>
                    <th className="py-3 px-4">Wednesday</th>
                    <th className="py-3 px-4">Thursday</th>
                    <th className="py-3 px-4">Friday</th>
                    {!selectedClassTimetable.isPrimary && <th className="py-3 px-4">Saturday</th>}
                  </tr>
                </thead>

                {/* Table Body */}
                <tbody className="text-xs divide-y divide-white/5 bg-slate-900/10">
                  
                  {/* Row 1: Assembly Time */}
                  <tr className="bg-amber-500/5 hover:bg-amber-500/10 transition-all font-sans">
                    <td className="py-2.5 px-4 font-mono font-bold text-[10px] text-amber-300 border-r border-white/5">
                      <span className="block font-sans text-[8px] uppercase tracking-wider text-amber-500">8.30 am to 8.50 am</span>
                      School Assembly
                    </td>
                    <td colSpan={selectedClassTimetable.isPrimary ? 5 : 6} className="text-center py-2 px-4 text-amber-200/95 font-semibold tracking-wider uppercase text-[10px] bg-amber-500/5 italic">
                       ✨ Morning School Prayer, Anthem, and National Assembly Time (All Faculty Presence)
                    </td>
                  </tr>

                  {/* Row 2: Meditation */}
                  <tr className="bg-indigo-500/5 hover:bg-indigo-500/10 transition-all font-sans">
                    <td className="py-2.5 px-4 font-mono font-bold text-[10px] text-indigo-300 border-r border-white/5">
                      <span className="block font-sans text-[8px] uppercase tracking-wider text-indigo-500">8.50 am to 8.55 am</span>
                      Meditation
                    </td>
                    <td colSpan={selectedClassTimetable.isPrimary ? 5 : 6} className="text-center py-2 px-4 text-indigo-200/95 font-semibold tracking-wider text-[10px] bg-indigo-500/5">
                       🧘 Meditation & Classroom Morning Roll Call (Class Teacher: <span className="font-bold underline text-indigo-300">{selectedClassTimetable.classTeacher || 'Teacher'}</span>)
                    </td>
                  </tr>

                  {/* Dynamic Periods 1-8 */}
                  {selectedClassTimetable.periods.map((p, idx) => {
                    // Check if lunch break should insert after Period 4 (Primary) or Period 6 (Senior)
                    const isLunchInsert = 
                      (selectedClassTimetable.isPrimary && p.periodNo === 5) || 
                      (!selectedClassTimetable.isPrimary && p.periodNo === 7);

                    // Check if fruit break inserts after Period 2
                    const isFruitInsert = p.periodNo === 3;

                    const rows: React.ReactNode[] = [];

                    // 1. Insert Fruit Break
                    if (isFruitInsert) {
                      rows.push(
                        <tr key="fruit_break" className="bg-rose-500/5 hover:bg-rose-500/10 transition-all font-sans">
                          <td className="py-2 px-4 font-mono font-bold text-[10px] text-rose-300 border-r border-white/5">
                            <span className="block font-sans text-[8px] uppercase tracking-wider text-rose-500">10.10 am to 10.25 am</span>
                            Fruit Break
                          </td>
                          <td colSpan={selectedClassTimetable.isPrimary ? 5 : 6} className="text-center py-1.5 px-4 text-rose-250 font-bold tracking-widest uppercase text-[10px] bg-rose-500/5">
                            🍉 FRUIT BREAK & NUTRITIONAL RESET (15 mins)
                          </td>
                        </tr>
                      );
                    }

                    // 2. Insert Lunch Break (Senior vs Primary)
                    if (isLunchInsert) {
                      const lunchTime = selectedClassTimetable.isPrimary ? "11.45 am to 12.25 pm" : "1.05 pm to 1.45 pm";
                      rows.push(
                        <tr key="lunch_break" className="bg-emerald-500/5 hover:bg-emerald-500/10 transition-all font-sans">
                          <td className="py-2 px-4 font-mono font-bold text-[10px] text-emerald-300 border-r border-white/5">
                            <span className="block font-sans text-[8px] uppercase tracking-wider text-emerald-500">{lunchTime}</span>
                            Lunch Break
                          </td>
                          <td colSpan={selectedClassTimetable.isPrimary ? 5 : 6} className="text-center py-1.5 px-4 text-emerald-300 font-bold tracking-widest uppercase text-[10px] bg-emerald-500/5">
                            🍱 LUNCH HOUR BREAK & STAFF RELIGIOUS RECESS (40 mins)
                          </td>
                        </tr>
                      );
                    }

                    // Render Standard Period Row
                    rows.push(
                      <tr key={`period_${p.periodNo}`} className="hover:bg-white/5 transition-all">
                        
                        {/* Period designation */}
                        <td className="py-3 px-4 font-mono font-semibold text-[11px] text-indigo-400 border-r border-white/5">
                          <span className="block font-sans font-black text-[12px] text-white">Period {p.periodNo}</span>
                          {p.time}
                        </td>

                        {/* Monday to Saturday cells */}
                        {daysOfWeek.map((day) => {
                          // Bypass saturday for primary grades
                          if (selectedClassTimetable.isPrimary && day === 'Saturday') return null;

                          const rawSubject = (p.subjects as any)[day] || "-";
                          const resolvedTeacherName = resolveTeacherForSubject(
                            selectedClassTimetable.className, 
                            rawSubject, 
                            allotments
                          );

                          // Highlight active teacher box
                          const isMyself = currentUser?.role === 'teacher' && 
                                           resolvedTeacherName.toLowerCase().includes(currentUser.name.toLowerCase());

                          return (
                            <td 
                              key={day} 
                              className={`p-3 border-r border-white/5 relative group ${
                                isMyself 
                                  ? 'bg-indigo-500/10 text-white font-sans' 
                                  : ''
                              }`}
                            >
                              <div className="space-y-0.5">
                                <span className={`text-[12px] block font-extrabold ${
                                  isMyself ? 'text-indigo-300' : 'text-slate-100'
                                }`}>
                                  {rawSubject}
                                </span>
                                
                                {rawSubject !== "-" && (
                                  <span className="text-[10px] block text-slate-400 font-semibold group-hover:text-slate-300 transition-all truncate">
                                    {resolvedTeacherName ? `(${resolvedTeacherName})` : '—'}
                                  </span>
                                )}
                              </div>

                              {isMyself && (
                                <span className="absolute top-1.5 right-1.5 bg-indigo-500 h-2 w-2 rounded-full shadow" title="Your assigned lecture" />
                              )}
                            </td>
                          );
                        })}

                      </tr>
                    );

                    return rows;
                  })}

                  {/* Row: Exit Prep */}
                  <tr className="bg-slate-900/60 hover:bg-slate-900/80 transition-all font-sans">
                    <td className="py-2.5 px-4 font-mono font-bold text-[10px] text-slate-400 border-r border-white/5">
                      <span className="block font-sans text-[8px] uppercase tracking-wider text-slate-500">2.55 pm to 3.00 pm</span>
                      Exit Prep
                    </td>
                    <td colSpan={selectedClassTimetable.isPrimary ? 5 : 6} className="text-center py-2 px-4 text-slate-350 font-bold tracking-wider uppercase text-[10px] italic">
                       🚍 Student Attendance Recall & Bus Boarding Prep
                    </td>
                  </tr>

                </tbody>
              </table>

            </div>

            {/* Quick legenda information */}
            <div className="bg-slate-950/50 rounded-xl p-3 border border-white/5 text-[10px] text-slate-400 flex flex-wrap gap-x-6 gap-y-2 font-mono items-center">
              <span className="font-bold uppercase text-slate-300 shrink-0">ℹ️ Timetable Legend:</span>
              <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-indigo-500/10 border border-indigo-500/25" /> Your Lecture</span>
              <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-amber-500/15" /> Assemblies</span>
              <span className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded bg-rose-500/15" /> Breaks & Lunch reces</span>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
