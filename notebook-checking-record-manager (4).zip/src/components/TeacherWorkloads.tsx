import React, { useState, useMemo, useEffect } from 'react';
import { 
  WEEKLY_WORKLOADS, 
  computeTeachersWorkloads, 
  TeacherWorkloadReport,
  GRADE_GROUPS,
  TeacherAllotment,
  SAMPLE_TEACHER_ALLOTMENTS,
  EMPTY_TEACHER_ALLOTMENTS,
  getSubjectsForGrade
} from '../data/teacherData';
import { 
  Search, 
  Users, 
  BookOpen, 
  Clock, 
  Table, 
  Layers, 
  Award, 
  FileSpreadsheet, 
  Sparkles,
  BarChart4,
  AlertTriangle,
  UserPlus,
  Trash2,
  ListRestart,
  CheckCircle,
  AlertCircle,
  ChevronDown,
  Wrench,
  Wand2,
  Lock,
  Key,
  ShieldCheck,
  X
} from 'lucide-react';

interface TeacherWorkloadsProps {
  allotments: TeacherAllotment[];
  onUpdateAllotments: (newAllotments: TeacherAllotment[]) => void;
  userPasswords?: { [username: string]: string };
  onUpdateUserPassword?: (username: string, pass: string) => void;
  onClearPassword?: (username: string) => void;
}

export default function TeacherWorkloads({ 
  allotments, 
  onUpdateAllotments,
  userPasswords,
  onUpdateUserPassword,
  onClearPassword
}: TeacherWorkloadsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('all');
  const [activeSubTab, setActiveSubTab] = useState<'workloads' | 'matrix' | 'manage' | 'security'>('workloads');

  const [bulkPasteText, setBulkPasteText] = useState('');
  const [selectedEditGrade, setSelectedEditGrade] = useState('I O');
  const [gradeClassTeacher, setGradeClassTeacher] = useState('');
  const [subjectAllotters, setSubjectAllotters] = useState<{ [subject: string]: string }>({});

  // Iframe-safe custom notifications, confirmations, and passcode prompts
  const [toast, setToast] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    confirmText: string;
    onConfirm: () => void;
  } | null>(null);
  const [passcodePrompt, setPasscodePrompt] = useState<{
    teacherName: string;
    currentVal: string;
    onSave: (newPass: string) => void;
  } | null>(null);
  const [promptInputVal, setPromptInputVal] = useState('');

  // Auto-dismiss custom toast banner
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    const curAllot = allotments.find(a => a.grade === selectedEditGrade);
    if (curAllot) {
      setGradeClassTeacher(curAllot.classTeacher || '');
      const mapping: { [subStr: string]: string } = {};
      WEEKLY_WORKLOADS.forEach(w => {
        mapping[w.subject] = curAllot.subjects[w.subject] || '';
      });
      setSubjectAllotters(mapping);
    }
  }, [selectedEditGrade, allotments]);

  // Compute all report data once
  const workloadReports = useMemo(() => computeTeachersWorkloads(allotments), [allotments]);

  // Extract all unique subjects in teaching allotments
  const allSubjectsList = useMemo(() => {
    const subs = new Set<string>();
    WEEKLY_WORKLOADS.forEach(w => subs.add(w.subject));
    return Array.from(subs).sort();
  }, []);

  // Filter workloads based on teacher name search or subject taught
  const filteredWorkloads = useMemo(() => {
    return workloadReports.filter(report => {
      const matchesSearch = report.teacherName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        report.assignedClasses.some(c => 
          c.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.subject.toLowerCase().includes(searchQuery.toLowerCase())
        );

      const matchesSubject = selectedSubjectFilter === 'all' || 
        report.assignedClasses.some(c => c.subject === selectedSubjectFilter);

      return matchesSearch && matchesSubject;
    });
  }, [workloadReports, searchQuery, selectedSubjectFilter]);

  // High-level metadata
  const totalTeachers = workloadReports.length;
  const avgWorkload = Math.round(
    workloadReports.reduce((sum, r) => sum + r.totalWorkload, 0) / (totalTeachers || 1)
  );
  
  const highWorkloadCount = workloadReports.filter(r => r.totalWorkload >= 35).length;
  const normalWorkloadCount = workloadReports.filter(r => r.totalWorkload < 35).length;

  // Get color and advice based on workload
  const getWorkloadSeverity = (total: number) => {
    if (total >= 40) return {
      bg: "bg-rose-500/10 border-rose-500/20 text-rose-300",
      progress: "bg-rose-500",
      status: "Critical Workload",
      icon: <AlertTriangle className="w-3.5 h-3.5 text-rose-450" />
    };
    if (total >= 32) return {
      bg: "bg-amber-500/10 border-amber-500/20 text-amber-300",
      progress: "bg-amber-500",
      status: "Heavy Load",
      icon: <Clock className="w-3.5 h-3.5 text-amber-450" />
    };
    return {
      bg: "bg-emerald-500/10 border-emerald-500/20 text-emerald-300",
      progress: "bg-emerald-500",
      status: "Balanced Load",
      icon: <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
    };
  };

  const handleWipeAllAllotments = () => {
    setConfirmModal({
      title: "Wipe All Staff/Subject Allotments?",
      message: "Are you sure you want to CLEAR ALL assigned teacher names and subjects allotments? This resets all allotments to an empty slate, though the 27 grades structure remains.",
      confirmText: "Clear All Staff",
      onConfirm: () => {
        const empty = allotments.map(a => ({
          ...a,
          classTeacher: '',
          subjects: {}
        }));
        onUpdateAllotments(empty);
        setToast({ type: 'success', text: "All teacher names and subjects have been cleared. Ready for your fresh lists!" });
        setConfirmModal(null);
      }
    });
  };

  const handleRestoreSampleAllotments = () => {
    setConfirmModal({
      title: "Restore Sample Staff?",
      message: "Restore pre-seeded sample teacher names and subject allotments? Your current records will be overwritten.",
      confirmText: "Restore Samples",
      onConfirm: () => {
        onUpdateAllotments(SAMPLE_TEACHER_ALLOTMENTS);
        setToast({ type: 'success', text: "Sample staff records successfully restored." });
        setConfirmModal(null);
      }
    });
  };

  const handleSaveSingleGradeAllotment = () => {
    onUpdateAllotments(allotments.map(a => {
      if (a.grade === selectedEditGrade) {
        const filteredSubjects: { [s: string]: string } = {};
        const allowed = getSubjectsForGrade(selectedEditGrade);
        Object.entries(subjectAllotters).forEach(([subj, teach]) => {
          if (!allowed.includes(subj)) return;
          const teachStr = teach as string;
          if (teachStr && teachStr.trim()) {
            filteredSubjects[subj] = teachStr.trim();
          }
        });
        return {
          ...a,
          classTeacher: gradeClassTeacher.trim(),
          subjects: filteredSubjects
        };
      }
      return a;
    }));
    setToast({
      type: 'success',
      text: `Successfully saved allotments for Grade ${selectedEditGrade}!`
    });
  };

  const handleBulkImportAllotments = (isOverwrite: boolean) => {
    if (!bulkPasteText.trim()) {
      setToast({ type: 'error', text: "Please paste some text records first!" });
      return;
    }

    const lines = bulkPasteText.split('\n');
    let matchedCount = 0;
    
    let nextAllotments = isOverwrite 
      ? EMPTY_TEACHER_ALLOTMENTS.map(a => ({ ...a, subjects: {} }))
      : allotments.map(a => ({ ...a, subjects: { ...a.subjects } }));

    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('//')) return;

      const parts = trimmed.split('|').map(p => p.trim());
      if (parts.length > 0 && parts[0]) {
        const gradeInput = parts[0].toUpperCase().replace('GRADE ', '').trim();
        const foundIdx = nextAllotments.findIndex(a => 
          a.grade.toUpperCase() === gradeInput || 
          a.grade.toUpperCase().replace(' ', '') === gradeInput.replace(' ', '')
        );

        if (foundIdx > -1) {
          matchedCount++;
          if (parts.length > 1) {
            nextAllotments[foundIdx].classTeacher = parts[1].trim();
          }
          if (parts.length > 2 && parts[2]) {
            const subjectPairs = parts[2].split(',').map(sub => sub.trim());
            subjectPairs.forEach(pair => {
              const delimIdx = pair.indexOf(':') !== -1 ? pair.indexOf(':') : pair.indexOf('=');
              if (delimIdx !== -1) {
                const subName = pair.substring(0, delimIdx).trim();
                const teachName = pair.substring(delimIdx + 1).trim();
                if (subName && teachName) {
                  const exactSubject = WEEKLY_WORKLOADS.find(w => w.subject.toLowerCase() === subName.toLowerCase());
                  const targetSubName = exactSubject ? exactSubject.subject : subName;
                  nextAllotments[foundIdx].subjects[targetSubName] = teachName;
                }
              }
            });
          }
        }
      }
    });

    if (matchedCount > 0) {
      onUpdateAllotments(nextAllotments);
      setBulkPasteText('');
      setToast({ type: 'success', text: `Bulk update successful! Matched and updated ${matchedCount} grades.` });
    } else {
      setToast({
        type: 'error',
        text: "No matching grade names found in your input. Make sure each line starts with a valid grade name like 'I O', 'V O', 'X O' followed by a '|' character."
      });
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Visual Statistics Dashboard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex items-center gap-4">
          <div className="p-3.5 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400">Total Registered Faculty</span>
            <span className="block text-2xl font-black text-white mt-0.5">{totalTeachers} Teachers</span>
            <span className="block text-[10px] text-slate-500 mt-0.5 font-bold">Subjectwise Allotted Staff</span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex items-center gap-4">
          <div className="p-3.5 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20">
            <BarChart4 className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400">Average Workload</span>
            <span className="block text-2xl font-black text-white mt-0.5">{avgWorkload} / week</span>
            <span className="block text-[10px] text-slate-500 mt-0.5 font-bold">Standard teaching periods</span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex items-center gap-4">
          <div className="p-3.5 bg-emerald-500/10 text-emerald-300 rounded-xl border border-emerald-500/20">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400">Balanced Load Staff</span>
            <span className="block text-2xl font-black text-emerald-300 mt-0.5">{normalWorkloadCount} Teachers</span>
            <span className="block text-[10px] text-slate-500 mt-0.5 font-bold">Below 32 periods threshold</span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex items-center gap-4">
          <div className="p-3.5 bg-amber-500/10 text-amber-300 rounded-xl border border-amber-500/20">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400">Heavy / Over allotted</span>
            <span className="block text-2xl font-black text-amber-300 mt-0.5">{highWorkloadCount} Teachers</span>
            <span className="block text-[10px] text-slate-500 mt-0.5 font-bold">Requires support review</span>
          </div>
        </div>

      </div>

      {/* Dynamic Sub-Tab Selector Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900 border border-white/10 rounded-2xl shadow-xl">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveSubTab('workloads')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'workloads'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 font-black'
                : 'text-slate-400 hover:text-white hover:bg-white/5 font-bold'
            }`}
          >
            <Users className="w-4 h-4 text-indigo-400" />
            <span>Faculty Directory</span>
          </button>
          <button
            onClick={() => setActiveSubTab('matrix')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'matrix'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 font-black'
                : 'text-slate-400 hover:text-white hover:bg-white/5 font-bold'
            }`}
          >
            <Table className="w-4 h-4 text-indigo-400" />
            <span>Workload Matrix Blueprint</span>
          </button>
          <button
            onClick={() => setActiveSubTab('manage')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'manage'
                ? 'bg-pink-600 text-white shadow-lg shadow-pink-600/30 font-black'
                : 'text-slate-400 hover:text-white hover:bg-white/5 font-bold'
            }`}
          >
            <Wrench className="w-4 h-4 text-pink-400" />
            <span>Manage Allotments</span>
          </button>
          <button
            onClick={() => setActiveSubTab('security')}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'security'
                ? 'bg-amber-650 text-white shadow-lg shadow-amber-600/30 font-black border border-amber-550/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5 font-bold'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Passcode Ledger</span>
          </button>
        </div>

        {/* Global Reset Buttons */}
        <div className="flex items-center gap-2 border-t sm:border-t-0 border-white/5 pt-3 sm:pt-0">
          <button
            onClick={handleRestoreSampleAllotments}
            className="px-3.5 py-2 text-[11px] bg-slate-950 border border-white/10 hover:border-indigo-500/40 text-indigo-300 font-extrabold rounded-lg flex items-center gap-1 cursor-pointer transition-all shrink-0"
            title="Restore default prefilled mock teachers & subjects lists"
          >
            <ListRestart className="w-3.5 h-3.5 text-indigo-400" />
            <span>Restore Samples</span>
          </button>
          <button
            onClick={handleWipeAllAllotments}
            className="px-3.5 py-2 text-[11px] bg-red-950/40 border border-red-500/20 hover:border-red-500/50 text-red-300 font-extrabold rounded-lg flex items-center gap-1 cursor-pointer transition-all shrink-0"
            title="Wipe out all teacher assignments to enter your clean record"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
            <span>Wipe All Staff</span>
          </button>
        </div>
      </div>

      {/* TAB 1: FACULTY WORKLOADS DIRECTORY */}
      {activeSubTab === 'workloads' && (
        <div className="space-y-6 animate-fade-in">
          {/* Filter and Search Bar */}
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Search Searchbar */}
            <div className="flex items-center gap-3 self-stretch md:self-auto flex-1">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20 shrink-0">
                <Search className="w-5 h-5 text-indigo-400" />
              </div>
              <div className="relative w-full max-w-md">
                <input
                  type="text"
                  placeholder="Search faculty name, grades (e.g. III T) or assigned subjects..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-950 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-500 font-bold pl-3"
                />
              </div>
            </div>

            {/* Drop Down Options */}
            <div>
              <select
                value={selectedSubjectFilter}
                onChange={(e) => setSelectedSubjectFilter(e.target.value)}
                className="text-xs p-2.5 bg-slate-900 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 font-bold text-slate-100 cursor-pointer"
              >
                <option value="all">Filter by Subject</option>
                {allSubjectsList.map(sub => (
                  <option key={sub} value={sub} className="bg-slate-950 text-white">{sub}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Directory Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredWorkloads.map((teac, idx) => {
              const conf = getWorkloadSeverity(teac.totalWorkload);
              return (
                <div 
                  key={idx} 
                  id={`teacher-card-${idx}`}
                  className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between hover:border-indigo-500/40 hover:shadow-indigo-500/5 transition-all shadow-xl group hover:-translate-y-0.5"
                >
                  <div>
                    {/* Header: Name and Load Status badge */}
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <div className="flex items-center gap-3">
                        <span className="p-2.5 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/15 group-hover:bg-indigo-600 group-hover:text-white transition-all font-mono font-black text-xs uppercase leading-none">
                          {teac.teacherName.split(' ').map(p => p[0]).join('').substring(0, 3)}
                        </span>
                        <div>
                          <h4 className="font-extrabold text-white text-sm tracking-tight">{teac.teacherName}</h4>
                          <span className="block text-[10px] text-slate-400 font-bold mt-0.5">Faculty Professor</span>
                        </div>
                      </div>
                      
                      {/* Badge status */}
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[9px] font-extrabold tracking-wide uppercase ${conf.bg}`}>
                        {conf.icon}
                        <span>{conf.status}</span>
                      </span>
                    </div>

                    {/* Progress slider bar indicator */}
                    <div className="space-y-1 mb-4">
                      <div className="flex justify-between items-center text-[10px] font-bold text-slate-300">
                        <span>Workload Stress Level</span>
                        <span className="font-mono">{teac.totalWorkload} periods (Max: 35)</span>
                      </div>
                      <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-white/5">
                        <div 
                          className={`h-full rounded-full transition-all ${conf.progress}`} 
                          style={{ width: `${Math.min(100, (teac.totalWorkload / 35) * 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Classes list mapped */}
                    <div className="space-y-2">
                      <span className="block text-[9px] font-bold uppercase text-slate-400 tracking-wider">Class Allotments</span>
                      <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                        {teac.assignedClasses.map((cl, cidx) => (
                          <div 
                            key={cidx} 
                            className="bg-white/5 border border-white/5 hover:border-white/10 flex items-center justify-between p-2 rounded-xl text-xs transition-all"
                          >
                            <div className="flex items-center gap-2 font-semibold">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                              <span className="text-slate-100">{cl.grade}</span>
                            </div>
                            <div className="text-right text-slate-400 font-medium">
                              <span>{cl.subject}</span>
                              <span className="ml-2 font-mono text-[10px] text-indigo-300 font-extrabold bg-indigo-500/10 border border-indigo-500/10 px-1.5 py-0.5 rounded">
                                {cl.weeklySessions} hr{cl.weeklySessions > 1 ? 's' : ''}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>

                  {/* Footer total highlight */}
                  <div className="mt-4 pt-3 border-t border-white/10 flex justify-between items-center text-[10px] text-slate-400">
                    <span className="flex items-center gap-1 font-bold">
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      {teac.assignedClasses.length} distinct classes
                    </span>
                    <span className="text-white font-extrabold text-xs">
                      Total: <strong className="text-indigo-300 font-black text-sm font-mono">{teac.totalWorkload}</strong> periods/wk
                    </span>
                  </div>

                </div>
              );
            })}

            {filteredWorkloads.length === 0 && (
              <div className="col-span-3 text-center py-16 bg-white/5 border border-white/10 rounded-2xl shadow-xl">
                <AlertTriangle className="w-12 h-12 text-slate-500 mx-auto mb-2" />
                <p className="text-white text-base font-bold">No Faculty Matches Search Filter</p>
                <p className="text-slate-400 text-xs mt-1">Refine your keywords or select another filter from the options above.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: ACADEMIC WORKLOAD MATRIX BLUEPRINT */}
      {activeSubTab === 'matrix' && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl shadow-2xl animate-fade-in space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/15">
                <FileSpreadsheet className="w-5 h-5 text-indigo-400" />
              </span>
              <div>
                <h3 className="font-extrabold text-white text-base">Weekly Class Workload Breakdown 2026-27</h3>
                <p className="text-slate-400 text-xs mt-0.5">Syllabus periods per week mapped to grade groups</p>
              </div>
            </div>
            <span className="text-[10px] uppercase font-bold bg-white/10 text-indigo-300 px-3 py-1 rounded-full border border-white/5 font-mono">
              Academic Blueprint
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-white/5">
            <table className="w-full text-[11px] text-left text-slate-300 font-semibold">
              <thead className="text-[9px] uppercase tracking-wider text-slate-400 bg-slate-950 border-b border-white/15">
                <tr>
                  <th scope="col" className="px-4 py-3 text-white font-extrabold">Weekly Syllabus Subject</th>
                  {GRADE_GROUPS.map(gr => (
                    <th key={gr.value} scope="col" className="px-4 py-3 font-extrabold text-center border-l border-white/10 bg-white/5">{gr.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {WEEKLY_WORKLOADS.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-white/5 transition-all">
                    <td className="px-4 py-2.5 font-bold text-white flex items-center gap-2">
                      <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span>{row.subject}</span>
                    </td>
                    {GRADE_GROUPS.map(grp => (
                      <td key={grp.value} className="px-4 py-2.5 text-center font-mono font-bold text-slate-300 border-l border-white/5 bg-white/2">
                        {row.grades[grp.value] !== undefined ? `${row.grades[grp.value]} hr${row.grades[grp.value] > 1 ? 's' : ''}` : '-'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: MANAGE ALLOTMENTS & BULK IMPORT */}
      {activeSubTab === 'manage' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
          
          {/* Direct Interactive Form (Left Column) */}
          <div className="bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-2 text-pink-400 font-extrabold pb-3 border-b border-white/5">
              <UserPlus className="w-5 h-5 text-pink-400" />
              <h4 className="text-white text-sm">Single Grade Allotment Designer</h4>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
              Directly select a specific class / grade to adjust its assigned Class Teacher and subject allocation mappings.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] text-slate-400 uppercase font-black mb-1.5">Select Class/Grade</label>
                <select
                  value={selectedEditGrade}
                  onChange={(e) => setSelectedEditGrade(e.target.value)}
                  className="w-full text-xs p-3 bg-slate-950 border border-white/15 rounded-xl text-white font-extrabold focus:border-pink-500 cursor-pointer"
                >
                  {allotments.map(a => (
                    <option key={a.grade} value={a.grade}>{a.grade}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 uppercase font-black mb-1.5">Class Teacher Name</label>
                <input
                  type="text"
                  placeholder="e.g. Ms. Monali H"
                  value={gradeClassTeacher}
                  onChange={(e) => setGradeClassTeacher(e.target.value)}
                  className="w-full text-xs p-3 bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-600 font-bold focus:border-pink-500"
                />
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="block text-[10px] text-slate-400 uppercase font-bold tracking-wider">Subject Teachers Mapping ({selectedEditGrade})</span>
                <span className="text-[9px] text-slate-500 uppercase font-bold font-mono">Direct Input Fields</span>
              </div>
              
              <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1 select-none border border-white/5 rounded-xl p-2.5 bg-slate-950/20">
                {WEEKLY_WORKLOADS.filter(w => getSubjectsForGrade(selectedEditGrade).includes(w.subject)).map(w => (
                  <div key={w.subject} className="flex items-center justify-between gap-3 bg-slate-950/40 p-2 border border-white/5 hover:border-white/10 rounded-xl transition-all">
                    <span className="text-[11px] font-bold text-slate-300 w-1/3 shrink-0 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-pink-500" />
                      <span>{w.subject}</span>
                    </span>
                    <input
                      type="text"
                      placeholder="teacher's name"
                      value={subjectAllotters[w.subject] || ''}
                      onChange={(e) => setSubjectAllotters({
                        ...subjectAllotters,
                        [w.subject]: e.target.value
                      })}
                      className="text-xs p-2 bg-slate-950 border border-white/15 rounded-lg text-white placeholder-slate-800 font-semibold w-full focus:border-pink-500 focus:outline-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleSaveSingleGradeAllotment}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl text-xs cursor-pointer shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-1.5 font-sans"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Apply & Save Grade {selectedEditGrade} Allotments</span>
            </button>
          </div>

          {/* Paste Data / Bulk Importer (Right Column) */}
          <div className="bg-slate-900 border border-white/10 rounded-2xl p-6 flex flex-col justify-between shadow-2xl">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-indigo-400 font-extrabold pb-3 border-b border-white/5">
                <Wand2 className="w-5 h-5 text-indigo-400" />
                <h4 className="text-white text-sm">Bulk Paste Allotments Registry</h4>
              </div>

              <div className="p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-xl text-xs space-y-2 animate-fade-in">
                <p className="text-slate-200 font-extrabold">Instructions & Format</p>
                <p className="text-slate-450 font-medium leading-relaxed">
                  Paste your updated records line-by-line using the simple pipe (<code className="text-indigo-300 font-mono">|</code>) layout. Each line targets one class:
                </p>
                <div className="bg-slate-950 text-[11px] font-mono p-3 rounded-lg border border-white/5 text-emerald-400 select-all leading-relaxed whitespace-pre-wrap font-semibold">
                  {"// Line Layout:\nGrade Name | Class Teacher | Subject: Teacher Name, Subject: Teacher Name\n\n// Examples:\nI O | Ms. Monali | English: Ms.Sunaina, Math: Ms.Vaishali, Hindi: Ms.Meena\nVI T | Mr. Sachin | SS: Mr.Kay, Computer: Mr.Uday, Science: Mr.Suresh"}
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400 uppercase font-black mb-1.5">Raw Text Area Input</label>
                <textarea
                  rows={8}
                  placeholder={`I O | Ms. Monali | English: Ms.Sunaina, Math: Ms.Vaishali\nVI T | Mr. Sachin | Science: Mr.Suresh, Social Studies: Mr.Kay`}
                  value={bulkPasteText}
                  onChange={(e) => setBulkPasteText(e.target.value)}
                  className="w-full text-xs font-mono p-4 bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-700 focus:outline-none focus:border-indigo-500 leading-relaxed resize-none font-semibold"
                />
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3 shrink-0">
              <button
                onClick={() => handleBulkImportAllotments(true)}
                className="py-3.5 bg-pink-600 hover:bg-pink-500 text-white text-xs font-black rounded-xl cursor-pointer shadow-lg shadow-pink-600/20 transition-all flex items-center justify-center gap-1.5 border border-pink-500/10"
                title="Wipes all existing teacher assignments first"
              >
                <Trash2 className="w-4 h-4" />
                <span>Overwrite Fresh</span>
              </button>
              <button
                onClick={() => handleBulkImportAllotments(false)}
                className="py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl cursor-pointer shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-1.5 border border-indigo-500/10"
                title="Apply updates only to the matched classes in pasted list"
              >
                <Sparkles className="w-4 h-4" />
                <span>Merge & Update</span>
              </button>
            </div>

          </div>

        </div>
      )}

      {/* TAB 4: FACULTY SECURITY PROTOCOLS & PASSCODE LEDGER */}
      {activeSubTab === 'security' && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl shadow-2xl animate-fade-in space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-amber-500/10 text-amber-300 rounded-xl border border-amber-500/15 animate-pulse">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
              </span>
              <div>
                <h3 className="font-extrabold text-white text-base">Faculty Security & Passcode Ledger</h3>
                <p className="text-slate-400 text-xs mt-0.5">School master index of active logins and security credentials.</p>
              </div>
            </div>
            
            <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-white/5 text-[10px] text-amber-400 font-mono font-bold">
              🔒 Master Database Mode: Persistent
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed font-semibold">
            Below is the master record of security passwords for all academic staff members. Teachers can log in with their name and custom passcode or their default allocation key. As an Administrator, you can view, edit, or reset any faculty password.
          </p>

          <div className="overflow-x-auto rounded-xl border border-white/5 shadow-inner">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-950 text-[10px] text-slate-400 font-black uppercase tracking-widest border-b border-white/10">
                  <th className="py-3 px-4">Faculty Member / Login ID Name</th>
                  <th className="py-3 px-4">Direct Security Passcode</th>
                  <th className="py-3 px-4 text-center">Credential Status</th>
                  <th className="py-3 px-4 text-center">Safety Rating</th>
                  <th className="py-3 px-4 text-right">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 bg-slate-900/10">
                {/* Admin record */}
                <tr className="hover:bg-white/[0.02] transition-all bg-indigo-500/[0.02]">
                  <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                    <span>School Administrator (admin)</span>
                  </td>
                  <td className="py-3 px-4 font-mono text-xs text-indigo-300 font-black">
                    {userPasswords?.['admin'] || 'admin123'}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-indigo-500/15 text-indigo-300 border border-indigo-500/25">
                      System administrator
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="text-[10px] text-emerald-400 font-extrabold flex items-center justify-center gap-1">
                      🛡️ Secure
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <span className="text-[10px] text-slate-500 italic font-semibold">Protected Master</span>
                  </td>
                </tr>

                {/* Faculty list */}
                {workloadReports.map((teac, idx) => {
                  const hasCustom = userPasswords && userPasswords[teac.teacherName];
                  const passwordVal = userPasswords?.[teac.teacherName] || 'teacher123';
                  
                  return (
                    <tr key={idx} className="hover:bg-white/[0.01] transition-all">
                      <td className="py-3 px-4 font-semibold text-slate-200">
                        {teac.teacherName}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-300 font-bold">
                        {passwordVal}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          hasCustom 
                            ? 'bg-emerald-500/15 text-emerald-350 border border-emerald-500/25' 
                            : 'bg-amber-500/15 text-amber-350 border border-amber-500/25'
                        }`}>
                          {hasCustom ? '🔐 Custom password' : '🔑 Default passcode'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`text-[10.5px] font-extrabold ${hasCustom ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {hasCustom ? '🟢 High standard' : '⚠️ Default key is public'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setPromptInputVal(passwordVal);
                              setPasscodePrompt({
                                teacherName: teac.teacherName,
                                currentVal: passwordVal,
                                onSave: (newPass) => {
                                  onUpdateUserPassword?.(teac.teacherName, newPass);
                                  setToast({ type: 'success', text: `Passcode updated for ${teac.teacherName}!` });
                                }
                              });
                            }}
                            className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded text-[10px] font-bold border border-white/5 cursor-pointer transition-all"
                          >
                            Edit
                          </button>
                          {hasCustom && (
                            <button
                              onClick={() => {
                                setConfirmModal({
                                  title: `Reset ${teac.teacherName}'s Passcode?`,
                                  message: `Are you sure you want to reset ${teac.teacherName}'s passcode back to the standard fallback password "teacher123"?`,
                                  confirmText: "Reset Passcode",
                                  onConfirm: () => {
                                    onClearPassword?.(teac.teacherName);
                                    setToast({ type: 'success', text: `Passcode for ${teac.teacherName} reset back to default.` });
                                    setConfirmModal(null);
                                  }
                                });
                              }}
                              className="px-2.5 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 rounded text-[10px] font-bold border border-rose-500/10 cursor-pointer transition-all"
                            >
                              Reset
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="bg-amber-500/5 rounded-xl p-3 border border-amber-500/10 text-[10px] text-amber-300 flex items-center gap-2 font-semibold">
            <span>💡 <strong>Administrative Security Note:</strong> Faculty accounts use standard local session tokens. If a professor requests a password recovery, you can copy their active passcode from the direct column above, or click 'Reset' to return them back to standard <strong>teacher123</strong> layout.</span>
          </div>
        </div>
      )}

      {/* Custom Floating Toast Alert */}
      {toast && (
        <div id="toast-banner" className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-slate-950 border border-indigo-500/30 px-5 py-4 rounded-2xl shadow-emerald-500/10 shadow-2xl animate-fade-in max-w-sm">
          {toast.type === 'success' && <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 animate-pulse" />}
          {toast.type === 'info' && <AlertTriangle className="w-5 h-5 text-indigo-400 shrink-0 animate-bounce" />}
          <span className="text-xs font-bold text-white tracking-wide pr-1">{toast.text}</span>
          <button 
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-white ml-auto cursor-pointer p-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Custom Confirmation Modal */}
      {confirmModal && (
        <div id="confirm-allotment-modal" className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/15 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-fade-in text-left">
            <div className="flex items-center gap-2 text-pink-400">
              <AlertTriangle className="w-5 h-5" />
              <h4 className="text-white text-sm font-black">{confirmModal.title}</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-semibold">
              {confirmModal.message}
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-4 py-2 bg-slate-950 border border-white/10 hover:border-white/25 text-slate-300 rounded-lg text-xs font-bold cursor-pointer transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  confirmModal.onConfirm();
                }}
                className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white rounded-lg text-xs font-black cursor-pointer transition-all shadow-lg shadow-pink-600/30"
              >
                {confirmModal.confirmText || "Confirm"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Passcode Prompt Modal */}
      {passcodePrompt && (
        <div id="passcode-prompt-modal" className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (promptInputVal.trim()) {
                passcodePrompt.onSave(promptInputVal.trim());
                setPasscodePrompt(null);
              }
            }}
            className="bg-slate-900 border border-white/15 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-4 animate-fade-in text-left"
          >
            <div className="flex items-center gap-2 text-indigo-400">
              <Key className="w-5 h-5" />
              <h4 className="text-white text-sm font-black">Update Prof. Passcode</h4>
            </div>
            <p className="text-xs text-slate-300 font-semibold leading-normal">
              Specify a custom secure allotment password mapping for <span className="text-pink-300 font-black">{passcodePrompt.teacherName}</span>:
            </p>

            <input
              type="text"
              required
              value={promptInputVal}
              onChange={(e) => setPromptInputVal(e.target.value)}
              placeholder="Enter new passcode..."
              className="w-full text-xs p-3 bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-650 font-bold focus:outline-none focus:border-indigo-500"
            />

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setPasscodePrompt(null)}
                className="px-4 py-2 bg-slate-950 border border-white/10 hover:border-white/25 text-slate-300 rounded-lg text-xs font-bold cursor-pointer transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-black cursor-pointer transition-all shadow-lg shadow-indigo-600/30"
              >
                Save Passcode
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
