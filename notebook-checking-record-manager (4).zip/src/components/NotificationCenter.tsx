import React, { useState, useEffect, useRef } from 'react';
import { 
  Bell, 
  Check, 
  MessageSquare, 
  BookOpen, 
  ArrowRightLeft, 
  CheckSquare, 
  Sparkles, 
  Inbox, 
  UserCheck, 
  Clock,
  ExternalLink
} from 'lucide-react';
import { SchoolClass, MonthlyTask, UserSession, ManagementReview } from '../types';
import { TeacherAllotment } from '../data/teacherData';
import { SyllabusTopicState } from './SyllabusCompletionTab';
import { 
  OFFICIAL_SYLLABUS_BANK, 
  APRIL_SYLLABUS_BANK,
  JUNE_SYLLABUS_BANK
} from '../data/officialSyllabus';

interface NotificationCenterProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  allotments: TeacherAllotment[];
  currentUser: UserSession | null;
  onJumpToTab?: (tab: string) => void;
}

export interface TeacherNotification {
  id: string;
  type: 'task' | 'comment' | 'carry_forward' | 'reminder' | 'compliance_status';
  title: string;
  message: string;
  details?: string;
  timestamp: string;
  priority?: 'info' | 'warning' | 'critical';
  meta?: {
    classId?: string;
    subject?: string;
    targetTab?: string;
  };
}

export default function NotificationCenter({
  classes,
  tasks,
  allotments,
  currentUser,
  onJumpToTab,
}: NotificationCenterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Active simulated clock day
  const [simulatedDay, setSimulatedDay] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  // Read notifications stored locally for the current user
  const [readIds, setReadIds] = useState<string[]>(() => {
    if (!currentUser) return [];
    const saved = localStorage.getItem(`nb_read_notifications_${currentUser.username}`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [];
  });

  // State to force recomputations when local storage changes
  const [lastUpdated, setLastUpdated] = useState<number>(Date.now());

  // Sync back to local storage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`nb_read_notifications_${currentUser.username}`, JSON.stringify(readIds));
    }
  }, [readIds, currentUser]);

  // Handle clicks outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Listen for storage changes as management updates reviews/comments in memory
  useEffect(() => {
    const handleStorageChange = () => {
      setLastUpdated(Date.now());
      const saved = localStorage.getItem('nb_audit_simulated_day');
      if (saved) {
        const val = parseInt(saved);
        setSimulatedDay(val);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  if (!currentUser || currentUser.role !== 'teacher') {
    return null; // Notification badge is specifically for the faculty/teacher login
  }

  // 1. Fetch teacher classes & subjects
  const getTeacherSubjects = () => {
    const list: { classId: string; className: string; subject: string }[] = [];
    const clean = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const uNameClean = clean(currentUser?.name || '');
    
    const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
      if (!className || !allotmentGrade) return false;
      const cleanClassStr = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
      return cleanClassStr(className) === cleanClassStr(allotmentGrade);
    };

    allotments.forEach(allot => {
      const cls = classes.find(c => isClassMatchAllotment(c.name, allot.grade));
      Object.entries(allot.subjects || {}).forEach(([subName, teachName]) => {
        const teachClean = teachName ? clean(teachName) : '';
        const isMatchedTeacher = teachClean && (teachClean.includes(uNameClean) || uNameClean.includes(teachClean));
        if (isMatchedTeacher) {
          list.push({
            classId: cls?.id || `class_${allot.grade.toLowerCase().replace(' ', '_')}`,
            className: cls?.name || allot.grade,
            subject: subName
          });
        }
      });
    });
    
    // Remove duplicates to prevent duplicate React keys or duplicate reminders
    return list.filter((v, i, a) => a.findIndex(t => t.classId === v.classId && t.subject === v.subject) === i);
  };

  const mySubjects = getTeacherSubjects();

  // Helper to construct notifications list based on state
  const computeNotifications = (): TeacherNotification[] => {
    const notifs: TeacherNotification[] = [];

    // --- A. NEW TASKS BY MANAGEMENT ---
    // Extract any tasks created by "admin" or "management" belonging to teacher's classes/subjects
    tasks.forEach(task => {
      const isManagementCreated = task.createdBy === 'management' || task.createdBy === 'admin';
      if (isManagementCreated) {
        // Is it assigned to this teacher?
        const isMine = mySubjects.some(sub => sub.classId === task.classId && sub.subject.toLowerCase() === task.subject.toLowerCase());
        if (isMine) {
          const cls = classes.find(c => c.id === task.classId);
          const classNameDisplay = cls ? cls.name : 'Your Class';
          notifs.push({
            id: `task_${task.id}`,
            type: 'task',
            title: 'New Syllabus Task Assigned',
            message: `Management added task for ${classNameDisplay} • ${task.subject}`,
            details: `"${task.title}" - Due: ${task.dueDate}`,
            timestamp: task.createdAt || new Date().toISOString(),
            meta: {
              classId: task.classId,
              subject: task.subject,
              targetTab: 'plans' // Month Planner
            }
          });
        }
      }
    });

    // --- B. MANAGEMENT REVIEW COMMENTS ---
    // Pull reviews from 'nb_management_reviews' for this teacher
    const reviewsSaved = localStorage.getItem('nb_management_reviews');
    if (reviewsSaved) {
      try {
        const parsedReviews: ManagementReview[] = JSON.parse(reviewsSaved);
        const myReviews = parsedReviews.filter(r => r.teacherName.toLowerCase() === currentUser.name.toLowerCase());
        
        myReviews.forEach(r => {
          // General comment
          if (r.generalComment && r.generalComment.trim().length > 0) {
            notifs.push({
              id: `review_comment_general_${r.id}_${r.generalComment.trim().slice(0, 15)}`,
              type: 'comment',
              title: `Notebook review: General Comment (${r.month})`,
              message: `Reviewed by ${r.verifiedBy}`,
              details: `"${r.generalComment}"`,
              timestamp: r.verifiedAt || new Date().toISOString(),
              meta: { targetTab: 'records' }
            });
          }
          // Notebook specific check feedback
          if (r.notebookStatusComment && r.notebookStatusComment.trim().length > 0) {
            notifs.push({
              id: `review_comment_nb_${r.id}_${r.notebookStatusComment.trim().slice(0, 15)}`,
              type: 'comment',
              title: `Notebook correction guideline (${r.month})`,
              message: `${r.verifiedBy} commented on notebook corrections`,
              details: `"${r.notebookStatusComment}"`,
              timestamp: r.verifiedAt || new Date().toISOString(),
              meta: { targetTab: 'records' }
            });
          }
          // Syllabus verification feedback
          if (r.syllabusStatusComment && r.syllabusStatusComment.trim().length > 0) {
            notifs.push({
              id: `review_comment_syl_${r.id}_${r.syllabusStatusComment.trim().slice(0, 15)}`,
              type: 'comment',
              title: `Syllabus status audit notice (${r.month})`,
              message: `${r.verifiedBy} inspected syllabus records`,
              details: `"${r.syllabusStatusComment}"`,
              timestamp: r.verifiedAt || new Date().toISOString(),
              meta: { targetTab: 'syllabus_completion' }
            });
          }
          // Test records feedback
          if (r.testRecordComment && r.testRecordComment.trim().length > 0) {
            notifs.push({
              id: `review_comment_test_${r.id}_${r.testRecordComment.trim().slice(0, 15)}`,
              type: 'comment',
              title: `Academic tests score review (${r.month})`,
              message: `${r.verifiedBy} evaluated test registers`,
              details: `"${r.testRecordComment}"`,
              timestamp: r.verifiedAt || new Date().toISOString(),
              meta: { targetTab: 'tests' }
            });
          }
          
          // Verified badge indicator
          if (r.isVerified) {
            notifs.push({
              id: `review_verified_${r.id}`,
              type: 'comment',
              title: `Checking Register Endorsed (${r.month})`,
              message: `Your check ledger has been verified successfully`,
              details: `Endorsed digitally by ${r.verifiedBy}. Keep up the diligent academic oversight!`,
              timestamp: r.verifiedAt || new Date().toISOString(),
              meta: { targetTab: 'records' }
            });
          }
        });
      } catch (e) {
        console.error('Error parsing management reviews in NotificationCenter', e);
      }
    }

    // --- C. CARRY-FORWARD RESOLUTIONS ---
    // Check syllabus decisions under `nb_syllabus_topic_states`
    const syllabusSaved = localStorage.getItem('nb_syllabus_topic_states');
    if (syllabusSaved) {
      try {
        const parsedTopics: SyllabusTopicState[] = JSON.parse(syllabusSaved);
        // Find carry forwards for classes and subjects taught by teacher
        parsedTopics.forEach(ts => {
          if (ts.carryForwardRequest && (ts.carryForwardRequest.status === 'approved' || ts.carryForwardRequest.status === 'rejected')) {
            const isMine = mySubjects.some(sub => ts.grade.toLowerCase().includes(sub.className.toLowerCase()) && ts.subject.toLowerCase() === sub.subject.toLowerCase()) || ts.updatedBy === currentUser.name;
            if (isMine) {
              const statusDisplay = ts.carryForwardRequest.status.toUpperCase();
              const decBy = ts.carryForwardRequest.decidedBy || 'Principal/VP';
              notifs.push({
                id: `carry_decision_${ts.id}_${ts.carryForwardRequest.status}`,
                type: 'carry_forward',
                title: `Carry Forward Decision: ${statusDisplay}`,
                message: `Topic: "${ts.topicText}" in ${ts.grade} ${ts.subject}`,
                details: ts.carryForwardRequest.feedback ? `Response: "${ts.carryForwardRequest.feedback}"` : `Reviewed by ${decBy}`,
                timestamp: ts.carryForwardRequest.decidedAt || new Date().toISOString(),
                meta: { targetTab: 'syllabus_completion' }
              });
            }
          }
        });
      } catch (e) {
        console.error('Error parsing syllabus states in NotificationCenter', e);
      }
    }

    // --- D. DATE 15+ COMMITTED REMINDERS & TASK COMPLETION STATUS ---
    if (simulatedDay > 15) {
      const mapClassToSyllabusGrade = (className: string): string => {
        const spaceIdx = className.indexOf(' ');
        const firstWord = spaceIdx !== -1 ? className.substring(0, spaceIdx) : className;
        const gradeMap: { [key: string]: string } = {
          'I': 'Grade I', 'II': 'Grade II', 'III': 'Grade III', 'IV': 'Grade IV', 'V': 'Grade V',
          'VI': 'Grade VI', 'VII': 'Grade VII', 'VIII': 'Grade VIII', 'IX': 'Grade IX', 'X': 'Grade X',
        };
        return gradeMap[firstWord.toUpperCase()] || `Grade ${firstWord}`;
      };

      // Retrieve all local states
      const syllabusSavedLocal = localStorage.getItem('nb_syllabus_topic_states');
      let parsedTopics: SyllabusTopicState[] = [];
      if (syllabusSavedLocal) {
        try { parsedTopics = JSON.parse(syllabusSavedLocal); } catch (e) {}
      }

      const testsSavedLocal = localStorage.getItem('nb_academic_tests');
      let testsList: any[] = [];
      if (testsSavedLocal) {
        try { testsList = JSON.parse(testsSavedLocal); } catch (e) {}
      }

      const marksSavedLocal = localStorage.getItem('nb_test_marks');
      let marksList: any[] = [];
      if (marksSavedLocal) {
        try { marksList = JSON.parse(marksSavedLocal); } catch (e) {}
      }

      const tasksSavedLocal = localStorage.getItem('nb_tasks');
      let tasksList: any[] = [];
      if (tasksSavedLocal) {
        try { tasksList = JSON.parse(tasksSavedLocal); } catch (e) {}
      }

      const recordsSavedLocal = localStorage.getItem('nb_records');
      let recordsList: any[] = [];
      if (recordsSavedLocal) {
        try { recordsList = JSON.parse(recordsSavedLocal); } catch (e) {}
      }

      // Check each allotted class/subject for the current teacher
      mySubjects.forEach(sub => {
        const sylGrade = mapClassToSyllabusGrade(sub.className);
        const currentClass = classes.find(c => c.id === sub.classId || c.name === sub.className);
        const students = currentClass ? currentClass.students : [];

        // 1. Syllabus topics complete?
        const gradeItems = JUNE_SYLLABUS_BANK[sylGrade] || [];
        const matchedItem = gradeItems.find(item => item.subject.toLowerCase() === sub.subject.toLowerCase());
        const topicsList = matchedItem ? matchedItem.topics : [];
        
        const completedTopicsCount = topicsList.filter((topicText, topicIdx) => {
          const id = `${sylGrade}_${sub.subject}_June 2026_${topicIdx}`;
          const state = parsedTopics.find(ts => ts.id === id);
          return state ? state.isCompleted : false;
        }).length;
        
        const isSyllabusDone = topicsList.length === 0 || completedTopicsCount === topicsList.length;

        // 2. Academic tests complete?
        const classTests = testsList.filter(t => t.classId === sub.classId && t.subject.toLowerCase() === sub.subject.toLowerCase() && t.month === "June 2026");
        let isTestsDone = true;
        if (classTests.length > 0 && students.length > 0) {
          isTestsDone = classTests.every(test => {
            return students.every(student => {
              const markId = `${test.id}_${student.id}`;
              const mark = marksList.find(m => m.id === markId);
              return mark && (mark.marksObtained !== '' || mark.isAbsent === true);
            });
          });
        }

        // 3. Notebook checks complete?
        const classTasks = tasksList.filter(t => t.classId === sub.classId && t.subject.toLowerCase() === sub.subject.toLowerCase() && t.month === "June 2026");
        let isNotebooksDone = true;
        if (classTasks.length > 0 && students.length > 0) {
          isNotebooksDone = classTasks.every(typeTask => {
            return students.every(student => {
              const recordId = `${student.id}_${typeTask.id}`;
              const rec = recordsList.find(r => r.id === recordId || (r.studentId === student.id && r.taskId === typeTask.id));
              return rec && rec.status !== 'unchecked';
            });
          });
        }

        const allDone = isSyllabusDone && isTestsDone && isNotebooksDone;

        if (allDone) {
          // If teachers completed all task class wise shows status to him or her in notification only!
          notifs.push({
            id: `date15_status_complete_${sub.classId}_${sub.subject}_day${simulatedDay}`,
            type: 'compliance_status',
            title: `🏆 Compliant: ${sub.className} • ${sub.subject}`,
            message: `Congratulations! Your curriculum logging, test records, and correction registers are 100% complete.`,
            details: `All checkpoints cleared successfully for June 2026 (Audited Day ${simulatedDay})`,
            timestamp: new Date(`2026-06-${simulatedDay.toString().padStart(2, '0')}T10:00:00Z`).toISOString(),
            priority: 'info',
            meta: {
              classId: sub.classId,
              subject: sub.subject,
              targetTab: 'syllabus_completion'
            }
          });
        } else {
          // Generate customized items missing list
          const missingItems: string[] = [];
          if (!isSyllabusDone) missingItems.push(`${topicsList.length - completedTopicsCount} syllabus topics`);
          if (!isTestsDone) missingItems.push(`test marks entry`);
          if (!isNotebooksDone) missingItems.push(`notebook checks`);
          const missingText = missingItems.join(', ');

          // Change color priority as date comes near
          // Days 16-20: 'info'
          // Days 21-24: 'warning'
          // Days 25+: 'critical' (red)
          const priority = simulatedDay >= 25 ? 'critical' : (simulatedDay >= 21 ? 'warning' : 'info');

          // Push Morning Reminder (9:00 AM)
          notifs.push({
            id: `date15_reminder_morning_${sub.classId}_${sub.subject}_day${simulatedDay}`,
            type: 'reminder',
            title: `⏰ Morning Nudge: Complete ${sub.className} • ${sub.subject}`,
            message: `Daily Morning Check: Please verify and record syllabus logs, test scores, and notebook corrections.`,
            details: `Required updates: ${missingText}. Lockouts start on day 25/28!`,
            timestamp: new Date(`2026-06-${simulatedDay.toString().padStart(2, '0')}T09:00:00Z`).toISOString(),
            priority: priority,
            meta: {
              classId: sub.classId,
              subject: sub.subject,
              targetTab: !isSyllabusDone ? 'syllabus_completion' : (!isNotebooksDone ? 'records' : 'tests')
            }
          });

          // Push Evening Reminder (6:00 PM)
          notifs.push({
            id: `date15_reminder_evening_${sub.classId}_${sub.subject}_day${simulatedDay}`,
            type: 'reminder',
            title: `🌙 Evening Warning: Pending Tasks for ${sub.className} • ${sub.subject}`,
            message: `Daily Evening Wrap-up: Secure compliant locks by keeping your class ledger pristine.`,
            details: `Incomplete: ${missingText}. Action needed before simulated cutoff limits.`,
            timestamp: new Date(`2026-06-${simulatedDay.toString().padStart(2, '0')}T18:00:00Z`).toISOString(),
            priority: priority,
            meta: {
              classId: sub.classId,
              subject: sub.subject,
              targetTab: !isSyllabusDone ? 'syllabus_completion' : (!isNotebooksDone ? 'records' : 'tests')
            }
          });
        }
      });
    }

    // Sort by timestamp desc (Newest first)
    return notifs.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  const allNotifications = computeNotifications();
  const unreadNotifications = allNotifications.filter(n => !readIds.includes(n.id));
  const unreadCount = unreadNotifications.length;

  const handleMarkAsRead = (id: string) => {
    if (!readIds.includes(id)) {
      setReadIds(prev => [...prev, id]);
    }
  };

  const handleMarkAllAsRead = () => {
    const allIds = allNotifications.map(n => n.id);
    setReadIds(allIds);
  };

  const handleNotificationClick = (n: TeacherNotification) => {
    handleMarkAsRead(n.id);
    if (n.meta?.targetTab && onJumpToTab) {
      onJumpToTab(n.meta.targetTab);
      setIsOpen(false);
    }
  };

  const formatTimeAgo = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins} min ago`;
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours} hr ago`;
      return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    } catch (e) {
      return '';
    }
  };

  return (
    <div className="relative" ref={containerRef}>
      {/* BELL TRIGGER BUTTON */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2 rounded-xl transition-all relative cursor-pointer border ${
          isOpen 
            ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300' 
            : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300 hover:text-white'
        }`}
        title="Oversight & comments feed"
      >
        <Bell className={`w-4.5 h-4.5 ${unreadCount > 0 ? 'animate-bounce' : ''}`} />
        
        {unreadCount > 0 && (
          <span className="absolute -top-1.5 -right-1.5 flex h-4.5 min-w-4.5 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white border-2 border-slate-950 animate-pulse shadow-lg">
            {unreadCount}
          </span>
        )}
      </button>

      {/* DROPDOWN BOX PANEL */}
      {isOpen && (
        <div className="absolute right-[-4.5rem] xs:right-[-2.5rem] sm:right-0 mt-3 w-[290px] xs:w-[320px] sm:w-[380px] max-w-[calc(100vw-2rem)] rounded-2xl bg-slate-950 border border-indigo-500/20 shadow-2xl z-50 overflow-hidden text-left animate-fade-in divide-y divide-white/5">
          {/* HEADER HEADER */}
          <div className="p-3 bg-gradient-to-r from-indigo-950/45 to-slate-900 border-b border-indigo-500/10 flex items-center justify-between">
            <div className="space-y-0.5">
              <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Management Updates</span>
              </h3>
              <p className="text-[9px] text-slate-400">
                {unreadCount === 0 ? 'All caught up' : `${unreadCount} unread announcements`}
              </p>
            </div>

            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllAsRead}
                className="text-[9px] py-0.5 px-2 rounded bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 hover:bg-indigo-550/20 transition-all font-bold cursor-pointer inline-flex items-center gap-1 uppercase"
              >
                <Check className="w-2.5 h-2.5" /> Dismiss All
              </button>
            )}
          </div>

          {/* LIST LIST AREA */}
          <div className="max-h-80 overflow-y-auto divide-y divide-white/5">
            {allNotifications.length === 0 ? (
              <div className="py-8 px-4 text-center space-y-2">
                <Inbox className="w-8 h-8 text-slate-700 mx-auto" />
                <div className="space-y-0.5">
                  <p className="text-[11px] font-bold text-slate-400">Oversight Register Clear</p>
                  <p className="text-[9px] text-slate-500 leading-relaxed max-w-xs mx-auto">
                    Management has not published review actions, comments, or syllabus assignments on your classes yet.
                  </p>
                </div>
              </div>
            ) : (
              allNotifications.map((notif) => {
                const isUnread = !readIds.includes(notif.id);
                
                // Determine container background based on status and unread state
                let containerClass = `p-3 transition-all hover:bg-white/2 flex gap-2.5 relative group `;
                if (isUnread) {
                  if (notif.priority === 'critical') {
                    containerClass += 'bg-rose-950/20 hover:bg-rose-950/30 border-l border-rose-500/20';
                  } else if (notif.priority === 'warning') {
                    containerClass += 'bg-amber-950/10 hover:bg-amber-950/20 border-l border-amber-500/25';
                  } else if (notif.type === 'compliance_status') {
                    containerClass += 'bg-emerald-950/10 hover:bg-emerald-950/20 border-l border-emerald-500/25';
                  } else {
                    containerClass += 'bg-indigo-550/2';
                  }
                }

                // Determine unread strip marker gradient
                let stripMarkerGradient = 'from-indigo-500 to-emerald-500';
                if (notif.priority === 'critical') {
                  stripMarkerGradient = 'from-rose-500 to-red-600';
                } else if (notif.priority === 'warning') {
                  stripMarkerGradient = 'from-amber-400 to-amber-600';
                } else if (notif.type === 'compliance_status') {
                  stripMarkerGradient = 'from-emerald-400 to-teal-500';
                }

                // Determine icon container styling
                let iconContainerStyle = '';
                if (notif.type === 'task') {
                  iconContainerStyle = 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400';
                } else if (notif.type === 'carry_forward') {
                  iconContainerStyle = 'bg-purple-500/10 border-purple-500/20 text-purple-400';
                } else if (notif.type === 'compliance_status') {
                  iconContainerStyle = 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400 font-bold';
                } else if (notif.type === 'reminder') {
                  if (notif.priority === 'critical') {
                    iconContainerStyle = 'bg-rose-500/20 border-rose-500/40 text-rose-400 animate-pulse';
                  } else if (notif.priority === 'warning') {
                    iconContainerStyle = 'bg-amber-500/15 border-amber-500/30 text-amber-400';
                  } else {
                    iconContainerStyle = 'bg-sky-500/15 border-sky-500/30 text-sky-400';
                  }
                } else {
                  iconContainerStyle = 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400';
                }

                return (
                  <div key={notif.id} className={containerClass}>
                    {/* Unread strip marker */}
                    {isUnread && (
                      <div className={`absolute left-0 top-0 bottom-0 w-0.5 bg-gradient-to-b ${stripMarkerGradient}`} />
                    )}

                    {/* Icon container */}
                    <div className="shrink-0">
                      <div className={`p-1.5 rounded-lg border ${iconContainerStyle}`}>
                        {notif.type === 'task' && <BookOpen className="w-3.5 h-3.5" />}
                        {notif.type === 'carry_forward' && <ArrowRightLeft className="w-3.5 h-3.5" />}
                        {notif.type === 'comment' && <MessageSquare className="w-3.5 h-3.5" />}
                        {notif.type === 'compliance_status' && <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
                        {notif.type === 'reminder' && <Clock className="w-3.5 h-3.5" />}
                      </div>
                    </div>

                    {/* Message Area */}
                    <div className="flex-1 space-y-0.5">
                      <div className="flex justify-between items-start gap-1">
                        <h4 className={`text-[11px] font-extrabold leading-tight transition-colors ${
                          notif.priority === 'critical' 
                            ? 'text-rose-200 group-hover:text-rose-100' 
                            : notif.type === 'compliance_status'
                              ? 'text-emerald-300 group-hover:text-emerald-200'
                              : 'text-white group-hover:text-indigo-300'
                        }`}>
                          {notif.priority === 'critical' && <span className="text-rose-400 mr-1 font-black">[🚨 ALERT]</span>}
                          {notif.title}
                        </h4>
                        <span className="text-[8px] text-slate-550 font-medium shrink-0 inline-flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {formatTimeAgo(notif.timestamp)}
                        </span>
                      </div>
                      
                      <p className={`text-[10px] leading-normal ${
                        notif.priority === 'critical' ? 'text-slate-300' : 'text-slate-350'
                      }`}>
                        {notif.message}
                      </p>

                      {notif.details && (
                        <p className={`text-[9px] border p-1.5 rounded-md italic font-mono mt-1 ${
                          notif.priority === 'critical' 
                            ? 'bg-rose-950/20 border-rose-500/10 text-rose-200' 
                            : notif.priority === 'warning'
                              ? 'bg-amber-950/15 border-amber-500/10 text-amber-200'
                              : 'bg-slate-900 border-white/5 text-slate-400'
                        }`}>
                          {notif.details}
                        </p>
                      )}

                      {/* Control controls */}
                      <div className="flex items-center justify-between pt-1.5">
                        {notif.meta?.targetTab ? (
                          <button
                            onClick={() => handleNotificationClick(notif)}
                            className="text-[8.5px] font-black text-indigo-400 hover:text-indigo-300 transition-all inline-flex items-center gap-0.5 cursor-pointer uppercase"
                          >
                            <span>Open Details</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </button>
                        ) : <div />}

                        {isUnread && (
                          <button
                            onClick={() => handleMarkAsRead(notif.id)}
                            className="text-[8.5px] py-0.5 px-1.5 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-slate-400 hover:text-white rounded transition-all font-bold cursor-pointer"
                          >
                            Dismiss
                          </button>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>

          {/* FOOTER */}
          <div className="p-2 bg-slate-900/60 flex justify-between items-center text-[9px] text-slate-450 px-3">
            <span className="inline-flex items-center gap-0.5">
              <UserCheck className="w-3 h-3 text-emerald-400" />
              <span>Verified: {currentUser.name}</span>
            </span>
            <span className="font-semibold uppercase tracking-wider text-[8px] text-slate-500">Live Sync</span>
          </div>

        </div>
      )}
    </div>
  );
}
