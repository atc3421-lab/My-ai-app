import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { SchoolClass, MonthlyTask, CheckingRecord, NotebookStatus } from '../types';
import { TeacherAllotment } from '../data/teacherData';
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  Trello, 
  BarChart3, 
  Calendar, 
  FileSpreadsheet, 
  Sparkles, 
  Plus, 
  Trash2, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Play, 
  Share2, 
  Printer, 
  Layers, 
  Search, 
  Moon, 
  Sun, 
  Filter, 
  ChevronRight, 
  Briefcase, 
  PenTool, 
  CheckSquare, 
  Award,
  ChevronUp,
  ChevronDown
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface TeacherProductivitySuiteProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  allotments: TeacherAllotment[];
  currentUser: { name: string; username: string; role: 'admin' | 'teacher' | 'management' } | null;
  onUpdateRecord: (studentId: string, taskId: string, status: NotebookStatus, notes: string) => void;
}

interface LessonPlan {
  id: string;
  classId: string;
  subject: string;
  title: string;
  objectives: string;
  duration: number; // in mins
  status: 'Drafted' | 'Ready' | 'Teaching' | 'Completed';
  priority: 'High' | 'Medium' | 'Low';
  order: number;
}

interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  type: 'checking' | 'lecture' | 'exam' | 'sync';
  classId?: string;
  subject?: string;
}

export default function TeacherProductivitySuite({
  classes,
  tasks,
  records,
  allotments,
  currentUser,
  onUpdateRecord
}: TeacherProductivitySuiteProps) {
  // Theme state localized to the productivity suite
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('productivity_theme') as 'dark' | 'light') || 'dark';
  });

  // Active Sub-Tab: 'dashboard' | 'syllabus' | 'planner' | 'kanban' | 'analytics' | 'calendar' | 'reports'
  const [activeSubTab, setActiveSubTab] = useState<string>('dashboard');

  // Filter states
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('');

  // Local State persistence managers for added custom elements
  const [lessonPlans, setLessonPlans] = useState<LessonPlan[]>(() => {
    const saved = localStorage.getItem('prod_lesson_plans');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return [
      { id: 'lp_1', classId: 'all', subject: 'Math', title: 'Quadratic Equations Introduction', objectives: 'Understand the formula and visual parabola shape.', duration: 40, status: 'Completed', priority: 'High', order: 1 },
      { id: 'lp_2', classId: 'all', subject: 'Science', title: 'Newton\'s Second Law Experiments', objectives: 'Verify F=ma using mass trolleys and electronic gates.', duration: 80, status: 'Teaching', priority: 'High', order: 2 },
      { id: 'lp_3', classId: 'all', subject: 'English', title: 'Shakespeare\'s Hamlet Act III Analysis', objectives: 'Analyze themes of hesitation and existential anxiety.', duration: 40, status: 'Ready', priority: 'Medium', order: 3 },
      { id: 'lp_4', classId: 'all', subject: 'S.S. (Social Studies)', title: 'French Revolution Key Phases', objectives: 'Examine rise of radical Jacobins and subsequent directoire.', duration: 50, status: 'Drafted', priority: 'Low', order: 4 },
    ];
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem('prod_calendar_events');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    // Seed with realistic dates
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const dayAfter = new Date(Date.now() + 172800000).toISOString().split('T')[0];
    
    return [
      { id: 'ev_1', title: 'Math Notebook Deadline Checking (V O)', date: today, type: 'checking', classId: 'class_v_o', subject: 'Math' },
      { id: 'ev_2', title: 'Class Assessment Exam (VI O)', date: tomorrow, type: 'exam', classId: 'class_vi_o', subject: 'Science' },
      { id: 'ev_3', title: 'Academic Coordinator Sync Session', date: dayAfter, type: 'sync' },
      { id: 'ev_4', title: 'Special Remedial Class (SS)', date: today, type: 'lecture', subject: 'S.S. (Social Studies)' },
    ];
  });

  // Kanban Specific States
  const [kanbanTaskId, setKanbanTaskId] = useState<string>('');
  const [localKanbanStates, setLocalKanbanStates] = useState<{ [studentId: string]: NotebookStatus }>({});

  // Dynamic Syllabus Toggling State
  const [syllabusChecks, setSyllabusChecks] = useState<{ [topicKey: string]: 'pending' | 'in_progress' | 'completed' }>({});

  // Alerts configuration list
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);

  // Form states specifically for adding lesson plans
  const [formLpTitle, setFormLpTitle] = useState('');
  const [formLpClass, setFormLpClass] = useState('');
  const [formLpSubject, setFormLpSubject] = useState('');
  const [formLpObjectives, setFormLpObjectives] = useState('');
  const [formLpDuration, setFormLpDuration] = useState(40);
  const [formLpPriority, setFormLpPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');

  // Form states for calendar events
  const [formEvTitle, setFormEvTitle] = useState('');
  const [formEvDate, setFormEvDate] = useState('');
  const [formEvType, setFormEvType] = useState<'checking' | 'lecture' | 'exam' | 'sync'>('checking');
  const [showAddEventModal, setShowAddEventModal] = useState(false);

  // Interactive Report generating states
  const [reportMonth, setReportMonth] = useState<string>('June 2026');
  const [reportClassId, setReportClassId] = useState<string>('all');
  const [reportSubject, setReportSubject] = useState<string>('all');
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [printError, setPrintError] = useState<string | null>(null);
  const [managementComment, setManagementComment] = useState<string>('');

  // Persistence hooks
  useEffect(() => {
    localStorage.setItem('productivity_theme', themeMode);
  }, [themeMode]);

  useEffect(() => {
    localStorage.setItem('prod_lesson_plans', JSON.stringify(lessonPlans));
  }, [lessonPlans]);

  useEffect(() => {
    localStorage.setItem('prod_calendar_events', JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  // Handle defaults initialization for filters
  useEffect(() => {
    const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
      if (!allotTeacher || !userTeacher) return false;
      const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
      const cleanAllot = cleanStr(allotTeacher);
      const cleanUser = cleanStr(userTeacher);
      if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
      
      const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
      const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      
      for (const allotW of allotWords) {
        for (const userW of userWords) {
          if (allotW.includes(userW) || userW.includes(allotW)) return true;
        }
      }
      return false;
    };

    // Attempt to map teacher's allotted classes to filters
    const teacherName = currentUser?.name || 'Ms.Vaishali';
    const firstMatch = allotments.find(a => 
      isTeacherNameMatched(a.classTeacher, teacherName) || 
      Object.values(a.subjects).some(subT => isTeacherNameMatched(subT, teacherName))
    );
    if (firstMatch) {
      const cls = classes.find(c => c.name.toLowerCase().includes(firstMatch.grade.toLowerCase()));
      if (cls) {
        setSelectedClassId(cls.id);
        const subK = Object.keys(firstMatch.subjects).find(k => isTeacherNameMatched(firstMatch.subjects[k], teacherName));
        if (subK) {
          setSelectedSubject(subK);
        }
      }
    } else if (classes.length > 0) {
      setSelectedClassId(classes[0].id);
      setSelectedSubject('Math');
    }
  }, [classes, allotments, currentUser]);

  // Synchronize target Kanban task
  useEffect(() => {
    if (selectedClassId) {
      const classFilteredTasks = tasks.filter(t => t.classId === selectedClassId && t.subject === selectedSubject);
      if (classFilteredTasks.length > 0) {
        setKanbanTaskId(classFilteredTasks[0].id);
      } else {
        const anyTask = tasks.find(t => t.classId === selectedClassId);
        if (anyTask) {
          setKanbanTaskId(anyTask.id);
        } else {
          setKanbanTaskId('');
        }
      }
    }
  }, [selectedClassId, selectedSubject, tasks]);

  // Load kanban statuses whenever task changes
  useEffect(() => {
    if (kanbanTaskId) {
      const taskR = records.filter(r => r.taskId === kanbanTaskId);
      const newStates: { [studentId: string]: NotebookStatus } = {};
      taskR.forEach(r => {
        newStates[r.studentId] = r.status;
      });
      setLocalKanbanStates(newStates);
    } else {
      setLocalKanbanStates({});
    }
  }, [kanbanTaskId, records]);

  // Derived Values
  const activeClass = classes.find(c => c.id === selectedClassId);
  const students = activeClass ? activeClass.students : [];
  const currentGradeField = activeClass ? activeClass.name.replace('Grade ', '') : '';

  // Get dynamic tasks filtered
  const filteredTasks = tasks.filter(t => {
    const matchClass = selectedClassId ? t.classId === selectedClassId : true;
    const matchSub = selectedSubject ? t.subject === selectedSubject : true;
    return matchClass && matchSub;
  });

  const activeMonthsList = ["April 2026", "June 2026", "July 2026"];

  // Calculate dynamic statistics
  const totalStudentsCount = classes.reduce((sum, c) => sum + c.students.length, 0);
  const totalTasksCount = tasks.length;
  const checkedRecords = records.filter(r => r.status === 'checked').length;
  const missingRecords = records.filter(r => r.status === 'missing').length;
  const totalPossibleChecks = totalStudentsCount * (tasks.filter(t => activeMonthsList.includes(t.month)).length || 1);
  const checkingRatio = totalPossibleChecks > 0 ? Math.round((checkedRecords / totalPossibleChecks) * 105) : 74;

  const smartAlerts = [
    { id: 'a1', title: 'Unchecked Notebook backlog detected', text: `You have ${records.filter(r => r.status === 'unchecked').length} pending notebook rows needing verification.`, variant: 'warning', urgency: 'High' },
    { id: 'a2', title: 'Upcoming Syllabus Audit Day', text: 'Administrative verification scheduled for this Friday. Ensure all tasks for June match plans.', variant: 'info', urgency: 'Medium' },
    { id: 'a3', title: 'Student Notebook Correction Needed', text: `Several student notebooks are marked 'Correction Required'. Recheck to grant sign-offs.`, variant: 'danger', urgency: 'Critical' }
  ].filter(a => !dismissedAlerts.includes(a.id));

  // Handle lesson plan modifications
  const handleAddLessonPlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formLpTitle) return;
    const newLp: LessonPlan = {
      id: 'lp_' + Date.now(),
      classId: formLpClass || 'all',
      subject: formLpSubject || 'General',
      title: formLpTitle,
      objectives: formLpObjectives || 'Deliver core unit study parameters.',
      duration: Number(formLpDuration) || 40,
      status: 'Ready',
      priority: formLpPriority,
      order: lessonPlans.length + 1
    };
    setLessonPlans([...lessonPlans, newLp]);
    setFormLpTitle('');
    setFormLpObjectives('');
  };

  const deleteLessonPlan = (id: string) => {
    setLessonPlans(lessonPlans.filter(p => p.id !== id));
  };

  const moveLessonOrder = (idx: number, direction: 'up' | 'down') => {
    const list = [...lessonPlans];
    if (direction === 'up' && idx > 0) {
      [list[idx], list[idx - 1]] = [list[idx - 1], list[idx]];
    } else if (direction === 'down' && idx < list.length - 1) {
      [list[idx], list[idx + 1]] = [list[idx + 1], list[idx]];
    }
    setLessonPlans(list.map((p, i) => ({ ...p, order: i + 1 })));
  };

  const updateLessonStatus = (id: string, nextStatus: 'Drafted' | 'Ready' | 'Teaching' | 'Completed') => {
    setLessonPlans(lessonPlans.map(p => p.id === id ? { ...p, status: nextStatus } : p));
  };

  // Drag and drop helper functions for lesson planner
  const [draggedLpId, setDraggedLpId] = useState<string | null>(null);
  const handleLpDragStart = (id: string) => {
    setDraggedLpId(id);
  };
  const handleLpDropSwap = (targetId: string) => {
    if (!draggedLpId || draggedLpId === targetId) return;
    const sourceIdx = lessonPlans.findIndex(p => p.id === draggedLpId);
    const targetIdx = lessonPlans.findIndex(p => p.id === targetId);
    if (sourceIdx === -1 || targetIdx === -1) return;
    const list = [...lessonPlans];
    const [removed] = list.splice(sourceIdx, 1);
    list.splice(targetIdx, 0, removed);
    setLessonPlans(list.map((p, i) => ({ ...p, order: i + 1 })));
    setDraggedLpId(null);
  };

  // Calendar Event manipulation
  const handleAddCalendarEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEvTitle || !formEvDate) return;
    const newEv: CalendarEvent = {
      id: 'ev_' + Date.now(),
      title: formEvTitle,
      date: formEvDate,
      type: formEvType,
      classId: selectedClassId,
      subject: selectedSubject
    };
    setCalendarEvents([...calendarEvents, newEv]);
    setFormEvTitle('');
    setFormEvDate('');
    setShowAddEventModal(false);
  };

  const handleDeleteCalendarEvent = (id: string) => {
    setCalendarEvents(calendarEvents.filter(e => e.id !== id));
  };

  // Kanban update handler: synchronizes to global status update function
  const executeKanbanMove = (studentId: string, targetStatus: NotebookStatus) => {
    if (!kanbanTaskId) return;
    onUpdateRecord(studentId, kanbanTaskId, targetStatus, `Updated via Teacher Kanban Suite on ${new Date().toLocaleDateString()}`);
    setLocalKanbanStates(prev => ({
      ...prev,
      [studentId]: targetStatus
    }));
  };

  // Mock circular progress calculator path
  const getRadiusPath = (percent: number, r: number = 24) => {
    const circum = 2 * Math.PI * r;
    const offset = circum - (percent / 100) * circum;
    return { circum, offset };
  };

  // Mock static student metric data for charts & roster sorting
  const notebookPerformers = students.map((s, idx) => {
    // Generate deterministic notebook submissions & scores
    const seed = Number(s.id.split('_').pop() || '5') + idx;
    const checkedCount = Math.round(((seed * 3) % 4) + 6); // out of 10
    const examScore = Math.round(55 + (seed * 4) % 41); // 55 to 96
    const submissionRate = Math.round(((checkedCount) / 10) * 100);
    const isAtRisk = submissionRate < 60 || examScore < 60;
    
    return {
      studentId: s.id,
      name: s.name,
      rollNo: s.rollNumber,
      submissionRate,
      examScore,
      isAtRisk
    };
  }).sort((a,b) => b.submissionRate - a.submissionRate);

  // Filter lessons based on class
  const filteredLessons = lessonPlans.filter(p => p.classId === 'all' || p.classId === selectedClassId);

  // Grouped tasks completion summary for reports
  const reportSyllabusSummary = classes.map(c => {
    const classTasks = tasks.filter(t => t.classId === c.id);
    const totalChapters = classTasks.length;
    const completedChapters = classTasks.filter(t => {
      const taskRecords = records.filter(r => r.taskId === t.id);
      return taskRecords.length > 0 && taskRecords.every(r => r.status === 'checked');
    }).length;
    
    const percentage = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
    return {
      className: c.name,
      total: totalChapters || 12,
      completed: completedChapters || Math.round((totalChapters || 12) * 0.7),
      rate: totalChapters > 0 ? percentage : Math.round(50 + Math.random() * 40)
    };
  });

  // Dynamic metrics compiling for Notebook Evaluation Management Reports
  const availableMonths = Array.from(new Set(tasks.map(t => t.month))).filter(Boolean);
  if (availableMonths.length === 0) {
    availableMonths.push("June 2026");
  }

  const availableSubjects = Array.from(new Set(tasks.map(t => t.subject))).filter(Boolean);

  // Filter tasks matching report controls
  const reportTasks = tasks.filter(t => {
    const matchMonth = t.month === reportMonth;
    const matchClass = reportClassId === 'all' ? true : t.classId === reportClassId;
    const matchSubject = reportSubject === 'all' ? true : t.subject === reportSubject;
    return matchMonth && matchClass && matchSubject;
  });

  // Calculate dynamic rates
  let totalPossibleRows = 0;
  let checkedCount = 0;
  let incompleteCount = 0;
  let missingCount = 0;
  let uncheckedCount = 0;

  interface FilteredRecordInfo {
    studentId: string;
    studentName: string;
    studentRoll: string;
    className: string;
    subject: string;
    taskTitle: string;
    status: NotebookStatus;
    notes: string;
    lastUpdatedAt: string;
  }

  const extractedNotes: FilteredRecordInfo[] = [];

  reportTasks.forEach(task => {
    const cls = classes.find(c => c.id === task.classId);
    if (!cls) return;

    totalPossibleRows += cls.students.length;

    cls.students.forEach(student => {
      const rec = records.find(r => r.studentId === student.id && r.taskId === task.id);
      const status = rec ? rec.status : 'unchecked';

      if (status === 'checked') checkedCount++;
      else if (status === 'incomplete') incompleteCount++;
      else if (status === 'missing') missingCount++;
      else uncheckedCount++;

      // Include comments
      if (rec && rec.notes && rec.notes.trim()) {
        extractedNotes.push({
          studentId: student.id,
          studentName: student.name,
          studentRoll: student.rollNumber,
          className: cls.name,
          subject: task.subject,
          taskTitle: task.title,
          status,
          notes: rec.notes,
          lastUpdatedAt: rec.lastUpdatedAt || new Date().toISOString()
        });
      }
    });
  });

  const completionPercentage = totalPossibleRows > 0 ? Math.round((checkedCount / totalPossibleRows) * 100) : 0;

  return (
    <div className={`p-4 md:p-6 duration-300 rounded-3xl border transition-all ${
      themeMode === 'dark' 
        ? 'bg-slate-900/60 border-indigo-500/10 text-white shadow-2xl shadow-slate-950/50 backdrop-blur-3xl' 
        : 'bg-white/95 border-teal-500/10 text-slate-800 shadow-xl shadow-slate-200/40'
    }`} id="teacher_productivity_suite">
      
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-indigo-500/15">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <div className={`h-8 w-8 rounded-lg flex items-center justify-center shadow-lg ${
              themeMode === 'dark' ? 'bg-teal-500/25 text-teal-400' : 'bg-teal-500 text-white'
            }`}>
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-xl font-black tracking-tight uppercase leading-none">
              Teacher Productivity Workspace
            </h2>
          </div>
          <p className={`text-[11px] font-bold uppercase tracking-wider ${
            themeMode === 'dark' ? 'text-indigo-300' : 'text-indigo-600'
          }`}>
            Samata Academic Faculty Suite • Dashboard, Tracker, Kanban, Planner & Analytics
          </p>
        </div>

        {/* Global Configuration Controls */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Class Selector Dropdown */}
          <div className="flex items-center gap-1">
            <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Class:</span>
            <select
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className={`text-xs font-bold rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-1 ${
                themeMode === 'dark' 
                  ? 'bg-slate-950 border border-white/10 text-white focus:ring-teal-500' 
                  : 'bg-slate-100 border border-slate-200 text-slate-800 focus:ring-teal-500'
              }`}
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Subject Selector Dropdown */}
          <div className="flex items-center gap-1">
            <span className="text-[10px] font-extrabold uppercase text-slate-400 font-mono">Subject:</span>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className={`text-xs font-bold rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-1 ${
                themeMode === 'dark' 
                  ? 'bg-slate-950 border border-white/10 text-white focus:ring-teal-500' 
                  : 'bg-slate-100 border border-slate-200 text-slate-800 focus:ring-teal-500'
              }`}
            >
              <option value="Math">Math</option>
              <option value="English">English</option>
              <option value="Hindi">Hindi</option>
              <option value="Science">Science</option>
              <option value="S.S. (Social Studies)">Social Studies</option>
              <option value="Computer">Computer</option>
            </select>
          </div>

          {/* Sun / Moon Theme Toggle */}
          <button
            onClick={() => setThemeMode(themeMode === 'dark' ? 'light' : 'dark')}
            className={`p-2 rounded-xl transition-all border outline-none ${
              themeMode === 'dark' 
                ? 'bg-slate-950 hover:bg-slate-900 text-teal-400 border-white/10' 
                : 'bg-slate-100 hover:bg-slate-200 text-indigo-700 border-slate-200'
            }`}
            title="Toggle localized Light/Dark palette"
          >
            {themeMode === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Dynamic Workspace Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 my-5 pb-2 border-b border-white/5 overflow-x-auto">
        {[
          { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
          { key: 'syllabus', label: 'Syllabus Tracker', icon: BookOpen },
          { key: 'planner', label: 'Lesson Planner', icon: FileText },
          { key: 'kanban', label: 'Notebook Kanban', icon: Trello },
          { key: 'analytics', label: 'Student Analytics', icon: BarChart3 },
          { key: 'calendar', label: 'Calendar Desk', icon: Calendar },
          { key: 'reports', label: 'Performance Reports', icon: FileSpreadsheet },
        ].map(sub => {
          const Icon = sub.icon;
          const isActive = activeSubTab === sub.key;
          return (
            <button
              key={sub.key}
              onClick={() => setActiveSubTab(sub.key)}
              className={`py-2 px-3.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer border ${
                isActive 
                  ? 'bg-gradient-to-r from-blue-600/15 to-teal-500/15 text-teal-400 border-teal-500/30 shadow-md shadow-teal-500/5' 
                  : themeMode === 'dark'
                    ? 'text-slate-400 hover:text-white hover:bg-white/5 border-transparent'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border-transparent'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {sub.label}
            </button>
          );
        })}
      </div>

      {/* SUB-TABS ROUTING SCENARIOS */}
      <div className="min-h-[550px]">
        
        {/* TAB 1: OVERVIEW DASHBOARD */}
        {activeSubTab === 'dashboard' && (
          <div className="space-y-6 animate-fade-in">
            
            {/* Visual Glassmorphism KPI Widgets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              <div className={`p-4 rounded-2xl border ${
                themeMode === 'dark' ? 'bg-slate-950/40 border-white/5' : 'bg-slate-50 border-slate-100'
              } flex items-center justify-between`}>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Notebook Checking Ratio</span>
                  <div className="text-2xl font-black text-teal-400 tracking-tight">{checkingRatio}%</div>
                  <div className="text-[9px] text-slate-400 font-semibold">Of overall April-July student rosters</div>
                </div>
                {/* Micro circular progress ring in SVG */}
                <svg className="w-12 h-12">
                  <circle cx="24" cy="24" r="18" fill="transparent" stroke={themeMode === 'dark' ? '#1e293b' : '#e2e8f0'} strokeWidth="4" />
                  <circle cx="24" cy="24" r="18" fill="transparent" stroke="#2dd4bf" strokeWidth="4" 
                    strokeDasharray={getRadiusPath(checkingRatio, 18).circum}
                    strokeDashoffset={getRadiusPath(checkingRatio, 18).offset}
                    strokeLinecap="round"
                    transform="rotate(-90 24 24)"
                  />
                  <text x="24" y="27" textAnchor="middle" fontSize="10" fontWeight="900" fill={themeMode === 'dark' ? '#fff' : '#000'}>{checkingRatio}%</text>
                </svg>
              </div>

              <div className={`p-4 rounded-2xl border ${
                themeMode === 'dark' ? 'bg-slate-950/40 border-white/5' : 'bg-slate-50 border-slate-100'
              } flex items-center justify-between`}>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Syllabus Completion</span>
                  <div className="text-2xl font-black text-blue-400 tracking-tight">82%</div>
                  <div className="text-[9px] text-slate-400 font-semibold">Chapters covered against timeline</div>
                </div>
                <svg className="w-12 h-12">
                  <circle cx="24" cy="24" r="18" fill="transparent" stroke={themeMode === 'dark' ? '#1e293b' : '#e2e8f0'} strokeWidth="4" />
                  <circle cx="24" cy="24" r="18" fill="transparent" stroke="#60a5fa" strokeWidth="4" 
                    strokeDasharray={getRadiusPath(82, 18).circum}
                    strokeDashoffset={getRadiusPath(82, 18).offset}
                    strokeLinecap="round"
                    transform="rotate(-90 24 24)"
                  />
                  <text x="24" y="27" textAnchor="middle" fontSize="10" fontWeight="900" fill={themeMode === 'dark' ? '#fff' : '#000'}>82%</text>
                </svg>
              </div>

              <div className={`p-4 rounded-2xl border ${
                themeMode === 'dark' ? 'bg-slate-950/40 border-white/5' : 'bg-slate-50 border-slate-100'
              } flex items-center justify-between`}>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Lesson Plans Active</span>
                  <div className="text-2xl font-black text-rose-400 tracking-tight">
                    {lessonPlans.filter(p => p.status === 'Ready' || p.status === 'Teaching').length} / {lessonPlans.length}
                  </div>
                  <div className="text-[9px] text-slate-400 font-semibold">Ready or currently in lecture delivery</div>
                </div>
                <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400"><FileText className="w-5 h-5" /></div>
              </div>

              <div className={`p-4 rounded-2xl border ${
                themeMode === 'dark' ? 'bg-slate-950/40 border-white/5' : 'bg-slate-50 border-slate-100'
              } flex items-center justify-between`}>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Unchecked Chapters</span>
                  <div className="text-2xl font-black text-amber-400 tracking-tight">
                    {tasks.filter(t => records.filter(r => r.taskId === t.id).length === 0).length} Chapters
                  </div>
                  <div className="text-[9px] text-slate-400 font-semibold">Awaiting initial evaluation matrix</div>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400"><AlertCircle className="w-5 h-5 animate-pulse" /></div>
              </div>

            </div>

            {/* Smart Alerts & Quick Actions Container */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Smart Alerts */}
              <div className="lg:col-span-2 space-y-4">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" /> Smart Academic Alerts & Reminders
                </h3>
                
                {smartAlerts.length === 0 ? (
                  <div className="text-center p-8 bg-slate-500/5 rounded-2xl border border-white/5">
                    <CheckCircle className="w-8 h-8 text-teal-400 mx-auto opacity-70 mb-2" />
                    <span className="text-xs text-slate-400 font-semibold block">All clear! No current workflow alerts.</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {smartAlerts.map(alert => (
                      <div key={alert.id} className={`p-3.5 rounded-xl border flex items-start gap-3 relative group ${
                        alert.variant === 'warning' 
                          ? 'bg-amber-500/5 border-amber-500/20 text-amber-300' 
                          : alert.variant === 'danger'
                          ? 'bg-rose-500/5 border-rose-500/20 text-rose-300'
                          : 'bg-blue-500/5 border-blue-500/20 text-blue-300'
                      }`}>
                        <div className="mt-0.5 shrink-0">
                          {alert.variant === 'warning' && <AlertTriangle className="w-4 h-4" />}
                          {alert.variant === 'danger' && <AlertCircle className="w-4 h-4" />}
                          {alert.variant === 'info' && <AlertCircle className="w-4 h-4" />}
                        </div>
                        <div className="space-y-0.5 pr-8">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-black">{alert.title}</span>
                            <span className="text-[8px] bg-white/5 px-2 py-0.5 rounded uppercase font-black tracking-widest">{alert.urgency}</span>
                          </div>
                          <p className="text-[11px] opacity-80 leading-relaxed">{alert.text}</p>
                        </div>
                        <button
                          onClick={() => setDismissedAlerts([...dismissedAlerts, alert.id])}
                          className="absolute right-2.5 top-2.5 text-[9px] font-black uppercase tracking-wider text-slate-400 hover:text-white cursor-pointer"
                        >
                          Dismiss
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Micro Area Chart showing Checking Velocity over Academic Terms */}
                <div className={`p-5 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/30 border-white/5' : 'bg-slate-50 border-slate-100'
                } space-y-3`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black text-slate-200">Weekly Notebook Submission Metrics</h4>
                      <p className="text-[10px] text-slate-400 font-semibold">Statistical curve indicating on-time completion rates</p>
                    </div>
                    <span className="text-xs font-extrabold text-teal-400 inline-flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" /> +14.2% Growth
                    </span>
                  </div>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={[
                        { name: 'Week 1', rate: 61, checkRate: 52 },
                        { name: 'Week 2', rate: 68, checkRate: 58 },
                        { name: 'Week 3', rate: 75, checkRate: 64 },
                        { name: 'Week 4', rate: 74, checkRate: 72 },
                        { name: 'Week 5', rate: 82, checkRate: 79 },
                        { name: 'Week 6', rate: 90, checkRate: 85 },
                      ]} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorCheck" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff0a" />
                        <XAxis dataKey="name" stroke="#64748b" fontSize={9} />
                        <YAxis stroke="#64748b" fontSize={9} />
                        <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 10, color: '#fff' }} />
                        <Area type="monotone" dataKey="rate" stroke="#2dd4bf" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRate)" name="On-Time Roster Submission" />
                        <Area type="monotone" dataKey="checkRate" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorCheck)" name="Teacher Verification Ledger" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>
              
              {/* Quick Actions Panel */}
              <div className="space-y-4">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-teal-400" /> Fast Checking Action
                </h3>

                <div className={`p-4 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/50 border-white/10 shadow-xl' : 'bg-slate-50 border-slate-200'
                } space-y-4`}>
                  <div className="space-y-1">
                    <span className="text-[11px] font-extrabold text-teal-400 uppercase tracking-wider">Notebook Spot Verification Check</span>
                    <p className="text-[10px] text-slate-400 leading-relaxed">Instantly write scores to the checking matrix for currently active filters.</p>
                  </div>

                  {students.length === 0 ? (
                    <div className="text-xs text-rose-300 py-2">Select a class section with loaded students.</div>
                  ) : (
                    <div className="space-y-3 pt-2">
                      <div className="space-y-1.5">
                        <label className="text-[9px] uppercase font-bold text-slate-400">Select Target Student</label>
                        <select
                          id="quick-action-student"
                          className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        >
                          {students.map(s => (
                            <option key={s.id} value={s.id}>{s.name} (R.{s.rollNumber})</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[9px] uppercase font-bold text-slate-400">Target Syllabus Task</label>
                        <select
                          id="quick-action-task"
                          className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        >
                          {filteredTasks.map(t => (
                            <option key={t.id} value={t.id}>{t.title} ({t.month})</option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => {
                            const std = (document.getElementById('quick-action-student') as HTMLSelectElement)?.value;
                            const tsk = (document.getElementById('quick-action-task') as HTMLSelectElement)?.value;
                            if (std && tsk) {
                              onUpdateRecord(std, tsk, 'checked', 'Spot checked - Verified Okay.');
                              alert('Notebook successfully signed off!');
                            }
                          }}
                          className="py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-lg text-[10px] uppercase transition-all tracking-wider text-center cursor-pointer"
                        >
                          ✅ Sign Off
                        </button>
                        <button
                          onClick={() => {
                            const std = (document.getElementById('quick-action-student') as HTMLSelectElement)?.value;
                            const tsk = (document.getElementById('quick-action-task') as HTMLSelectElement)?.value;
                            if (std && tsk) {
                              onUpdateRecord(std, tsk, 'incomplete', 'Incomplete notebook - needs revision.');
                              alert('Flagged as incomplete review!');
                            }
                          }}
                          className="py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white font-black rounded-lg text-[10px] uppercase transition-all tracking-wider text-center cursor-pointer"
                        >
                          ❌ Flaged Incomplete
                        </button>
                      </div>

                    </div>
                  )}
                </div>

                {/* Calendar highlights list */}
                <div className={`p-4 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/20 border-white/5' : 'bg-slate-50 border-slate-100'
                } space-y-3`}>
                  <h4 className="text-xs font-black text-slate-200 uppercase tracking-widest flex items-center justify-between">
                    <span>Upcoming Deadlines</span>
                    <button onClick={() => setActiveSubTab('calendar')} className="text-[10px] text-teal-400 underline">View Full Desk</button>
                  </h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {calendarEvents.slice(0, 3).map(ev => (
                      <div key={ev.id} className="p-2 bg-white/5 rounded-xl border border-white/5 flex items-center justify-between text-[11px]">
                        <div className="space-y-0.5">
                          <span className="font-extrabold text-slate-200 block truncate max-w-[160px]">{ev.title}</span>
                          <span className="text-[9px] text-slate-500 font-mono italic">{ev.date}</span>
                        </div>
                        <span className={`text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider ${
                          ev.type === 'checking' ? 'bg-teal-500/10 text-teal-300' :
                          ev.type === 'exam' ? 'bg-rose-500/10 text-rose-300' : 'bg-blue-500/10 text-blue-300'
                        }`}>{ev.type}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* TAB 2: SYLLABUS TRACKER */}
        {activeSubTab === 'syllabus' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-teal-400" /> Syllabus Topic Completion Matrix
                </h3>
                <p className="text-[11px] text-slate-400 font-semibold">
                  Track and tick off syllabus topics allotted to class section: <span className="font-extrabold text-teal-400">{currentGradeField || 'Selected Grade'}</span>
                </p>
              </div>

              {/* Status tally indicators */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="h-2 w-2 rounded bg-emerald-400" />
                  <span className="font-bold text-slate-300">Completed</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="h-2 w-2 rounded bg-indigo-400" />
                  <span className="font-bold text-slate-300">In Progress</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="h-2 w-2 rounded bg-slate-600" />
                  <span className="font-bold text-slate-300">Pending</span>
                </div>
              </div>
            </div>

            {filteredTasks.length === 0 ? (
              <div className="text-center p-12 bg-slate-500/5 rounded-2xl border border-white/5 space-y-2">
                <AlertCircle className="w-10 h-10 text-amber-400 mx-auto opacity-70" />
                <span className="text-sm text-slate-400 font-extrabold block">No tasks defined for this class/subject intersection.</span>
                <p className="text-xs text-slate-500">Go to Monthly Plan Syllabus tab to configure curriculum items.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredTasks.map((t, idx) => {
                  const topicKey = `${t.id}-${t.subject}`;
                  const currentStatus = syllabusChecks[topicKey] || (idx % 3 === 0 ? 'completed' : idx % 3 === 1 ? 'in_progress' : 'pending');
                  
                  return (
                    <div key={t.id} className={`p-4 rounded-2xl border transition-all space-y-3 relative overflow-hidden group ${
                      currentStatus === 'completed' 
                        ? 'bg-emerald-950/15 border-emerald-500/25' 
                        : currentStatus === 'in_progress'
                        ? 'bg-indigo-950/15 border-indigo-500/25 animate-pulse'
                        : 'bg-slate-950/40 border-white/5'
                    }`}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <span className="text-[9px] font-black tracking-widest text-indigo-400 uppercase">{t.month}</span>
                          <h4 className="text-xs font-bold text-slate-100 group-hover:text-teal-400 transition-colors line-clamp-1">{t.title}</h4>
                          <span className="text-[10px] text-slate-400 font-semibold">{t.subject} (Allotment: {t.createdBy || 'Staff'})</span>
                        </div>
                        <div className="shrink-0 flex gap-1">
                          <button
                            onClick={() => setSyllabusChecks({...syllabusChecks, [topicKey]: 'pending'})}
                            className={`p-1 rounded text-[8px] font-black uppercase ${
                              currentStatus === 'pending' ? 'bg-slate-300/20 text-slate-300' : 'bg-transparent text-slate-500 hover:text-white'
                            }`}
                          >
                            Pend
                          </button>
                          <button
                            onClick={() => setSyllabusChecks({...syllabusChecks, [topicKey]: 'in_progress'})}
                            className={`p-1 rounded text-[8px] font-black uppercase ${
                              currentStatus === 'in_progress' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-transparent text-slate-500 hover:text-white'
                            }`}
                          >
                            Prog
                          </button>
                          <button
                            onClick={() => setSyllabusChecks({...syllabusChecks, [topicKey]: 'completed'})}
                            className={`p-1 rounded text-[8px] font-black uppercase ${
                              currentStatus === 'completed' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-transparent text-slate-500 hover:text-white'
                            }`}
                          >
                            Done
                          </button>
                        </div>
                      </div>

                      {/* Horizontal progress bar mapping progress of and estimated velocity completion */}
                      <div className="space-y-1.5 text-[10px]">
                        <div className="flex justify-between items-center text-slate-400">
                          <span>Status: <strong className="uppercase">{currentStatus.replace('_', ' ')}</strong></span>
                          <span>Est. Completion: <strong>{currentStatus === 'completed' ? 'Finished' : idx % 2 === 0 ? 'June 25' : 'July 05'}</strong></span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all duration-300 ${
                            currentStatus === 'completed' ? 'w-full bg-emerald-400' : 
                            currentStatus === 'in_progress' ? 'w-1/2 bg-indigo-400' : 'w-0'
                          }`} />
                        </div>
                      </div>

                      {/* Display items check */}
                      {t.description && (
                        <p className="text-[9px] text-slate-400 leading-normal italic bg-black/15 p-2 rounded-xl border border-white/5 line-clamp-2">
                          📖 {t.description}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* TAB 3: LESSON PLANNER */}
        {activeSubTab === 'planner' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Add Lesson Plan Form */}
              <div className="lg:col-span-1 space-y-4">
                <div className={`p-5 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/30 border-white/10' : 'bg-slate-50 border-slate-200'
                } space-y-4`}>
                  <div className="space-y-1">
                    <h3 className="text-xs font-black uppercase tracking-wider text-teal-400 flex items-center gap-1">
                      <PenTool className="w-3.5 h-3.5" /> Draft New Lesson Plan
                    </h3>
                    <p className="text-[10px] text-slate-400 leading-normal">
                      Establish structural lesson objectives, delivery metrics, and print ready checklists.
                    </p>
                  </div>

                  <form onSubmit={handleAddLessonPlan} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400">Lesson Title</label>
                      <input
                        type="text"
                        required
                        value={formLpTitle}
                        onChange={(e) => setFormLpTitle(e.target.value)}
                        placeholder="e.g. Chemical Bonds Structure"
                        className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                          themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                        }`}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[10px] uppercase font-bold text-slate-400">Allotted Class</label>
                        <select
                          value={formLpClass}
                          onChange={(e) => setFormLpClass(e.target.value)}
                          className={`w-full text-xs font-bold rounded-xl px-2 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        >
                          <option value="all">Across All</option>
                          {classes.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] uppercase font-bold text-slate-400">Subject</label>
                        <select
                          value={formLpSubject}
                          onChange={(e) => setFormLpSubject(e.target.value)}
                          className={`w-full text-xs font-bold rounded-xl px-2 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        >
                          <option value="Math">Math</option>
                          <option value="English">English</option>
                          <option value="Hindi">Hindi</option>
                          <option value="Science">Science</option>
                          <option value="S.S. (Social Studies)">Social Studies</option>
                          <option value="Computer">Computer</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400">Objectives & Deliverables</label>
                      <textarea
                        value={formLpObjectives}
                        onChange={(e) => setFormLpObjectives(e.target.value)}
                        placeholder="Define what students will master..."
                        rows={3}
                        className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                          themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                        }`}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[10px] uppercase font-bold text-slate-400">Duration (Mins)</label>
                        <input
                          type="number"
                          value={formLpDuration}
                          onChange={(e) => setFormLpDuration(Number(e.target.value))}
                          className={`w-full text-xs font-bold rounded-xl px-2 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] uppercase font-bold text-slate-400">Rank Priority</label>
                        <select
                          value={formLpPriority}
                          onChange={(e) => setFormLpPriority(e.target.value as any)}
                          className={`w-full text-xs font-bold rounded-xl px-2 py-2 ${
                            themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                          }`}
                        >
                          <option value="High">🔴 High</option>
                          <option value="Medium">🟡 Medium</option>
                          <option value="Low">🟢 Low</option>
                        </select>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-teal-500 hover:bg-teal-600 text-white font-black py-2.5 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer"
                    >
                      + Save & Queue Plan
                    </button>
                  </form>
                </div>
              </div>

              {/* Lesson Plan Queue Checklist */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                    Active Lesson Queue (Drag-and-Drop Order Persistent Ranks)
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono italic">
                    💡 Click arrows or drag cards to re-order sequence
                  </span>
                </div>

                <div className="space-y-3">
                  {filteredLessons.sort((a,b) => a.order - b.order).map((plan, idx) => (
                    <div
                      key={plan.id}
                      draggable
                      onDragStart={() => handleLpDragStart(plan.id)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => handleLpDropSwap(plan.id)}
                      className={`p-4 rounded-2xl border transition-all relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 cursor-grab active:cursor-grabbing ${
                        plan.status === 'Completed'
                          ? 'bg-slate-950/20 border-white/5 opacity-60'
                          : plan.status === 'Teaching'
                          ? 'bg-teal-500/5 border-teal-500/30'
                          : themeMode === 'dark'
                          ? 'bg-slate-950/40 border-white/5 hover:border-teal-500/20'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      {/* Left: Move handles + Meta details */}
                      <div className="flex items-start gap-3">
                        <div className="flex flex-col gap-0.5 mt-1">
                          <button
                            onClick={() => moveLessonOrder(idx, 'up')}
                            disabled={idx === 0}
                            className="p-1 hover:bg-white/10 rounded disabled:opacity-20 cursor-pointer"
                          >
                            <ChevronUp className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => moveLessonOrder(idx, 'down')}
                            disabled={idx === filteredLessons.length - 1}
                            className="p-1 hover:bg-white/10 rounded disabled:opacity-20 cursor-pointer"
                          >
                            <ChevronDown className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[9px] font-black text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded uppercase tracking-wider">
                              Rank {idx + 1}
                            </span>
                            <span className="text-[9px] font-extrabold text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded">
                              {plan.subject}
                            </span>
                            <span className="text-[9px] font-bold text-slate-400">
                              {plan.duration} mins
                            </span>
                          </div>
                          <h4 className="text-xs font-bold text-white leading-snug">{plan.title}</h4>
                          <p className="text-[10px] text-slate-400 leading-relaxed max-w-md italic">
                            🎯 Goal: {plan.objectives}
                          </p>
                        </div>
                      </div>

                      {/* Right: State modifiers */}
                      <div className="flex flex-wrap items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                        <select
                          value={plan.status}
                          onChange={(e) => updateLessonStatus(plan.id, e.target.value as any)}
                          className={`text-[10px] font-bold rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 ${
                            themeMode === 'dark' 
                              ? 'bg-slate-900 border border-white/5 text-slate-200 focus:ring-teal-500' 
                              : 'bg-white border text-slate-800'
                          }`}
                        >
                          <option value="Drafted">📝 Drafted</option>
                          <option value="Ready">💡 Ready</option>
                          <option value="Teaching">🧑‍🏫 Teaching</option>
                          <option value="Completed">✅ Completed</option>
                        </select>

                        <button
                          onClick={() => deleteLessonPlan(plan.id)}
                          className="p-1.5 hover:bg-rose-500/15 rounded text-rose-300 transition-all cursor-pointer border border-transparent hover:border-rose-500/20"
                          title="Delete Lesson Plan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: NOTEBOOK CHECKING KANBAN BOARD */}
        {activeSubTab === 'kanban' && (
          <div className="space-y-6 animate-fade-in">
            {/* Header selection info */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                  <Trello className="w-4 h-4 text-teal-400" /> Interactive Notebook Checking Kanban
                </h3>
                <p className="text-[11px] text-slate-400 font-semibold">
                  Drag & Drop or click buttons to transfer student notebooks through evaluation pathways for: 
                  <span className="font-extrabold text-teal-400 ml-1">
                    {filteredTasks.find(t => t.id === kanbanTaskId)?.title || 'Selected Syllabus Task'}
                  </span>
                </p>
              </div>

              {/* Selector task */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">Curriculum Task:</span>
                <select
                  value={kanbanTaskId}
                  onChange={(e) => setKanbanTaskId(e.target.value)}
                  className={`text-xs font-bold rounded-xl px-2.5 py-1.5 focus:outline-none focus:ring-1 ${
                    themeMode === 'dark' 
                      ? 'bg-slate-950 border border-white/10 text-white focus:ring-teal-500' 
                      : 'bg-slate-100 border border-slate-200 text-slate-800 focus:ring-teal-500'
                  }`}
                >
                  {filteredTasks.map(t => (
                    <option key={t.id} value={t.id}>{t.title} ({t.month})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Kanban Columns */}
            {students.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-xs italic">
                Please load a class section with register students inside the top-right filters.
              </div>
            ) : !kanbanTaskId ? (
              <div className="text-center py-12 text-slate-400 text-sm font-bold">
                No monthly syllabus checking tasks registered. Head to 'Syllabus Tracker' or 'Monthly Plan' to preseed a checking event.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Column 1: To Check (status: unchecked or empty) */}
                {(() => {
                  const items = students.filter(s => {
                    const status = localKanbanStates[s.id];
                    return !status || status === 'unchecked';
                  });

                  return (
                    <div 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const stdId = (window as any).__draggedStudentId;
                        if (stdId) executeKanbanMove(stdId, 'unchecked');
                      }}
                      className="p-4 rounded-2xl bg-slate-950/50 border border-white/5 space-y-3 min-h-[450px]"
                    >
                      <div className="flex items-center justify-between border-b border-white/5 pb-2">
                        <span className="text-xs font-black uppercase text-amber-300">⏳ To Check ({items.length})</span>
                      </div>
                      <div className="space-y-2 overflow-y-auto max-h-[380px] pr-1">
                        {items.length === 0 ? (
                          <div className="text-[10px] text-slate-500 italic text-center py-8">All clear in this column!</div>
                        ) : (
                          items.map(s => (
                            <div
                              key={s.id}
                              draggable
                              onDragStart={() => { (window as any).__draggedStudentId = s.id; }}
                              className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2 cursor-grab active:cursor-grabbing hover:border-amber-400/20 transition-all"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] font-extrabold text-slate-200">{s.name}</span>
                                <span className="text-[9px] font-mono text-slate-500">R.{s.rollNumber}</span>
                              </div>
                              {/* Quick Move Action buttons */}
                              <div className="flex flex-wrap gap-1 pt-1.5 border-t border-white/5">
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'checked')}
                                  className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded hover:bg-emerald-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Sign ✓
                                </button>
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'incomplete')}
                                  className="text-[8px] font-bold text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded hover:bg-rose-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Fix ⚠️
                                </button>
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'missing')}
                                  className="text-[8px] font-bold text-slate-400 bg-slate-500/10 px-1.5 py-0.5 rounded hover:bg-slate-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Absent 🚫
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })()}

                {/* Column 2: Missing (status: missing) */}
                {(() => {
                  const items = students.filter(s => {
                    const status = localKanbanStates[s.id];
                    return status === 'missing';
                  });

                  return (
                    <div 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const stdId = (window as any).__draggedStudentId;
                        if (stdId) executeKanbanMove(stdId, 'missing');
                      }}
                      className="p-4 rounded-2xl bg-slate-950/50 border border-white/5 space-y-3 min-h-[450px]"
                    >
                      <div className="flex items-center justify-between border-b border-white/5 pb-2">
                        <span className="text-xs font-black uppercase text-slate-400">🚫 Missing / Absent ({items.length})</span>
                      </div>
                      <div className="space-y-2 overflow-y-auto max-h-[380px] pr-1">
                        {items.length === 0 ? (
                          <div className="text-[10px] text-slate-500 italic text-center py-8">No missing notebooks.</div>
                        ) : (
                          items.map(s => (
                            <div
                              key={s.id}
                              draggable
                              onDragStart={() => { (window as any).__draggedStudentId = s.id; }}
                              className="p-3 bg-red-950/25 border border-red-500/25 rounded-xl space-y-2 cursor-grab active:cursor-grabbing hover:border-red-400/20 transition-all"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] font-extrabold text-slate-200">{s.name}</span>
                                <span className="text-[9px] font-mono text-slate-500">R.{s.rollNumber}</span>
                              </div>
                              <span className="text-[9.5px] text-red-400/80 font-medium">Notebook was missing</span>
                              <div className="flex items-center gap-1 pt-1.5 border-t border-white/5">
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'unchecked')}
                                  className="text-[8px] font-bold text-teal-400 bg-teal-500/10 px-1.5 py-0.5 rounded hover:bg-teal-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Found/Submit ⏳
                                </button>
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'checked')}
                                  className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded hover:bg-emerald-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Sign ✓
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })()}

                {/* Column 3: Incomplete / Correction Required (status: incomplete) */}
                {(() => {
                  const items = students.filter(s => {
                    const status = localKanbanStates[s.id];
                    return status === 'incomplete';
                  });

                  return (
                    <div 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const stdId = (window as any).__draggedStudentId;
                        if (stdId) executeKanbanMove(stdId, 'incomplete');
                      }}
                      className="p-4 rounded-2xl bg-slate-950/50 border border-white/5 space-y-3 min-h-[450px]"
                    >
                      <div className="flex items-center justify-between border-b border-white/5 pb-2">
                        <span className="text-xs font-black uppercase text-rose-350">⚠️ Correction ({items.length})</span>
                      </div>
                      <div className="space-y-2 overflow-y-auto max-h-[380px] pr-1">
                        {items.length === 0 ? (
                          <div className="text-[10px] text-slate-500 italic text-center py-8">None flagged correction.</div>
                        ) : (
                          items.map(s => (
                            <div
                              key={s.id}
                              draggable
                              onDragStart={() => { (window as any).__draggedStudentId = s.id; }}
                              className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2 cursor-grab active:cursor-grabbing hover:border-rose-400/20 transition-all"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] font-extrabold text-slate-200">{s.name}</span>
                                <span className="text-[9px] font-mono text-slate-500">R.{s.rollNumber}</span>
                              </div>
                              <span className="text-[9px] block text-rose-400 italic font-medium">Correction required</span>
                              <div className="flex items-center gap-1 pt-1.5 border-t border-white/5">
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'unchecked')}
                                  className="text-[8px] font-bold text-indigo-400 bg-white/5 px-1.5 py-0.5 rounded cursor-pointer"
                                >
                                  Re-Submit ⏳
                                </button>
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'checked')}
                                  className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded hover:bg-emerald-500 hover:text-white transition-all cursor-pointer"
                                >
                                  Sign ✓
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })()}

                {/* Column 4: Completed & Signed (status: checked) */}
                {(() => {
                  const items = students.filter(s => {
                    const status = localKanbanStates[s.id];
                    return status === 'checked';
                  });

                  return (
                    <div 
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        const stdId = (window as any).__draggedStudentId;
                        if (stdId) executeKanbanMove(stdId, 'checked');
                      }}
                      className="p-4 rounded-2xl bg-slate-950/50 border border-white/5 space-y-3 min-h-[450px]"
                    >
                      <div className="flex items-center justify-between border-b border-white/5 pb-2">
                        <span className="text-xs font-black uppercase text-emerald-400">✅ Checked ({items.length})</span>
                      </div>
                      <div className="space-y-2 overflow-y-auto max-h-[380px] pr-1">
                        {items.length === 0 ? (
                          <div className="text-[10px] text-slate-500 italic text-center py-8">No signed notebooks yet.</div>
                        ) : (
                          items.map(s => (
                            <div
                              key={s.id}
                              draggable
                              onDragStart={() => { (window as any).__draggedStudentId = s.id; }}
                              className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2 cursor-grab active:cursor-grabbing hover:border-emerald-400/20 transition-all opacity-85"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[11px] font-extrabold text-slate-200 line-through decoration-emerald-500/50">{s.name}</span>
                                <span className="text-[9px] font-mono text-slate-500">R.{s.rollNumber}</span>
                              </div>
                              <span className="block text-[9px] text-emerald-400 font-bold">✓ Signed-off</span>
                              <div className="flex items-center gap-1 pt-1 border-t border-white/5">
                                <button
                                  onClick={() => executeKanbanMove(s.id, 'unchecked')}
                                  className="text-[8px] font-bold text-slate-400 hover:text-white transition-all cursor-pointer"
                                >
                                  Revert to To Check
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })()}

              </div>
            )}
          </div>
        )}

        {/* TAB 5: STUDENT ANALYTICS */}
        {activeSubTab === 'analytics' && (
          <div className="space-y-6 animate-fade-in text-slate-300">
            <div className="space-y-1">
              <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-teal-400" /> Student Progress and Submission Insights
              </h3>
              <p className="text-[11px] text-slate-400 font-semibold">
                Analyse individual submission consistency trends vs exam marks mapped on active grade classes.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Submission Roster List */}
              <div className="lg:col-span-2 space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center justify-between">
                  <span>Student Submission Rates (Sorted highest first)</span>
                  <span className="text-[10px] text-teal-400">Roster total: {students.length} Pupils</span>
                </h4>

                <div className="overflow-x-auto rounded-xl border border-white/5">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950/80 text-[10px] text-slate-400 font-black uppercase border-b border-white/10 uppercase tracking-wider">
                        <th className="py-2.5 px-3">Roll No</th>
                        <th className="py-2.5 px-3">Student Name</th>
                        <th className="py-2.5 px-3 text-center">Submission Curve</th>
                        <th className="py-2.5 px-3 text-center">Exam Performance</th>
                        <th className="py-2.5 px-3 text-right">Status Flag</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {notebookPerformers.map(p => (
                        <tr key={p.studentId} className="hover:bg-white/5">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-400">{p.rollNo}</td>
                          <td className="py-2.5 px-3 font-extrabold text-slate-200">{p.name}</td>
                          <td className="py-2.5 px-3 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <div className="w-16 bg-slate-950 h-2 rounded overflow-hidden">
                                <div className={`h-full rounded ${p.submissionRate > 80 ? 'bg-emerald-400' : p.submissionRate > 60 ? 'bg-indigo-400' : 'bg-rose-400'}`} style={{ width: `${p.submissionRate}%` }} />
                              </div>
                              <span className="font-mono text-[10px] font-bold">{p.submissionRate}%</span>
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`font-mono font-black text-[10px] rounded px-1.5 py-0.5 ${p.examScore > 85 ? 'bg-emerald-500/10 text-emerald-350' : p.examScore > 70 ? 'bg-blue-500/10 text-blue-300' : 'bg-amber-500/10 text-amber-300'}`}>
                              {p.examScore}%
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            {p.isAtRisk ? (
                              <span className="text-[9px] font-black text-rose-350 bg-rose-500/10 px-2 py-0.5 rounded tracking-widest uppercase">⚠️ At Risk</span>
                            ) : (
                              <span className="text-[9px] font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded tracking-widest uppercase">✓ Outstanding</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Action Insights Card */}
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Dynamic Interventions</h4>
                
                <div className={`p-4 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/30 border-white/10' : 'bg-slate-50 border-slate-200'
                } space-y-4`}>
                  <div className="space-y-1">
                    <span className="text-[11px] font-extrabold text-yellow-400 uppercase tracking-widest">Early Intervention Flags</span>
                    <p className="text-[10px] text-slate-400 leading-normal">The system identified these students as having an audit risk due to missing or incomplete checks:</p>
                  </div>

                  <div className="space-y-2">
                    {notebookPerformers.filter(p => p.isAtRisk).slice(0, 3).map(p => (
                      <div key={p.studentId} className="p-3 bg-rose-500/5 rounded-xl border border-rose-500/15 text-[11px] flex justify-between items-center">
                        <div className="space-y-0.5">
                          <span className="font-extrabold text-slate-100 block">{p.name}</span>
                          <span className="text-[9px] text-slate-500">Exam: {p.examScore}% | Notebook: {p.submissionRate}%</span>
                        </div>
                        <button
                          onClick={() => alert(`Review memo drafted for parent contact of: ${p.name}`)}
                          className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500 text-rose-300 hover:text-white rounded text-[9px] font-bold transition-all cursor-pointer"
                        >
                          Draft Notice
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-white/5 space-y-2">
                    <span className="text-[11px] font-extrabold text-teal-400 block uppercase">Smart Recommendations</span>
                    <ul className="text-[10px] text-slate-400 space-y-2 list-disc pl-4 italic">
                      <li>Launch a catch-up workspace for students below 70% notebook completion rates.</li>
                      <li>Sync monthly checklists to the Parent desk search area.</li>
                      <li>Consolidate Class Test grades in Syllabus Tests Scorebook prior to next audit cycle.</li>
                    </ul>
                  </div>
                </div>

              </div>
              
            </div>

          </div>
        )}

        {/* TAB 6: MY CALENDAR */}
        {activeSubTab === 'calendar' && (
          <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-teal-400" /> Academic Schedule & Calendar Desk
                </h3>
                <p className="text-[11px] text-slate-400 font-semibold font-sans">
                  Manage checking deadlines, revision exams, and key events mapped on the timeline.
                </p>
              </div>

              <button
                onClick={() => setShowAddEventModal(true)}
                className="bg-teal-500 hover:bg-teal-600 text-white font-black py-2 px-3.5 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" /> Schedule Event
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Daily Checklist Grid list */}
              <div className="lg:col-span-2 space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Events Directory</h4>
                
                {calendarEvents.length === 0 ? (
                  <div className="text-center p-8 bg-slate-500/5 rounded-2xl">
                    <span className="text-xs text-slate-500 italic block">No events scheduled. click "Schedule Event" above.</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {calendarEvents.map(ev => (
                      <div key={ev.id} className={`p-4 rounded-2xl border flex flex-col justify-between gap-3 bg-slate-950/40 relative overflow-hidden group ${
                        ev.type === 'checking' ? 'border-teal-500/15' :
                        ev.type === 'exam' ? 'border-rose-500/15' :
                        ev.type === 'sync' ? 'border-indigo-500/15' : 'border-blue-500/15'
                      }`}>
                        <div className="space-y-1">
                          <div className="flex items-center justify-between">
                            <span className={`text-[8px] px-2 py-0.5 rounded font-black uppercase tracking-widest ${
                              ev.type === 'checking' ? 'bg-teal-500/10 text-teal-300' :
                              ev.type === 'exam' ? 'bg-rose-500/10 text-rose-300' :
                              ev.type === 'sync' ? 'bg-indigo-500/10 text-indigo-300' : 'bg-blue-500/10 text-blue-300'
                            }`}>{ev.type}</span>

                            <button
                              onClick={() => handleDeleteCalendarEvent(ev.id)}
                              className="text-slate-500 hover:text-rose-400 text-xs cursor-pointer opacity-0 group-hover:opacity-100 transition-all"
                              title="Delete event"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                          
                          <h4 className="text-xs font-bold text-white line-clamp-1">{ev.title}</h4>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-white/5 font-mono">
                          <span>📅 {ev.date}</span>
                          <span>{ev.subject || 'All Faculty'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Static visual monthly view calendar for teacher reminder context */}
              <div className="space-y-4">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">June 2026 Grid Overview</h4>
                
                <div className={`p-4 rounded-2xl border ${
                  themeMode === 'dark' ? 'bg-slate-950/40 border-white/5 shadow-2xl' : 'bg-slate-50 border-slate-200'
                } space-y-4`}>
                  <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-black text-indigo-400 font-mono">
                    <span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span>
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold font-mono">
                    <span className="text-slate-600">1</span><span className="text-slate-600">2</span><span className="text-slate-600">3</span><span className="text-slate-600">4</span>
                    <span className="bg-teal-500 text-white rounded font-black felt-active relative">5</span>
                    <span>6</span><span>7</span>
                    <span>8</span><span>9</span><span className="bg-rose-500 text-white rounded">10</span><span>11</span><span>12</span>
                    <span className="bg-blue-500 text-white rounded font-extrabold">13</span><span>14</span>
                    <span>15</span><span>16</span><span>17</span><span>18</span><span>19</span><span>20</span><span>21</span>
                    <span>22</span><span>23</span><span>24</span><span>25</span><span>26</span><span>27</span><span>28</span>
                    <span>29</span><span>30</span>
                  </div>
                  <div className="text-[10px] text-slate-400 space-y-1.5 italic bg-black/15 p-2.5 rounded-xl border border-white/5">
                    <div>🔵 <strong className="text-blue-300">Today:</strong> June 13, 2026 Workflows</div>
                    <div>🟢 <strong className="text-teal-300">Audit Deadlines:</strong> Every alternating Friday</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Calendar modal triggers */}
            {showAddEventModal && (
              <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-55 animate-fade-in">
                <div className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
                  <div className="text-center space-y-1">
                    <h3 className="font-extrabold text-base text-white">Schedule Calendar Entry</h3>
                    <p className="text-[11px] text-slate-400">Allocate checking tasks, alarms, or testing dates.</p>
                  </div>

                  <form onSubmit={handleAddCalendarEvent} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400">Event Title</label>
                      <input
                        type="text"
                        required
                        value={formEvTitle}
                        onChange={(e) => setFormEvTitle(e.target.value)}
                        placeholder="e.g. Science Revision Drill"
                        className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs text-white"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400">Deadline Target Date</label>
                      <input
                        type="date"
                        required
                        value={formEvDate}
                        onChange={(e) => setFormEvDate(e.target.value)}
                        className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs text-white"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] uppercase font-bold text-slate-400">Action Type</label>
                      <select
                        value={formEvType}
                        onChange={(e) => setFormEvType(e.target.value as any)}
                        className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs text-white"
                      >
                        <option value="checking">Checking Task Deadline ⏳</option>
                        <option value="exam">Model Chapter Exam 📝</option>
                        <option value="sync">Administrative Sync Meeting 👥</option>
                        <option value="lecture">Remedial Special Lecture 📚</option>
                      </select>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddEventModal(false)}
                        className="flex-1 py-2 px-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300 transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 px-3 bg-teal-500 hover:bg-teal-600 rounded-xl text-xs font-black text-white transition-all cursor-pointer"
                      >
                        Add Entry
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB 7: REPORTS CENTER */}
        {activeSubTab === 'reports' && (
          <div className="space-y-6 animate-fade-in" id="reports-print-section">
            
            {/* Header / Subtitle bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 no-print">
              <div className="space-y-1">
                <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-teal-400" /> Administrative Notebook Evaluation Ledger
                </h3>
                <p className="text-[11px] text-slate-400 font-semibold">
                  Compile and export official monthly notebook audit summary PDF reports for management submission.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowPrintModal(true)}
                  className="bg-teal-500 hover:bg-teal-600 text-white font-black py-2.5 px-4 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer flex items-center gap-1.5 shadow-md shadow-teal-500/10"
                >
                  <Printer className="w-4 h-4" /> Export Report to PDF
                </button>
              </div>
            </div>

            {/* Selection filters */}
            <div className="no-print grid grid-cols-1 md:grid-cols-4 gap-4 p-5 rounded-2xl bg-slate-950/40 border border-white/5">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Audit Target Month</label>
                <select
                  value={reportMonth}
                  onChange={(e) => setReportMonth(e.target.value)}
                  className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                    themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                  }`}
                >
                  {availableMonths.map(mon => (
                    <option key={mon} value={mon}>{mon}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Class Section</label>
                <select
                  value={reportClassId}
                  onChange={(e) => setReportClassId(e.target.value)}
                  className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                    themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                  }`}
                >
                  <option value="all">📁 All Classes combined</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Curriculum Subject</label>
                <select
                  value={reportSubject}
                  onChange={(e) => setReportSubject(e.target.value)}
                  className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 ${
                    themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                  }`}
                >
                  <option value="all">📚 All Subjects combined</option>
                  {availableSubjects.map(sub => (
                    <option key={sub} value={sub}>{sub}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Assigned Reviewer / auditor</label>
                <input
                  type="text"
                  disabled
                  value={currentUser ? `${currentUser.name} (${currentUser.role})` : 'Ms.Vaishali (Teacher)'}
                  className={`w-full text-xs font-bold rounded-xl px-2.5 py-2 opacity-75 ${
                    themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                  }`}
                />
              </div>
            </div>

            {/* Management Review Custom general comments input before printing */}
            <div className="no-print p-4 rounded-2xl bg-indigo-950/15 border border-indigo-500/15 space-y-2">
              <span className="text-[11px] font-black uppercase text-indigo-400 tracking-wider flex items-center gap-1">
                📝 Management Memo remarks & Auditor Recommendation
              </span>
              <p className="text-[10px] text-slate-400 leading-normal">
                Pre-populate comments, summary observations, or notice requirements to highlight at the top of the exported PDF.
              </p>
              <textarea
                value={managementComment}
                onChange={(e) => setManagementComment(e.target.value)}
                placeholder="e.g., Note: Class 6-A notebooks have been 95% evaluated. Hindi notebooks require immediate follow-up prior to final audits."
                rows={2}
                className={`w-full text-xs font-bold rounded-xl px-3 py-2 ${
                  themeMode === 'dark' ? 'bg-slate-950 border border-white/5 text-white' : 'bg-white border text-slate-800'
                }`}
              />
            </div>

            {/* LIVE PREVIEW OF PDF SHEET */}
            <div className="space-y-3 no-print">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Management Report Live Preview
              </h4>

              <div className={`p-6 rounded-3xl border ${
                themeMode === 'dark' ? 'bg-slate-950/40 border-white/5 shadow-2xl' : 'bg-slate-50 border-slate-200'
              } space-y-6`}>
                
                {/* School Letterhead */}
                <div className="border-b border-indigo-500/15 pb-4 flex justify-between items-start gap-4 flex-wrap">
                  <div className="space-y-1">
                    <span className="text-[9px] font-black uppercase text-teal-400 bg-teal-500/10 px-2.5 py-0.5 rounded tracking-widest">
                      ACADEMIC AUDIT LOG
                    </span>
                    <h3 className={`text-base font-black tracking-tight ${themeMode === 'dark' ? 'text-white' : 'text-slate-800'}`}>
                      Samata International School Administration Office
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Curriculum notebooks spot evaluation and submission coverage index
                    </p>
                  </div>
                  <div className="text-right text-[10px] text-slate-400 font-mono">
                    <div>Date Compiled: June 13, 2026</div>
                    <div>Auditor: {currentUser?.name || 'Academic Coordinator'}</div>
                  </div>
                </div>

                {/* Target Scope metadata */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-3 bg-black/15 border border-white/5 rounded-xl space-y-0.5">
                    <span className="text-[9px] text-slate-500 uppercase font-bold pr-1">Audit Month:</span>
                    <span className="text-xs font-extrabold text-indigo-400 block">{reportMonth}</span>
                  </div>
                  <div className="p-3 bg-black/15 border border-white/5 rounded-xl space-y-0.5">
                    <span className="text-[9px] text-slate-500 uppercase font-bold pr-1">Grade Class:</span>
                    <span className="text-xs font-extrabold text-indigo-400 block">
                      {reportClassId === 'all' ? 'All Classes combined' : classes.find(c => c.id === reportClassId)?.name}
                    </span>
                  </div>
                  <div className="p-3 bg-black/15 border border-white/5 rounded-xl space-y-0.5">
                    <span className="text-[9px] text-slate-500 uppercase font-bold pr-1">Subject Scope:</span>
                    <span className="text-xs font-extrabold text-indigo-400 block">
                      {reportSubject === 'all' ? 'All Subjects combined' : reportSubject}
                    </span>
                  </div>
                </div>

                {/* Main Completion Percentage highlights bar */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-500/5 to-indigo-500/5 border border-teal-500/25 flex flex-col sm:flex-row items-center gap-6 justify-between">
                  <div className="space-y-1 text-center sm:text-left">
                    <span className="text-[10px] font-black uppercase text-teal-400 tracking-wider">Notebook Audit completeness Cover ratio</span>
                    <h4 className={`text-xl font-black ${themeMode === 'dark' ? 'text-white' : 'text-slate-800'}`}>
                      {completionPercentage}% Evaluated & Approved
                    </h4>
                    <p className="text-[10px] text-slate-400 font-semibold leading-normal">
                      Based on {checkedCount} signed-off checks out of {totalPossibleRows} registered notebooks.
                    </p>
                  </div>

                  {/* Percentage bar scale */}
                  <div className="w-full sm:w-64 space-y-1.5 shrink-0">
                    <div className="flex justify-between items-center text-[10px] text-slate-400">
                      <span>Percentage: <strong className="text-teal-400 font-black">{completionPercentage}%</strong></span>
                    </div>
                    <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-white/5">
                      <div 
                        className="h-full rounded-full bg-gradient-to-r from-teal-400 to-indigo-405 transition-all duration-500"
                        style={{ width: `${completionPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Substats breakdown */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                  <div className="p-3.5 bg-emerald-500/5 border border-emerald-500/15 rounded-xl text-center">
                    <span className="text-[9px] font-black text-emerald-400 uppercase">Checked ✅</span>
                    <strong className="block text-lg font-black text-slate-200 mt-1">{checkedCount}</strong>
                    <span className="text-[9px] text-slate-500 font-semibold">Checks signed</span>
                  </div>

                  <div className="p-3.5 bg-rose-500/5 border border-rose-500/15 rounded-xl text-center">
                    <span className="text-[9px] font-black text-rose-400 uppercase">Incomplete ⚠️</span>
                    <strong className="block text-lg font-black text-slate-200 mt-1">{incompleteCount}</strong>
                    <span className="text-[9px] text-slate-500 font-semibold">Correction flags</span>
                  </div>

                  <div className="p-3.5 bg-red-950/25 border border-red-500/20 rounded-xl text-center">
                    <span className="text-[9px] font-black text-red-400 uppercase">Absent/Missing 🚫</span>
                    <strong className="block text-lg font-black text-slate-200 mt-1">{missingCount}</strong>
                    <span className="text-[9px] text-slate-500 font-semibold">Not submitted</span>
                  </div>

                  <div className="p-3.5 bg-slate-500/5 border border-slate-100/10 rounded-xl text-center">
                    <span className="text-[9px] font-black text-slate-400 uppercase">Pending Review ⏳</span>
                    <strong className="block text-lg font-black text-slate-200 mt-1">{uncheckedCount}</strong>
                    <span className="text-[9px] text-slate-500 font-semibold">Evaluation backlog</span>
                  </div>
                </div>

                {/* General memo display if populated */}
                {managementComment.trim() && (
                  <div className={`p-4 rounded-xl border ${
                    themeMode === 'dark' ? 'bg-indigo-950/10 border-indigo-500/15' : 'bg-indigo-50 border-indigo-100'
                  } space-y-1`}>
                    <span className="text-[10px] font-black text-indigo-400 uppercase">Preloaded Memo observations:</span>
                    <p className={`text-xs font-semibold leading-relaxed ${themeMode === 'dark' ? 'text-slate-200' : 'text-slate-800'}`}>
                      "{managementComment}"
                    </p>
                  </div>
                )}

                {/* Specific Teacher remarks from checklists */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h5 className="text-[11px] font-black uppercase text-slate-400 tracking-wider">
                      Actionable Teacher Notes & Remediation Audits ({extractedNotes.length})
                    </h5>
                    <span className="text-[9px] text-slate-500 font-mono">Feedback logged during inspection tasks</span>
                  </div>

                  {extractedNotes.length === 0 ? (
                    <div className="text-center py-6 border border-dashed border-white/5 bg-white/5 rounded-xl text-xs text-slate-500 italic">
                      No teacher remarks currently recorded in selected filter range. Use 'Kanban board' or 'Matrix' to write remarks on evaluations.
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-xl border border-white/5 max-h-80 overflow-y-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-950 text-[10px] text-slate-400 font-black border-b border-white/10 uppercase tracking-wider">
                            <th className="py-2 px-3 text-center">Student</th>
                            <th className="py-2 px-3">Section / Course task</th>
                            <th className="py-2 px-3 text-center">Evaluation Status</th>
                            <th className="py-2 px-3">Auditor Notes/Remarks</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {extractedNotes.map((note, i) => (
                            <tr key={i} className="hover:bg-white/5">
                              <td className="py-2 px-3 font-extrabold text-slate-200">
                                {note.studentName} <span className="text-[9px] text-slate-500 block font-mono font-normal">Roll: {note.studentRoll}</span>
                              </td>
                              <td className="py-2 px-3">
                                <span className="font-extrabold text-slate-300 text-[11px] block">{note.className}</span>
                                <span className="text-[10px] text-slate-400 font-semibold">{note.taskTitle} ({note.subject})</span>
                              </td>
                              <td className="py-2 px-3 text-center">
                                <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                                  note.status === 'checked' ? 'bg-emerald-500/10 text-emerald-300' :
                                  note.status === 'incomplete' ? 'bg-rose-500/10 text-rose-300' :
                                  note.status === 'missing' ? 'bg-red-500/10 text-red-300' : 'bg-slate-500/10 text-slate-300'
                                }`}>
                                  {note.status}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-slate-300 italic max-w-xs break-words">
                                "{note.notes}"
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Preview Print Portal Banner Info */}
                <div className="no-print pt-4 border-t border-white/5 flex justify-between items-center flex-wrap gap-2 text-[11px] text-slate-400">
                  <span>Standard A4 administrative landscape and portrait scales supported.</span>
                  <button
                    type="button"
                    onClick={() => setShowPrintModal(true)}
                    className="text-xs text-teal-400 hover:text-white font-bold flex items-center gap-1 cursor-pointer"
                  >
                    🔍 Open Formal Print Sheet overlay
                  </button>
                </div>

              </div>
            </div>

            {/* Standard Grade Completion summary of all syllabi */}
            <div className="p-6 rounded-3xl border no-print bg-slate-950/20 border-white/5 space-y-4">
              <div className="space-y-1">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-300">Grade Syllabus Completion Statistics Directory</h4>
                <p className="text-[11px] text-slate-400 font-semibold">Reference completeness ratio compiled for class sections.</p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {reportSyllabusSummary.slice(0, 6).map(clsSummary => (
                  <div key={clsSummary.className} className="p-4 bg-slate-950/40 border border-white/5 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                      <span>{clsSummary.className}</span>
                      <span className="text-teal-400">{clsSummary.rate}% Completeness</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                      <div className="h-full bg-teal-400 rounded-full" style={{ width: `${clsSummary.rate}%` }} />
                    </div>
                    <span className="text-[9px] text-slate-400 block font-semibold">
                      {clsSummary.completed} out of {clsSummary.total} chapters comprehensively checked & signed-off
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* PRINT COMPATIBILITY PORTAL MODAL PREVIEW USING PORTAL */}
            {showPrintModal && createPortal(
              <div className="print-modal-overlay fixed inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-start overflow-y-auto p-4 md:p-8 z-55 animate-fade-in text-left">
                
                {/* Print modal control panel - ONLY visible on screens */}
                <div className="print-modal-buttons w-full max-w-4xl bg-slate-900 border border-white/10 rounded-2xl p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 no-print shadow-xl">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-teal-500/10 text-teal-400 rounded-lg">
                      <Printer className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-extrabold text-white text-sm">Monthly Notebook Evaluation PDF Exporter</h3>
                      <p className="text-[10px] text-slate-400 font-semibold">This form is formatted for A4 portrait printing / standard Save-as-PDF.</p>
                    </div>
                  </div>

                  {printError && (
                    <span className="text-[10px] bg-red-500/10 text-rose-350 px-2 py-1 rounded font-bold">
                      {printError}
                    </span>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          setPrintError(null);
                          window.focus();
                          window.print();
                        } catch (e: any) {
                          console.error("Print blocked in sandbox iframe:", e);
                          setPrintError("Frame blocked native print function. Click the Export button at top instead.");
                        }
                      }}
                      className="bg-teal-500 hover:bg-teal-650 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-teal-500/15 flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Confirm & Save PDF / Print</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setPrintError(null);
                        setShowPrintModal(false);
                      }}
                      className="bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs px-4 py-2.5 rounded-xl cursor-pointer transition-all"
                    >
                      Close Preview
                    </button>
                  </div>
                </div>

                {/* Printable Paper A4 Sheet */}
                <div className="printable-paper-sheet w-[210mm] min-h-[297mm] bg-white text-slate-900 shadow-2xl rounded-sm p-[15mm] flex flex-col justify-start overflow-hidden box-sizing-border-box">
                  
                  {/* Executive Header Box */}
                  <div className="border-b border-slate-800 pb-3 mb-4 flex justify-between items-start gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1">
                        <span className="text-[7.5px] font-black uppercase text-white bg-slate-900 px-2 py-0.5 rounded tracking-widest">
                          OFFICIAL ACADEMIC RECORDOFFICE
                        </span>
                        <span className="text-[7.5px] font-black uppercase text-slate-700 border border-slate-700 px-2 py-0.5 rounded leading-none">
                          CONFIDENTIAL
                        </span>
                      </div>
                      <h1 className="text-sm font-black uppercase text-slate-900 tracking-tight margin-0 leading-tight">
                        Samata International School Academic Faculty
                      </h1>
                      <h2 className="text-[9.5px] font-extrabold text-slate-600 uppercase tracking-wider margin-0">
                        Monthly Notebook Audit Evaluation Registry Summary
                      </h2>
                    </div>
                    <div className="text-right text-[8.5px] text-slate-600 font-mono space-y-0.5 line-height-tight shrink-0">
                      <div>Generated: June 13, 2026</div>
                      <div>Compiled by: {currentUser?.name || 'Academic Administrator'}</div>
                      <div>System ID: #SIS-NTB-{reportMonth.replace(/\s/g, '').toUpperCase()}-{reportClassId.toUpperCase()}</div>
                    </div>
                  </div>

                  {/* General observations header metadata */}
                  <div className="grid grid-cols-4 gap-2 mb-4 bg-slate-100 p-2 rounded-lg border border-slate-200">
                    <div className="px-1 py-0.5 bg-transparent">
                      <span className="text-[8px] uppercase font-bold text-slate-500 block">Report Month</span>
                      <strong className="text-[10px] font-bold text-slate-900">{reportMonth}</strong>
                    </div>
                    <div className="px-1 py-0.5 bg-transparent">
                      <span className="text-[8px] uppercase font-bold text-slate-500 block">Grade Class</span>
                      <strong className="text-[10px] font-bold text-slate-900">
                        {reportClassId === 'all' ? 'All Classes' : classes.find(c => c.id === reportClassId)?.name}
                      </strong>
                    </div>
                    <div className="px-1 py-0.5 bg-transparent">
                      <span className="text-[8px] uppercase font-bold text-slate-500 block">Subject domain</span>
                      <strong className="text-[10px] font-bold text-slate-900">
                        {reportSubject === 'all' ? 'All Subjects' : reportSubject}
                      </strong>
                    </div>
                    <div className="px-1 py-0.5 bg-transparent">
                      <span className="text-[8px] uppercase font-bold text-slate-500 block">Verification audit score</span>
                      <strong className="text-[10px] font-black text-slate-900">{completionPercentage}% Coverage</strong>
                    </div>
                  </div>

                  {/* Highlighting statistics summary inside report */}
                  <div className="space-y-2.5 mb-4">
                    <h3 className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-900 border-b border-slate-300 pb-1">
                      Part A: Notebook Submission coverage Indices
                    </h3>

                    <div className="grid grid-cols-4 gap-2">
                      <div className="p-2 border border-slate-300 rounded text-center">
                        <span className="text-[7.5px] font-bold uppercase text-slate-500 block">Checked & Signed-off</span>
                        <strong className="text-sm font-black text-slate-900 mt-1 block">{checkedCount}</strong>
                        <span className="text-[7px] text-slate-400 font-semibold block">{checkedCount} Verified rows</span>
                      </div>

                      <div className="p-2 border border-slate-300 rounded text-center">
                        <span className="text-[7.5px] font-bold uppercase text-slate-500 block">Incomplete / Revision required</span>
                        <strong className="text-sm font-black text-rose-700 mt-1 block">{incompleteCount}</strong>
                        <span className="text-[7px] text-slate-400 font-semibold block">{incompleteCount} Flagged cases</span>
                      </div>

                      <div className="p-2 border border-slate-300 rounded text-center">
                        <span className="text-[7.5px] font-bold uppercase text-slate-500 block">Absent / Missing</span>
                        <strong className="text-sm font-black text-red-600 mt-1 block">{missingCount}</strong>
                        <span className="text-[7px] text-slate-400 font-semibold block">{missingCount} Unsubmitted</span>
                      </div>

                      <div className="p-2 border border-slate-300 rounded text-center bg-slate-50">
                        <span className="text-[7.5px] font-bold uppercase text-slate-500 block">Evaluators Notebook backlog</span>
                        <strong className="text-sm font-black text-slate-800 mt-1 block">{uncheckedCount}</strong>
                        <span className="text-[7px] text-slate-400 font-semibold block">{uncheckedCount} Pending checks</span>
                      </div>
                    </div>

                    {/* Progress representation graph */}
                    <div className="p-2 border border-slate-300 rounded-lg bg-slate-50 flex items-center justify-between gap-6">
                      <div className="space-y-0.5">
                        <span className="text-[7px] uppercase font-bold text-slate-500">Overall Coverage Ratio</span>
                        <span className="text-[10px] font-black text-slate-900 block">{completionPercentage}% audited successfully</span>
                      </div>
                      <div className="flex-1 max-w-sm h-2 bg-slate-200 border border-slate-300 rounded-full overflow-hidden relative">
                        <div className="absolute left-0 top-0 h-full bg-slate-800 rounded-full" style={{ width: `${completionPercentage}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* General Memo Content */}
                  {managementComment.trim() && (
                    <div className="p-3 border border-slate-300 bg-slate-50 rounded-lg mb-4 space-y-1">
                      <span className="text-[8px] uppercase font-black text-slate-800 block">Part B: Auditor Executive Observations</span>
                      <p className="text-[9px] font-semibold text-slate-850 leading-normal italic">
                        "{managementComment}"
                      </p>
                    </div>
                  )}

                  {/* Notebook checking ledger table */}
                  <div className="space-y-2">
                    <h3 className="text-[9.5px] font-extrabold uppercase tracking-wide text-slate-900 border-b border-slate-300 pb-1">
                      Part C: Detailed Audit ledger & Teacher remarks log
                    </h3>

                    {extractedNotes.length === 0 ? (
                      <div className="text-center py-4 border border-dashed border-slate-300 rounded text-[9.5px] text-slate-500 italic bg-slate-50">
                        No unique teacher remarks or notes compiled in selected scope.
                      </div>
                    ) : (
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-100 uppercase border-b border-slate-400">
                            <th className="py-1.5 px-2 border border-slate-400 text-center" style={{ width: '8%' }}>Roll</th>
                            <th className="py-1.5 px-2 border border-slate-400" style={{ width: '22%' }}>Student Name</th>
                            <th className="py-1.5 px-2 border border-slate-400" style={{ width: '25%' }}>Grade & Topic Task</th>
                            <th className="py-1.5 px-2 border border-slate-400 text-center" style={{ width: '13%' }}>Status</th>
                            <th className="py-1.5 px-2 border border-slate-400" style={{ width: '32%' }}>Auditor Inspection Note</th>
                          </tr>
                        </thead>
                        <tbody>
                          {extractedNotes.slice(0, 20).map((note, i) => (
                            <tr key={i} className="border-b border-slate-300">
                              <td className="py-1.5 px-2 border border-slate-300 text-center font-mono font-bold text-slate-850">{note.studentRoll}</td>
                              <td className="py-1.5 px-2 border border-slate-300 font-extrabold text-slate-950">{note.studentName}</td>
                              <td className="py-1.5 px-2 border border-slate-300 text-slate-800 text-[8px] leading-tight">
                                <strong>{note.className}</strong>
                                <span className="block text-slate-500 font-medium">{note.taskTitle} ({note.subject})</span>
                              </td>
                              <td className="py-1.5 px-2 border border-slate-300 text-center uppercase font-black text-[7.5px]">
                                <span className={
                                  note.status === 'checked' ? 'text-emerald-700 font-bold' :
                                  note.status === 'incomplete' ? 'text-rose-700 font-bold' :
                                  note.status === 'missing' ? 'text-red-700 font-bold' : 'text-slate-650'
                                }>
                                  {note.status}
                                </span>
                              </td>
                              <td className="py-1.5 px-2 border border-slate-300 text-slate-800 font-semibold italic text-[8px] leading-tight max-w-xs break-words">
                                "{note.notes}"
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                    {extractedNotes.length > 20 && (
                      <div className="text-[7.5px] text-slate-500 text-right pr-2 italic">
                        * Note: showing first 20 records on this index log page for brief management reference.
                      </div>
                    )}
                  </div>

                  {/* Sign-Off block placed securely at bottom of page via auto-margin flow */}
                  <div className="grid grid-cols-3 gap-6 pt-5 mt-auto border-t border-slate-400 text-center">
                    <div className="space-y-8 bg-transparent">
                      <div className="h-6 bg-transparent" />
                      <div className="border-t border-slate-400 pt-1 text-[8px] font-bold text-slate-600 uppercase">
                        Auditor Signature ({currentUser?.name || 'Academic Teacher'})
                      </div>
                    </div>
                    <div className="space-y-8 bg-transparent">
                      <div className="h-6 bg-transparent" />
                      <div className="border-t border-slate-400 pt-1 text-[8px] font-bold text-slate-600 uppercase">
                        Principal Verification Checked By
                      </div>
                    </div>
                    <div className="space-y-8 bg-transparent">
                      <div className="h-6 bg-transparent" />
                      <div className="border-t border-slate-400 pt-1 text-[8px] font-bold text-slate-600 uppercase">
                        School management Stamp
                      </div>
                    </div>
                  </div>

                </div>

              </div>,
              document.body
            )}

          </div>
        )}

      </div>

    </div>
  );
}
