import React, { useState, useEffect } from 'react';
import { 
  SchoolClass, 
  MonthlyTask, 
  CheckingRecord, 
  AcademicTest, 
  StudentTestMark, 
  UserSession 
} from '../types';
import { TeacherAllotment } from '../data/teacherData';
import { 
  Calendar, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  UserCheck, 
  Sliders, 
  Compass, 
  BookOpen, 
  Bell, 
  Users, 
  AlertCircle 
} from 'lucide-react';

interface AcademicAuditCalendarProps {
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  academicTests: AcademicTest[];
  testMarks: StudentTestMark[];
  allotments: TeacherAllotment[];
  currentUser: UserSession | null;
}

export default function AcademicAuditCalendar({
  classes,
  tasks,
  records,
  academicTests,
  testMarks,
  allotments,
  currentUser,
}: AcademicAuditCalendarProps) {
  // Calendar standard list of months
  const monthsList = ['April 2026', 'June 2026', 'July 2026', 'August 2026'];
  const [selectedMonth, setSelectedMonth] = useState<string>('June 2026');
  // Interactive Day simulation so users can test how phase alerts behave for any simulated date of the month!
  // Simulated Day initial value change in localStorage
  const [simulatedDay, setSimulatedDay] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  const [selectedDate, setSelectedDate] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  // Track storage change to sync simulation with other views/tabs
  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('nb_audit_simulated_day');
      if (saved) {
        const val = parseInt(saved);
        if (val !== simulatedDay) {
          setSimulatedDay(val);
          setSelectedDate(val);
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [simulatedDay]);

  const handleSimulatedDayChange = (day: number) => {
    setSimulatedDay(day);
    setSelectedDate(day);
    localStorage.setItem('nb_audit_simulated_day', day.toString());
    window.dispatchEvent(new Event('storage'));
  };
  
  // View mode filters: allows teachers to toggle seeing only their things or the entire school list
  const isTeacherRole = currentUser?.role === 'teacher';
  const [filterToMyAllotments, setFilterToMyAllotments] = useState<boolean>(isTeacherRole);

  const [notifications, setNotifications] = useState<{ id: string; text: string; date: string; type: 'success' | 'alert' | 'info' }[]>(() => {
    const saved = localStorage.getItem('nb_faculty_notifs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [
      { id: 't1', text: 'Syllabus planner reminder: Please record June lesson plans before the upcoming 25th deadline.', date: '2026-06-10', type: 'info' },
      { id: 't2', text: 'Grade VIII English scoring window scheduled to open from 25th to 28th June.', date: '2026-06-11', type: 'success' },
    ];
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync notifs to local storage
  useEffect(() => {
    localStorage.setItem('nb_faculty_notifs', JSON.stringify(notifications));
  }, [notifications]);

  // Determine classes and subjects taught by current logged-in teacher
  const getTeacherAllotments = () => {
    if (!currentUser || currentUser.role !== 'teacher') return [];
    
    const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
      if (!allotTeacher || !userTeacher) return false;
      const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
      const cleanAllot = cleanStr(allotTeacher);
      const cleanUser = cleanStr(userTeacher);
      if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
      
      const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
      const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      
      for (const allotW of allotWords) {
        for (const userW of userWords) {
          if (allotW.includes(userW) || userW.includes(allotW)) return true;
        }
      }
      return false;
    };

    return allotments.filter(item => {
      const isCT = isTeacherNameMatched(item.classTeacher, currentUser.name);
      const isSub = Object.values(item.subjects).some(subTeacher => 
        isTeacherNameMatched(subTeacher, currentUser.name)
      );
      return isCT || isSub;
    });
  };

  const myTaughtInfo = getTeacherAllotments();

  // Check if a task or test belongs to the logged-in teacher
  const isOwnedByTeacher = (classId: string, subject: string) => {
    if (!currentUser || currentUser.role !== 'teacher') return true;
    
    // Find class name
    const schoolClass = classes.find(c => c.id === classId);
    if (!schoolClass) return false;
    
    const className = schoolClass.name.replace('Grade ', '').trim();
    const allotment = allotments.find(a => a.grade.toLowerCase() === className.toLowerCase());
    if (!allotment) return false;

    const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
      if (!allotTeacher || !userTeacher) return false;
      const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
      const cleanAllot = cleanStr(allotTeacher);
      const cleanUser = cleanStr(userTeacher);
      if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
      
      const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
      const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      
      for (const allotW of allotWords) {
        for (const userW of userWords) {
          if (allotW.includes(userW) || userW.includes(allotW)) return true;
        }
      }
      return false;
    };

    const subTeacher = allotment.subjects[subject];
    const teachesSubject = isTeacherNameMatched(subTeacher, currentUser.name);
    const isClassTeacherOfGrade = isTeacherNameMatched(allotment.classTeacher, currentUser.name);
    
    return teachesSubject || isClassTeacherOfGrade;
  };

  // Helper calculating month length and start day in grid layout
  const getMonthConfig = (monthYearStr: string) => {
    const parts = monthYearStr.split(' ');
    const monthName = parts[0];
    const monthsMap: { [key: string]: { days: number; startDay: number; monthNum: string } } = {
      'April': { days: 30, startDay: 3, monthNum: '04' }, // Wed
      'June': { days: 30, startDay: 1, monthNum: '06' },  // Mon
      'July': { days: 31, startDay: 3, monthNum: '07' },  // Wed
      'August': { days: 31, startDay: 6, monthNum: '08' }, // Sat
    };
    return monthsMap[monthName] || { days: 30, startDay: 1, monthNum: '06' };
  };

  // Helper to match class name to allotment grade
  const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
    if (!className || !allotmentGrade) return false;
    const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
    const c1 = clean(className);
    const c2 = clean(allotmentGrade);
    return c1 === c2;
  };

  // Get active teacher name for a grade and subject
  const getAssignedTeacher = (className: string, subject: string) => {
    const allotment = allotments.find(a => isClassMatchAllotment(className, a.grade));
    if (!allotment) return 'Staff Teacher';
    return allotment.subjects[subject] || allotment.classTeacher || 'Staff Teacher';
  };

  // Enhanced notebooks tasks mapped with stats
  const getEnrichedTasks = () => {
    return tasks.map(task => {
      const sciClass = classes.find(c => c.id === task.classId);
      const className = sciClass ? sciClass.name : 'Unknown';
      const countStudents = sciClass ? sciClass.students.length : 0;
      const teacherName = getAssignedTeacher(className, task.subject);
      
      const taskRecs = records.filter(r => r.taskId === task.id);
      const checked = taskRecs.filter(r => r.status === 'checked').length;
      const pending = countStudents - checked;
      
      const completionRate = countStudents > 0 ? Math.round((checked / countStudents) * 100) : 0;
      
      return {
        ...task,
        className,
        studentCount: countStudents,
        checkedCount: checked,
        pendingCount: pending,
        completionRate,
        teacherName,
        isMine: isOwnedByTeacher(task.classId, task.subject)
      };
    }).filter(t => !filterToMyAllotments || t.isMine);
  };

  // Enhanced academic tests mapped with stats
  const getEnrichedTests = () => {
    return academicTests.map(test => {
      const sciClass = classes.find(c => c.id === test.classId);
      const className = sciClass ? sciClass.name : 'Unknown';
      const countStudents = sciClass ? sciClass.students.length : 0;
      const teacherName = getAssignedTeacher(className, test.subject);
      
      const subMarks = testMarks.filter(m => m.testId === test.id);
      const entered = subMarks.filter(m => m.marksObtained !== '' || m.isAbsent).length;
      const completionRate = countStudents > 0 ? Math.round((entered / countStudents) * 100) : 0;

      return {
        ...test,
        className,
        studentCount: countStudents,
        enteredCount: entered,
        completionRate,
        teacherName,
        isMine: isOwnedByTeacher(test.classId, test.subject)
      };
    }).filter(t => !filterToMyAllotments || t.isMine);
  };

  // State phases calculations
  const isSyllabusPhase = simulatedDay <= 25;
  const isDataEntryPhase = simulatedDay >= 25 && simulatedDay <= 28;
  const isManagementReviewPhase = simulatedDay >= 29 && simulatedDay <= 30;

  // Render variables according to simulated day
  const getPhaseProperties = () => {
    if (simulatedDay === 25) {
      return {
        title: "Syllabus Plan Lock-In Deadline",
        badge: "LOCK BOUNDS TODAY",
        bg: "from-rose-950/45 to-slate-900 border-rose-500/40",
        accent: "text-rose-400",
        message: "🚨 TODAY the monthly chapters check-in window closes. All outstanding syllabus lesson logs must be completed immediately for auditing review."
      };
    } else if (isDataEntryPhase) {
      return {
        title: "Test Marks & Notebook Correction Updates",
        badge: "DATA ENTRY ACTIVE",
        bg: "from-amber-950/45 to-slate-900 border-amber-500/40",
        accent: "text-amber-400",
        message: "⚡ High intensity entry window! Update unit scorecard matrices and catalog notebook verification indexes between the 25th & 28th numbers."
      };
    } else if (isManagementReviewPhase) {
      return {
        title: "Management Verification Audit Process",
        badge: "STAMP SIGN-OFFS",
        bg: "from-emerald-950/45 to-slate-900 border-emerald-500/40",
        accent: "text-emerald-400",
        message: "🔍 Academic Principal & Governing VP endorsement loop. Stash sheets of classrooms are locked; discrepancy notices are dispatched to delinquent teachers."
      };
    } else {
      return {
        title: "Syllabus Delivery & Lesson Prep Phase",
        badge: "PREPARATION PERIOD",
        bg: "from-indigo-950/45 to-slate-900 border-indigo-500/30",
        accent: "text-indigo-400",
        message: "📅 Standard teaching & worksheet delivery window. Add tests and log student workbook submissions ahead of the monthly locking bounds."
      };
    }
  };

  const activePhase = getPhaseProperties();

  // Create notifications or simulated alarms based on simulated state
  const handleTriggerAdHocNudge = (subject: string, className: string, tName: string, type: 'syllabus' | 'marks') => {
    let text = "";
    if (type === 'syllabus') {
      text = `⚠️ Deadline Nudge: ${tName} has a syllabus planning deadline on the 25th of the month for ${className} - ${subject}.`;
    } else {
      text = `⚡ Entry Nudge: ${tName} must input Grade ${className} - ${subject} test marks and notebook logs before the 28th.`;
    }
    
    setNotifications(prev => [
      { id: Date.now().toString(), text, date: `2026-06-${simulatedDay.toString().padStart(2, '0')}`, type: 'alert' },
      ...prev
    ]);
    
    setToastMessage(`Dispatched official reminder dispatch alert to ${tName}!`);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* HEADER HERO AREA */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-950 border border-white/10 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-br from-indigo-500/10 to-transparent blur-3xl rounded-full" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10 text-left">
          <div className="space-y-1.5">
            <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/25 rounded-md text-[10px] font-black tracking-widest uppercase">
              Samata Administrative Protocol
            </span>
            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <Calendar className="w-6 h-6 text-indigo-400 animate-pulse" />
              <span>Academic Audit Calendar & Deadline Center</span>
            </h2>
            <p className="text-slate-400 text-xs max-w-2xl leading-relaxed">
              Every month, the school governs rigorous milestone locks. Below, faculty and management can coordinate syllabus checkpoints, data uploads, and quality audits according to the calendar structure.
            </p>
          </div>

          {/* Simulated user feedback */}
          <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl flex flex-col items-center shrink-0 min-w-44 text-center">
            <span className="text-[9.5px] text-slate-500 font-extrabold block">ACTIVE USER ACCOUNT</span>
            <span className="text-xs font-black text-white block mt-1">{currentUser?.name}</span>
            <span className="text-[10px] text-indigo-400 font-black uppercase mt-0.5 tracking-wider">
              {currentUser?.role === 'admin' ? 'SYSTEM ADMIN' : currentUser?.role === 'management' ? 'VERIFYING PRINCIPAL' : 'SCHOOL FACULTY'}
            </span>
          </div>
        </div>
      </div>

      {/* THREE PHASES CHRONOLOGICAL ROADMAP (STRICT RULES HIGHLIGHT - SHOWN EVERY DAY!) */}
      <div className="bg-slate-950/50 border border-white/5 rounded-3xl p-6 text-left">
        <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-5">
          <div>
            <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Official School-Wide Operational Checking Cycle</span>
            </h3>
            <p className="text-[11px] text-slate-450 mt-1">These standard checkpoints govern our monthly quality assessments. Highlighted daily for maximum conformity.</p>
          </div>
          
          <div className="px-3 py-1 bg-amber-500/10 text-amber-450 border border-amber-500/25 rounded-full text-[9px] font-extrabold animate-pulse">
            POLICY STANDARD
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Phase 1 card */}
          <div className={`p-4 rounded-2xl border transition-all ${
            simulatedDay <= 25 
              ? 'bg-indigo-500/10 border-indigo-500/40 shadow-xl shadow-indigo-550/5' 
              : 'bg-white/2 border-white/5 opacity-70'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-6 w-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-black text-xs">
                1
              </span>
              <h4 className="text-xs font-black text-white">Syllabus Completion Plan</h4>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
              Due <strong className="text-indigo-300 text-xs">on or before the 25th</strong> of every active month. Teachers must finish chapters and log teaching progress in their records.
            </p>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[9.5px] font-bold text-indigo-400 uppercase">First Phase Timeline</span>
              {simulatedDay <= 25 && <span className="h-2 w-2 rounded-full bg-indigo-400 animate-ping" />}
            </div>
          </div>

          {/* Phase 2 card */}
          <div className={`p-4 rounded-2xl border transition-all ${
            isDataEntryPhase 
              ? 'bg-amber-500/10 border-amber-500/40 shadow-xl shadow-amber-550/5' 
              : 'bg-white/2 border-white/5 opacity-70'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-6 w-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs">
                2
              </span>
              <h4 className="text-xs font-black text-white">Scorebook & Notebook Entry</h4>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
              Active window: <strong className="text-amber-300 text-xs">25th to 28th every month</strong>. Complete record entry including all workbook correction logs and exam scores sheets.
            </p>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[9.5px] font-bold text-amber-400 uppercase">Interactive Window Open</span>
              {isDataEntryPhase && <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />}
            </div>
          </div>

          {/* Phase 3 card */}
          <div className={`p-4 rounded-2xl border transition-all ${
            isManagementReviewPhase 
              ? 'bg-emerald-500/10 border-emerald-500/40 shadow-xl shadow-emerald-555/5' 
              : 'bg-white/2 border-white/5 opacity-70'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-6 w-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-xs">
                3
              </span>
              <h4 className="text-xs font-black text-white">Management verification</h4>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
              Period: <strong className="text-emerald-300 text-xs">29th to 30th of every month</strong>. Board review and Principals seal verification endorsement locks down classroom compliance.
            </p>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[9.5px] font-bold text-emerald-400 uppercase">Audit Assessment Review</span>
              {isManagementReviewPhase && <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />}
            </div>
          </div>

        </div>

        {/* CONTROLLER SECTION: SIMULATE THE CALENDAR PROGRESS */}
        <div className="mt-6 p-4 bg-slate-950/80 rounded-2xl border-2 border-dashed border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <span className="text-xs font-black text-indigo-400 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
              <span>Simulated Date of the Month Control Panel Slider</span>
            </span>
            <p className="text-[10.5px] text-slate-400">
              Drag the controller to change the school calendar date. Check how warnings, alerts, and locks update live!
            </p>
          </div>

          <div className="flex flex-1 flex-col items-end gap-3 max-w-md w-full">
            <div className="flex items-center gap-4 w-full">
              <span className="text-[11px] font-bold text-slate-400">Day 1</span>
              <input 
                type="range" 
                min="1" 
                max="30" 
                value={simulatedDay}
                onChange={(e) => {
                  const val = parseInt(e.target.value);
                  handleSimulatedDayChange(val);
                }}
                className="flex-1 accent-indigo-505 bg-slate-900 rounded-lg appearance-none h-2 cursor-pointer border border-white/10" 
              />
              <span className="text-[11px] font-bold text-slate-400 font-mono">Day 30</span>
              <div className="bg-indigo-500 text-slate-950 py-1.5 px-3 rounded-xl text-xs font-black shrink-0 shadow-lg shadow-indigo-500/20">
                {selectedMonth.split(' ')[0]} {simulatedDay}, {selectedMonth.split(' ')[1]}
              </div>
            </div>
            
            <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 justify-end w-full">
              <span className="text-slate-500 uppercase">Real Today:</span>
              <span className="text-emerald-400 font-mono">
                {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </span>
              <button 
                onClick={() => handleSimulatedDayChange(new Date().getDate())}
                className="bg-white/5 hover:bg-white/10 border border-white/5 text-indigo-300 hover:text-indigo-200 transition-colors uppercase px-2 py-0.5 rounded text-[9px] cursor-pointer animate-pulse"
              >
                📍 Reset to Today
              </button>
            </div>
          </div>
        </div>

        {/* REMINDER ALERTS BANNER FROM CURRENT SIMULATION */}
        <div className={`mt-4 p-4 rounded-2xl border bg-gradient-to-r ${activePhase.bg} text-left transition-all duration-300 animate-fade-in`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <div className="mt-0.5 shrink-0 text-amber-450 text-md">
                🚨
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-black text-white">{activePhase.title}</h4>
                  <span className={`px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[8.5px] font-black ${activePhase.accent}`}>
                    {activePhase.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-200 mt-1 font-semibold leading-relaxed">
                  {activePhase.message}
                </p>
              </div>
            </div>

            {/* Personalized Reminder action */}
            {isTeacherRole ? (
              <div className="shrink-0 self-end sm:self-auto">
                {simulatedDay < 25 ? (
                  <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-xl px-4 py-2 text-center text-xs font-extrabold text-emerald-400">
                    🟢 {25 - simulatedDay} Days left to submit plans!
                  </div>
                ) : simulatedDay <= 28 ? (
                  <button 
                    onClick={() => {
                      setToastMessage("Submitted compliant portfolio registry sheets for checking validation.");
                    }}
                    className="py-1.5 px-4 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-lg text-xs cursor-pointer tracking-wide shadow-md"
                  >
                    🚀 Lock & Sumbit Grades Registry Now
                  </button>
                ) : (
                  <div className="bg-rose-500/10 border border-rose-500/25 rounded-xl px-4 py-2 text-center text-xs font-black text-rose-400">
                    🔒 Classroom Sheet Locked
                  </div>
                )}
              </div>
            ) : (
              <div className="shrink-0 self-end sm:self-auto">
                {simulatedDay < 29 ? (
                  <div className="bg-slate-900 border border-white/10 rounded-xl px-4 py-2 text-xs font-black text-slate-350">
                     Audit Stage begins on the 29th
                  </div>
                ) : (
                  <div className="bg-emerald-550 text-slate-950 py-1.5 px-4 rounded-xl text-xs font-black animate-pulse shadow-md">
                     Verification Clears Active
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

      </div>

      {/* FILTER & CONTROL BAR */}
      {isTeacherRole && (
        <div className="bg-white/5 border border-white/10 p-4 rounded-3xl flex flex-wrap items-center justify-between gap-4 text-left">
          <div className="space-y-0.5">
            <h4 className="text-xs font-black text-white flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Personalized Faculty Space: {currentUser?.name}</span>
            </h4>
            <p className="text-[10.5px] text-slate-400">
              Showing files and checklists assigned to your classrooms: <strong className="text-indigo-300 font-bold">{myTaughtInfo.map(i => i.grade).join(', ') || 'None assigned'}</strong>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterToMyAllotments(true)}
              className={`py-1.5 px-3 rounded-lg text-[10.5px] font-black transition-all cursor-pointer ${
                filterToMyAllotments 
                  ? 'bg-indigo-500 text-white shadow-md' 
                  : 'bg-slate-950/40 text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              Only My Subject Duties
            </button>
            <button
              onClick={() => setFilterToMyAllotments(false)}
              className={`py-1.5 px-3 rounded-lg text-[10.5px] font-black transition-all cursor-pointer ${
                !filterToMyAllotments 
                  ? 'bg-indigo-500 text-white shadow-md' 
                  : 'bg-slate-950/40 text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              Whole School Audit Roll
            </button>
          </div>
        </div>
      )}

      {/* TWO COLUMNS: CALENDAR VIEW & LIST OF EVENTS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: INTERACTIVE GRID (8 COLS) */}
        <div className="lg:col-span-8 bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl space-y-6">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div className="text-left">
              <h3 className="text-md font-extrabold text-white flex items-center gap-1.5 font-sans">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <span>Academic Audit Calendar Planner</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Pick a milestone day to audit outstanding portfolios</p>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-950/60 p-1.5 rounded-2xl border border-white/5 self-end sm:self-auto">
              {monthsList.map(m => (
                <button
                  key={m}
                  onClick={() => {
                    setSelectedMonth(m);
                    setSelectedDate(1);
                  }}
                  className={`py-1.5 px-3 rounded-xl text-[10.5px] font-black transition-all cursor-pointer uppercase ${
                    selectedMonth === m
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'text-slate-350 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {m.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Render Month Grid Details */}
          {(() => {
            const config = getMonthConfig(selectedMonth);
            const cells: (number | null)[] = [];
            for (let i = 0; i < config.startDay; i++) {
              cells.push(null);
            }
            for (let d = 1; d <= config.days; d++) {
              cells.push(d);
            }

            return (
              <div className="space-y-4">
                
                {/* Day of week labels */}
                <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-black text-slate-450 uppercase tracking-widest bg-slate-950/40 p-2.5 rounded-xl border border-white/5">
                  <div>Sun</div>
                  <div>Mon</div>
                  <div>Tue</div>
                  <div>Wed</div>
                  <div>Thu</div>
                  <div>Fri</div>
                  <div>Sat</div>
                </div>

                {/* Day cells */}
                <div className="grid grid-cols-7 gap-2">
                  {cells.map((dayNum, idx) => {
                    if (dayNum === null) {
                      return (
                        <div key={`empty-${idx}`} className="aspect-square bg-slate-950/20 border border-white/2 rounded-xl opacity-20" />
                      );
                    }

                    // Look up events
                    const searchDate = `2026-${config.monthNum}-${dayNum.toString().padStart(2, '0')}`;
                    const targetTasks = getEnrichedTasks().filter(t => t.dueDate === searchDate);
                    const targetTests = getEnrichedTests().filter(t => t.testDate === searchDate);

                    const totalOnDay = targetTasks.length + targetTests.length;
                    
                    // Determine if any task on this date is past due (outstanding checkings)
                    const containsPastDue = targetTasks.some(t => {
                      const todayStr = `2026-${config.monthNum}-${simulatedDay.toString().padStart(2, '0')}`;
                      return t.dueDate < todayStr && t.completionRate < 100;
                    });

                    const isSimulatedToday = selectedMonth === 'June 2026' && dayNum === simulatedDay;
                    const isSelected = selectedDate === dayNum;

                    return (
                      <button
                        key={`day-${dayNum}`}
                        onClick={() => setSelectedDate(dayNum)}
                        className={`aspect-square p-1.5 rounded-2xl flex flex-col justify-between items-start transition-all relative border outline-none text-left cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-500/20 border-indigo-400 text-white shadow-xl shadow-indigo-500/10'
                            : isSimulatedToday
                              ? 'bg-emerald-500/10 border-emerald-500 text-emerald-200 animate-pulse'
                              : containsPastDue
                                ? 'bg-rose-955/20 border-rose-500/50 hover:border-rose-400 shadow-md'
                                : 'bg-slate-950/40 border-white/5 hover:border-white/20 text-slate-350'
                        }`}
                      >
                        <span className={`text-[10px] font-black px-1 rounded ${
                          isSimulatedToday ? 'bg-emerald-555 text-slate-950 font-black' : 'text-slate-400'
                        }`}>
                          {dayNum}
                        </span>

                        {totalOnDay > 0 && (
                          <div className="flex flex-wrap gap-1 mt-auto w-full">
                            {targetTasks.map((t, ti) => (
                              <span 
                                key={`nt-${ti}`} 
                                className={`h-1.5 w-1.5 rounded-full ${t.completionRate === 100 ? 'bg-emerald-400' : 'bg-pink-500'}`}
                                title={`${t.className}: ${t.title}`}
                              />
                            ))}
                            {targetTests.map((t, ti) => (
                              <span 
                                key={`test-${ti}`} 
                                className={`h-1.5 w-1.5 rounded-full ${t.completionRate === 100 ? 'bg-emerald-400' : 'bg-amber-400'}`}
                                title={`${t.className}: ${t.testName}`}
                              />
                            ))}
                          </div>
                        )}

                        {/* Red warning exclamation badge for items with past deadline but remains pending */}
                        {containsPastDue && (
                          <span className="absolute top-1 right-1 h-3.5 w-3.5 flex items-center justify-center font-black rounded-full bg-rose-500 text-slate-950 text-[8px] leading-none animate-pulse" title="Deadline exceeded! Pending checkings.">
                            !
                          </span>
                        )}

                        {isSimulatedToday && !containsPastDue && (
                          <span className="absolute top-1 right-1 h-1.5 w-1.5 bg-emerald-400 rounded-full" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Legend bar */}
                <div className="bg-slate-950/50 p-3 rounded-xl border border-white/5 flex flex-wrap gap-4 text-[10px] items-center justify-center">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-pink-500" />
                    <span className="text-slate-400 font-semibold">Notebook Due (Unchecked)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                    <span className="text-slate-400 font-semibold">Checks Completed (100%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-amber-400" />
                    <span className="text-slate-400 font-semibold">Test Exam Roster (Pending)</span>
                  </div>
                  <div className="flex items-center gap-1.5 border-l border-white/10 pl-4">
                    <span className="h-3.5 w-3.5 bg-rose-500 text-slate-950 text-[8.5px] font-black flex items-center justify-center rounded-full leading-none">!</span>
                    <span className="text-rose-400 font-bold">Past Due Discrepancy Alerts</span>
                  </div>
                </div>

              </div>
            );
          })()}

        </div>

        {/* RIGHT COLUMN: DETAIL DECK ON SELECTED DATE (4 COLS) */}
        <div className="lg:col-span-4 space-y-6 text-left">
          
          {/* SELECTED DAY EVENTS BOX */}
          {(() => {
            const config = getMonthConfig(selectedMonth);
            const dateStr = `2026-${config.monthNum}-${selectedDate.toString().padStart(2, '0')}`;
            const dayTasks = getEnrichedTasks().filter(t => t.dueDate === dateStr);
            const dayTests = getEnrichedTests().filter(t => t.testDate === dateStr);
            const totalCount = dayTasks.length + dayTests.length;
            
            const monthDayDisplay = new Date(dateStr).toLocaleDateString(undefined, {
              month: 'long',
              day: 'numeric',
              year: 'numeric'
            });

            return (
              <div className="bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-indigo-400 block">Milestone Selection</span>
                    <h3 className="text-sm font-black text-white">{monthDayDisplay}</h3>
                  </div>
                  <span className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[9.5px] text-slate-300 font-black">
                    {totalCount} Task{totalCount !== 1 ? 's' : ''}
                  </span>
                </div>

                <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                  
                  {totalCount === 0 ? (
                    <div className="text-center py-8 text-slate-500">
                      <BookOpen className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                      <p className="text-[11px] italic">No active inspections or evaluations scheduled on this day.</p>
                      <p className="text-[10px] text-slate-600 mt-1">Navigate using the date planner grid on the left.</p>
                    </div>
                  ) : (
                    <>
                      {/* List of Tasks */}
                      {dayTasks.map((t, idx) => {
                        const isTaskPastDue = t.dueDate < `2026-${config.monthNum}-${simulatedDay.toString().padStart(2, '0')}` && t.completionRate < 100;
                        
                        return (
                          <div key={`tsk-${idx}`} className={`p-3 rounded-xl border border-white/5 space-y-2.5 transition-all text-left ${
                            isTaskPastDue 
                              ? 'bg-rose-500/10 border-rose-500/20' 
                              : t.completionRate === 100 
                                ? 'bg-emerald-500/5 border-emerald-500/10' 
                                : 'bg-slate-950/40'
                          }`}>
                            <div className="flex items-start justify-between">
                              <div>
                                <span className="text-xs font-black text-white">{t.className} - {t.subject}</span>
                                <span className="text-[10.5px] text-slate-300 block">{t.title}</span>
                              </div>
                              {isTaskPastDue ? (
                                <span className="px-1.5 py-0.5 bg-rose-500/20 text-rose-455 border border-rose-500/20 rounded text-[8.5px] font-black animate-pulse">
                                  PAST DUE
                                </span>
                              ) : t.completionRate === 100 ? (
                                <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-450 rounded text-[8.5px] font-black">
                                  VERIFIED
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 bg-slate-900 border border-white/5 text-slate-400 rounded text-[8.5px] font-bold">
                                  PENDING
                                </span>
                              )}
                            </div>

                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400">
                                <span>Checked progress:</span>
                                <span className={t.completionRate === 100 ? "text-emerald-400" : isTaskPastDue ? "text-rose-400" : "text-slate-300"}>
                                  {t.completionRate}% Done ({t.checkedCount}/{t.studentCount})
                                </span>
                              </div>
                              <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all duration-300 ${t.completionRate === 100 ? 'bg-emerald-400' : isTaskPastDue ? 'bg-rose-500' : 'bg-indigo-500'}`}
                                  style={{ width: `${t.completionRate}%` }}
                                />
                              </div>
                              <p className="text-[9.5px] text-slate-500 mt-0.5">Assigned Faculty: <strong className="text-slate-350">{t.teacherName}</strong></p>
                            </div>

                            {/* Self reminder or admin nudge button */}
                            <button
                              onClick={() => handleTriggerAdHocNudge(t.subject, t.className, t.teacherName, 'syllabus')}
                              className="w-full py-1 bg-white/5 hover:bg-white/10 text-[9.5px] font-black text-slate-300 rounded hover:text-white transition-all cursor-pointer border border-white/5 uppercase"
                            >
                              Dispatch Compliance Alert
                            </button>
                          </div>
                        );
                      })}

                      {/* List of Academic Tests */}
                      {dayTests.map((test, idx) => {
                        return (
                          <div key={`tst-${idx}`} className={`p-3 rounded-xl border border-white/5 space-y-2.5 transition-all text-left bg-slate-950/40`}>
                            <div className="flex items-start justify-between">
                              <div>
                                <span className="text-xs font-black text-white">{test.className} - {test.subject}</span>
                                <span className="text-[10.5px] text-slate-300 block">{test.testName} (Exam)</span>
                              </div>
                              {test.completionRate === 100 ? (
                                <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-450 rounded text-[8.5px] font-black">
                                  SCORED
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-450 rounded text-[8.5px] font-black">
                                  ROSTER OPEN
                                </span>
                              )}
                            </div>

                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400">
                                <span>Marks uploaded:</span>
                                <span className="text-slate-300">{test.completionRate}% ({test.enteredCount}/{test.studentCount})</span>
                              </div>
                              <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-amber-450 rounded-full transition-all duration-300"
                                  style={{ width: `${test.completionRate}%` }}
                                />
                              </div>
                              <p className="text-[9.5px] text-slate-500 mt-0.5">Assigned Faculty: <strong className="text-slate-350">{test.teacherName}</strong></p>
                            </div>

                            <button
                              onClick={() => handleTriggerAdHocNudge(test.subject, test.className, test.teacherName, 'marks')}
                              className="w-full py-1 bg-white/5 hover:bg-white/10 text-[9.5px] font-black text-slate-350 rounded hover:text-white transition-all cursor-pointer border border-white/5 uppercase"
                            >
                              Nudge Test Scores Sheet
                            </button>
                          </div>
                        );
                      })}
                    </>
                  )}

                </div>
              </div>
            );
          })()}

          {/* FACULTY NOTIFICATION STREAM */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <h4 className="text-xs font-black text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-indigo-400" />
                <span>Audit Activity Transmissions Logs</span>
              </h4>
              <button 
                onClick={() => setNotifications([])}
                className="text-[9px] text-slate-500 hover:text-rose-400 font-bold"
              >
                Clear Stream
              </button>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {notifications.length === 0 ? (
                <p className="text-xs text-slate-500 italic text-center py-4">No logged notices generated yet.</p>
              ) : (
                notifications.map((notif, nIdx) => (
                  <div key={notif.id} className="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 text-[11px] leading-snug">
                    <div className="flex justify-between items-center text-[9px] text-slate-500 mb-1 font-bold">
                      <span>{notif.date}</span>
                      <span className={notif.type === 'alert' ? 'text-rose-400' : 'text-sky-400'}>
                        {notif.type.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-slate-300 font-medium">{notif.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 bg-slate-950 border border-indigo-500/40 px-4 py-3 rounded-2xl shadow-2xl animate-fade-in text-xs font-bold text-white">
          <CheckCircle2 className="w-4 h-4 text-emerald-450 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
