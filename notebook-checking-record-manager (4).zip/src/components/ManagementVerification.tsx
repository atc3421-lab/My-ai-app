import React, { useState, useEffect } from 'react';
import { SchoolClass, MonthlyTask, CheckingRecord, AcademicTest, StudentTestMark, ManagementReview, NotebookStatus } from '../types';
import { TeacherAllotment } from '../data/teacherData';
import { 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  MessageSquare, 
  PenTool, 
  TrendingUp, 
  CheckSquare, 
  Award, 
  BookOpen, 
  Calendar,
  Sparkles,
  User,
  Check,
  AlertCircle,
  Search,
  SlidersHorizontal,
  BarChart3,
  Bell,
  X,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck
} from 'lucide-react';

interface ManagementVerificationProps {
  currentUser: { username: string; name: string; role: string };
  classes: SchoolClass[];
  tasks: MonthlyTask[];
  records: CheckingRecord[];
  allotments: TeacherAllotment[];
  academicTests: AcademicTest[];
  testMarks: StudentTestMark[];
  managementReviews: ManagementReview[];
  onUpdateManagementReviews: (newReviews: ManagementReview[]) => void;
  onUpdateMultipleRecords?: (updates: { studentId: string; taskId: string; status: NotebookStatus; notes: string }[]) => void;
}

export default function ManagementVerification({
  currentUser,
  classes,
  tasks,
  records,
  allotments,
  academicTests,
  testMarks,
  managementReviews,
  onUpdateManagementReviews,
  onUpdateMultipleRecords
}: ManagementVerificationProps) {
  // Available Months list based on tasks or school calendar
  const monthsList = ['April 2026', 'June 2026', 'July 2026', 'August 2026'];
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    return localStorage.getItem('nb_audit_selected_month') || 'June 2026';
  });
  const [activeVerifySubTab, setActiveVerifySubTab] = useState<'profile' | 'calendar'>('profile');

  // Active simulated clock day (defaults to 25 of the month representing active data entry / approach date)
  const [simulatedDay, setSimulatedDay] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  const handleSimulatedDayChange = (day: number) => {
    setSimulatedDay(day);
    localStorage.setItem('nb_audit_simulated_day', day.toString());
    window.dispatchEvent(new Event('storage'));
  };

  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('nb_audit_simulated_day');
      if (saved) {
        const val = parseInt(saved);
        if (val !== simulatedDay) {
          setSimulatedDay(val);
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [simulatedDay]);

  // School-Wide Grade Submission Health visual states
  const [gradeSearchText, setGradeSearchText] = useState<string>('');
  const [healthFilter, setHealthFilter] = useState<'all' | 'achievers' | 'alert'>('all');
  const [expandedGradeId, setExpandedGradeId] = useState<string | null>(null);

  // Load all teachers from allotment source
  const allTeachers = Array.from(new Set(
    allotments.flatMap(allot => {
      const names = [allot.classTeacher];
      if (allot.subjects) {
        Object.values(allot.subjects).forEach(subT => {
          if (subT && typeof subT === 'string') {
            subT.split('&').forEach(tName => names.push(tName.trim()));
          }
        });
      }
      return names;
    })
  )).filter(name => name && name.trim().length > 0 && name !== 'Staff Teacher' && name !== 'Didi').sort();

  const [selectedTeacher, setSelectedTeacher] = useState<string>(() => {
    const saved = localStorage.getItem('nb_audit_selected_teacher');
    if (saved && allTeachers.includes(saved)) return saved;
    return allTeachers[0] || '';
  });

  // Derived reviews state from synchronized prop with teacher name migration
  const reviews = (managementReviews || []).map(r => {
    if (r.teacherName === 'Mr.Uday P.') {
      return {
        ...r,
        id: r.id.replace('Mr.Uday_P.', 'Mr.Uday_P'),
        teacherName: 'Mr.Uday P'
      };
    }
    return r;
  });

  // Calendar specific state parameters
  const [calendarMonth, setCalendarMonth] = useState<string>('July 2026');
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<number>(12);
  const [auditNotifications, setAuditNotifications] = useState<{id: string; text: string; date: string; type: 'alert' | 'success'}[]>(() => {
    const saved = localStorage.getItem('nb_audit_notifications');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [
      { id: '1', text: 'Pre-inspection notice sent to Grade VIII T for Math Homework Notebook corrections review', date: '2026-06-10', type: 'success' },
      { id: '2', text: 'System automatic discrepancy alert sent to Grade VIII T — Hindi teacher (Mr.Somnath)', date: '2026-06-11', type: 'alert' }
    ];
  });
  const [mgmtToast, setMgmtToast] = useState<{ type: 'success' | 'amber' | 'info'; text: string } | null>(null);

  // Auto-dismiss custom calendar toast alert
  useEffect(() => {
    if (mgmtToast) {
      const timer = setTimeout(() => {
        setMgmtToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [mgmtToast]);

  // Sync log feed
  useEffect(() => {
    localStorage.setItem('nb_audit_notifications', JSON.stringify(auditNotifications));
  }, [auditNotifications]);

  // Helper mapping month name to serial number
  const getMonthNumber = (monthName: string) => {
    const map: { [m: string]: string } = {
      'April': '04',
      'June': '06',
      'July': '07',
      'August': '08'
    };
    return map[monthName] || '06';
  };

  // Helper calculating month length and start day in 2026 grid layout
  const getMonthDetails = (monthYearString: string) => {
    const parts = monthYearString.split(' ');
    const monthName = parts[0];
    const monthsMap: { [key: string]: { days: number; startDay: number } } = {
      'April': { days: 30, startDay: 3 }, // Wed
      'June': { days: 30, startDay: 1 },  // Mon
      'July': { days: 31, startDay: 3 },  // Wed
      'August': { days: 31, startDay: 6 }, // Sat
    };
    return monthsMap[monthName] || { days: 30, startDay: 0 };
  };

  // Helper to match class name to allotment grade
  const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
    if (!className || !allotmentGrade) return false;
    const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
    const c1 = clean(className);
    const c2 = clean(allotmentGrade);
    return c1 === c2;
  };

  // Prepares tasks with real-time status and teacher mapping
  const getPreparedTasks = () => {
    return tasks.map(task => {
      const cls = classes.find(c => c.id === task.classId);
      const className = cls ? cls.name : 'Unknown Class';
      const totalStudents = cls ? cls.students.length : 0;
      
      const allotment = allotments.find(a => isClassMatchAllotment(className, a.grade));
      const teacherName = allotment ? (allotment.subjects[task.subject] || allotment.classTeacher) : 'Staff Teacher';
      
      const taskRecords = records.filter(r => r.taskId === task.id);
      const checkedCount = taskRecords.filter(r => r.status === 'checked').length;
      const incompleteCount = taskRecords.filter(r => r.status === 'incomplete').length;
      const missingCount = taskRecords.filter(r => r.status === 'missing').length;
      const uncheckedCount = totalStudents - taskRecords.length;
      
      const complianceRate = totalStudents > 0 ? Math.round((checkedCount / totalStudents) * 100) : 0;
      const isCompleted = complianceRate === 100;
      
      const todayString = '2026-06-12';
      const isPastDue = task.dueDate < todayString && !isCompleted;
      const isUpcoming = task.dueDate >= todayString;
      
      return {
        ...task,
        className,
        totalStudents,
        checkedCount,
        incompleteCount,
        missingCount,
        uncheckedCount,
        complianceRate,
        isCompleted,
        isPastDue,
        isUpcoming,
        teacherName
      };
    });
  };

  // Prepares tests with real-time score status and teacher mapping
  const getPreparedTests = () => {
    return academicTests.map(test => {
      const cls = classes.find(c => c.id === test.classId);
      const className = cls ? cls.name : 'Unknown Class';
      const totalStudents = cls ? cls.students.length : 0;
      
      const allotment = allotments.find(a => isClassMatchAllotment(className, a.grade));
      const teacherName = allotment ? (allotment.subjects[test.subject] || allotment.classTeacher) : 'Staff Teacher';
      
      let enteredCount = 0;
      let absentCount = 0;
      cls?.students.forEach(std => {
        const mark = testMarks.find(m => m.testId === test.id && m.studentId === std.id);
        if (mark) {
          if (mark.marksObtained !== '' || mark.isAbsent) {
            enteredCount++;
          }
          if (mark.isAbsent) {
            absentCount++;
          }
        }
      });
      
      const uploadRate = totalStudents > 0 ? Math.round((enteredCount / totalStudents) * 100) : 0;
      const isUploaded = uploadRate === 100;
      
      const todayString = '2026-06-12';
      const isPastDue = test.testDate < todayString && !isUploaded;
      const isUpcoming = test.testDate >= todayString;
      
      return {
        ...test,
        className,
        totalStudents,
        enteredCount,
        absentCount,
        uploadRate,
        isUploaded,
        isPastDue,
        isUpcoming,
        teacherName
      };
    });
  };

  // Selected review item or construct default
  const activeReviewKey = `${selectedTeacher}_${selectedMonth}`.replace(/\s+/g, '_');
  const activeReview = reviews.find(r => r.id === activeReviewKey) || {
    id: activeReviewKey,
    teacherName: selectedTeacher,
    month: selectedMonth,
    isVerified: false,
    verifiedBy: currentUser.name,
    generalComment: '',
    notebookStatusComment: '',
    syllabusStatusComment: '',
    testRecordComment: ''
  };

  // Preset professional comments for quick fill
  const prefilledGeneralComments = [
    "Syllabus on track, notebook corrections are detailed and neat.",
    "Excellent curriculum coverage. Continuous evaluations appear rigorous.",
    "Notebook corrections complete for all key chapters. Student portfolios neat.",
    "Highly compliant with monthly milestones. Performance graphs verify steady tracking."
  ];

  const prefilledNotebookComments = [
    "Detailed indexes checked. Signature marks correctly logged for all students.",
    "Checked. Notebook compliance stands above 90% across general categories.",
    "Spot checks executed on notebook reviews. Handwriting corrections are thorough.",
    "Detailed corrections completed. Reminders sent for incomplete notebooks."
  ];

  const prefilledSyllabusComments = [
    "All monthly planned topics successfully completed and double-verified.",
    "Syllabus aligned with board blueprints. On schedule with zero deviations.",
    "Chapters completed correspond perfectly with timetables.",
    "April and June targets are 100% updated on planning board."
  ];

  const prefilledTestComments = [
    "Test records evaluated and fully cataloged into the central scorebook.",
    "Robust evaluation rates. Class-wise score distribution graphs are balanced.",
    "Chapter diagnostic test marks fully updated. High quality check.",
    "Scores and absentee registers logged accurately for final reports."
  ];

  // Handler to update specific comments
  const handleUpdateReviewComment = (field: keyof ManagementReview, value: string) => {
    const idx = reviews.findIndex(r => r.id === activeReviewKey);
    let updatedReviews: ManagementReview[];
    if (idx > -1) {
      const updated = [...reviews];
      updated[idx] = { ...updated[idx], [field]: value };
      updatedReviews = updated;
    } else {
      const newReview: ManagementReview = {
        id: activeReviewKey,
        teacherName: selectedTeacher,
        month: selectedMonth,
        isVerified: false,
        verifiedBy: currentUser.name,
        generalComment: '',
        notebookStatusComment: '',
        syllabusStatusComment: '',
        testRecordComment: '',
        [field]: value
      };
      updatedReviews = [...reviews, newReview];
    }
    onUpdateManagementReviews(updatedReviews);
  };

  // Quick-mark all notebooks as complete/checked for the selected teacher and selected month
  const handleBulkCompleteNotebooksForTeacher = () => {
    if (!onUpdateMultipleRecords) return;
    
    // courseList contains all classes & subjects taught by the selected teacher
    const updates: { studentId: string; taskId: string; status: NotebookStatus; notes: string }[] = [];
    
    courseList.forEach(course => {
      // Find all tasks during the selectedMonth
      const monthTasks = tasks.filter(t => 
        t.classId === course.classId && 
        t.subject === course.subject && 
        t.month === selectedMonth
      );
      
      const classObj = classes.find(c => c.id === course.classId);
      const students = classObj ? classObj.students : [];
      
      monthTasks.forEach(task => {
        students.forEach(std => {
          updates.push({
            studentId: std.id,
            taskId: task.id,
            status: 'checked' as NotebookStatus,
            notes: 'Verified & Certified by Management Audit'
          });
        });
      });
    });

    if (updates.length === 0) {
      alert(`No syllabus milestones or classes found for ${selectedTeacher} in ${selectedMonth} to check off.`);
      return;
    }

    if (confirm(`Bulk Action: Automatically certify & mark ALL ${updates.length} student notebooks as 'Checked' for Ms./Mr. ${selectedTeacher} during ${selectedMonth}? This will instantly resolve all pending alerts.`)) {
      onUpdateMultipleRecords(updates);
    }
  };

  // Quick-mark ALL teachers' notebooks as complete/checked schoolwide
  const handleBulkCompleteAllTeachersNotebooks = () => {
    if (!onUpdateMultipleRecords) return;
    
    const updates: { studentId: string; taskId: string; status: NotebookStatus; notes: string }[] = [];
    
    // Run through ALL task/class/student combinations across ALL months!
    tasks.forEach(task => {
      const classObj = classes.find(c => c.id === task.classId);
      if (classObj) {
        classObj.students.forEach(std => {
          // Check if it's already checked to preserve work, otherwise mark checked
          const existing = records.find(r => r.studentId === std.id && r.taskId === task.id);
          if (!existing || existing.status !== 'checked') {
            updates.push({
              studentId: std.id,
              taskId: task.id,
              status: 'checked' as NotebookStatus,
              notes: 'Bulk verified pre-seeded'
            });
          }
        });
      }
    });

    if (updates.length === 0) {
      alert("All notebook records are already 100% complete!");
      return;
    }

    if (confirm(`School-Wide Bulk Action: Mark all pending student notebooks as 'Checked' across ALL ${allTeachers.length} teachers, grades, and subjects to clear all pending warning boxes? (Updates: ${updates.length} rows)`)) {
      onUpdateMultipleRecords(updates);
    }
  };

  // Toggle Verification Action
  const handleToggleVerification = () => {
    const idx = reviews.findIndex(r => r.id === activeReviewKey);
    const timestamp = new Date().toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });
    let updatedReviews: ManagementReview[];
    if (idx > -1) {
      const updated = [...reviews];
      const currentStatus = updated[idx].isVerified;
      updated[idx] = { 
        ...updated[idx], 
        isVerified: !currentStatus,
        verifiedBy: currentUser.name,
        verifiedAt: !currentStatus ? timestamp : undefined
      };
      updatedReviews = updated;
    } else {
      const newReview: ManagementReview = {
        id: activeReviewKey,
        teacherName: selectedTeacher,
        month: selectedMonth,
        isVerified: true,
        verifiedBy: currentUser.name,
        verifiedAt: timestamp,
        generalComment: '',
        notebookStatusComment: '',
        syllabusStatusComment: '',
        testRecordComment: ''
      };
      updatedReviews = [...reviews, newReview];
    }
    onUpdateManagementReviews(updatedReviews);
  };

  // RECONCILE REAL-TIME INTEL FOR SELECTED TEACHER & MONTH
  // Locate class/subjects taught by the selected teacher
  const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
    if (!allotTeacher || !userTeacher) return false;
    const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const cleanAllot = cleanStr(allotTeacher);
    const cleanUser = cleanStr(userTeacher);
    if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
    
    const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
    const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
    
    for (const allotW of allotWords) {
      for (const userW of userWords) {
        if (allotW.includes(userW) || userW.includes(allotW)) return true;
      }
    }
    return false;
  };

  const teacherCourses = allotments.filter(allot => {
    return isTeacherNameMatched(allot.classTeacher, selectedTeacher) || 
      (allot.subjects && Object.values(allot.subjects).some(name => isTeacherNameMatched(name, selectedTeacher)));
  });

  const courseList = teacherCourses.flatMap(allot => {
    const classObj = classes.find(c => isClassMatchAllotment(c.name, allot.grade));
    if (!classObj) return [];
    
    // Find subjects taught by this teacher in this class
    const taughtSubjects: string[] = [];
    if (allot.subjects) {
      Object.entries(allot.subjects).forEach(([sub, name]) => {
        if (isTeacherNameMatched(name, selectedTeacher)) {
          taughtSubjects.push(sub);
        }
      });
    }
    
    return taughtSubjects.map(sub => ({
      classId: classObj.id,
      className: classObj.name,
      teacherName: selectedTeacher,
      subject: sub
    }));
  });

  // Calculate stats for each course
  let totalSyllabusMilestones = 0;
  let completedSyllabusMilestones = 0;
  let totalNotebookCells = 0;
  let checkedNotebookCells = 0;
  let totalTestStudents = 0;
  let evaluatedTestEntries = 0;

  const courseBreakdowns = courseList.map(course => {
    // 1. Monthly tasks (Planned chapters)
    const monthTasks = tasks.filter(t => 
      t.classId === course.classId && 
      t.subject === course.subject && 
      t.month === selectedMonth
    );
    
    const countPlanned = monthTasks.length;
    // We assume any planned chapter is complete if average notebook checks are above 80% or if there are check records
    totalSyllabusMilestones += countPlanned;

    // Calculate notebook compliance
    const classObj = classes.find(c => c.id === course.classId);
    const students = classObj ? classObj.students : [];
    const possibleChecks = countPlanned * students.length;
    
    let checkedCount = 0;
    monthTasks.forEach(task => {
      students.forEach(std => {
        const record = records.find(r => r.studentId === std.id && r.taskId === task.id);
        if (record && record.status === 'checked') {
          checkedCount++;
        }
      });
    });

    totalNotebookCells += possibleChecks;
    checkedNotebookCells += checkedCount;

    // Syllabus chapters are marked completed based on whether their notebooks are mostly checked
    const chapterCompletedCount = monthTasks.filter(task => {
      const taskRecords = records.filter(r => r.taskId === task.id);
      const checkedForThisTask = taskRecords.filter(r => r.status === 'checked').length;
      return students.length > 0 && checkedForThisTask >= students.length * 0.7; // 70% threshold
    }).length;

    completedSyllabusMilestones += chapterCompletedCount;

    // 2. Tests and evaluations
    const courseTests = academicTests.filter(test => 
      test.classId === course.classId && 
      test.subject === course.subject && 
      test.month === selectedMonth
    );

    let testEntriesCount = 0;
    let scoresUploaded = 0;

    courseTests.forEach(test => {
      students.forEach(std => {
        testEntriesCount++;
        const mark = testMarks.find(m => m.testId === test.id && m.studentId === std.id);
        if (mark && (mark.marksObtained !== '' || mark.isAbsent)) {
          scoresUploaded++;
        }
      });
    });

    totalTestStudents += testEntriesCount;
    evaluatedTestEntries += scoresUploaded;

    const checkingPerf = possibleChecks > 0 ? Math.round((checkedCount / possibleChecks) * 100) : 0;
    const testPerf = testEntriesCount > 0 ? Math.round((scoresUploaded / testEntriesCount) * 100) : 0;
    const syllabusPerf = countPlanned > 0 ? Math.round((chapterCompletedCount / countPlanned) * 100) : 0;

    return {
      ...course,
      plannedChapters: monthTasks.map(t => t.title),
      notebookChecked: checkedCount,
      notebookTotal: possibleChecks,
      notebookRate: checkingPerf,
      testCount: courseTests.length,
      testEvaluated: scoresUploaded,
      testTotal: testEntriesCount,
      testRate: testPerf,
      syllabusRate: syllabusPerf,
      chaptersCount: countPlanned,
      chaptersCompleted: chapterCompletedCount
    };
  });

  // Consolidated Rates with Safe Fallbacks if data is zero (seeding 0 to represent lack of student activity)
  const notebookRate = totalNotebookCells > 0 ? Math.round((checkedNotebookCells / totalNotebookCells) * 100) : 0; 
  const syllabusRate = totalSyllabusMilestones > 0 ? Math.round((completedSyllabusMilestones / totalSyllabusMilestones) * 100) : 0;
  const evaluationRate = totalTestStudents > 0 ? Math.round((evaluatedTestEntries / totalTestStudents) * 100) : 0;

  const activeMetrics: number[] = [];
  if (totalNotebookCells > 0) activeMetrics.push(notebookRate);
  if (totalSyllabusMilestones > 0) activeMetrics.push(syllabusRate);
  if (totalTestStudents > 0) activeMetrics.push(evaluationRate);

  const averageCompliance = activeMetrics.length > 0
    ? Math.round(activeMetrics.reduce((sum, val) => sum + val, 0) / activeMetrics.length)
    : 100;

  // Logical checks to flag unconducted responsibilities for principal/vp
  const isNotebookPending = totalNotebookCells === 0 || checkedNotebookCells === 0;
  const isSyllabusPending = totalSyllabusMilestones === 0 || completedSyllabusMilestones === 0;
  const isTestsPending = totalTestStudents > 0 && evaluatedTestEntries === 0;
  const anyPending = (totalNotebookCells > 0 && checkedNotebookCells < totalNotebookCells) ||
                     (totalSyllabusMilestones > 0 && completedSyllabusMilestones < totalSyllabusMilestones) ||
                     (totalTestStudents > 0 && evaluatedTestEntries < totalTestStudents);

  // Graphical Data for Radial Progress dial
  const strokeDashoffset = 339.2 - (339.2 * averageCompliance) / 100;

  return (
    <div className="space-y-6 animate-fade-in text-left font-sans">
      
      {/* ⚠️ Management Guard Info Header */}
      <div className="bg-gradient-to-r from-sky-950/40 via-indigo-950/20 to-slate-950/40 border border-sky-500/20 rounded-3xl p-6 relative overflow-hidden backdrop-blur-xl flex flex-wrap items-center justify-between gap-6 shadow-xl leading-relaxed">
        <div className="space-y-1.5 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-sky-500/10 text-sky-400 border border-sky-500/20 rounded-lg text-[9.5px] font-extrabold tracking-wider uppercase inline-flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> READ-ONLY AUDIT MODE
            </span>
            <span className="text-[10px] text-slate-400 font-bold">•</span>
            <span className="text-[10.5px] text-slate-350 font-bold">Authenticated as: <strong className="text-white font-extrabold">{currentUser.name}</strong></span>
          </div>
          <h1 className="text-xl md:text-2.5xl font-black text-white tracking-tight flex items-center gap-2">
            Academic Verification & Endorsement Wing
          </h1>
          <p className="text-xs text-slate-400">
            Vice Principal and Principal audit panel. Crosscheck classroom notebooks corrections status, monthly chapter test scoreboards, and syllabus progress records. Submitting reviews adds permanent stamp clearances.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Verification Authority</p>
            <p className="text-xs font-black text-sky-400">{currentUser.name}</p>
          </div>
          <div className="h-12 w-12 bg-sky-500/15 border border-sky-500/30 rounded-xl flex items-center justify-center text-sky-400 shadow-md">
            <PenTool className="w-5 h-5 text-sky-400" />
          </div>
        </div>
      </div>

      {/* 🔔 DEADLINE ALERT BANNER */}
      {(() => {
        const banner = (() => {
          if (simulatedDay <= 24) {
            const daysLeft = 25 - simulatedDay;
            return {
              phase: 'Syllabus Planner Progress Phase',
              status: `${daysLeft} Day${daysLeft === 1 ? '' : 's'} Left`,
              badgeColor: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
              bgGradient: 'from-indigo-950/40 via-slate-900/40 to-slate-950/40 border-indigo-500/20',
              title: 'Syllabus Completion Deadline is Approaching!',
              description: `All subject teachers must finish syllabus planning and log completed chapters by the 25th at 23:59. You have ${daysLeft} day${daysLeft === 1 ? '' : 's'} remaining to complete logging of the active June 2026 course chapters.`,
              nudgeText: 'Administrative Alert: Remind teachers to update lesson progress journals before lock-in.',
              icon: <Clock className="w-5 h-5 text-indigo-400 animate-pulse" />
            };
          } else if (simulatedDay === 25) {
            return {
              phase: 'SYLLABUS COMPLETION DEADLINE TODAY',
              status: 'ACTION REQUIRED TODAY',
              badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30 animate-pulse',
              bgGradient: 'from-rose-950/40 via-slate-900/40 to-slate-950/40 border-rose-500/40 shadow-rose-500/5',
              title: '🚨 CRITICAL SYLLABUS DEADLINE LOCKOUT!',
              description: 'Today is the 25th! Syllabus completion recording closes tonight. Teachers must log teaching progress for all subjects now.',
              nudgeText: 'Active Nudge Mode: Automated dispatch notifies teachers with outstanding planning entries.',
              icon: <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
            };
          } else if (simulatedDay >= 25 && simulatedDay <= 28) {
            const daysLeft = 28 - simulatedDay;
            return {
              phase: 'DATA ENTRY ACTIVE WINDOW',
              status: daysLeft === 0 ? 'CLOSES TONIGHT' : `${daysLeft} Day${daysLeft === 1 ? '' : 's'} Left`,
              badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30 animate-pulse',
              bgGradient: 'from-amber-950/40 via-slate-900/40 to-slate-950/40 border-amber-500/40 shadow-amber-500/5',
              title: '⚡ Marks & Notebook Correction Updates Open!',
              description: `Active entries window (25th-28th). You have ${daysLeft === 0 ? 'LESS THAN A DAY' : `${daysLeft} day${daysLeft === 1 ? '' : 's'}`} remaining to update Unit Test evaluation metrics and log notebook check statuses.`,
              nudgeText: 'Quality alert: Subject teachers must complete all record entries. Post-28th edits are locked for Principal evaluation stamps.',
              icon: <Sparkles className="w-5 h-5 text-amber-455 animate-pulse" />
            };
          } else {
            const daysLeft = 30 - simulatedDay;
            return {
              phase: 'MANAGEMENT REVIEW PERIOD',
              status: 'ENTRIES LOCKED - AUDIT STAGE',
              badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
              bgGradient: 'from-emerald-950/40 via-slate-900/40 to-slate-950/40 border-emerald-500/20',
              title: '🔒 Quality Verification Audit in Progress',
              description: 'The entries window has locked. Management is currently reviewing syllabus delivery metrics and student workbook checking registers.',
              nudgeText: 'Principals Command: Clearances, stamps, and Board compliance reports are being formulated.',
              icon: <ShieldCheck className="w-5 h-5 text-emerald-450" />
            };
          }
        })();

        return (
          <div className={`bg-gradient-to-r ${banner.bgGradient} border rounded-3xl p-5 relative overflow-hidden shadow-xl leading-relaxed animate-fade-in`}>
            <div className="absolute top-0 right-0 h-32 w-32 bg-white/2 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div className="flex items-start gap-3.5">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10 shrink-0">
                  {banner.icon}
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                      {banner.phase}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[9.5px] font-black uppercase tracking-wide border ${banner.badgeColor}`}>
                      {banner.status}
                    </span>
                  </div>
                  <h4 className="text-white text-sm font-black tracking-tight">{banner.title}</h4>
                  <p className="text-slate-300 text-xs mt-1 max-w-3xl leading-relaxed font-semibold">
                    {banner.description}
                  </p>
                  <p className="text-slate-400 text-[11px] mt-2 italic flex items-center gap-1.5 font-sans">
                    <Bell className="w-3.5 h-3.5 shrink-0" />
                    <span>{banner.nudgeText}</span>
                  </p>
                </div>
              </div>

              {/* Simulation controller widget inside the warning banner */}
              <div className="shrink-0 bg-slate-950/80 border border-white/5 p-4 rounded-2xl flex flex-col items-center min-w-[210px] gap-2">
                <div className="text-center">
                  <span className="text-[9px] text-slate-550 font-black block uppercase tracking-wider">
                    Calendar Simulator
                  </span>
                  <span className="text-xs font-black text-sky-400 block mt-0.5">
                    {selectedMonth.split(' ')[0]} {simulatedDay}, {selectedMonth.split(' ')[1]}
                  </span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="30" 
                  value={simulatedDay}
                  onChange={(e) => handleSimulatedDayChange(parseInt(e.target.value))}
                  className="w-full accent-indigo-500 bg-slate-900 rounded-lg appearance-none h-1.5 cursor-pointer focus:outline-none" 
                />
                <div className="flex items-center justify-between w-full text-[8.5px] text-slate-500 font-bold px-1">
                  <span>Day 1</span>
                  <span>Day 25 (Due)</span>
                  <span>Day 30</span>
                </div>

                <div className="flex flex-col items-center w-full border-t border-white/5 pt-1.5 mt-0.5 gap-1">
                  <span className="text-[8px] text-slate-500 font-black uppercase tracking-wider">
                    Today: {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                  <button 
                    onClick={() => handleSimulatedDayChange(new Date().getDate())}
                    className="text-[8px] font-bold text-indigo-300 hover:text-indigo-200 transition-colors bg-white/5 hover:bg-white/10 px-2 py-0.5 rounded cursor-pointer uppercase"
                  >
                    📍 Use Today's Day
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Dynamic Sub-Tab Management Navigation */}
      <div className="flex border-b border-white/10 gap-2 mb-2">
        <button
          onClick={() => setActiveVerifySubTab('profile')}
          className={`pb-3 px-6 text-sm font-black transition-all flex items-center gap-2 relative cursor-pointer outline-none ${
            activeVerifySubTab === 'profile'
              ? 'text-indigo-400 border-b-2 border-indigo-500 font-extrabold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <User className="w-4 h-4 text-indigo-400" />
          <span>Faculty Audits & Endorsement</span>
        </button>
        <button
          onClick={() => setActiveVerifySubTab('calendar')}
          className={`pb-3 px-6 text-sm font-black transition-all flex items-center gap-2 relative cursor-pointer outline-none ${
            activeVerifySubTab === 'calendar'
              ? 'text-emerald-400 border-b-2 border-emerald-500 font-extrabold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4 text-emerald-400" />
          <span>Academic Audit Calendar</span>
          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-1.5 py-0.5 rounded-full text-[9px] font-black animate-pulse">
            LIVE CALENDAR
          </span>
        </button>
      </div>

      {activeVerifySubTab === 'profile' ? (
        <>
          {/* Selector Panels: Month & Faculty */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Faculty and Month selectors panel */}
        <div className="lg:col-span-1 bg-white/5 border border-white/10 rounded-2xl p-5 space-y-5 shadow-xl">
          
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <span>Target Audit Year Month</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {monthsList.map(m => (
                <button
                  key={m}
                  onClick={() => {
                    setSelectedMonth(m);
                    localStorage.setItem('nb_audit_selected_month', m);
                  }}
                  className={`py-2 px-1 text-center rounded-xl text-[11px] font-black transition-all cursor-pointer ${
                    selectedMonth === m
                      ? 'bg-indigo-500 text-white shadow-lg'
                      : 'bg-white/5 text-slate-350 hover:bg-white/10'
                  }`}
                >
                  {m.replace(' 2026', '')}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-white/5 pt-4 space-y-2">
            <label className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 flex items-center justify-between">
              <span>Auditable Teachers ({allTeachers.length})</span>
              <span className="text-[9px] text-indigo-300 font-black">Allotment Synced</span>
            </label>

            {onUpdateMultipleRecords && (
              <button
                onClick={handleBulkCompleteAllTeachersNotebooks}
                className="w-full py-1.5 px-2.5 bg-gradient-to-r from-emerald-500/10 to-indigo-500/10 hover:from-emerald-500/20 hover:to-indigo-500/20 text-emerald-300 hover:text-white border border-emerald-500/25 rounded-xl text-[10px] font-black tracking-wider uppercase transition-all mb-3 cursor-pointer flex items-center justify-center gap-1.5 active:scale-98 shadow-md"
              >
                <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Bulk Check All School Notebooks</span>
              </button>
            )}
            
            <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1 scrollbar-thin">
              {allTeachers.map(teachName => {
                // Calculate quick indicators for this teacher
                const hasVer = reviews.find(r => r.teacherName === teachName && r.month === selectedMonth && r.isVerified);
                return (
                  <button
                    key={teachName}
                    onClick={() => {
                      setSelectedTeacher(teachName);
                      localStorage.setItem('nb_audit_selected_teacher', teachName);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left border cursor-pointer transition-all ${
                      selectedTeacher === teachName
                        ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-xl translate-x-1'
                        : 'bg-white/3 border-white/5 hover:bg-white/5 text-slate-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <div className={`h-6 w-6 rounded-lg text-[10px] font-bold flex items-center justify-center shrink-0 ${
                        selectedTeacher === teachName ? 'bg-indigo-500 text-white' : 'bg-white/5 text-slate-400'
                      }`}>
                        {teachName.replace('Ms.', '').replace('Mr.', '').trim().charAt(0)}
                      </div>
                      <span className="text-xs font-bold truncate">{teachName}</span>
                    </div>

                    <div className="shrink-0 flex items-center gap-1 pl-1">
                      {hasVer ? (
                        <span className="h-5 px-1.5 bg-emerald-500/15 border border-emerald-500/20 rounded-full text-[8.5px] font-extrabold text-emerald-400 tracking-wide flex items-center gap-0.5">
                          <Check className="w-2.5 h-2.5" /> Endorsed
                        </span>
                      ) : (
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-400" title="Review Pending" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Dynamic graphical indicators and charts */}
        <div className="lg:col-span-3 bg-white/5 border border-white/10 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-4 border-b border-white/15">
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <User className="w-5 h-5 text-indigo-400" />
                Audit Profile: {selectedTeacher}
              </h2>
              <p className="text-xs text-slate-350">
                Performance parameters calculated dynamically for <strong className="text-indigo-300 font-extrabold">{selectedMonth}</strong> syllabus targets.
              </p>
            </div>

            {/* Glowing active approval state */}
            {activeReview.isVerified ? (
              <div className="bg-emerald-500/10 border-2 border-dashed border-emerald-500/35 px-4 py-2 rounded-2xl flex items-center gap-3 animate-fade-in shrink-0 shadow-lg shadow-emerald-500/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-emerald-500/5 hover:scale-105 transition-all" />
                <div className="h-8 w-8 bg-emerald-500 text-slate-950 rounded-full flex items-center justify-center font-black text-lg shadow shrink-0">
                  ✓
                </div>
                <div>
                  <div className="text-[10px] text-emerald-400 font-black uppercase tracking-wider leading-none">ENDORSED & STAMPED</div>
                  <div className="text-[9px] text-slate-350 mt-0.5">By {activeReview.verifiedBy} | {activeReview.verifiedAt}</div>
                </div>
              </div>
            ) : (
              <div className="bg-amber-500/10 border-2 border-dashed border-amber-500/30 px-4 py-2 rounded-2xl flex items-center gap-3 shrink-0">
                <div className="h-8 w-8 bg-amber-500/10 text-amber-400 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-amber-400 font-black uppercase tracking-wider leading-none">AWAITING SYSTEM SIGN-OFF</div>
                  <div className="text-[9px] text-slate-350 mt-0.5">Please review course parameters and apply stamp signature.</div>
                </div>
              </div>
            )}
          </div>

          {/* Dynamic Warning Alert for Unconducted Responsibilities */}
          {anyPending && (
            <div className="bg-red-500/10 border-2 border-red-500/25 rounded-2xl p-4 flex items-start gap-3.5 text-left">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1 w-full">
                <h4 className="text-[11px] font-black text-red-300 uppercase tracking-wider flex items-center gap-1.5">
                  ⚠️ PENDING ACADEMIC TRANSACTIONS DETECTED
                </h4>
                <p className="text-xs text-slate-350 font-medium">
                  Principal, VP, and Management Warning: <strong className="text-white font-extrabold">{selectedTeacher || 'This teacher'}</strong> has not completed or conducted key responsibilities for <strong className="text-indigo-350 font-black">{selectedMonth}</strong>:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 w-full">
                  
                  {/* Column 1: Notebook Checking */}
                  {isNotebookPending ? (
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-red-500/15 flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] font-bold text-red-400 uppercase block tracking-wider leading-none">Notebook Checking</span>
                        <span className="text-xs font-bold text-slate-100 mt-1 block">Not Started</span>
                        <span className="text-[9.5px] text-slate-400 block mt-0.5">0 books checked</span>
                      </div>
                      {onUpdateMultipleRecords && (
                        <button
                          onClick={handleBulkCompleteNotebooksForTeacher}
                          className="mt-3 w-full py-1.5 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 text-[10px] uppercase font-black tracking-wider rounded-lg border border-emerald-400/20 transition-all cursor-pointer text-center whitespace-nowrap"
                        >
                          Autofill & Verify All
                        </button>
                      )}
                    </div>
                  ) : checkedNotebookCells < totalNotebookCells ? (
                    <div className="bg-amber-950/25 p-3 rounded-xl border border-amber-500/15 flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] font-bold text-amber-400 uppercase block tracking-wider leading-none">Notebook Checking</span>
                        <span className="text-xs font-bold text-slate-100 mt-1 block">In Progress ({notebookRate}%)</span>
                        <span className="text-[9.5px] text-amber-350 font-semibold block mt-0.5">{checkedNotebookCells} / {totalNotebookCells} books verified</span>
                      </div>
                      {onUpdateMultipleRecords && (
                        <button
                          onClick={handleBulkCompleteNotebooksForTeacher}
                          className="mt-3 w-full py-1.5 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 text-[10px] uppercase font-black tracking-wider rounded-lg border border-emerald-400/20 transition-all cursor-pointer text-center whitespace-nowrap"
                        >
                          Autofill & Verify All
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/15 flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] font-bold text-emerald-400 uppercase block tracking-wider leading-none">Notebook Checking</span>
                        <span className="text-xs font-bold text-slate-100 mt-1 block">100% Completed</span>
                        <span className="text-[9.5px] text-emerald-350 font-semibold block mt-0.5">{checkedNotebookCells} books verified</span>
                      </div>
                    </div>
                  )}

                  {/* Column 2: Syllabus Completion */}
                  {isSyllabusPending ? (
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-red-500/15">
                      <span className="text-[9px] font-bold text-red-400 uppercase block tracking-wider leading-none">Syllabus Completion</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">No Chapters Completed</span>
                      <span className="text-[9.5px] text-slate-400 block mt-0.5">0 / {totalSyllabusMilestones || '0'} monthly chapters finished</span>
                    </div>
                  ) : completedSyllabusMilestones < totalSyllabusMilestones ? (
                    <div className="bg-amber-950/25 p-3 rounded-xl border border-amber-500/15">
                      <span className="text-[9px] font-bold text-amber-400 uppercase block tracking-wider leading-none">Syllabus Completion</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">In Progress ({syllabusRate}%)</span>
                      <span className="text-[9.5px] text-amber-350 font-semibold block mt-0.5">{completedSyllabusMilestones} / {totalSyllabusMilestones} chapters completed</span>
                    </div>
                  ) : (
                    <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/15">
                      <span className="text-[9px] font-bold text-emerald-400 uppercase block tracking-wider leading-none">Syllabus Completion</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">100% Completed</span>
                      <span className="text-[9.5px] text-emerald-350 font-semibold block mt-0.5">{completedSyllabusMilestones} / {totalSyllabusMilestones} chapters verified</span>
                    </div>
                  )}

                  {/* Column 3: Scorebook Entries */}
                  {totalTestStudents === 0 ? (
                    <div className="bg-slate-950/40 p-3 rounded-xl border border-white/5">
                      <span className="text-[9px] font-bold text-slate-400 uppercase block tracking-wider leading-none">Scorebook Entries</span>
                      <span className="text-xs font-bold text-slate-300 mt-1 block">No Tests Scheduled</span>
                      <span className="text-[9.5px] text-slate-500 block mt-0.5">0 tests expected this month</span>
                    </div>
                  ) : isTestsPending ? (
                    <div className="bg-slate-950/60 p-3 rounded-xl border border-red-500/15">
                      <span className="text-[9px] font-bold text-red-400 uppercase block tracking-wider leading-none">Scorebook Entries</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">Tests Not Logged</span>
                      <span className="text-[9.5px] text-slate-400 block mt-0.5">0 / {totalTestStudents} marks uploaded</span>
                    </div>
                  ) : evaluatedTestEntries < totalTestStudents ? (
                    <div className="bg-amber-950/25 p-3 rounded-xl border border-amber-500/15">
                      <span className="text-[9px] font-bold text-amber-400 uppercase block tracking-wider leading-none">Scorebook Entries</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">In Progress ({evaluationRate}%)</span>
                      <span className="text-[9.5px] text-amber-350 font-semibold block mt-0.5">{evaluatedTestEntries} / {totalTestStudents} marks loaded</span>
                    </div>
                  ) : (
                    <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/15">
                      <span className="text-[9px] font-bold text-emerald-400 uppercase block tracking-wider leading-none">Scorebook Entries</span>
                      <span className="text-xs font-bold text-slate-100 mt-1 block">100% Completed</span>
                      <span className="text-[9.5px] text-emerald-350 font-semibold block mt-0.5">{evaluatedTestEntries} marks fully archived</span>
                    </div>
                  )}

                </div>
                <p className="text-[9.5px] text-amber-300 font-bold mt-2">
                  💡 Recommendation: Review course parameters before applying the stamp signature.
                </p>
              </div>
            </div>
          )}

          {/* Graphical Progress dashboard section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            
            {/* Double Circle SVG Radial Gauge: Core Index Compliance */}
            <div className="flex flex-col items-center justify-center bg-slate-950/40 p-4 border border-white/5 rounded-2xl relative">
              <span className="text-[10px] font-extrabold tracking-wider text-slate-400 uppercase text-center mb-3">CONSOLIDATED COMPLIANCE DIAL</span>
              
              <div className="relative flex items-center justify-center w-36 h-36">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                  <circle
                    cx="60"
                    cy="60"
                    r="54"
                    fill="transparent"
                    stroke="rgba(255,255,255,0.05)"
                    strokeWidth="8"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="54"
                    fill="transparent"
                    stroke={averageCompliance >= 85 ? "#10b981" : averageCompliance >= 65 ? "#f59e0b" : "#f43f5e"}
                    strokeWidth="8"
                    strokeDasharray="339.2"
                    strokeDashoffset={strokeDashoffset}
                    className="transition-all duration-1000 ease-out"
                    strokeLinecap="round"
                    style={{ filter: "drop-shadow(0px 0px 8px rgba(99, 102, 241, 0.35))" }}
                  />
                </svg>

                <div className="absolute text-center">
                  <span className="text-3xl font-black text-white">{averageCompliance}%</span>
                  <span className="block text-[8px] tracking-widest text-[#818cf8] uppercase font-bold mt-1">METRICS RANK</span>
                </div>
              </div>

              <div className="text-center mt-3 scale-95">
                <p className="text-[11px] text-slate-300 font-black">
                  {averageCompliance >= 85 ? "Excellent Performance" : averageCompliance >= 65 ? "Steady Standards" : "Pending Fast Check-off"}
                </p>
                <p className="text-[9px] text-slate-400 mt-0.5">Weighted checklist compliance</p>
              </div>
            </div>

            {/* Custom SVG Bar Chart comparing Notebook Correction vs Syllabus Completion vs Score entries */}
            <div className="md:col-span-2 bg-slate-950/40 p-4 border border-white/5 rounded-2xl space-y-4">
              <span className="text-[10px] font-extrabold tracking-wider text-slate-400 uppercase block">CORE AUDIT METRICS COMPARATIVE</span>
              
              <div className="space-y-3 pt-1">
                
                {/* Metric 1 BAR */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-350 flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-indigo-400" />
                      Class Notebook Corrections Rate
                    </span>
                    <span className="text-indigo-300">{notebookRate}%</span>
                  </div>
                  <div className="h-4 w-full bg-white/5 rounded-lg overflow-hidden flex">
                    <div 
                      className="bg-indigo-500 rounded-lg h-full transition-all duration-1000 ease-out flex items-center justify-end pr-2 text-[9px] text-white font-bold"
                      style={{ width: `${Math.max(notebookRate, 5)}%` }}
                    >
                      {notebookRate >= 15 ? `${checkedNotebookCells}/${totalNotebookCells || 'Sync'} slots` : ''}
                    </div>
                  </div>
                  <span className="text-[9px] text-slate-400 block leading-tight">Total checking instances scheduled based on students roster. Goal: 100% verified.</span>
                </div>

                {/* Metric 2 BAR */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-350 flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-emerald-400" />
                      Monthly Syllabus Completion Rate
                    </span>
                    <span className="text-emerald-300">{syllabusRate}%</span>
                  </div>
                  <div className="h-4 w-full bg-white/5 rounded-lg overflow-hidden flex">
                    <div 
                      className="bg-emerald-500 rounded-lg h-full transition-all duration-1000 ease-out flex items-center justify-end pr-2 text-[9px] text-slate-950 font-bold"
                      style={{ width: `${Math.max(syllabusRate, 5)}%` }}
                    >
                      {syllabusRate >= 15 ? `${completedSyllabusMilestones}/${totalSyllabusMilestones || 'Sync'} topics` : ''}
                    </div>
                  </div>
                  <span className="text-[9px] text-slate-400 block leading-tight">Monthly syllabus chapters logged in the Planner. Completed status is automatically matched.</span>
                </div>

                {/* Metric 3 BAR */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-350 flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-amber-400" />
                      Syllabus Tests Evaluation & Scorebook Entry
                    </span>
                    <span className="text-amber-300">{totalTestStudents > 0 ? `${evaluationRate}%` : 'N/A'}</span>
                  </div>
                  <div className="h-4 w-full bg-white/5 rounded-lg overflow-hidden flex">
                    <div 
                      className="bg-amber-500 rounded-lg h-full transition-all duration-1000 ease-out flex items-center justify-end pr-2 text-[9px] text-slate-950 font-bold"
                      style={{ width: `${totalTestStudents > 0 ? Math.max(evaluationRate, 5) : 0}%` }}
                    >
                      {totalTestStudents > 0 ? `${evaluatedTestEntries}/${totalTestStudents} scored` : 'No scheduled tests'}
                    </div>
                  </div>
                  <span className="text-[9px] text-slate-400 block leading-tight">Calculates score updates inside tests registry. Helps track pending absent updates.</span>
                </div>

              </div>
            </div>

          </div>

          {/* List of courses taught by this teacher for reference */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Classes & Roster Mapping for verification</h3>
            
            {courseBreakdowns.length === 0 ? (
              <div className="text-xs text-slate-500 bg-slate-950/20 border border-white/5 p-4 rounded-xl italic">
                No active class worksheets or planner assignments mapped for this teacher during {selectedMonth}. If this is a class monitor or specific monitor role, please check standard workloads in 'Faculty Hub'.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {courseBreakdowns.map((cb, idx) => (
                  <div key={idx} className="bg-white/3 border border-white/5 p-4 rounded-xl space-y-3 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-10 w-10 bg-indigo-500/5 rounded-bl-full pointer-events-none" />
                    
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-xs font-bold text-slate-150 block">{cb.className} ({cb.subject})</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">Teacher: {cb.teacherName}</span>
                      </div>
                      <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/10 rounded-md text-[9px] font-bold">
                        {cb.plannedChapters.length} Assigned Milestone{cb.plannedChapters.length !== 1 ? 's' : ''}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 border-t border-white/5 pt-2.5 text-center divide-x divide-white/5">
                      <div>
                        <span className="text-[9px] text-slate-400 font-bold uppercase block">Planner Tasks</span>
                        <span className="text-xs font-black text-indigo-300 mt-1 block">
                          {cb.chaptersCompleted} / {cb.chaptersCount}
                        </span>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 font-bold uppercase block">Notebook Check</span>
                        <span className="text-xs font-black text-emerald-300 mt-1 block">
                          {cb.notebookRate}%
                        </span>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 font-bold uppercase block">Tests Entry</span>
                        <span className="text-xs font-black text-amber-300 mt-1 block">
                          {cb.testCount > 0 ? `${cb.testRate}%` : 'N/A'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* SCHOOL-WIDE GRADE SUBMISSION HEALTH INDEX */}
      <div className="bg-gradient-to-br from-indigo-950/30 to-slate-900/50 border border-indigo-500/15 rounded-3xl p-6 shadow-2xl space-y-6">
        
        {/* Header Title with Subtitle */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md text-[9px] font-black tracking-widest uppercase">
                CAMPUS-WIDE EXECUTIVE INDEX
              </span>
              <span className="h-1 w-1 bg-slate-500 rounded-full" />
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{selectedMonth}</span>
            </div>
            <h2 className="text-lg font-black text-white mt-1 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-400" />
              School-Wide Grade Submission Health
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 leading-normal">
              Aggregated audit index combining class notebook corrections, monthly tests scored, and syllabus chapters progress. Focuses on achieving the gold standard of <strong className="text-emerald-400 font-bold">90%+ compliance bounds</strong>.
            </p>
          </div>
          
          <div className="text-[10px] text-slate-400 font-bold italic bg-slate-950/60 px-3.5 py-1.5 rounded-xl border border-white/5 flex items-center gap-1.5 self-start md:self-auto">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Operational Real-Time Ledger Active</span>
          </div>
        </div>

        {/* Computations Section */}
        {(() => {
          const gradeHealthRecords = classes.map(cls => {
            // Find Chapters/Syllabus Tasks
            const classTasks = tasks.filter(t => t.classId === cls.id && t.month === selectedMonth);
            const totalChapters = classTasks.length;

            const completedChapters = classTasks.filter(task => {
              const taskRecords = records.filter(r => r.taskId === task.id);
              const checkedCount = taskRecords.filter(r => r.status === 'checked').length;
              return cls.students.length > 0 && checkedCount >= cls.students.length * 0.7;
            }).length;

            // Notebook check expected cells
            const totalNotebookExpected = totalChapters * cls.students.length;
            let checkedNotebookActual = 0;
            classTasks.forEach(task => {
              cls.students.forEach(std => {
                const rec = records.find(r => r.studentId === std.id && r.taskId === task.id);
                if (rec && rec.status === 'checked') {
                  checkedNotebookActual++;
                }
              });
            });

            // Academic tests scored
            const classTests = academicTests.filter(t => t.classId === cls.id && t.month === selectedMonth);
            const totalTestEntriesExpected = classTests.length * cls.students.length;
            let evaluatedTestEntriesActual = 0;
            classTests.forEach(test => {
              cls.students.forEach(std => {
                const mark = testMarks.find(m => m.testId === test.id && m.studentId === std.id);
                if (mark && (mark.marksObtained !== '' || mark.isAbsent)) {
                  evaluatedTestEntriesActual++;
                }
              });
            });

            const syllabusPct = totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
            const notebookPct = totalNotebookExpected > 0 ? Math.round((checkedNotebookActual / totalNotebookExpected) * 100) : 0;
            const testPct = totalTestEntriesExpected > 0 ? Math.round((evaluatedTestEntriesActual / totalTestEntriesExpected) * 100) : 0;

            // Aggregate Health is a fair average of active/scheduled categories
            const activePcts: number[] = [];
            if (totalChapters > 0) {
              activePcts.push(syllabusPct);
              activePcts.push(notebookPct);
            }
            if (totalTestEntriesExpected > 0) {
              activePcts.push(testPct);
            }

            const healthScore = activePcts.length > 0
              ? Math.round(activePcts.reduce((sum, val) => sum + val, 0) / activePcts.length)
              : 0;

            const hasActivity = totalChapters > 0 || classTests.length > 0;

            return {
              id: cls.id,
              name: cls.name,
              studentsCount: cls.students.length,
              totalChapters,
              completedChapters,
              totalNotebookExpected,
              checkedNotebookActual,
              totalTests: classTests.length,
              evaluatedTestEntriesActual,
              totalTestEntriesExpected,
              syllabusPct,
              notebookPct,
              testPct,
              healthScore,
              hasActivity
            };
          });

          // Aggregate metrics calculations
          const activeGrades = gradeHealthRecords.filter(g => g.hasActivity);
          const averageSchoolHealth = activeGrades.length > 0 
            ? Math.round(activeGrades.reduce((sum, g) => sum + g.healthScore, 0) / activeGrades.length) 
            : 0;
          const eliteCount = gradeHealthRecords.filter(g => g.hasActivity && g.healthScore >= 90).length;
          const sortedByPerformance = [...activeGrades].sort((a, b) => b.healthScore - a.healthScore);
          const premierClass = sortedByPerformance[0];

          // Filter logic based on interactive states
          const filteredGradesList = gradeHealthRecords.filter(g => {
            const matchSearch = g.name.toLowerCase().includes(gradeSearchText.toLowerCase()) ||
                                g.id.toLowerCase().includes(gradeSearchText.toLowerCase());
            if (healthFilter === 'achievers') {
              return matchSearch && g.healthScore >= 90;
            }
            if (healthFilter === 'alert') {
              return matchSearch && g.healthScore < 90;
            }
            return matchSearch;
          });

          return (
            <div className="space-y-6">
              
              {/* Executive Overview Cards statistics panel */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                <div className="bg-slate-950/50 p-4 border border-white/5 rounded-2xl flex items-center justify-between shadow">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-extrabold block tracking-wider">CAMPUS HEALTH INDEX</span>
                    <span className="text-xl font-black text-indigo-350">{averageSchoolHealth}%</span>
                    <span className="text-[9.5px] text-slate-500 block leading-tight">Average rate across all active class registers</span>
                  </div>
                  <div className="h-10 w-10 rounded-xl bg-indigo-500/15 flex items-center justify-center text-indigo-400">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                </div>

                <div className="bg-slate-950/50 p-4 border border-white/5 rounded-2xl flex items-center justify-between shadow">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-extrabold block tracking-wider">90%+ ELITE STATUS MET</span>
                    <span className="text-xl font-black text-emerald-400">{eliteCount} Grade{eliteCount !== 1 ? 's' : ''}</span>
                    <span className="text-[9.5px] text-emerald-500/80 block leading-tight font-bold">Successfully met target standard bounds</span>
                  </div>
                  <div className="h-10 w-10 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400">
                    <Award className="w-5 h-5" />
                  </div>
                </div>

                <div className="bg-slate-950;60 p-4 border border-white/5 rounded-2xl flex items-center justify-between shadow">
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-extrabold block tracking-wider">HIGHEST SUBMISSION HEALTH</span>
                    {premierClass ? (
                      <>
                        <span className="text-sm font-black text-amber-300 block truncate max-w-[200px]">{premierClass.name}</span>
                        <div className="flex items-center gap-1">
                          <span className="text-[10.5px] font-black text-white">{premierClass.healthScore}% health</span>
                          <span className="text-[9.5px] text-slate-500">({premierClass.checkedNotebookActual} checks complete)</span>
                        </div>
                      </>
                    ) : (
                      <span className="text-xs font-black text-slate-500">No scheduled activities</span>
                    )}
                  </div>
                  <div className="h-10 w-10 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400">
                    <Sparkles className="w-5 h-5" />
                  </div>
                </div>

              </div>

              {/* Filtering Suite Controls */}
              <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-slate-950/40 p-3.5 border border-white/5 rounded-2xl">
                
                {/* Search query box */}
                <div className="relative w-full md:w-80 shrink-0">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={gradeSearchText}
                    onChange={(e) => setGradeSearchText(e.target.value)}
                    placeholder="Search by grade name (e.g. VIII O, I)..."
                    className="w-full bg-slate-900 border border-white/5 hover:border-white/10 focus:border-indigo-500 rounded-xl py-1.5 pl-9 pr-4 text-xs text-white placeholder-slate-500 focus:outline-none transition-all font-sans"
                  />
                </div>

                {/* Filter Pills selectors */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-500 mr-1 hidden lg:inline">Filter Compliance:</span>
                  {[
                    { id: 'all', label: 'All Grades', count: gradeHealthRecords.length },
                    { id: 'achievers', label: '🌟 90%+ Achievers', count: gradeHealthRecords.filter(g => g.healthScore >= 90).length },
                    { id: 'alert', label: '⚠️ Needs Attention (<90%)', count: gradeHealthRecords.filter(g => g.hasActivity && g.healthScore < 90).length }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setHealthFilter(tab.id as any)}
                      className={`text-[10.5px] font-black px-3.5 py-1.5 rounded-xl cursor-pointer transition-all border ${
                        healthFilter === tab.id
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                          : 'bg-white/3 border-white/5 text-slate-300 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      {tab.label} <span className="text-[9.5px] opacity-70 ml-0.5">({tab.count})</span>
                    </button>
                  ))}
                </div>

              </div>

              {/* List of Grade Health Columns */}
              <div className="space-y-3.5">
                {filteredGradesList.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950/25 border border-dashed border-white/10 rounded-2xl">
                    <SlidersHorizontal className="w-6 h-6 text-slate-600 mx-auto mb-2" />
                    <p className="text-xs font-bold text-slate-400">No grades match your target search criteria.</p>
                  </div>
                ) : (
                  filteredGradesList.map((g) => {
                    const isElite = g.healthScore >= 90;
                    const isLow = g.healthScore < 60 && g.hasActivity;
                    const isExpanded = expandedGradeId === g.id;

                    return (
                      <div 
                        key={g.id} 
                        className={`bg-slate-950/30 border rounded-2xl overflow-hidden transition-all duration-300 ${
                          isElite 
                            ? 'border-emerald-500/20 hover:border-emerald-500/35 hover:shadow-emerald-500/5 hover:-translate-y-0.5' 
                            : 'border-white/5 hover:border-white/10 hover:shadow-lg'
                        }`}
                      >
                        
                        {/* Primary Row Grid clickable to toggle details */}
                        <div 
                          onClick={() => setExpandedGradeId(isExpanded ? null : g.id)}
                          className="p-4 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 cursor-pointer select-none"
                        >
                          
                          {/* Class / Grade Identity */}
                          <div className="flex items-center gap-3 w-full lg:w-1/4 shrink-0">
                            <div className={`h-9 w-9 rounded-xl flex items-center justify-center font-black text-sm shrink-0 shadow-inner ${
                              isElite 
                                ? 'bg-gradient-to-br from-emerald-500/20 to-teal-500/10 text-emerald-400 border border-emerald-500/25' 
                                : 'bg-slate-900 text-slate-300 border border-white/5'
                            }`}>
                              {g.name.replace('Class ', '').split(' ')[0]}
                            </div>
                            <div className="space-y-0.5 text-left">
                              <span className="text-xs font-black text-white hover:text-indigo-300 transition-colors block">{g.name}</span>
                              <span className="text-[10px] text-slate-400 block font-semibold">
                                {g.studentsCount} students • {g.totalTests} academic tests
                              </span>
                            </div>
                          </div>

                          {/* Submission Health Progress Bar component */}
                          <div className="flex-1 flex items-center gap-3.5">
                            
                            <div className="flex-1 space-y-1.5">
                              <div className="flex justify-between items-center text-[10px]">
                                <span className="text-slate-400 uppercase font-black tracking-wider block">Submission Health Rating</span>
                                <span className={`font-black ${isElite ? 'text-emerald-400' : 'text-indigo-300'}`}>
                                  {g.hasActivity ? `${g.healthScore}%` : '0% (Awaiting Register)'}
                                </span>
                              </div>

                              <div className="h-3 w-full bg-slate-900 border border-white/5 rounded-lg overflow-hidden flex relative">
                                {/* 90% indicator notch */}
                                <div className="absolute top-0 bottom-0 left-[90%] w-0.5 bg-indigo-500/30 z-10" title="90% Benchmark threshold" />
                                
                                <div 
                                  className={`rounded-lg h-full transition-all duration-1000 ease-out flex items-center justify-end pr-1.5 ${
                                    isElite 
                                      ? 'bg-gradient-to-r from-emerald-600 to-emerald-400 shadow-md shadow-emerald-500/10 animate-pulse' 
                                      : isLow 
                                      ? 'bg-gradient-to-r from-rose-600 to-rose-400'
                                      : 'bg-indigo-500'
                                  }`}
                                  style={{ width: `${Math.max(g.healthScore, g.hasActivity ? 5 : 0)}%` }}
                                />
                              </div>
                            </div>

                            {/* Standard Bound badge */}
                            <div className="shrink-0">
                              {isElite ? (
                                <span className="h-6 px-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md text-[9px] font-black tracking-widest uppercase flex items-center gap-0.5 animate-bounce">
                                  🌟 Elite Std
                                </span>
                              ) : g.hasActivity ? (
                                <span className="h-6 px-2.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/10 rounded-md text-[9px] font-black tracking-widest uppercase flex items-center">
                                  Standard
                                </span>
                              ) : (
                                <span className="h-6 px-2.5 bg-amber-500/5 text-amber-400/70 border border-amber-500/10 rounded-md text-[8.5px] font-black tracking-wider uppercase flex items-center">
                                  Awaiting
                                </span>
                              )}
                            </div>

                          </div>

                          {/* Quick expand caret trigger action button */}
                          <div className="shrink-0 flex items-center justify-end pl-3">
                            <button
                              type="button"
                              className="text-[10px] font-black text-indigo-400 hover:text-white hover:underline focus:outline-none cursor-pointer flex items-center gap-0.5"
                            >
                              <span>{isExpanded ? 'Collapse' : 'Audit Details'}</span>
                              <span>{isExpanded ? '▲' : '▼'}</span>
                            </button>
                          </div>

                        </div>

                        {/* Expandable detailed breakdown sections */}
                        {isExpanded && (
                          <div className="border-t border-white/5 bg-slate-950/60 p-4.5 space-y-4 animate-slide-down">
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                              
                              {/* Gauge 1: Notebook checklist */}
                              <div className="space-y-1 bg-white/3 border border-white/5 rounded-xl p-3">
                                <div className="flex justify-between items-center text-[10.5px]">
                                  <span className="font-bold text-slate-300">Notebook Corrections Check</span>
                                  <span className="text-[10.5px] font-black text-[#818cf8]">{g.notebookPct}%</span>
                                </div>
                                <div className="h-1.5 w-full bg-slate-900 rounded-lg overflow-hidden mt-1.5">
                                  <div 
                                    className="bg-indigo-500 rounded-lg h-full transition-all duration-700" 
                                    style={{ width: `${g.notebookPct}%` }}
                                  />
                                </div>
                                <span className="text-[9px] text-slate-400 block mt-1">
                                  {g.checkedNotebookActual} out of {g.totalNotebookExpected || '0'} scheduled notebooks certified
                                </span>
                              </div>

                              {/* Gauge 2: Syllabus Progress */}
                              <div className="space-y-1 bg-white/3 border border-white/5 rounded-xl p-3">
                                <div className="flex justify-between items-center text-[10.5px]">
                                  <span className="font-bold text-slate-300">Syllabus Monthly Chapters</span>
                                  <span className="text-[10.5px] font-black text-emerald-400">{g.syllabusPct}%</span>
                                </div>
                                <div className="h-1.5 w-full bg-slate-900 rounded-lg overflow-hidden mt-1.5">
                                  <div 
                                    className="bg-emerald-500 rounded-lg h-full transition-all duration-700" 
                                    style={{ width: `${g.syllabusPct}%` }}
                                  />
                                </div>
                                <span className="text-[9px] text-slate-400 block mt-1">
                                  {g.completedChapters} out of {g.totalChapters || '0'} active monthly syllabus milestones completed
                                </span>
                              </div>

                              {/* Gauge 3: Tests Logs */}
                              <div className="space-y-1 bg-white/3 border border-white/5 rounded-xl p-3">
                                <div className="flex justify-between items-center text-[10.5px]">
                                  <span className="font-bold text-slate-300">Test Scores Evaluation Register</span>
                                  <span className="text-[10.5px] font-black text-amber-300">
                                    {g.totalTestEntriesExpected > 0 ? `${g.testPct}%` : 'N/A'}
                                  </span>
                                </div>
                                <div className="h-1.5 w-full bg-slate-900 rounded-lg overflow-hidden mt-1.5">
                                  <div 
                                    className="bg-amber-500 rounded-lg h-full transition-all duration-700" 
                                    style={{ width: `${g.totalTestEntriesExpected > 0 ? g.testPct : 0}%` }}
                                  />
                                </div>
                                <span className="text-[9px] text-slate-400 block mt-1">
                                  {g.totalTestEntriesExpected > 0 
                                    ? `${g.evaluatedTestEntriesActual} out of ${g.totalTestEntriesExpected} scholar marks registered` 
                                    : 'No evaluation tests registered'}
                                </span>
                              </div>

                            </div>

                            {/* Executive Decision support guide */}
                            <div className="bg-slate-900/85 p-3 rounded-xl border border-white/5 text-left text-[11px] leading-relaxed flex items-start gap-2.5">
                              <span className="text-sm">💡</span>
                              <div>
                                <span className="font-bold text-slate-200 block">Executive Guidelines & Directives</span>
                                <span className="text-slate-400 text-[10.5px] block mt-0.5">
                                  {isElite 
                                    ? `Excellent academic operations verified. Notebook check-offs is verified at ${g.notebookPct}%, syllabus at ${g.syllabusPct}%, and evaluations scored up to date. Keep up the high compliance bounds.`
                                    : g.hasActivity 
                                    ? `Compliance standards stand below the elite threshold parameter. Ensure the class teacher completes outstanding notebook checklists (${g.checkedNotebookActual}/${g.totalNotebookExpected || '0'}) or logs missing test scores inside the central scorebook.`
                                    : `Inactive data registry for this target audit month. Class syllabus planning tracker records must be created inside 'Monthly Plan Syllabus' to trigger checking pipelines.`
                                  }
                                </span>
                              </div>
                            </div>

                          </div>
                        )}

                      </div>
                    );
                  })
                )}
              </div>

            </div>
          );
        })()}

      </div>

      {/* READ-ONLY AUDIT LEDGER SECTION */}
      <div className="bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-md text-[9.5px] font-extrabold tracking-wider uppercase">
              RECORDS REGISTER
            </span>
            <h2 className="text-base font-black text-white mt-1">
              Double-Verification Ledger: {selectedTeacher} ({selectedMonth})
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Review completed topics, evaluation scores entries, and checks statistics. Fields are read-only to prevent unauthorized administrative alterations.
            </p>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-slate-400 font-bold italic bg-slate-900 px-3.5 py-1.5 rounded-xl border border-white/5">
            <span>🛡️ Editing Controls Disabled for Read-Only Evaluation</span>
          </div>
        </div>

        {/* Detailed course targets */}
        {courseBreakdowns.length > 0 ? (
          <div className="space-y-6">
            {courseBreakdowns.map((cb, idx) => (
              <div key={idx} className="bg-slate-950/25 border border-white/5 rounded-2xl overflow-hidden shadow">
                <div className="bg-white/3 px-4 py-3 flex items-center justify-between border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-black text-white">{cb.className} — {cb.subject} Classroom Tracker</span>
                  </div>
                  <span className="text-[10.5px] text-indigo-200 bg-indigo-500/10 border border-indigo-500/15 py-0.5 px-2.5 rounded-lg font-bold">
                    Class Monitor Checklist Verified
                  </span>
                </div>

                <div className="p-4 grid grid-cols-1 lg:grid-cols-3 gap-6 divide-y lg:divide-y-0 lg:divide-x divide-white/5">
                  
                  {/* Monthly plans targets */}
                  <div className="space-y-3 pb-4 lg:pb-0 lg:pr-4">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Syllabus Monthly Milestones</span>
                    <ul className="space-y-2">
                      {cb.plannedChapters.length === 0 ? (
                        <li className="text-slate-500 italic text-[11px]">No planned tasks/chapters on register for this month.</li>
                      ) : (
                        cb.plannedChapters.map((title, tIdx) => (
                          <li key={tIdx} className="bg-white/5 p-2 rounded-xl border border-white/5 flex items-start gap-2">
                            <span className="h-4 w-4 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-[9px] shrink-0 mt-0.5">
                              ✓
                            </span>
                            <div className="leading-tight">
                              <p className="text-xs font-bold text-slate-200">{title}</p>
                              <p className="text-[9.5px] text-emerald-400 font-bold mt-0.5">Syllabus Complete</p>
                            </div>
                          </li>
                        ))
                      )}
                    </ul>
                  </div>

                  {/* Notebook corrections metrics details */}
                  <div className="space-y-3 pt-4 lg:pt-0 lg:px-4">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Class Notebook Correction</span>
                    
                    <div className="bg-white/5 rounded-xl p-3 border border-white/5 space-y-3">
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400">Total Checking Portfolios:</span>
                        <span className="text-slate-100">{cb.notebookTotal} slots</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400 font-normal">Portfolios Checked:</span>
                        <span className="text-emerald-400 font-black">{cb.notebookChecked} complete</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400 font-normal">Incomplete / Missing rate:</span>
                        <span className="text-amber-400">{cb.notebookTotal - cb.notebookChecked} pending</span>
                      </div>

                      <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-bold">
                        <span className="text-slate-350">Correction completeness:</span>
                        <span className="text-indigo-300 font-black text-xs">{cb.notebookRate}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Evaluation scorebook registers */}
                  <div className="space-y-3 pt-4 lg:pt-0 lg:pl-4">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Unit / Chapter Scorebook Register</span>
                    
                    <div className="bg-white/5 rounded-xl p-3 border border-white/5 space-y-3">
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400">Chapter Evaluation Tests:</span>
                        <span className="text-slate-100">{cb.testCount} tests scheduled</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400 font-normal">Roster Scorecards Entered:</span>
                        <span className="text-slate-100 font-black">{cb.testEvaluated} / {cb.testTotal} entries</span>
                      </div>

                      <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-bold">
                        <span className="text-slate-350">Register Evaluation Rate:</span>
                        <span className="text-indigo-300 font-black text-xs">{cb.testCount > 0 ? `${cb.testRate}%` : 'N/A'}</span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center bg-slate-900 border border-white/5 rounded-2xl">
            <AlertCircle className="w-8 h-8 text-slate-500 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-300">No active course allotments synced for {selectedTeacher}</p>
            <p className="text-xs text-slate-500 mt-1">Check timetable allotments in 'Faculty Workloads Hub'.</p>
          </div>
        )}
      </div>

      {/* FEEDBACK & COMMENTS WORKSPACE PANEL */}
      <div className="bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl space-y-6">
        <div>
          <span className="px-2.5 py-0.5 bg-sky-500/10 text-sky-300 border border-sky-500/20 rounded-md text-[9.5px] font-extrabold tracking-wider uppercase">
            ENDORSEMENT SUITE
          </span>
          <h2 className="text-lg font-black text-white mt-1.5 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-sky-400" />
            Management Verifications & Comments
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Log comments on the teacher's work. Click any prefilled professional comment to load instantly, or key-in customized feedback below.
          </p>
        </div>

        {/* Form Inputs and Prefilled suggestions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          <div className="space-y-5">
            
            {/* 1. Notebook Comment */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                <span>1. Notebook Corrections Review Comments</span>
                <span className="text-[9.5px] text-sky-400 font-bold uppercase tracking-wider">Notebook Audit</span>
              </label>
              
              <textarea
                value={activeReview.notebookStatusComment}
                onChange={(e) => handleUpdateReviewComment('notebookStatusComment', e.target.value)}
                placeholder="Write observations about index accuracy, neatness of corrections, teacher signatures..."
                rows={2}
                className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-sky-500 transition-all font-sans leading-relaxed"
                disabled={activeReview.isVerified}
              />
              
              {!activeReview.isVerified && (
                <div className="flex flex-wrap gap-1.5">
                  {prefilledNotebookComments.map((comment, sIdx) => (
                    <button
                      key={sIdx}
                      onClick={() => handleUpdateReviewComment('notebookStatusComment', comment)}
                      className="text-[9.5px] font-bold text-sky-300 bg-sky-500/5 hover:bg-sky-500/10 border border-sky-500/15 py-1 px-2 rounded-lg cursor-pointer transition-all"
                    >
                      💡 {comment.slice(0, 30)}...
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Syllabus Comment */}
            <div className="space-y-2 border-t border-white/5 pt-4">
              <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                <span>2. Syllabus & Topic Completion Review Comments</span>
                <span className="text-[9.5px] text-emerald-400 font-bold uppercase tracking-wider">Milestones Audit</span>
              </label>
              
              <textarea
                value={activeReview.syllabusStatusComment}
                onChange={(e) => handleUpdateReviewComment('syllabusStatusComment', e.target.value)}
                placeholder="Write observations about chapter milestones completion status, planner alignment..."
                rows={2}
                className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all font-sans leading-relaxed"
                disabled={activeReview.isVerified}
              />
              
              {!activeReview.isVerified && (
                <div className="flex flex-wrap gap-1.5">
                  {prefilledSyllabusComments.map((comment, sIdx) => (
                    <button
                      key={sIdx}
                      onClick={() => handleUpdateReviewComment('syllabusStatusComment', comment)}
                      className="text-[9.5px] font-bold text-emerald-300 bg-emerald-500/5 hover:bg-emerald-500/10 border border-emerald-500/15 py-1 px-2 rounded-lg cursor-pointer transition-all"
                    >
                      💡 {comment.slice(0, 30)}...
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

          <div className="space-y-5">
            
            {/* 3. Test Score Comment */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                <span>3. Monthly Tests Evaluation Review Comments</span>
                <span className="text-[9.5px] text-amber-400 font-bold uppercase tracking-wider">Evaluation Audit</span>
              </label>
              
              <textarea
                value={activeReview.testRecordComment}
                onChange={(e) => handleUpdateReviewComment('testRecordComment', e.target.value)}
                placeholder="Write observations on test results entry status, marks distribution..."
                rows={2}
                className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 transition-all font-sans leading-relaxed"
                disabled={activeReview.isVerified}
              />
              
              {!activeReview.isVerified && (
                <div className="flex flex-wrap gap-1.5">
                  {prefilledTestComments.map((comment, sIdx) => (
                    <button
                      key={sIdx}
                      onClick={() => handleUpdateReviewComment('testRecordComment', comment)}
                      className="text-[9.5px] font-bold text-amber-300 bg-amber-500/5 hover:bg-amber-500/10 border border-amber-500/15 py-1 px-2 rounded-lg cursor-pointer transition-all"
                    >
                      💡 {comment.slice(0, 30)}...
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 4. Overall General Comment */}
            <div className="space-y-2 border-t border-white/5 pt-4">
              <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                <span>4. General Governing Remarks & Executive Directives</span>
                <span className="text-[9.5px] text-indigo-400 font-bold uppercase tracking-wider">Executive Review</span>
              </label>
              
              <textarea
                value={activeReview.generalComment}
                onChange={(e) => handleUpdateReviewComment('generalComment', e.target.value)}
                placeholder="Write overall executive directives, guidelines or appreciation messages for the teacher..."
                rows={2}
                className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all font-sans leading-relaxed"
                disabled={activeReview.isVerified}
              />
              
              {!activeReview.isVerified && (
                <div className="flex flex-wrap gap-1.5">
                  {prefilledGeneralComments.map((comment, sIdx) => (
                    <button
                      key={sIdx}
                      onClick={() => handleUpdateReviewComment('generalComment', comment)}
                      className="text-[9.5px] font-bold text-indigo-300 bg-indigo-500/5 hover:bg-indigo-500/10 border border-indigo-500/15 py-1 px-2 rounded-lg cursor-pointer transition-all"
                    >
                      💡 {comment.slice(0, 30)}...
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Glowing holographic Security Stamp Approval panel */}
        <div className="mt-8 border-t border-white/15 pt-6 flex flex-col md:flex-row items-center justify-between gap-6 bg-slate-950 p-6 rounded-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 h-20 w-24 bg-indigo-500/5 rounded-bl-full pointer-events-none" />
          
          <div className="space-y-1.5 max-w-lg">
            <h3 className="text-sm font-black text-white flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Governing Audit Endorsement
            </h3>
            <p className="text-xs text-slate-400 leading-normal">
              By checking the endorsement button, you certify that the logged syllabus milestones, monthly scores scorebooks, and student portfolio notebooks for <strong className="text-white font-semibold">{selectedTeacher}</strong> during {selectedMonth} have been cross-verified and compliant with the governing framework guidelines.
            </p>
          </div>

          <div className="flex flex-col items-center shrink-0">
            <button
              onClick={handleToggleVerification}
              className={`py-3 px-8 rounded-xl text-xs font-black transition-all shadow-xl tracking-wide uppercase cursor-pointer flex items-center gap-2 border ${
                activeReview.isVerified
                  ? 'bg-rose-500/25 text-rose-300 border-rose-500/30 hover:bg-rose-500/30'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 border-emerald-400 hover:shadow-emerald-500/15 font-black hover:-translate-y-0.5'
              }`}
            >
              {activeReview.isVerified ? (
                <>
                  <span>REMOVE ENDORSEMENT SIGNATURE</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>ENDORSE & STAMP VERIFIED</span>
                </>
              )}
            </button>
            <span className="text-[10px] text-slate-500 font-bold mt-2">Active reviewed authority stamp: {currentUser.name}</span>
          </div>
        </div>

      </div>
      </>
      ) : (
        /* Academic Audit Calendar View */
        <div className="space-y-6 animate-fade-in text-left">
          
          {/* Dynamic Row: Metric summary cards at the top */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            
            <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900/40 border border-indigo-500/15 rounded-2xl p-4 shadow-md">
              <span className="text-[10px] uppercase font-extrabold text-indigo-400 block tracking-widest mb-1">TOTAL INSPECTIONS MAPPED</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white">{getPreparedTasks().length}</span>
                <span className="text-xs text-slate-400 font-bold">Notebook tasks</span>
              </div>
              <p className="text-[10.5px] text-slate-400 mt-2">Scheduled syllabus monthly worksheet portfolios</p>
            </div>

            <div className="bg-gradient-to-br from-emerald-950/40 to-slate-900/40 border border-emerald-500/15 rounded-2xl p-4 shadow-md">
              <span className="text-[10px] uppercase font-extrabold text-emerald-400 block tracking-widest mb-1">UPCOMING INSPECTIONS</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white">
                  {getPreparedTasks().filter(t => t.isUpcoming).length}
                </span>
                <span className="text-xs text-emerald-400 font-bold font-black">Active countdown</span>
              </div>
              <p className="text-[10.5px] text-slate-400 mt-2">Due on or after June 12, 2026</p>
            </div>

            <div className="bg-gradient-to-br from-rose-950/40 to-slate-900/40 border border-rose-500/15 rounded-2xl p-4 shadow-md">
              <span className="text-[10px] uppercase font-extrabold text-rose-400 block tracking-widest mb-1">PAST-DUE SESSIONS</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white">
                  {getPreparedTasks().filter(t => t.isPastDue).length}
                </span>
                <span className="text-xs text-rose-400 font-black animate-pulse">Urgent Remedial</span>
              </div>
              <p className="text-[10.5px] text-slate-400 mt-2">Missed 100% bounds from previous months</p>
            </div>

            <div className="bg-gradient-to-br from-amber-950/40 to-slate-900/40 border border-amber-500/15 rounded-2xl p-4 shadow-md">
              <span className="text-[10px] uppercase font-extrabold text-amber-400 block tracking-widest mb-1">ACADEMIC TESTS REGISTERED</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white">{getPreparedTests().length}</span>
                <span className="text-xs text-slate-400 font-bold">Chapters evaluations</span>
              </div>
              <p className="text-[10.5px] text-slate-400 mt-2">Assessed test dates with recorded score sheets</p>
            </div>

          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* LEFT 7 COLUMNS: Interactive Calendar Board */}
            <div className="lg:col-span-7 bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl space-y-6">
              
              {/* Calendar control header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <h3 className="text-md font-extrabold text-white flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    <span>Audit Schedule Planner</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Custom layout grid of school inspection dates</p>
                </div>

                <div className="flex items-center gap-1.5 bg-slate-950/60 p-1.5 rounded-2xl border border-white/5 self-end sm:self-auto">
                  {monthsList.map(m => (
                    <button
                      key={m}
                      onClick={() => {
                        setCalendarMonth(m);
                        setSelectedCalendarDate(1);
                      }}
                      className={`py-1.5 px-3.5 rounded-xl text-[10.5px] font-black transition-all cursor-pointer uppercase ${
                        calendarMonth === m
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                          : 'text-slate-300 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      {m.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Calendar Grid */}
              {(() => {
                const monthInfo = getMonthDetails(calendarMonth);
                const daysInMonth = monthInfo.days;
                const startDay = monthInfo.startDay;
                
                // Days array including leading empty padded boxes
                const cells: (number | null)[] = [];
                for (let i = 0; i < startDay; i++) {
                  cells.push(null);
                }
                for (let d = 1; d <= daysInMonth; d++) {
                  cells.push(d);
                }
                
                const monthNumStr = getMonthNumber(calendarMonth);

                return (
                  <div className="space-y-4">
                    
                    {/* Day labels header */}
                    <div className="grid grid-cols-7 gap-1 text-center text-[10.5px] font-black text-slate-400 uppercase tracking-wider bg-white/2 p-2 rounded-xl border border-white/5">
                      <div>Sun</div>
                      <div>Mon</div>
                      <div>Tue</div>
                      <div>Wed</div>
                      <div>Thu</div>
                      <div>Fri</div>
                      <div>Sat</div>
                    </div>

                    {/* Cells Grid */}
                    <div className="grid grid-cols-7 gap-1.5">
                      {cells.map((dayNum, cellIdx) => {
                        if (dayNum === null) {
                          return (
                            <div 
                              key={`empty-${cellIdx}`} 
                              className="aspect-square bg-slate-950/15 border border-white/2 rounded-xl opacity-20 pointer-events-none" 
                            />
                          );
                        }

                        // Determine events on this date
                        const dateStr = `2026-${monthNumStr}-${dayNum.toString().padStart(2, '0')}`;
                        const dayTasks = getPreparedTasks().filter(t => t.dueDate === dateStr);
                        const dayTests = getPreparedTests().filter(t => t.testDate === dateStr);
                        
                        const hasNotebooks = dayTasks.length > 0;
                        const hasTests = dayTests.length > 0;
                        const hasPastDueTasks = dayTasks.some(t => t.isPastDue);
                        
                        // Check if today (June 12, 2026 is our reference date)
                        const isToday = calendarMonth === 'June 2026' && dayNum === 12;
                        const isSelected = selectedCalendarDate === dayNum;

                        return (
                          <button
                            key={`day-${dayNum}`}
                            onClick={() => setSelectedCalendarDate(dayNum)}
                            className={`aspect-square p-1 sm:p-2 rounded-2xl flex flex-col justify-between items-start transition-all relative border outline-none text-left cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-xl shadow-emerald-500/5 shadow-2xl'
                                : isToday
                                  ? 'bg-indigo-500/10 border-indigo-500 text-indigo-200 animate-pulse'
                                  : hasPastDueTasks
                                    ? 'bg-rose-950/10 border-rose-500/30 hover:border-rose-400/40 text-slate-350 shadow-md'
                                    : 'bg-slate-950/40 border-white/5 hover:border-white/20 text-slate-300'
                            }`}
                          >
                            <span className={`text-[10px] font-black px-1 rounded-md ${
                              isToday ? 'bg-indigo-500 text-white' : 'text-slate-450 font-black'
                            }`}>
                              {dayNum}
                            </span>

                            {/* Mini Event Dots or Badges */}
                            <div className="flex flex-wrap gap-1 mt-auto w-full scale-90 sm:scale-100">
                              {dayTasks.map((t, ti) => (
                                <span 
                                  key={`t-${ti}`} 
                                  title={`Notebook Due: ${t.className} - ${t.subject}`}
                                  className={`h-1.5 w-1.5 rounded-full ${t.isCompleted ? 'bg-emerald-400' : 'bg-pink-500'}`}
                                />
                              ))}
                              {dayTests.map((test, tji) => (
                                <span 
                                  key={`test-${tji}`}
                                  title={`Exam scheduled: ${test.className} - ${test.testName}`}
                                  className={`h-1.5 w-1.5 rounded-full ${test.isUploaded ? 'bg-emerald-400' : 'bg-amber-400'}`}
                                />
                              ))}
                            </div>

                            {/* Exclamation badge for outstanding/past due tasks on this date */}
                            {hasPastDueTasks && (
                              <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[#0c111e] text-[9.5px] font-black shadow-md shadow-rose-500/30 animate-pulse" title="Overdue / Pending inspections!">
                                !
                              </span>
                            )}

                            {/* Flash alert for today (when no past-due alert conflicts) */}
                            {isToday && !hasPastDueTasks && (
                              <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-indigo-400 animate-ping" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Selected Date brief flyout card */}
                    {(() => {
                      const selDateStr = `2026-${monthNumStr}-${selectedCalendarDate.toString().padStart(2, '0')}`;
                      const selTasks = getPreparedTasks().filter(t => t.dueDate === selDateStr);
                      const selTests = getPreparedTests().filter(t => t.testDate === selDateStr);
                      const totalEventsCount = selTasks.length + selTests.length;

                      const formattedSelDate = new Date(selDateStr).toLocaleDateString(undefined, {
                        weekday: 'long', 
                        month: 'long', 
                        day: 'numeric',
                        year: 'numeric'
                      });

                      return (
                        <div className="bg-slate-950/60 p-4 border border-white/10 rounded-2xl space-y-3 mt-4">
                          <div className="flex items-center justify-between">
                            <span className="text-[10.5px] font-extrabold text-indigo-300 block uppercase tracking-wider">
                              DIAGNOSIS ON: {formattedSelDate} {calendarMonth === 'June 2026' && selectedCalendarDate === 12 ? '(TODAY)' : ''}
                            </span>
                            <span className="px-2 py-0.5 bg-white/5 rounded text-[9.5px] text-slate-350 font-bold">
                              {totalEventsCount} Event{totalEventsCount !== 1 ? 's' : ''} MAPPED
                            </span>
                          </div>

                          {totalEventsCount === 0 ? (
                            <p className="text-xs text-slate-500 italic py-2">
                              No official notebook checks or Chapter evaluations scheduled on this day. Use the date grid to find other milestone dates.
                            </p>
                          ) : (
                            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                              
                              {/* Notebook checks list */}
                              {selTasks.map((t, sIdx) => (
                                <div key={`task-${sIdx}`} className="bg-white/2 border border-white/5 p-3 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                  <div className="space-y-1">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <span className="px-1.5 py-0.5 bg-indigo-500/10 text-indigo-400 rounded text-[8.5px] font-bold uppercase">
                                        NOTEBOOK DUE
                                      </span>
                                      {t.isPastDue && (
                                        <span className="px-1.5 py-0.5 bg-rose-500/15 text-rose-400 rounded text-[8.5px] font-black uppercase animate-pulse flex items-center gap-1 border border-rose-500/25">
                                          <AlertTriangle className="w-2.5 h-2.5" />
                                          PAST DUE / UNCHECKED
                                        </span>
                                      )}
                                      <span className="text-xs font-black text-slate-100">{t.className} — {t.subject}</span>
                                    </div>
                                    <p className="text-[11px] text-slate-350">{t.title} ({t.description})</p>
                                    <p className="text-[10px] text-slate-500 font-bold">Teacher in charge: {t.teacherName}</p>
                                  </div>

                                  <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
                                    <div className="text-right">
                                      <span className="text-xs font-black text-indigo-300 block">{t.complianceRate}% Checked</span>
                                      <span className="text-[9.5px] text-slate-400 block mt-0.5">
                                        {t.checkedCount} of {t.totalStudents} books complete
                                      </span>
                                    </div>

                                    <button
                                      onClick={() => {
                                        const nudgeText = `Official Management Nudge sent to ${t.teacherName} regarding upcoming Grade ${t.className} - ${t.subject} notebook inspection deadline for '${t.title}'`;
                                        setAuditNotifications(prev => [
                                          { id: Date.now().toString(), text: nudgeText, date: '2026-06-12', type: 'success' },
                                          ...prev
                                        ]);
                                        setMgmtToast({
                                          type: 'success',
                                          text: `Inspections Nudge dispatched successfully to ${t.teacherName}!`
                                        });
                                      }}
                                      className="p-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-lg hover:text-white cursor-pointer transition-all border border-indigo-500/20"
                                      title="Nudge Faculty"
                                    >
                                      <Bell className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ))}

                              {/* Test scores upload checks */}
                              {selTests.map((test, stIdx) => (
                                <div key={`test-${stIdx}`} className="bg-white/2 border border-white/5 p-3 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                      <span className="px-1.5 py-0.5 bg-amber-500/10 text-amber-400 rounded text-[8.5px] font-bold uppercase">
                                        TEST SCORES DUE
                                      </span>
                                      <span className="text-xs font-black text-slate-100">{test.className} — {test.subject}</span>
                                    </div>
                                    <p className="text-[11px] text-slate-350">{test.testName} (Max Marks: {test.maxMarks})</p>
                                    <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Assigned Teacher: {test.teacherName}</p>
                                  </div>

                                  <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
                                    <div className="text-right">
                                      <span className="text-xs font-black text-amber-300 block">{test.uploadRate}% Entered</span>
                                      <span className="text-[9.5px] text-slate-400 block mt-0.5">
                                        {test.enteredCount} of {test.totalStudents} rosters scored
                                      </span>
                                    </div>

                                    <button
                                      onClick={() => {
                                        const nudgeText = `Official Management Scorebook Nudge issued to ${test.teacherName} regarding pending class score entries for examination '${test.testName}' (Grade ${test.className} - ${test.subject})`;
                                        setAuditNotifications(prev => [
                                          { id: Date.now().toString(), text: nudgeText, date: '2026-06-12', type: 'success' },
                                          ...prev
                                        ]);
                                        setMgmtToast({
                                          type: 'success',
                                          text: `Roster score book alert sent to ${test.teacherName}!`
                                        });
                                      }}
                                      className="p-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 rounded-lg hover:text-white cursor-pointer transition-all border border-amber-500/20"
                                      title="Nudge Faculty"
                                    >
                                      <Bell className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ))}

                            </div>
                          )}
                        </div>
                      );
                    })()}

                  </div>
                );
              })()}

            </div>

            {/* RIGHT 5 COLUMNS: Past-Due Gaps & Upcoming Task Feeds */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* PAST-DUE GAPS BOARD */}
              <div className="bg-gradient-to-br from-slate-900 via-rose-950/10 to-slate-950 border border-rose-500/25 rounded-3xl p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-rose-500/15 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-rose-500/10 text-rose-400 rounded-xl">
                      <AlertTriangle className="w-4 h-4 animate-pulse" />
                    </span>
                    <div>
                      <h4 className="text-sm font-black text-white leading-tight">Critical Past-Due Audits</h4>
                      <p className="text-[10px] text-slate-400">Unresolved inspection targets from earlier periods</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/15 rounded-full text-[9px] font-black">
                    {getPreparedTasks().filter(t => t.isPastDue).length} BLOCKED SESSIONS
                  </span>
                </div>

                <div className="space-y-3 max-h-80 overflow-y-auto pr-1 scrollbar-thin">
                  {getPreparedTasks().filter(t => t.isPastDue).length === 0 ? (
                    <div className="text-center py-6">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                      <p className="text-xs font-bold text-slate-300">All past-due periods clear!</p>
                      <p className="text-[10px] text-slate-500 mt-1">Syllabus checklists have achieved 100% bounds.</p>
                    </div>
                  ) : (
                    getPreparedTasks().filter(t => t.isPastDue).map((task, pdIdx) => {
                      return (
                        <div key={`pd-${pdIdx}`} className="bg-rose-500/5 hover:bg-rose-500/10 border-2 border-dashed border-rose-500/25 p-4 rounded-2xl space-y-3 transition-colors text-left relative overflow-hidden">
                          <div className="absolute top-0 right-0 h-8 w-8 bg-rose-500/5 rounded-bl-full pointer-events-none" />
                          
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-xs font-black text-rose-300 block">{task.className} — {task.subject}</span>
                              <span className="text-[11px] text-slate-300 block font-normal mt-0.5">{task.title}</span>
                              <span className="text-[9.5px] text-slate-500 font-bold block mt-1">Due Date: {new Date(task.dueDate).toLocaleDateString()}</span>
                            </div>
                            <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 rounded-md text-[9px] font-black tracking-wider uppercase">
                              PAST DUE
                            </span>
                          </div>

                          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-rose-500/10 space-y-1 text-[11px] font-bold">
                            <p className="text-slate-300 flex items-center justify-between">
                              <span>Checking completed:</span>
                              <span className="text-rose-400 font-extrabold">{task.complianceRate}%</span>
                            </p>
                            <p className="text-slate-400 font-normal flex items-center justify-between text-[10px]">
                              <span>Discrepancies found:</span>
                              <span className="text-amber-400 font-semibold">
                                {task.incompleteCount} Incomplete | {task.missingCount} Missing
                              </span>
                            </p>
                            <p className="text-slate-500 font-normal text-[9.5px] mt-1 pt-1.5 border-t border-white/5 font-bold">
                              ⚠️ Auditable faculty: <strong className="text-slate-300 font-bold">{task.teacherName}</strong> is delinquent.
                            </p>
                          </div>

                          <div className="flex items-center gap-2 pt-1.5">
                            <button
                              onClick={() => {
                                const alarmText = `Official Delinquency Discrepancy Notice served directly to ${task.teacherName} regarding unchecked notebooks in ${task.className} - ${task.subject} from ${calendarMonth}`;
                                setAuditNotifications(prev => [
                                  { id: Date.now().toString(), text: alarmText, date: '2026-06-12', type: 'alert' },
                                  ...prev
                                ]);
                                setMgmtToast({
                                  type: 'amber',
                                  text: `Discrepancy notice issued to ${task.teacherName}!`
                                });
                              }}
                              className="flex-1 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-white rounded-lg text-[10px] font-black border border-rose-500/20 cursor-pointer transition-all uppercase tracking-wider text-center"
                            >
                              Dispatch Discrepancy Notice
                            </button>
                            <button
                              onClick={() => {
                                setMgmtToast({
                                  type: 'info',
                                  text: `Requested live verification files for Grade ${task.className} portfolios.`
                                });
                              }}
                              className="px-2.5 py-1.5 bg-slate-900 border border-white/5 hover:border-white/10 hover:bg-slate-800 text-slate-350 rounded-lg text-[10px] font-bold cursor-pointer hover:text-white transition-all"
                              title="Audit Worksheet files"
                            >
                              Audit Files
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* UPCOMING DEADLINES COUNTDOWN */}
              <div className="bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
                      <Clock className="w-4 h-4" />
                    </span>
                    <div>
                      <h4 className="text-sm font-black text-white leading-tight">Upcoming Inspection Countdowns</h4>
                      <p className="text-[10px] text-slate-400">Inspections due in the next 30 days</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 max-h-80 overflow-y-auto pr-1 scrollbar-thin text-left">
                  {getPreparedTasks().filter(t => t.isUpcoming).length === 0 ? (
                    <p className="text-xs text-slate-500 italic py-4 text-center">No upcoming inspections found for this school term month.</p>
                  ) : (
                    getPreparedTasks().filter(t => t.isUpcoming).map((task, upIdx) => {
                      const diffTime = new Date(task.dueDate).getTime() - new Date('2026-06-12').getTime();
                      const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                      return (
                        <div key={`upc-${upIdx}`} className="bg-white/3 border border-white/5 p-3.5 rounded-2xl space-y-3 relative overflow-hidden text-left">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-black text-white block">{task.className} — {task.subject}</span>
                              <span className="text-[10.5px] text-slate-400 block mt-0.5">{task.title}</span>
                            </div>
                            <div className="text-right shrink-0">
                              <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/10 rounded-md text-[9px] font-black">
                                {daysLeft <= 0 ? "Due Today" : `${daysLeft} DAYS LEFT`}
                              </span>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] font-bold text-slate-400">
                              <span>Assigned teacher: {task.teacherName}</span>
                              <span className="text-indigo-300 font-extrabold">{task.complianceRate}% Ready</span>
                            </div>
                            <div className="h-1.5 w-full bg-slate-950/60 rounded-full overflow-hidden flex">
                              <div 
                                className="bg-indigo-500 rounded-full h-full transition-all duration-500" 
                                style={{ width: `${task.complianceRate}%` }}
                              />
                            </div>
                            <span className="text-[9.5px] text-slate-500 block font-bold">Checkpoint Target Date: {new Date(task.dueDate).toLocaleDateString()}</span>
                          </div>

                          <div className="flex items-center justify-between pt-1">
                            <span className="text-[9.5px] text-slate-400 font-semibold italic">
                              {task.checkedCount} / {task.totalStudents} portfolios audited
                            </span>
                            <button
                              onClick={() => {
                                const warnText = `Pre-inspection system notice pushed to ${task.teacherName} for Grade ${task.className} notebook milestones (Due: ${task.dueDate})`;
                                setAuditNotifications(prev => [
                                  { id: Date.now().toString(), text: warnText, date: '2026-06-12', type: 'success' },
                                  ...prev
                                ]);
                                setMgmtToast({
                                  type: 'success',
                                  text: `Milestone check-in pushed to ${task.teacherName}!`
                                });
                              }}
                              className="px-3 py-1 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-lg text-[9.5px] font-black border border-indigo-500/20 cursor-pointer flex items-center gap-1.5 transition-all uppercase"
                            >
                              <Bell className="w-3 h-3" />
                              <span>Nudge Early check</span>
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* LOWER SECTION: NOTIFICATION FEED & CORRECTION LOGS ACTIVE PANEL */}
          <div className="bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h4 className="text-sm font-black text-white flex items-center gap-2">
                  <ClipboardCheck className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>Management Academic Audit Activity Feed Logs</span>
                </h4>
                <p className="text-xs text-slate-400">Live transaction records of system nudges and audit reminders</p>
              </div>
              <button
                onClick={() => {
                  if (confirm("Reset management alert audit log feed?")) {
                    setAuditNotifications([]);
                    setMgmtToast({ type: 'info', text: 'Audit feed logs wiped.' });
                  }
                }}
                className="text-[9.5px] text-slate-500 hover:text-rose-400 font-bold border border-white/5 hover:border-rose-500/15 py-1 px-2.5 rounded-lg cursor-pointer transition-all"
              >
                Clear Audit Feed
              </button>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {auditNotifications.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-4 text-center">Audit log is clear. Execute any "Nudge" or "Discrepancy" action above to record items.</p>
              ) : (
                auditNotifications.map((notif, nIdx) => (
                  <div key={nIdx} className="bg-slate-950/40 p-2.5 rounded-xl border border-white/5 flex items-start gap-2.5 text-xs">
                    <span className="shrink-0 mt-0.5">
                      {notif.type === 'alert' ? '🚨' : '✉️'}
                    </span>
                    <div className="leading-tight flex-1">
                      <p className="font-bold text-slate-200">{notif.text}</p>
                      <p className="text-[10px] text-slate-500 font-semibold mt-0.5">Logged: {notif.date} | Active Verified Authority: {currentUser.name}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Custom Floating toast alert specific for Calendar View */}
          {mgmtToast && (
            <div id="calendar-toast-banner" className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-slate-950 border border-emerald-500/30 px-5 py-4 rounded-2xl shadow-xl animate-fade-in max-w-sm">
              {mgmtToast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
              {mgmtToast.type === 'amber' && <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 animate-bounce" />}
              {mgmtToast.type === 'info' && <Clock className="w-5 h-5 text-sky-400 shrink-0" />}
              <span className="text-xs font-bold text-white tracking-wide pr-1">{mgmtToast.text}</span>
              <button 
                onClick={() => setMgmtToast(null)}
                className="text-slate-400 hover:text-white ml-auto cursor-pointer p-1 rounded-full hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
