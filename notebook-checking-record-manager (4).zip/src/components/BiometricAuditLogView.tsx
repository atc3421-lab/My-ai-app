import React, { useState } from 'react';
import { AuthenticationAuditLog } from '../types';
import { 
  Fingerprint, 
  Camera, 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  CheckCircle2, 
  Laptop, 
  Smartphone, 
  Globe, 
  RefreshCw,
  Cpu,
  ShieldCheck,
  Calendar,
  AlertCircle
} from 'lucide-react';

interface BiometricAuditLogViewProps {
  logs: AuthenticationAuditLog[];
  onClearLogs?: () => void;
}

export default function BiometricAuditLogView({ logs, onClearLogs }: BiometricAuditLogViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'admin' | 'teacher' | 'management'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'thumb' | 'face'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [revokedDevices, setRevokedDevices] = useState<string[]>([]);
  const [showNotification, setShowNotification] = useState<string | null>(null);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      triggerToast('Security matrices synchronized with sandboxed telemetry module.');
    }, 600);
  };

  const triggerToast = (msg: string) => {
    setShowNotification(msg);
    setTimeout(() => setShowNotification(null), 3500);
  };

  const toggleRevokeDevice = (deviceId: string) => {
    if (revokedDevices.includes(deviceId)) {
      setRevokedDevices(prev => prev.filter(id => id !== deviceId));
      triggerToast(`Device node [${deviceId}] block list revoked. Hardware unlocked.`);
    } else {
      setRevokedDevices(prev => [...prev, deviceId]);
      triggerToast(`Device node [${deviceId}] successfully placed in sandbox block list.`);
    }
  };

  // Calculations for Stats Cards
  const totalLogs = logs.length;
  const thumbCount = logs.filter(l => l.biometricType === 'thumb').length;
  const faceCount = logs.filter(l => l.biometricType === 'face').length;
  const activeNodes = Array.from(new Set(logs.map(l => l.deviceId))).length;

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          log.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          log.deviceId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (log.ipAddress && log.ipAddress.includes(searchTerm));
    
    const matchesRole = roleFilter === 'all' || log.role === roleFilter;
    const matchesType = typeFilter === 'all' || log.biometricType === typeFilter;
    
    return matchesSearch && matchesRole && matchesType;
  });

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `samata_biometric_audit_log_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    triggerToast('JSON Audit Matrix report exported successfully.');
  };

  return (
    <div className="space-y-6" id="biometric-audit-view">
      
      {/* Dynamic Toast System */}
      {showNotification && (
        <div className="fixed bottom-6 right-6 z-50 bg-indigo-950 border border-indigo-500/30 text-indigo-300 font-bold text-xs rounded-xl py-3 px-5 shadow-2xl flex items-center gap-2 animate-bounce">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{showNotification}</span>
        </div>
      )}

      {/* Main Header Control Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-900/60 border border-white/5 p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
              <Fingerprint className="w-5 h-5 animate-pulse" />
            </span>
            <div>
              <h3 className="text-lg font-black text-white tracking-tight flex items-center gap-2">
                Unified Authentication Audit Log
              </h3>
              <p className="text-slate-400 text-xs mt-0.5">
                Central Cryptographic Ledger tracking biometric authentications and hardware node logins.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleRefresh}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-slate-350 hover:text-white hover:bg-white/5 text-xs font-bold transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Telemetry check</span>
          </button>
          
          <button
            type="button"
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-505/20 hover:bg-indigo-500 border border-indigo-500/30 text-indigo-200 hover:text-white rounded-xl text-xs font-black transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Registry JSON</span>
          </button>

          {onClearLogs && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Are you sure you want to completely flush the sandboxed biometric login ledger? This action is irreversible.")) {
                  onClearLogs();
                  triggerToast('Ledger historical log directory purged.');
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-500/10 hover:bg-rose-500 hover:text-white border border-rose-500/20 rounded-xl text-rose-350 text-xs font-bold transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset Trails</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI 1: TOTAL */}
        <div className="bg-slate-900/50 border border-white/5 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Total Biometric Logins</span>
            <span className="text-2xl font-black text-white mt-1 block font-mono">{totalLogs}</span>
            <span className="text-[10px] text-emerald-400 font-bold mt-1.5 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> 100% Verified Access
            </span>
          </div>
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
            <Cpu className="w-6 h-6" />
          </div>
        </div>

        {/* KPI 2: THUMBPRINT */}
        <div className="bg-slate-900/50 border border-white/5 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Fingerprint Matrix Match</span>
            <span className="text-2xl font-black text-white mt-1 block font-mono">{thumbCount}</span>
            <span className="text-[10px] text-slate-400 block mt-1.5">
              {(totalLogs > 0 ? (thumbCount / totalLogs * 100).toFixed(0) : 0)}% of login distribution
            </span>
          </div>
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
            <Fingerprint className="w-6 h-6 animate-pulse" />
          </div>
        </div>

        {/* KPI 3: FACE RECOGNITION */}
        <div className="bg-slate-900/50 border border-white/5 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Webcam Facial Alignment</span>
            <span className="text-2xl font-black text-white mt-1 block font-mono">{faceCount}</span>
            <span className="text-[10px] text-slate-400 block mt-1.5">
              {(totalLogs > 0 ? (faceCount / totalLogs * 100).toFixed(0) : 0)}% of login distribution
            </span>
          </div>
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl">
            <Camera className="w-6 h-6" />
          </div>
        </div>

        {/* KPI 4: DEVICE NODES */}
        <div className="bg-slate-900/50 border border-white/5 p-4.5 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Authenticated Hardware Nodes</span>
            <span className="text-2xl font-black text-white mt-1 block font-mono">{activeNodes}</span>
            <span className="text-[10px] text-indigo-300 font-bold mt-1.5 flex items-center gap-1">
              <Globe className="w-3 h-3 animate-spin" /> Live Device Sync
            </span>
          </div>
          <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl">
            <Laptop className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* SEARCH AND FILTERS */}
      <div className="bg-slate-900/40 border border-white/5 p-4 rounded-xl flex flex-col md:flex-row gap-3">
        
        {/* Search input */}
        <div className="flex-1 relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-550">
            <Search className="w-4 h-4 text-slate-400" />
          </span>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter logs by operator name, IP address, hardware ID..."
            className="w-full bg-slate-950 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 transition-all"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          
          <div className="flex items-center bg-slate-950 border border-white/10 rounded-xl px-2.5 py-1.5">
            <Filter className="w-3 h-3 text-indigo-400 mr-2" />
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as any)}
              className="bg-transparent border-none text-xs text-slate-300 focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-950 text-slate-200">All Roles</option>
              <option value="admin" className="bg-slate-950 text-slate-200">Administrative Desk</option>
              <option value="teacher" className="bg-slate-950 text-slate-200">Faculty Members</option>
              <option value="management" className="bg-slate-950 text-slate-200">School Officials (VP/Principal)</option>
            </select>
          </div>

          <div className="flex items-center bg-slate-950 border border-white/10 rounded-xl px-2.5 py-1.5">
            <Cpu className="w-3 h-3 text-emerald-400 mr-2" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as any)}
              className="bg-transparent border-none text-xs text-slate-300 focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-950 text-slate-200">All Scanners</option>
              <option value="thumb" className="bg-slate-950 text-slate-200">Fingerprint Sensor</option>
              <option value="face" className="bg-slate-950 text-slate-200">Face Scan Align</option>
            </select>
          </div>

        </div>

      </div>

      {/* MATRIX AUDIT RECORD TABLE */}
      <div className="bg-slate-900/60 border border-white/5 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-white/10 text-[10px] uppercase font-black text-slate-400 tracking-wider">
                <th className="py-3 px-4">Audit ID</th>
                <th className="py-3 px-4">Operator Name</th>
                <th className="py-3 px-4 text-center">Auth Status</th>
                <th className="py-3 px-4 text-center">Method</th>
                <th className="py-3 px-4">Hardware node Signature</th>
                <th className="py-3 px-4">Device Details</th>
                <th className="py-3 px-4">Source IP</th>
                <th className="py-3 px-4">Access Time (UTC)</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLogs.length > 0 ? (
                filteredLogs.map(log => {
                  const isBlackListed = revokedDevices.includes(log.deviceId);
                  return (
                    <tr 
                      key={log.id} 
                      className={`text-xs hover:bg-white/2 transition-colors ${
                        isBlackListed ? 'bg-rose-950/20 opacity-80' : ''
                      }`}
                    >
                      {/* LOG ID */}
                      <td className="py-3.5 px-4 font-mono font-bold text-indigo-400">
                        {log.id}
                      </td>

                      {/* OPERATOR NAME */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white leading-none">{log.name}</div>
                        <div className="text-[10px] text-slate-400 font-medium font-mono mt-1">
                          @{log.username} • <span className="uppercase text-[9px] px-1 py-0.2 bg-slate-950 rounded text-slate-300 font-extrabold">{log.role}</span>
                        </div>
                      </td>

                      {/* AUTH STATUS */}
                      <td className="py-3.5 px-4 text-center">
                        {isBlackListed ? (
                          <span className="inline-flex items-center gap-1 text-[9px] uppercase font-black px-2 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400">
                            Blocked Node
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[9px] uppercase font-black px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                            success
                          </span>
                        )}
                      </td>

                      {/* METHOD */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex justify-center">
                          {log.biometricType === 'thumb' ? (
                            <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/25 font-bold flex items-center gap-1 text-[10px]">
                              <Fingerprint className="w-3 h-3 text-indigo-400" /> Thumb
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/25 font-bold flex items-center gap-1 text-[10px]">
                              <Camera className="w-3 h-3 text-emerald-400" /> Face
                            </span>
                          )}
                        </div>
                      </td>

                      {/* HARDWARE SIGNATURE */}
                      <td className="py-3.5 px-4 font-mono text-[10px] text-indigo-300 font-bold">
                        {log.deviceId}
                      </td>

                      {/* DEVICE DETAILS */}
                      <td className="py-3.5 px-4 font-medium text-slate-350 font-mono text-[10.5px]">
                        {log.deviceDetails || 'Sandbox Verified Desktop'}
                      </td>

                      {/* IP ADDRESS */}
                      <td className="py-3.5 px-4 font-mono font-medium text-indigo-200">
                        {log.ipAddress || '127.0.0.1'}
                      </td>

                      {/* ACCESS TIME */}
                      <td className="py-3.5 px-4 text-slate-400 font-mono text-[10px]">
                        {new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString()}
                      </td>

                      {/* ACTION CELL */}
                      <td className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => toggleRevokeDevice(log.deviceId)}
                          className={`px-2.5 py-1 text-[10px] font-black rounded-lg border transition-all cursor-pointer ${
                            isBlackListed 
                              ? 'bg-emerald-500/10 hover:bg-emerald-500 hover:text-white border-emerald-500/30 text-emerald-400' 
                              : 'bg-rose-500/10 hover:bg-rose-550 hover:text-white border-rose-500/30 text-rose-400'
                          }`}
                        >
                          {isBlackListed ? 'Unlock Device' : 'De-authorize'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center">
                    <div className="flex flex-col items-center justify-center space-y-2 text-slate-500">
                      <AlertCircle className="w-8 h-8 text-indigo-400 animate-pulse" />
                      <p className="text-xs font-extrabold max-w-md">
                        No biometric event patterns match standard criteria or search keywords in active directories.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setSearchTerm('');
                          setRoleFilter('all');
                          setTypeFilter('all');
                        }}
                        className="px-3.5 py-1.5 mt-2 bg-indigo-500/20 hover:bg-indigo-500 text-indigo-200 hover:text-white rounded-lg text-[10px] font-bold"
                      >
                        Reset Search Filters
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Table summary count */}
        <div className="bg-slate-950 p-4 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-2 text-slate-400 text-xs font-semibold">
          <span>Displaying <strong>{filteredLogs.length}</strong> of <strong>{logs.length}</strong> authenticated biometric transactions.</span>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-[10px] text-slate-400 font-mono">Sandbox Node Server Active. Ledger validated.</span>
          </div>
        </div>
      </div>

    </div>
  );
}
