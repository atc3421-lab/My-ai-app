import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { 
  SchoolClass, 
  UserSession,
  ManagementReview
} from '../types';
import { TeacherAllotment, SAMPLE_TEACHER_ALLOTMENTS } from '../data/teacherData';
import { 
  OFFICIAL_SYLLABUS_BANK, 
  APRIL_SYLLABUS_BANK,
  JUNE_SYLLABUS_BANK
} from '../data/officialSyllabus';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  CheckSquare, 
  TrendingUp, 
  ArrowRightLeft, 
  Users, 
  BookOpen, 
  HelpCircle, 
  ShieldCheck, 
  User, 
  AlertCircle,
  FileSpreadsheet,
  XCircle,
  PlusCircle,
  ChevronRight,
  Filter,
  Check,
  Send,
  MessageSquare,
  Printer,
  Search,
  FileText,
  Calendar
} from 'lucide-react';

interface SyllabusCompletionTabProps {
  classes: SchoolClass[];
  allotments: TeacherAllotment[];
  currentUser: UserSession | null;
  topicStates?: SyllabusTopicState[];
  onUpdateTopicStates?: (states: SyllabusTopicState[]) => void;
  managementReviews?: ManagementReview[];
}

// In-memory / LocalStorage state schema for Syllabus Completion tracking
export interface SyllabusTopicState {
  id: string; // `grade_subject_month_topicIndex`
  grade: string; // e.g. "Grade X"
  subject: string;
  month: string; // e.g. "June 2026"
  topicText: string;
  isCompleted: boolean;
  updatedBy: string;
  updatedAt: string;
  carryForwardRequest?: {
    targetMonth: string;
    reason: string;
    status: 'pending' | 'approved' | 'rejected';
    feedback?: string;
    decidedBy?: string;
    decidedAt?: string;
  };
}

export default function SyllabusCompletionTab({
  classes,
  allotments,
  currentUser,
  topicStates: externalTopicStates,
  onUpdateTopicStates,
  managementReviews,
}: SyllabusCompletionTabProps) {
  const isTeacher = currentUser?.role === 'teacher';
  const isManagement = currentUser?.role === 'management';
  const isAdmin = currentUser?.role === 'admin';
  const canApprove = isManagement || isAdmin;
  const activeAllotments = allotments && allotments.length > 0 ? allotments : SAMPLE_TEACHER_ALLOTMENTS;

  // Active simulated or local date variables
  const [simulatedDay, setSimulatedDay] = useState<number>(() => {
    const saved = localStorage.getItem('nb_audit_simulated_day');
    return saved ? parseInt(saved) : new Date().getDate();
  });

  // Track storage change to sync simulation with calendar view
  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('nb_audit_simulated_day');
      if (saved) {
        const val = parseInt(saved);
        if (val !== simulatedDay) {
          setSimulatedDay(val);
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [simulatedDay]);

  const handleSimulatedDayChange = (day: number) => {
    setSimulatedDay(day);
    localStorage.setItem('nb_audit_simulated_day', day.toString());
    window.dispatchEvent(new Event('storage'));
  };

  // State keys 
  const [selectedMonth, setSelectedMonth] = useState<string>('June 2026');
  
  // Clean Grade Mapping Helper: Map classroom names (e.g. "X O", "V D") to standardized syllabus grades (e.g. "Grade X", "Grade V")
  const mapClassToSyllabusGrade = (className: string): string => {
    const cleanClassName = className.replace('Grade ', '').trim();
    const spaceIdx = cleanClassName.indexOf(' ');
    const firstWord = spaceIdx !== -1 ? cleanClassName.substring(0, spaceIdx) : cleanClassName;
    // Map roman numerals to Grade standard
    const gradeMap: { [key: string]: string } = {
      'I': 'Grade I', 'II': 'Grade II', 'III': 'Grade III', 'IV': 'Grade IV', 'V': 'Grade V',
      'VI': 'Grade VI', 'VII': 'Grade VII', 'VIII': 'Grade VIII', 'IX': 'Grade IX', 'X': 'Grade X',
    };
    return gradeMap[firstWord.toUpperCase()] || `Grade ${firstWord}`;
  };

  // State elements
  const [topicStatesLocal, setTopicStatesLocal] = useState<SyllabusTopicState[]>(() => {
    const saved = localStorage.getItem('nb_syllabus_topic_states');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [];
  });

  const topicStates = externalTopicStates || topicStatesLocal;

  const setTopicStates = (updatedList: SyllabusTopicState[]) => {
    if (onUpdateTopicStates) {
      onUpdateTopicStates(updatedList);
    } else {
      setTopicStatesLocal(updatedList);
      localStorage.setItem('nb_syllabus_topic_states', JSON.stringify(updatedList));
    }
  };

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Determine subjects taught by logged-in teacher
  const getTeacherSubjectsList = () => {
    if (!currentUser || currentUser.role !== 'teacher') return [];
    
    const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
      if (!allotTeacher || !userTeacher) return false;
      const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
      const cleanAllot = cleanStr(allotTeacher);
      const cleanUser = cleanStr(userTeacher);
      if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
      
      const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
      const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
      
      for (const allotW of allotWords) {
        for (const userW of userWords) {
          if (allotW.includes(userW) || userW.includes(allotW)) return true;
        }
      }
      return false;
    };

    const isClassMatchAllotment = (className: string, allotmentGrade: string): boolean => {
      if (!className || !allotmentGrade) return false;
      const clean = (s: string) => s.toLowerCase().replace(/\bgrade\b/g, '').replace(/[^a-z0-9]/g, '').trim();
      const c1 = clean(className);
      const c2 = clean(allotmentGrade);
      return c1 === c2;
    };

    const list: { classId: string; className: string; syllabusGrade: string; subject: string; classNames?: string[] }[] = [];
    activeAllotments.forEach(allot => {
      // Find actual class in list supporting both direct match and "Grade " prefix mismatch
      const matchedClass = classes.find(c => isClassMatchAllotment(c.name, allot.grade));
      
      Object.entries(allot.subjects).forEach(([subName, teachName]) => {
        const isMatchedTeacher = isTeacherNameMatched(teachName, currentUser.name);
        if (isMatchedTeacher) {
          const sylGrade = mapClassToSyllabusGrade(allot.grade);
          list.push({
            classId: matchedClass?.id || allot.grade,
            className: matchedClass?.name || allot.grade,
            syllabusGrade: sylGrade,
            subject: subName
          });
        }
      });
    });
    
    // Remove duplicates by combining className list for same standardized grade and subject
    const uniqueList: typeof list = [];
    list.forEach(item => {
      const existing = uniqueList.find(t => t.syllabusGrade === item.syllabusGrade && t.subject === item.subject);
      if (existing) {
        if (existing.classNames && !existing.classNames.includes(item.className)) {
          existing.classNames.push(item.className);
        } else if (!existing.classNames) {
          existing.classNames = [existing.className, item.className];
        }
      } else {
        uniqueList.push({
          ...item,
          classNames: [item.className]
        });
      }
    });

    // Format uniqueList's className to combine them neatly
    uniqueList.forEach(item => {
      if (item.classNames && item.classNames.length > 1) {
        const suffixes = item.classNames.map(cn => {
          const parts = cn.split(' ');
          return parts[parts.length - 1]; // e.g. "O", "T"
        });
        const prefix = item.classNames[0].split(' ').slice(0, -1).join(' '); // e.g. "Grade IX"
        item.className = `${prefix} ${suffixes.join(' & ')}`;
      }
    });

    return uniqueList;
  };

  const mySubjects = getTeacherSubjectsList();

  // Active Subject Selector filters for teacher or admin view
  const [activeGradeFilter, setActiveGradeFilter] = useState<string>(() => {
    if (isTeacher && mySubjects.length > 0) return mySubjects[0].syllabusGrade;
    return 'Grade X';
  });

  const [activeSubjectFilter, setActiveSubjectFilter] = useState<string>(() => {
    if (isTeacher && mySubjects.length > 0) return mySubjects[0].subject;
    return 'English';
  });

  // Modal / Request form states
  const [showRequestModal, setShowRequestModal] = useState<boolean>(false);
  const [requestTopicIndex, setRequestTopicIndex] = useState<number>(-1);
  const [requestTopicText, setRequestTopicText] = useState<string>('');
  const [requestTargetMonth, setRequestTargetMonth] = useState<string>('July 2026');
  const [requestReason, setRequestReason] = useState<string>('');

  // Principal feedback comment states
  const [principalFeedback, setPrincipalFeedback] = useState<{ [id: string]: string }>({});

  // Syllabus Completion Print Report State variables
  const [showPrintReportModal, setShowPrintReportModal] = useState<boolean>(false);
  const [selectedTeacherPrint, setSelectedTeacherPrint] = useState<string>('All Teachers');
  const [selectedPrintMonths, setSelectedPrintMonths] = useState<string[]>(['April 2026', 'June 2026']);
  const [printLayoutDensity, setPrintLayoutDensity] = useState<'normal' | 'dense'>('dense');
  const [printError, setPrintError] = useState<string | null>(null);

  // Robust teacher name matcher
  const isTeacherMatched = (allotTeacher: string | undefined, selectedTeacherName: string): boolean => {
    if (!allotTeacher || !selectedTeacherName) return false;
    const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
    const cleanAllot = cleanStr(allotTeacher);
    const cleanSelected = cleanStr(selectedTeacherName);
    if (cleanAllot.includes(cleanSelected) || cleanSelected.includes(cleanAllot)) return true;
    
    const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
    const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 2 && !ignoreList.includes(w));
    const selectedWords = selectedTeacherName.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 2 && !ignoreList.includes(w));
    
    for (const allotW of allotWords) {
      for (const selectW of selectedWords) {
        if (allotW.includes(selectW) || selectW.includes(allotW)) return true;
      }
    }
    return false;
  };

  // Get unique teachers list
  const getTeachersList = () => {
    const list = new Set<string>();
    activeAllotments.forEach(allot => {
      Object.values(allot.subjects).forEach(teacherName => {
        if (teacherName && teacherName.trim()) {
          list.add(teacherName.replace(/\.$/, '').trim());
        }
      });
    });
    return Array.from(list).sort();
  };

  const getTopicStateForPrint = (grade: string, subject: string, month: string, index: number, topicText: string) => {
    const id = `${grade}_${subject}_${month}_${index}`;
    const found = topicStates.find(s => s.id === id);
    if (found) return found;

    return {
      id,
      grade,
      subject,
      month,
      topicText,
      isCompleted: false,
      updatedBy: 'Not set',
      updatedAt: ''
    };
  };

  // Compile statistics for a specific teacher and months
  const getSyllabusStatsForTeacher = (teacherName: string, months: string[]) => {
    const teacherAllots: { grade: string; syllabusGrade: string; subject: string }[] = [];
    
    activeAllotments.forEach(allot => {
      Object.entries(allot.subjects).forEach(([subName, teachName]) => {
        if (isTeacherMatched(teachName, teacherName)) {
          const sylGrade = mapClassToSyllabusGrade(allot.grade);
          const exists = teacherAllots.some(item => item.grade === allot.grade && item.subject === subName);
          if (!exists) {
            teacherAllots.push({
              grade: allot.grade,
              syllabusGrade: sylGrade,
              subject: subName
            });
          }
        }
      });
    });

    const rows: {
      grade: string;
      syllabusGrade: string;
      subject: string;
      month: string;
      totalTopics: number;
      completedTopics: number;
      topicsList: { text: string; isCompleted: boolean }[];
    }[] = [];

    teacherAllots.forEach(allot => {
      months.forEach(month => {
        const topics = getTopicsForFilter(allot.syllabusGrade, allot.subject, month);
        let completedCount = 0;
        const topicsList = topics.map((t, idx) => {
          const state = getTopicStateForPrint(allot.syllabusGrade, allot.subject, month, idx, t);
          if (state.isCompleted) completedCount++;
          return {
            text: t,
            isCompleted: state.isCompleted
          };
        });

        rows.push({
          grade: allot.grade,
          syllabusGrade: allot.syllabusGrade,
          subject: allot.subject,
          month,
          totalTopics: topics.length,
          completedTopics: completedCount,
          topicsList
        });
      });
    });

    return rows;
  };

  // Helper inside the syllabus retrieval dictionary
  const getTopicsForFilter = (grade: string, subject: string, month: string) => {
    // April, June and July have their respective syllabus banks
    const bank = month === 'April 2026' ? APRIL_SYLLABUS_BANK : (month === 'June 2026' ? JUNE_SYLLABUS_BANK : (month === 'July 2026' ? OFFICIAL_SYLLABUS_BANK : {}));
    const gradeItems = bank[grade] || [];
    const matched = gradeItems.find(item => item.subject.toLowerCase() === subject.toLowerCase() || 
                                           item.subject.toLowerCase().includes(subject.toLowerCase()) || 
                                           subject.toLowerCase().includes(item.subject.toLowerCase()));
    return matched ? matched.topics : [];
  };

  // Retrieve dynamic list of topics for current selection
  const currentBank = selectedMonth === 'April 2026' ? APRIL_SYLLABUS_BANK : (selectedMonth === 'June 2026' ? JUNE_SYLLABUS_BANK : OFFICIAL_SYLLABUS_BANK);
  const currentTopics = getTopicsForFilter(activeGradeFilter, activeSubjectFilter, selectedMonth);

  // Status retriever for a specific topic
  const getTopicState = (index: number, topicText: string): SyllabusTopicState => {
    const id = `${activeGradeFilter}_${activeSubjectFilter}_${selectedMonth}_${index}`;
    const found = topicStates.find(s => s.id === id);
    if (found) return found;

    return {
      id,
      grade: activeGradeFilter,
      subject: activeSubjectFilter,
      month: selectedMonth,
      topicText,
      isCompleted: false,
      updatedBy: 'Not set',
      updatedAt: ''
    };
  };

  // Toggle completion checkbox
  const handleToggleCompleted = (index: number, topicText: string) => {
    if (simulatedDay > 25 && !canApprove) {
      triggerToast("⚠️ Locked! Progress updates after the 25th deadline require Principal / VP approval.");
      return;
    }

    const id = `${activeGradeFilter}_${activeSubjectFilter}_${selectedMonth}_${index}`;
    const existingIdx = topicStates.findIndex(s => s.id === id);

    let updatedList = [...topicStates];
    const userDisplay = currentUser?.name || 'Staff User';

    if (existingIdx !== -1) {
      const current = updatedList[existingIdx];
      // Reset request if marked completed
      const newCompleted = !current.isCompleted;
      updatedList[existingIdx] = {
        ...current,
        isCompleted: newCompleted,
        updatedBy: userDisplay,
        updatedAt: new Date().toISOString(),
        // If becoming complete, remove any pending carry requests
        carryForwardRequest: newCompleted ? undefined : current.carryForwardRequest
      };
    } else {
      updatedList.push({
        id,
        grade: activeGradeFilter,
        subject: activeSubjectFilter,
        month: selectedMonth,
        topicText,
        isCompleted: true,
        updatedBy: userDisplay,
        updatedAt: new Date().toISOString()
      });
    }

    setTopicStates(updatedList);
    triggerToast("📅 Topic completion status updated successfully.");
  };

  // Open carry forward workflow
  const handleOpenCarryForward = (index: number, topicText: string) => {
    setRequestTopicIndex(index);
    setRequestTopicText(topicText);
    setRequestReason('');
    // Suggest next chronologic month
    const nextMonth = selectedMonth === 'July 2026' ? 'August 2026' : 'September 2026';
    setTargetMonthSuggested(nextMonth);
    setShowRequestModal(true);
  };

  const [targetMonthSuggested, setTargetMonthSuggested] = useState<string>('August 2026');

  // Submit carry forward request to localStorage state
  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestReason.trim()) {
      triggerToast("⚠️ Please enter a real reason justify carrying this syllabus topic forward.");
      return;
    }

    const id = `${activeGradeFilter}_${activeSubjectFilter}_${selectedMonth}_${requestTopicIndex}`;
    const existingIdx = topicStates.findIndex(s => s.id === id);

    let updatedList = [...topicStates];
    const userDisplay = currentUser?.name || 'Staff User';

    const reqData = {
      targetMonth: targetMonthSuggested,
      reason: requestReason,
      status: 'pending' as const
    };

    if (existingIdx !== -1) {
      updatedList[existingIdx] = {
        ...updatedList[existingIdx],
        isCompleted: false, // Must be incomplete to be carried forward
        carryForwardRequest: reqData,
        updatedBy: userDisplay,
        updatedAt: new Date().toISOString()
      };
    } else {
      updatedList.push({
        id,
        grade: activeGradeFilter,
        subject: activeSubjectFilter,
        month: selectedMonth,
        topicText: requestTopicText,
        isCompleted: false,
        updatedBy: userDisplay,
        updatedAt: new Date().toISOString(),
        carryForwardRequest: reqData
      });
    }

    setTopicStates(updatedList);
    setShowRequestModal(false);
    triggerToast(`🚀 Carry forward petition dispatched to Principal/VP dashboard!`);
  };

  // Manage Carry Forward approval decisions (Management / VP role)
  const handleDecision = (topicId: string, status: 'approved' | 'rejected') => {
    const updatedList = topicStates.map(state => {
      if (state.id === topicId && state.carryForwardRequest) {
        const feedback = principalFeedback[topicId] || '';
        
        let targetMonthForInsertion = state.carryForwardRequest.targetMonth;
        
        // If approved, insert/propagate topic text to target month's database representation
        const newTopicState = {
          ...state,
          updatedBy: currentUser?.name || 'Academic Principal',
          updatedAt: new Date().toISOString(),
          carryForwardRequest: {
            ...state.carryForwardRequest,
            status,
            feedback: feedback || `Reviewed and ${status} on day ${simulatedDay} by Principal/VP`,
            decidedBy: currentUser?.name || 'Academic Principal',
            decidedAt: new Date().toISOString()
          }
        };

        return newTopicState;
      }
      return state;
    });

    setTopicStates(updatedList);
    triggerToast(`📝 Carry forward request ${status.toUpperCase()}!`);
    
    // Clear feedback input field
    setPrincipalFeedback(prev => {
      const copy = { ...prev };
      delete copy[topicId];
      return copy;
    });
  };

  // Count helper statistics
  const getCarryForwardRequests = () => {
    return topicStates.filter(s => s.carryForwardRequest && s.carryForwardRequest.status === 'pending');
  };

  const pendingRequests = getCarryForwardRequests();

  // Selected topics counts
  const getSelectedClassStats = () => {
    if (currentTopics.length === 0) return { total: 0, completed: 0, percentage: 0, remaining: 0 };
    
    let completedCount = 0;
    currentTopics.forEach((t, idx) => {
      const st = getTopicState(idx, t);
      if (st.isCompleted) completedCount++;
    });

    const percent = Math.round((completedCount / currentTopics.length) * 100);
    return {
      total: currentTopics.length,
      completed: completedCount,
      remaining: currentTopics.length - completedCount,
      percentage: percent
    };
  };

  const classStats = getSelectedClassStats();

  return (
    <div className="space-y-6">
      
      {/* HEADER BAR */}
      <div className="bg-gradient-to-r from-teal-950/45 via-slate-900 to-slate-950 border border-emerald-500/20 rounded-3xl p-6 shadow-xl relative overflow-hidden text-left">
        <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-br from-emerald-500/10 to-transparent blur-3xl rounded-full" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-1.5">
            <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[10px] font-black tracking-widest uppercase">
              Syllabus Auditing Protocol
            </span>
            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-emerald-400" />
              <span>Syllabus Completion & Carry Forward System</span>
            </h2>
            <p className="text-slate-400 text-xs max-w-2xl leading-relaxed">
              Ensure pedagogical compliance ahead of school closure dates. Track completed topics, flag delays, and submit carrying forward requests under Principal or Vice-Principal oversight.
            </p>
            <div className="pt-2 flex flex-col gap-3 items-start">
              <div className="flex flex-col md:flex-row flex-wrap gap-3 items-start md:items-center w-full">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTeacherPrint('All Teachers');
                    setShowPrintReportModal(true);
                  }}
                  className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black py-2.5 px-4 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer flex items-center gap-1.5 shadow-md shadow-emerald-500/10 no-print"
                >
                  <Printer className="w-4 h-4" /> Print All Teachers Report
                </button>
                
                <div className="flex flex-col gap-2 bg-slate-950/80 p-3 rounded-2xl border border-emerald-500/10 no-print flex-1 w-full max-w-2xl">
                  <span className="text-[10px] text-slate-400 font-extrabold uppercase tracking-wider flex items-center gap-1">
                    <Printer className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Generate Separate Teacher Audit Logs</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {getTeachersList().map(teacher => (
                      <button
                        key={teacher}
                        type="button"
                        onClick={() => {
                          setSelectedTeacherPrint(teacher);
                          setShowPrintReportModal(true);
                        }}
                        className="bg-slate-900 hover:bg-slate-850 text-emerald-400 hover:text-emerald-300 border border-white/5 hover:border-emerald-500/30 px-3 py-1.5 rounded-xl text-[10px] font-bold cursor-pointer transition-all flex items-center gap-1.5"
                      >
                        <Printer className="w-3 h-3 text-emerald-500" />
                        <span>{teacher}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-950/80 border border-emerald-500/15 p-4 rounded-2xl flex flex-col items-center shrink-0 min-w-44 text-center">
            <span className="text-[9.5px] text-slate-500 font-extrabold block uppercase tracking-wider">CURRENT CALENDAR PHASE</span>
            <span className="text-xs font-black text-emerald-400 block mt-1">
              {simulatedDay <= 25 ? "Plan Phase (Active Entries)" : "Verification Phase (Locked)"}
            </span>
            <span className="text-[10px] text-slate-350 font-black uppercase mt-0.5 tracking-wider">
              {simulatedDay <= 25 ? `${25 - simulatedDay} days to lock` : "Closed for reviews"}
            </span>
          </div>
        </div>
      </div>

      {/* DEADLINE INFORMATION CARD - SHOWN TO EVERY LOGGED IN USER */}
      <div className="bg-slate-950/60 border border-white/5 p-5 rounded-3xl text-left space-y-4">
        <div className="flex flex-wrap items-center justify-between border-b border-white/5 pb-3">
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>Syllabus Update Regulations & Carry Forward Policy</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Mandated process review rules shown daily for compliance validation.</p>
          </div>
          <span className="px-2.5 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded text-[9px] font-black">
            DEADLINE: 25th @ 23:59
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          
          <div className="md:col-span-8 space-y-2">
            <ul className="space-y-1.5 text-[11px] text-slate-300 font-medium">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>Each month's curriculum chapter log has an absolute lock deadline on <strong className="text-indigo-400">the 25th at 23:59</strong>.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">✓</span>
                <span>Any uncompleted topic remaining past the 25th must be logged as <strong className="text-rose-400">Incomplete</strong>.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 font-bold text-lg leading-none">!</span>
                <span><strong>Required Action</strong>: If topics are remaining, teachers cannot self-resolve them. They must input a justification and petition online to <strong className="text-emerald-400">Carry Forward</strong> the topic to next month with physical VP or Principal digital signatures.</span>
              </li>
            </ul>
          </div>

          {/* SIMULATION SLIDER CARD */}
          <div className="md:col-span-4 bg-slate-950 border border-white/10 p-4 rounded-2xl flex flex-col gap-2 shadow-2xl">
            <div className="flex justify-between items-center text-[10px] font-black">
              <span className="text-slate-400 uppercase">Interactive Date</span>
              <span className="text-indigo-400 font-mono">{selectedMonth.split(' ')[0]} {simulatedDay}, {selectedMonth.split(' ')[1]}</span>
            </div>
            
            <input 
              type="range" 
              min="1" 
              max="30" 
              value={simulatedDay}
              onChange={(e) => handleSimulatedDayChange(parseInt(e.target.value))}
              className="w-full h-1.5 bg-slate-900 rounded-lg appearance-none accent-emerald-500 cursor-pointer" 
            />

            <div className="flex justify-between text-[8px] text-slate-500 font-black uppercase">
              <span>Day 1</span>
              <span className="text-rose-400">Day 25 (Lock)</span>
              <span>Day 30</span>
            </div>

            <div className="flex justify-between items-center text-[9.5px] font-black border-t border-white/5 pt-2 mt-1">
              <span className="text-slate-500 uppercase tracking-wider">Real Today</span>
              <span className="text-emerald-400 font-mono">
                {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </span>
            </div>
            <button
              onClick={() => handleSimulatedDayChange(new Date().getDate())}
              className="text-[9px] font-bold uppercase text-indigo-300 hover:text-indigo-200 transition-colors bg-white/5 hover:bg-white/10 py-1 rounded-lg mt-1 border border-white/5 cursor-pointer text-center"
            >
              📍 Reset Slider to Today
            </button>
          </div>

        </div>
      </div>

      {/* PRIMARY APPLICATION PORTALS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
        
        {/* MANAGEMENT PENDING PETITIONS CORNER (SHOWN HIGHLIGHTED FOR PRINCIPAL/VP OR ADMIN) */}
        {canApprove && (
          <div className="lg:col-span-12 bg-gradient-to-br from-indigo-950/20 to-slate-900/40 border border-indigo-500/20 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-wrap items-center justify-between border-b border-indigo-500/10 pb-3 gap-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">Principal & Vice-President Portal: Carry Forward Approvals Desk</h3>
                  <p className="text-xs text-indigo-400">Act as reviewing authority. Endorse or reject teacher-directed backlog petitions.</p>
                </div>
              </div>
              
              <span className="px-3 py-1 bg-indigo-500 text-slate-950 text-xs font-black rounded-lg shadow-lg shadow-indigo-500/20 flex items-center gap-1">
                {pendingRequests.length} Pending Actions
              </span>
            </div>

            {pendingRequests.length === 0 ? (
              <div className="text-center py-6 text-slate-500">
                <CheckCircle2 className="w-8 h-8 text-slate-655 mx-auto mb-2" />
                <p className="text-[11px] italic font-medium">No pending carry-forward requests awaiting approval sign-off.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingRequests.map((state) => (
                  <div key={state.id} className="bg-slate-950 border border-indigo-500/25 p-4 rounded-2xl flex flex-col justify-between gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 bg-indigo-550/10 text-indigo-300 border border-indigo-550/20 rounded text-[9.5px] font-black uppercase">
                          {state.grade} • {state.subject}
                        </span>
                        <span className="text-[10px] text-slate-500 font-semibold">{state.month} Plan</span>
                      </div>
                      
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-white leading-relaxed">Topic: {state.topicText}</h4>
                        <p className="text-[11px] bg-slate-900 border border-white/5 p-2 rounded-lg text-slate-350 italic">
                          "Reason: {state.carryForwardRequest?.reason}"
                        </p>
                      </div>

                      <div className="text-[10px] text-slate-400 font-medium">
                        Target Carry-Forward Month: <strong className="text-emerald-400">{state.carryForwardRequest?.targetMonth}</strong>
                      </div>
                      
                      <div className="text-[9.5px] text-slate-500">
                        Dispatched by: <strong className="text-slate-300">{state.updatedBy}</strong>
                      </div>
                    </div>

                    {/* Decision action box */}
                    <div className="space-y-3 pt-2 border-t border-white/5">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Provide feedback or extra instruction..."
                          className="flex-1 bg-slate-900 border border-white/10 text-[11px] text-white px-2.5 py-1.5 rounded-xl placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                          value={principalFeedback[state.id] || ''}
                          onChange={(e) => setPrincipalFeedback({
                            ...principalFeedback,
                            [state.id]: e.target.value
                          })}
                        />
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleDecision(state.id, 'approved')}
                          className="flex-1 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg text-xs cursor-pointer text-center"
                        >
                          Approve Carry-Forward
                        </button>
                        <button
                          onClick={() => handleDecision(state.id, 'rejected')}
                          className="flex-1 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/20 font-black rounded-lg text-xs cursor-pointer text-center"
                        >
                          Reject & Require Extra Class
                        </button>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* LEFT COLUMN: ACTIVE FILTERS & STATS GRID (4 COLS) */}
        <div className="lg:col-span-4 bg-white/5 border border-white/10 p-5 rounded-3xl space-y-6 shadow-xl">
          <div className="space-y-2">
            <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <Filter className="w-4 h-4 text-emerald-400" />
              <span>Syllabus Scope Filter</span>
            </h3>
            <p className="text-[11px] text-slate-400">Update parameters to load specific class curriculums</p>
          </div>

          {/* Month selector button group */}
          <div className="space-y-2">
            <label className="text-[10px] text-slate-500 font-black uppercase tracking-wider">Plan Horizon Month</label>
            <div className="grid grid-cols-2 gap-2 bg-slate-950/60 p-1.5 rounded-2xl border border-white/5">
              {['April 2026', 'June 2026', 'July 2026', 'August 2026'].map(m => (
                <button
                  key={m}
                  onClick={() => setSelectedMonth(m)}
                  className={`py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    selectedMonth === m
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {m.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Class selection dropdown */}
          <div className="space-y-2">
            <label className="text-[10px] text-slate-500 font-black uppercase tracking-wider block">Class Allotment</label>
            {isTeacher ? (
              <div className="space-y-1">
                {mySubjects.map((sub, idx) => (
                  <button
                    key={`${sub.className}-${sub.subject}-${idx}`}
                    onClick={() => {
                      setActiveGradeFilter(sub.syllabusGrade);
                      setActiveSubjectFilter(sub.subject);
                    }}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all text-xs flex items-center justify-between cursor-pointer ${
                      activeGradeFilter === sub.syllabusGrade && activeSubjectFilter === sub.subject
                        ? 'bg-indigo-500/20 border-indigo-400 text-white font-black'
                        : 'bg-slate-950/40 border-white/5 text-slate-350 hover:border-white/10'
                    }`}
                  >
                    <div>
                      <span className="block font-black">{sub.className}</span>
                      <span className="text-[10px] text-slate-450 block">{sub.subject}</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 shrink-0" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-2.5">
                {/* Select grade dropdown */}
                <select
                  value={activeGradeFilter}
                  onChange={(e) => setActiveGradeFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  {Object.keys(currentBank).map(grade => (
                    <option key={grade} value={grade}>{grade}</option>
                  ))}
                </select>

                {/* Subject selector button list based on selected grade */}
                <div className="grid grid-cols-2 gap-1.5 max-h-40 overflow-y-auto pr-1">
                  {(currentBank[activeGradeFilter] || []).map(topicGroup => (
                    <button
                      key={topicGroup.subject}
                      onClick={() => setActiveSubjectFilter(topicGroup.subject)}
                      className={`p-2 rounded-xl text-[11px] font-black text-center transition-all cursor-pointer border ${
                        activeSubjectFilter === topicGroup.subject
                          ? 'bg-emerald-500/20 border-emerald-400 text-white'
                          : 'bg-slate-950/40 border-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      {topicGroup.subject}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* TARGET SCOREBOARD CARD */}
          <div className="bg-slate-950 border border-white/5 p-4 rounded-2xl space-y-3 relative overflow-hidden">
            <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-widest block">Class Compliance Metrics</span>
            
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-white">{classStats.percentage}%</span>
              <span className="text-[10px] text-slate-450">
                {classStats.completed}/{classStats.total} completed
              </span>
            </div>

            <div className="w-full bg-white/2 h-1.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-400 transition-all duration-300"
                style={{ width: `${classStats.percentage}%` }}
              />
            </div>

            <div className="flex justify-between text-[9.5px] font-semibold text-slate-400 pt-1 border-t border-white/5">
              <span>Remaining backlogs:</span>
              <span className={classStats.remaining > 0 ? "text-amber-400" : "text-emerald-400"}>
                {classStats.remaining} chapter{classStats.remaining !== 1 ? 's' : ''}
              </span>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: CHAPTER CHECKLIST & REQUEST FORM PORT (8 COLS) */}
        <div className="lg:col-span-8 bg-white/5 border border-white/10 p-5 rounded-3xl space-y-4 shadow-xl">
          
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <div>
              <span className="text-[10px] text-indigo-400 font-black block uppercase tracking-wider">{activeGradeFilter}</span>
              <h3 className="text-sm font-black text-white">Course Syllabus Ledger: {activeSubjectFilter}</h3>
            </div>
            
            <span className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] font-black text-slate-350">
              {currentTopics.length} Total Chapters
            </span>
          </div>

          <div className="space-y-3">
            {currentTopics.length === 0 ? (
              <div className="text-center py-12 text-slate-550 border-2 border-dashed border-white/5 rounded-2xl">
                <AlertCircle className="w-10 h-10 text-slate-650 mx-auto mb-2" />
                <p className="text-xs italic font-semibold">No formal syllabus maps found for this selection.</p>
                <p className="text-[10px] text-slate-600 mt-0.5">Please map course topics under master configurations first.</p>
              </div>
            ) : (
              currentTopics.map((topicText, index) => {
                const state = getTopicState(index, topicText);
                const hasPendingRequest = state.carryForwardRequest?.status === 'pending';
                const hasApprovedRequest = state.carryForwardRequest?.status === 'approved';
                const hasRejectedRequest = state.carryForwardRequest?.status === 'rejected';

                return (
                  <div 
                    key={index}
                    className={`p-4 rounded-2xl border transition-all ${
                      state.isCompleted
                        ? 'bg-emerald-500/5 border-emerald-500/20'
                        : hasApprovedRequest
                          ? 'bg-indigo-50a bg-indigo-500/5 border-indigo-400/30'
                          : hasPendingRequest
                            ? 'bg-amber-500/5 border-amber-550/30'
                            : 'bg-slate-950/50 border-white/5'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      
                      {/* Checkbox item */}
                      <button
                        onClick={() => handleToggleCompleted(index, topicText)}
                        className="flex items-start gap-3.5 focus:outline-none flex-1 text-left cursor-pointer group"
                      >
                        <div className={`mt-0.5 h-5 w-5 rounded border flex items-center justify-center shrink-0 transition-all ${
                          state.isCompleted
                            ? 'bg-emerald-500 border-emerald-500 text-slate-950'
                            : 'bg-slate-900 border-white/15 hover:border-indigo-400'
                        }`}>
                          {state.isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>

                        <div>
                          <p className={`text-xs font-semibold leading-relaxed ${state.isCompleted ? 'line-through text-slate-450' : 'text-slate-205'}`}>
                            {topicText}
                          </p>

                          {state.updatedAt && (
                            <span className="text-[9px] text-slate-500 block mt-1">
                              Status changed by {state.updatedBy}
                            </span>
                          )}
                        </div>
                      </button>

                      {/* Carry forward status / button panel */}
                      <div className="shrink-0 flex items-center gap-2">
                        {state.isCompleted ? (
                          <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-black uppercase">
                            COMPLETED
                          </span>
                        ) : hasApprovedRequest ? (
                          <div className="flex flex-col items-end gap-1">
                            <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded text-[9.5px] font-black uppercase flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5 text-indigo-400" />
                              CARRIED FORWARD
                            </span>
                            <span className="text-[8.5px] text-slate-500">
                              Approved to {state.carryForwardRequest?.targetMonth}
                            </span>
                          </div>
                        ) : hasPendingRequest ? (
                          <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/20 rounded text-[9px] font-black uppercase tracking-wide animate-pulse">
                            PENDING VP APPROVAL
                          </span>
                        ) : hasRejectedRequest ? (
                          <div className="flex flex-col items-end gap-1">
                            <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded text-[9px] font-black uppercase">
                              REJECTED BY PRINCIPAL
                            </span>
                            <span className="text-[8px] text-rose-350 select-none">
                              Require Extra Classes
                            </span>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleOpenCarryForward(index, topicText)}
                            className="py-1 px-2.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/20 hover:border-indigo-500/30 text-[10px] font-black rounded-lg transition-all flex items-center gap-1 cursor-pointer uppercase"
                          >
                            <ArrowRightLeft className="w-3 h-3" />
                            Carry Forward
                          </button>
                        )}
                      </div>

                    </div>

                    {/* Show comments or explanation logs if attached */}
                    {(hasPendingRequest || hasApprovedRequest || hasRejectedRequest) && state.carryForwardRequest && (
                      <div className="mt-3.5 pt-3.5 border-t border-dashed border-white/5 space-y-1.5 text-left bg-slate-950/40 p-3 rounded-xl border border-white/5 text-[11px] leading-relaxed">
                        <div className="text-slate-400 font-medium">
                          <strong className="text-indigo-350">Submission Justification:</strong> "{state.carryForwardRequest.reason}"
                        </div>
                        {state.carryForwardRequest.feedback && (
                          <div className="text-amber-405 font-bold flex items-start gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                            <span>
                              <strong>Principal Response:</strong> "{state.carryForwardRequest.feedback}"
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                  </div>
                );
              })
            )}
          </div>

        </div>

      </div>

      {/* CARRY FORWARD REQUEST POPULAR FORM OVERLAY / REGISTRY MODAL */}
      {showRequestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-950 border border-indigo-500/30 max-w-lg w-full rounded-3xl p-6 shadow-2xl relative text-left space-y-5 animate-fade-in">
            <button 
              onClick={() => setShowRequestModal(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-white font-black text-sm"
            >
              ✕
            </button>

            <div className="space-y-1.5">
              <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded text-[9px] font-black uppercase">
                FORM DISPATCH
              </span>
              <h3 className="text-md font-black text-white flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5 text-indigo-400 animate-pulse" />
                <span>Request Syllabus Carry-Forward Approval</span>
              </h3>
              <p className="text-xs text-slate-400">
                Submit this form to petition the school principal/VP for carrying incomplete topics to next month.
              </p>
            </div>

            <form onSubmit={handleSubmitRequest} className="space-y-4">
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase">Target Carry Month</label>
                <select
                  value={targetMonthSuggested}
                  onChange={(e) => setTargetMonthSuggested(e.target.value)}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="July 2026">July 2026</option>
                  <option value="August 2026">August 2026</option>
                  <option value="September 2026">September 2026</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase block">Selected Topic</label>
                <p className="text-xs text-slate-300 font-bold bg-white/2 p-3 rounded-xl border border-white/5">
                  {requestTopicText}
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase block">Pedagogical Reason / Justification</label>
                <textarea
                  rows={4}
                  placeholder="State clearly why this topic got delayed (e.g., remedial support required, extra laboratory hours, sports calendar overlap) and your timeline plan for covering it..."
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-655 focus:outline-none focus:border-indigo-500 resize-none font-medium"
                  value={requestReason}
                  onChange={(e) => setRequestReason(e.target.value)}
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-855 text-xs text-slate-400 font-black rounded-xl border border-white/5 cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-500 hover:bg-indigo-600 text-xs text-slate-950 font-black rounded-xl cursor-pointer text-center shadow-lg shadow-indigo-500/15 flex items-center justify-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  Request Permission from VP
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* TOAST SYSTEM ACCORDING TO SYSTEM CONFIG */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 bg-slate-950 border border-emerald-500/40 px-4 py-3 rounded-2xl shadow-xl animate-fade-in text-xs font-bold text-white">
          <CheckCircle2 className="w-4 h-4 text-emerald-405 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* SYLLABUS AUDIT PRINT PREVIEW MODAL */}
      {showPrintReportModal && createPortal(
        <div className="fixed inset-0 z-50 flex flex-col md:flex-row bg-slate-950/90 backdrop-blur-md overflow-y-auto print-modal-overlay">
          
          {/* SIDEBAR CONTROL CENTER - HIDDEN IN PRINT */}
          <div className="w-full md:w-80 bg-slate-900 border-b md:border-b-0 md:border-r border-white/10 p-5 space-y-6 shrink-0 no-print text-left flex flex-col justify-between">
            <div className="space-y-6">
              <div className="space-y-1">
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-black uppercase tracking-wider">
                  Compliance Report
                </span>
                <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Syllabus Audit Ledger</span>
                </h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Generate print-perfect A4 ledger pages grouped by teacher. Optimized for single-page printing.
                </p>
              </div>

              {/* Teacher Selector */}
              <div className="space-y-3">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Audited Teacher</label>
                  <div className="relative">
                    <select
                      value={selectedTeacherPrint}
                      onChange={(e) => setSelectedTeacherPrint(e.target.value)}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 appearance-none cursor-pointer"
                    >
                      <option value="All Teachers">All Teachers (Individual Pages)</option>
                      {getTeachersList().map(t => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                    <span className="absolute right-3 top-2.5 text-slate-500 text-xs pointer-events-none">▼</span>
                  </div>
                </div>

                {/* Quick-select teacher chip list */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block">Quick Switch Teacher</label>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedTeacherPrint('All Teachers')}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                        selectedTeacherPrint === 'All Teachers'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-slate-950/40 text-slate-400 hover:text-white border-white/5'
                      }`}
                    >
                      All Teachers
                    </button>
                    {getTeachersList().map(t => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setSelectedTeacherPrint(t)}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                          selectedTeacherPrint === t
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-slate-950/40 text-slate-400 hover:text-white border-white/5'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Months Selector */}
              <div className="space-y-2.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Include Syllabus Months</label>
                <div className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-white/5">
                  {['April 2026', 'June 2026', 'July 2026', 'August 2026'].map(m => {
                    const isChecked = selectedPrintMonths.includes(m);
                    return (
                      <label key={m} className="flex items-center gap-2.5 text-xs font-semibold text-slate-350 cursor-pointer hover:text-white select-none">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              if (selectedPrintMonths.length > 1) {
                                setSelectedPrintMonths(selectedPrintMonths.filter(x => x !== m));
                              }
                            } else {
                              setSelectedPrintMonths([...selectedPrintMonths, m]);
                            }
                          }}
                          className="rounded bg-slate-950 border-white/10 text-emerald-500 focus:ring-emerald-500"
                        />
                        <span>{m}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Layout Density */}
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Layout Optimization</label>
                <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-white/5">
                  <button
                    type="button"
                    onClick={() => setPrintLayoutDensity('normal')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                      printLayoutDensity === 'normal'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Standard
                  </button>
                  <button
                    type="button"
                    onClick={() => setPrintLayoutDensity('dense')}
                    className={`py-1.5 px-3 rounded-lg text-[10px] font-black uppercase transition-all cursor-pointer ${
                      printLayoutDensity === 'dense'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    1-Page Dense
                  </button>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-relaxed">
                  Dense mode minimizes padding and spacing to enforce fitting a teacher's full syllabus log onto a single page.
                </p>
              </div>
            </div>

            <div className="space-y-2.5 pt-4 border-t border-white/5">
              <button
                type="button"
                onClick={() => window.print()}
                className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black rounded-xl cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/10 uppercase tracking-wider"
              >
                <Printer className="w-4 h-4" /> Trigger Print / PDF
              </button>
              <button
                type="button"
                onClick={() => setShowPrintReportModal(false)}
                className="w-full py-2.5 bg-slate-950 hover:bg-slate-800 text-slate-400 text-xs font-black rounded-xl cursor-pointer text-center border border-white/10 uppercase tracking-wider"
              >
                Return to System
              </button>
            </div>
          </div>

          {/* PRINTABLE PREVIEW SHEET CANVAS */}
          <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center bg-slate-900/60 print:bg-white print:p-0 print:block print:overflow-visible print:w-full print:h-auto print:flex-none">
            
            {/* Screen Banner - Hidden in Print */}
            <div className="w-full max-w-[210mm] mb-4 bg-slate-950 border border-emerald-500/10 p-3 rounded-2xl flex items-center justify-between gap-3 text-left no-print">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="text-[10px] font-bold text-slate-350 uppercase tracking-widest">
                  Active Print Preview Area (A4 Portrait Format)
                </span>
              </div>
              <span className="text-[9.5px] text-slate-500 font-mono">
                {selectedTeacherPrint === 'All Teachers' ? `${getTeachersList().length} pages will print` : '1 page will print'}
              </span>
            </div>

            {/* Pagination of Teachers */}
            <div className="space-y-6 print:space-y-0 print:block print:overflow-visible print:w-full print:h-auto">
              {(selectedTeacherPrint === 'All Teachers' ? getTeachersList() : [selectedTeacherPrint]).map((teacherName, tIdx) => {
                const statsRows = getSyllabusStatsForTeacher(teacherName, selectedPrintMonths);
                
                // Lookup verification status from management reviews
                const activeReview = managementReviews?.find(r => {
                  const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
                  const cleanTeacher = cleanStr(teacherName);
                  const reviewTeacherClean = cleanStr(r.teacherName);
                  const isTeacherMatch = reviewTeacherClean === cleanTeacher || 
                                         reviewTeacherClean.includes(cleanTeacher) || 
                                         cleanTeacher.includes(reviewTeacherClean);
                  return isTeacherMatch && selectedPrintMonths.includes(r.month) && r.isVerified;
                });

                // If a teacher has absolutely no classes allotted, skip them in bulk mode to save paper
                if (statsRows.length === 0 && selectedTeacherPrint === 'All Teachers') return null;

                return (
                  <div 
                    key={teacherName} 
                    className={`bg-white shadow-2xl text-black select-none printable-paper-sheet ${
                      printLayoutDensity === 'dense' ? 'dense-layout' : ''
                    }`}
                  >
                    
                    {/* Header Letterhead */}
                    <div className="border-b-2 border-slate-900 pb-2 text-center space-y-1">
                      <div className="flex items-center justify-center gap-2">
                        <span className="text-md font-black tracking-widest text-slate-950 uppercase font-sans">
                          Samata International School
                        </span>
                      </div>
                      <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">
                        Academic Department • Syllabus Verification Ledger
                      </p>
                      <div className="w-16 h-0.5 bg-emerald-600 mx-auto" />
                    </div>

                    {/* Meta Profile Grid */}
                    <div className="grid grid-cols-2 gap-4 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-left text-[10.5px] mt-3">
                      <div className="space-y-0.5">
                        <div>
                          <span className="text-slate-500 font-semibold">Teacher of Record:</span>{' '}
                          <strong className="text-slate-950 font-black uppercase">{teacherName}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 font-semibold">Verification Ledger:</span>{' '}
                          <span className="text-indigo-600 font-bold">Academic Coverage Audit</span>
                        </div>
                      </div>
                      <div className="space-y-0.5 text-right">
                        <div>
                          <span className="text-slate-500 font-semibold">Target Months:</span>{' '}
                          <strong className="text-slate-950">{selectedPrintMonths.join(' & ')}</strong>
                        </div>
                        <div>
                          <span className="text-slate-500 font-semibold">Generation Date:</span>{' '}
                          <span className="text-slate-700 font-medium">
                            {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Syllabus Status Table */}
                    <div className="flex-1 overflow-hidden mt-3">
                      {statsRows.length === 0 ? (
                        <div className="text-center py-12 text-slate-400 border border-dashed border-slate-200 rounded-lg text-xs">
                          No allotments found for this teacher in the current configuration.
                        </div>
                      ) : (
                        <table className="syllabus-audit-table w-full border-collapse border border-slate-300 text-left text-[13px]">
                          <thead>
                            <tr className="bg-slate-100 text-slate-950 font-bold uppercase tracking-wider text-[13px]">
                              <th className="border border-slate-300 p-1.5 w-[10%]">Class / Grade</th>
                              <th className="border border-slate-300 p-1.5 w-[12%]">Subject</th>
                              <th className="border border-slate-300 p-1.5 w-[10%]">Month</th>
                              <th className="border border-slate-300 p-1.5 w-[12%] text-center">Progress</th>
                              <th className="border border-slate-300 p-1.5 w-[56%]">Topic Progress details</th>
                            </tr>
                          </thead>
                          <tbody>
                            {statsRows.map((row, rIdx) => {
                              const completionPercent = row.totalTopics > 0 ? Math.round((row.completedTopics / row.totalTopics) * 100) : 0;
                              return (
                                <tr key={rIdx} className="hover:bg-slate-50/50">
                                  <td className="border border-slate-300 p-1.5 font-black text-slate-950">{row.grade}</td>
                                  <td className="border border-slate-300 p-1.5 font-bold text-slate-700">{row.subject}</td>
                                  <td className="border border-slate-300 p-1.5 text-slate-600 font-semibold">{row.month.split(' ')[0]}</td>
                                  <td className="border border-slate-300 p-1.5 text-center">
                                    <div className="space-y-1">
                                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-black ${
                                        completionPercent === 100 
                                          ? 'bg-emerald-100 text-emerald-800' 
                                          : completionPercent >= 50 
                                          ? 'bg-amber-100 text-amber-800' 
                                          : 'bg-rose-100 text-rose-800'
                                      }`}>
                                        {row.completedTopics}/{row.totalTopics} ({completionPercent}%)
                                      </span>
                                      <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                                        <div 
                                          className={`h-full rounded-full ${
                                            completionPercent === 100 
                                              ? 'bg-emerald-600' 
                                              : completionPercent >= 50 
                                              ? 'bg-amber-500' 
                                              : 'bg-rose-500'
                                          }`}
                                          style={{ width: `${completionPercent}%` }}
                                        />
                                      </div>
                                    </div>
                                  </td>
                                  <td className="border border-slate-300 p-1.5 text-left">
                                    {row.topicsList.length === 0 ? (
                                      <span className="text-slate-400 italic">No syllabus mapped</span>
                                    ) : (
                                      <ul className="space-y-0.5 text-[13px] leading-tight">
                                        {row.topicsList.map((top, tIdx) => {
                                          // Find if this specific topic has a Carry Forward state
                                          const topicId = `${row.syllabusGrade}_${row.subject}_${row.month}_${tIdx}`;
                                          const state = topicStates.find(s => s.id === topicId);
                                          const hasCF = state?.carryForwardRequest;
                                          const isCFApproved = hasCF?.status === 'approved';

                                          return (
                                            <li key={tIdx} className="flex items-start gap-1">
                                              <span className={`font-mono text-[13px] ${top.isCompleted ? 'text-emerald-600 font-black' : 'text-slate-450'}`}>
                                                {top.isCompleted ? '☑' : '☐'}
                                              </span>
                                              <div className="flex-1">
                                                <span className={top.isCompleted ? 'text-slate-400 line-through' : 'text-slate-800 font-medium'}>
                                                  {top.text}
                                                </span>
                                                {hasCF && (
                                                  <span className={`ml-1 text-[10px] font-extrabold uppercase px-1 py-0.2 rounded ${
                                                    isCFApproved ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-800'
                                                  }`}>
                                                    → CF ({isCFApproved ? 'Approved' : 'Pending'})
                                                  </span>
                                                )}
                                              </div>
                                            </li>
                                          );
                                        })}
                                      </ul>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      )}
                    </div>

                    {/* Signatures Row */}
                    <div className="grid grid-cols-3 gap-6 pt-4 border-t border-slate-200 mt-auto text-center text-[9px]">
                      <div className="space-y-2">
                        <div className="h-6 border-b border-slate-300 flex items-end justify-center">
                          <span className="font-mono text-[9px] italic text-slate-400">Class Teacher Signed</span>
                        </div>
                        <span className="text-slate-500 font-semibold block uppercase tracking-wider text-[8px]">Teacher Signature</span>
                      </div>
                      <div className="space-y-2 relative">
                        {activeReview && (
                          <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                            <div className="border-2 border-double border-indigo-600/75 text-indigo-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[4deg] bg-white/95 scale-90 shadow-sm leading-tight">
                              <div className="text-[6px] border-b border-indigo-600/75 pb-0.5 leading-none">★ AUDITOR PORTFOLIO ★</div>
                              <div className="text-[8px] font-extrabold my-0.5 leading-none">VP AUDIT PASSED</div>
                              <div className="text-[6px] border-t border-indigo-600/75 pt-0.5 mt-0.5 leading-none">
                                {activeReview.verifiedAt || 'VERIFIED'}
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="h-6 border-b border-slate-300 flex items-end justify-center">
                          <span className="font-mono text-[9px] italic text-slate-400">
                            {activeReview ? '✓ VERIFIED DIGITAL' : 'Academic Auditor Verified'}
                          </span>
                        </div>
                        <span className="text-slate-500 font-semibold block uppercase tracking-wider text-[8px]">Vice-Principal Endorsement</span>
                      </div>
                      <div className="space-y-2 relative">
                        {activeReview && (
                          <div className="absolute inset-x-0 -top-8 flex justify-center pointer-events-none select-none">
                            <div className="border-2 border-double border-rose-600/75 text-rose-600/85 px-2 py-0.5 rounded font-mono font-black text-center text-[7.5px] tracking-wider uppercase transform rotate-[-3deg] bg-white/95 scale-90 shadow-sm leading-tight">
                              <div className="text-[6px] border-b border-rose-600/75 pb-0.5 leading-none">★ SAMATA INT. SCHOOL ★</div>
                              <div className="text-[8px] font-extrabold my-0.5 leading-none">PRINCIPAL APPROVED</div>
                              <div className="text-[6px] border-t border-rose-600/75 pt-0.5 mt-0.5 leading-none">
                                {activeReview.verifiedBy.replace(/\s*\(Academic Audit\)/g, '')}
                              </div>
                            </div>
                          </div>
                        )}
                        <div className="h-6 border-b border-slate-300 flex items-end justify-center">
                          <span className="font-mono text-[9px] italic text-slate-400">
                            {activeReview ? '✓ APPROVED ONLINE' : 'SIS Executive Chamber'}
                          </span>
                        </div>
                        <span className="text-slate-500 font-semibold block uppercase tracking-wider text-[8px]">Principal Approval Stamp</span>
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="mt-3 pt-1.5 border-t border-slate-100 flex justify-between text-[7.5px] text-slate-400 font-bold uppercase tracking-wider">
                      <span>PAGE {tIdx + 1} OF {selectedTeacherPrint === 'All Teachers' ? getTeachersList().length : 1}</span>
                      <span>SYSTEM CODE: SIS-SYL-AUD-2026</span>
                    </div>

                  </div>
                );
              })}
            </div>

          </div>

        </div>,
        document.body
      )}

    </div>
  );
}
