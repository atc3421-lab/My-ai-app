import { SchoolClass, MonthlyTask, CheckingRecord, ActivityLog } from '../types';
import { TEACHER_ALLOTMENTS } from './teacherData';
import { REAL_STUDENT_ROSTERS } from './realStudentData';
import { APRIL_SYLLABUS_BANK, OFFICIAL_SYLLABUS_BANK, JUNE_SYLLABUS_BANK } from './officialSyllabus';

const FIRST_NAMES = [
  "Abhishek", "Aditya", "Aarav", "Aniket", "Ayush", "Ganesh", "Harsh", "Jay", "Kunal", "Omkar",
  "Pranav", "Rahul", "Rohan", "Sarthak", "Siddharth", "Tejas", "Vedant", "Yash", "Atharva", "Suyash",
  "Aishwarya", "Ananya", "Arya", "Gauri", "Isha", "Janhavi", "Kalyani", "Mansi", "Neha", "Prisha",
  "Rutuja", "Sakshi", "Shruti", "Siddhi", "Tanvi", "Vaishnavi", "Vedika", "Aditi", "Snehal", "Pooja"
];

const LAST_NAMES = [
  "Patil", "Deshmukh", "Kulkarni", "Shinde", "Joshi", "More", "Pawar", "Chavan", "Gaekwad", "Tambe",
  "Rathod", "Thakre", "Wagh", "Borse", "Manjule", "Kamble", "Shelar", "Salunkhe", "Gite", "Kadam"
];

// Dynamically generate the 27 real classes of Samata International School
export const DEFAULT_CLASSES: SchoolClass[] = TEACHER_ALLOTMENTS.map((allot, classIdx) => {
  const classId = `class_${allot.grade.toLowerCase().replace(" ", "_")}`;
  const className = `Grade ${allot.grade}`;
  const gradeValue = allot.grade.split(" ")[0]; // e.g. "I", "II", "III"
  
  // Try to load real students from the uploaded school PDF roster, fallback to deterministic names
  const realNames = REAL_STUDENT_ROSTERS[allot.grade];
  let students;

  if (realNames && realNames.length > 0) {
    students = realNames.map((fullName, studIdx) => {
      const rollNo = String(studIdx + 1).padStart(2, '0');
      return {
        id: `stud_${classId}_${studIdx + 1}`,
        name: fullName,
        rollNumber: rollNo
      };
    });
  } else {
    // Fallback to 12 deterministic student entities for each class
    students = Array.from({ length: 12 }).map((_, studIdx) => {
      const fnIdx = (classIdx * 11 + studIdx * 3) % FIRST_NAMES.length;
      const lnIdx = (classIdx * 7 + studIdx * 13) % LAST_NAMES.length;
      const fullName = `${FIRST_NAMES[fnIdx]} ${LAST_NAMES[lnIdx]}`;
      const rollNo = String(studIdx + 1).padStart(2, '0');
      
      return {
        id: `stud_${classId}_${studIdx + 1}`,
        name: fullName,
        rollNumber: rollNo
      };
    });
  }

  return {
    id: classId,
    name: className,
    grade: gradeValue,
    students
  };
});

// Allowed subject registry across different Grade ranges
export const DEFAULT_SUBJECTS = [
  "Math",
  "English",
  "Hindi",
  "Marathi",
  "Science",
  "S.S. (Social Studies)",
  "Science (Bio,Phy,Chem)",
  "Computer",
  "Biology",
  "Chemistry",
  "Physics"
];

// Preseeded syllabus plans for Grade V O, VI O and VII T
const leg_tasks: MonthlyTask[] = [];

// Dynamically generate Tasks for all 27 class sections across all focus months
const generated_tasks: MonthlyTask[] = [];
const activeMonths = ["April 2026", "June 2026", "July 2026"];

activeMonths.forEach((month) => {
  TEACHER_ALLOTMENTS.forEach((allot) => {
    const classId = `class_${allot.grade.toLowerCase().replace(" ", "_")}`;
    
    // Extract main grade (e.g. "I", "II" etc.)
    const gradeParts = allot.grade.split(" ");
    const gradeNum = gradeParts[0]; // "I", "V", "X"
    const gradeKey = `Grade ${gradeNum}`;
    
    // Use April, June or main syllabus bank
    const syllabusItems = (month === "April 2026")
      ? (APRIL_SYLLABUS_BANK[gradeKey] || [])
      : (month === "June 2026")
      ? (JUNE_SYLLABUS_BANK[gradeKey] || [])
      : (OFFICIAL_SYLLABUS_BANK[gradeKey] || []);
    
    syllabusItems.forEach((syllabusItem) => {
      const subjectName = syllabusItem.subject; // e.g. "Math", "English", "Science", "EVS"
      
      // Normalize subject name to match our allowed subjects list
      let matchedSubject = subjectName;
      if (subjectName === "Mathematics" || subjectName === "Maths") {
        matchedSubject = "Math";
      } else if (subjectName === "SS" || subjectName === "S.S" || subjectName === "Social Science" || subjectName === "Social Studies") {
        matchedSubject = "S.S. (Social Studies)";
      } else if (subjectName === "Computer" || subjectName === "IT" || subjectName === "Information Technology") {
        matchedSubject = "Computer";
      } else if (subjectName === "EVS") {
        matchedSubject = "Science";
      }

      // Determine sub-items lists to register tasks
      interface SubItemTaskGroup {
        sub: string;
        topics: string[];
      }
      const subItems: SubItemTaskGroup[] = [];

      if (subjectName === "Science" && (gradeNum === "IX" || gradeNum === "X")) {
        const rawTopics = syllabusItem.topics || [];
        const bioTopics = rawTopics.filter(t => t.toLowerCase().includes("biology"));
        const phyTopics = rawTopics.filter(t => t.toLowerCase().includes("physics"));
        const chemTopics = rawTopics.filter(t => t.toLowerCase().includes("chemistry"));

        subItems.push({ sub: "Biology", topics: bioTopics.length > 0 ? bioTopics : ["Biology Chapter study"] });
        subItems.push({ sub: "Physics", topics: phyTopics.length > 0 ? phyTopics : ["Physics Chapter study"] });
        subItems.push({ sub: "Chemistry", topics: chemTopics.length > 0 ? chemTopics : ["Chemistry Chapter study"] });
      } else {
        subItems.push({ sub: matchedSubject, topics: syllabusItem.topics || [] });
      }

      subItems.forEach(({ sub, topics: safeTopicList }) => {
        // Check if teacher is allotted, or resolve fallback options
        let teacherName = allot.subjects[sub];
        if (!teacherName || teacherName === "-") {
          if (allot.subjects[subjectName]) {
            teacherName = allot.subjects[subjectName];
          } else {
            teacherName = allot.classTeacher || "Staff Teacher";
          }
        }
        
        if (teacherName && teacherName !== "-") {
          // Construct custom titles and descriptions for each month to be realistic
          let title = "";
          let description = "";
          let dueDate = "";
          
          if (month === "April 2026") {
            title = safeTopicList[0] || `${sub} Chap 1 Introduction`;
            description = `April monthly syllabus notebook check and evaluation. Topics: ${safeTopicList.join(", ")}`;
            dueDate = "2026-04-25";
          } else if (month === "June 2026") {
            title = safeTopicList[0] || `${sub} Chap 2 Study`;
            description = `June monthly syllabus notebook check and evaluation. Topics: ${safeTopicList.join(", ")}`;
            dueDate = "2026-06-25";
          } else {
            title = safeTopicList[0] || `${sub} Chap 1 Introduction`;
            description = `July conceptual assignment checklist and regular notebook evaluation checks. Topics: ${safeTopicList.join(", ")}`;
            dueDate = "2026-07-31";
          }

          generated_tasks.push({
            id: `task_${month.replace(" ", "_").toLowerCase()}_${allot.grade.replace(" ", "_").toLowerCase()}_${sub.toLowerCase().replace(/[^a-z0-9]/g, "_")}`,
            classId: classId,
            subject: sub,
            month: month,
            title: title,
            description: description,
            dueDate: dueDate
          });
        }
      });
    });
  });
});

export const DEFAULT_TASKS: MonthlyTask[] = [...leg_tasks, ...generated_tasks];

const generated_records: CheckingRecord[] = [];

// By default, all notebook checking statuses are 'unchecked' for all classes and subjects.
// We avoid pre-populating pre-checked records to let teachers log their checks from a clean slate.

export const DEFAULT_RECORDS: CheckingRecord[] = [
  ...generated_records
];

export const INITIAL_LOGS: ActivityLog[] = [
  { id: "l_1", studentName: "Abhishek Patil", className: "Grade V O", subject: "Math", taskTitle: "Large Numbers & Decimals Introduction", status: "checked", timestamp: "2026-07-05T09:30:00Z" },
  { id: "l_2", studentName: "Aditya Deshmukh", className: "Grade V O", subject: "Math", taskTitle: "Large Numbers & Decimals Introduction", status: "checked", timestamp: "2026-07-05T09:35:00Z" },
  { id: "l_3", studentName: "Aarav Kulkarni", className: "Grade V O", subject: "Math", taskTitle: "Large Numbers & Decimals Introduction", status: "incomplete", timestamp: "2026-07-05T09:40:00Z" }
];
