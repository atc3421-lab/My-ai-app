// Samata International School Teacher Allotment & Workload Data (Academic Year 2026-27)

export interface SubjectWorkloadMapping {
  subject: string;
  grades: {
    [gradeGroup: string]: number; // e.g., "I & II", "III", "IV & V", "VI", "VII & VIII", "IX", "X"
  };
}

export interface TeacherAllotment {
  grade: string;       // e.g., "I O", "I T", "V D", "X O"
  classTeacher: string;
  subjects: {
    [subjectName: string]: string; // subjectName -> teacherName
  };
}

// 1. Weekly Workload 2026-27 mapping matching requested subject constraints including core and co-scholastic subjects from PDF
export const WEEKLY_WORKLOADS: SubjectWorkloadMapping[] = [
  { subject: "English", grades: { "I & II": 5, "III": 5, "IV & V": 5, "VI": 6, "VII & VIII": 6, "IX": 6, "X": 6 } },
  { subject: "Hindi", grades: { "I & II": 4, "III": 5, "IV & V": 5, "VI": 5, "VII & VIII": 4, "IX": 6, "X": 6 } },
  { subject: "Marathi", grades: { "I & II": 4, "III": 4, "IV & V": 4, "VI": 4, "VII & VIII": 4, "IX": 0, "X": 0 } },
  { subject: "Math", grades: { "I & II": 5, "III": 6, "IV & V": 5, "VI": 7, "VII & VIII": 7, "IX": 8, "X": 8 } },
  { subject: "Science", grades: { "I & II": 5, "III": 5, "IV & V": 5, "VI": 5, "VII & VIII": 5, "IX": 0, "X": 0 } },
  { subject: "S.S. (Social Studies)", grades: { "I & II": 0, "III": 0, "IV & V": 0, "VI": 5, "VII & VIII": 5, "IX": 8, "X": 8 } },
  { subject: "Science (Bio,Phy,Chem)", grades: { "I & II": 0, "III": 0, "IV & V": 0, "VI": 0, "VII & VIII": 0, "IX": 0, "X": 0 } },
  { subject: "Computer", grades: { "I & II": 2, "III": 2, "IV & V": 2, "VI": 2, "VII & VIII": 2, "IX": 3, "X": 3 } },
  
  // Co-scholastic subjects from PDF
  { subject: "Soft Skills", grades: { "I & II": 1, "III": 0, "IV & V": 0, "VI": 0, "VII & VIII": 0, "IX": 0, "X": 0 } },
  { subject: "GK", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 0, "VII & VIII": 0, "IX": 0, "X": 0 } },
  { subject: "Arts", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 1, "VII & VIII": 1, "IX": 0, "X": 0 } },
  { subject: "Craft", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 0, "VII & VIII": 1, "IX": 0, "X": 0 } },
  { subject: "Music", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 2, "VII & VIII": 1, "IX": 1, "X": 1 } },
  { subject: "Drama", grades: { "I & II": 1, "III": 0, "IV & V": 0, "VI": 1, "VII & VIII": 1, "IX": 0, "X": 0 } },
  { subject: "Mental Ability", grades: { "I & II": 0, "III": 0, "IV & V": 2, "VI": 0, "VII & VIII": 2, "IX": 0, "X": 0 } },
  { subject: "Lib", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 1, "VII & VIII": 1, "IX": 1, "X": 1 } },
  { subject: "Dance", grades: { "I & II": 1, "III": 1, "IV & V": 1, "VI": 1, "VII & VIII": 1, "IX": 0, "X": 0 } },

  // To support sub-subjects in IX & X specifically
  { subject: "Biology", grades: { "I & II": 0, "III": 0, "IV & V": 0, "VI": 0, "VII & VIII": 0, "IX": 3, "X": 3 } },
  { subject: "Physics", grades: { "I & II": 0, "III": 0, "IV & V": 0, "VI": 0, "VII & VIII": 0, "IX": 3, "X": 3 } },
  { subject: "Chemistry", grades: { "I & II": 0, "III": 0, "IV & V": 0, "VI": 0, "VII & VIII": 0, "IX": 3, "X": 3 } }
];

export const GRADE_GROUPS = [
  { name: "Grade I & II", value: "I & II" },
  { name: "Grade III", value: "III" },
  { name: "Grade IV & V", value: "IV & V" },
  { name: "Grade VI", value: "VI" },
  { name: "Grade VII & VIII", value: "VII & VIII" }
];

export const SAMPLE_TEACHER_ALLOTMENTS: TeacherAllotment[] = [
  // GRADE I
  {
    grade: "I O",
    classTeacher: "Ms. Monali H",
    subjects: {
      "English": "Ms.Sunaina S",
      "Hindi": "Ms.Muskan S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms.Vaishali",
      "Science": "Ms. Monali H",
      "Soft Skills": "Ms.Shwetali S",
      "Computer": "Ms.Sunanda",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "I T",
    classTeacher: "Ms.Muskan S",
    subjects: {
      "English": "Ms.Sunaina S",
      "Hindi": "Ms.Muskan S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms.Vaishali",
      "Science": "Ms. Monali H",
      "Soft Skills": "Ms.Shwetali S",
      "Computer": "Ms.Sunanda",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "I D",
    classTeacher: "Ms.Vaishali",
    subjects: {
      "English": "Ms.Sunaina S",
      "Hindi": "Ms.Muskan S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms.Vaishali",
      "Science": "Ms. Monali H",
      "Soft Skills": "Ms.Smita G",
      "Computer": "Ms.Sunanda",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  
  // GRADE II
  {
    grade: "II O",
    classTeacher: "Ms. Priyanka",
    subjects: {
      "English": "Ms.Sunaina S",
      "Hindi": "Ms.Muskan S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms.Vaishali",
      "Science": "Ms. Monali H",
      "Soft Skills": "Ms.Smita G",
      "Computer": "Ms.Sunanda",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Mangesh",
      "Craft": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "II T",
    classTeacher: "Ms.Sunaina S",
    subjects: {
      "English": "Ms.Sunaina S",
      "Hindi": "Ms.Muskan S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms.Vaishali",
      "Science": "Ms. Monali H",
      "Soft Skills": "Ms.Smita G",
      "Computer": "Ms.Sunanda",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Mangesh",
      "Craft": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE III
  {
    grade: "III O",
    classTeacher: "Ms.Sayali",
    subjects: {
      "English": "Ms.Shwetali S",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms. Bhakti B",
      "Science": "Ms.Sayali",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "III T",
    classTeacher: "Ms. Shilpa I",
    subjects: {
      "English": "Ms.Shwetali S",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms. Shilpa I",
      "Math": "Ms. Bhakti B",
      "Science": "Ms.Sayali",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "III D",
    classTeacher: "Ms.Varsha K",
    subjects: {
      "English": "Ms.Shwetali S",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms.Joshi",
      "Math": "Ms. Bhakti B",
      "Science": "Ms.Sayali",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE IV
  {
    grade: "IV O",
    classTeacher: "Ms.Smita G",
    subjects: {
      "English": "Ms.Smita G",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms. Shilpa I",
      "Math": "Mr. Pranav",
      "Science": "Ms.Sayali",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Mangesh",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "IV T",
    classTeacher: "Ms. Ketki D",
    subjects: {
      "English": "Ms.Smita G",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms. Shilpa I",
      "Math": "Ms. Bhakti B",
      "Science": "Ms. Ketki D",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Mangesh",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Mental Ability": "Mr. Pranav",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "IV D",
    classTeacher: "Ms.Shwetali S",
    subjects: {
      "English": "Ms.Shwetali S",
      "Hindi": "Ms.Jayashri S",
      "Marathi": "Ms. Shilpa I",
      "Math": "Mr. Pranav",
      "Science": "Ms. Ketki D",
      "Computer": "Ms.Varsha K",
      "GK": "Ms. Priyanka",
      "Arts": "Mr. Mangesh",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE V
  {
    grade: "V O",
    classTeacher: "Mr.Akshay",
    subjects: {
      "English": "Ms.Smita G",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Ms. Shilpa I",
      "Math": "Mr.Akshay",
      "Science": "Ms. Ketki D",
      "Computer": "Ms.Varsha K",
      "GK": "Didi",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "V T",
    classTeacher: "Mr.Janardhan",
    subjects: {
      "English": "Ms.Smita G",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Ms. Shilpa I",
      "Math": "Mr.Akshay",
      "Science": "Ms. Ketki D",
      "Computer": "Ms.Varsha K",
      "GK": "Didi",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Mental Ability": "Mr. Pranav",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "V D",
    classTeacher: "Mr. Manjule",
    subjects: {
      "English": "Mr. Satish",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Didi",
      "Math": "Mr.Akshay",
      "Science": "Mr. Manjule",
      "Computer": "Ms.Varsha K",
      "GK": "Didi",
      "Arts": "Mr. Borse",
      "Craft": "Ms. Komal",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE VI
  {
    grade: "VI O",
    classTeacher: "Mr.Kakade M",
    subjects: {
      "English": "Mr.Pravin K",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Didi",
      "Math": "Mr.Akshay",
      "Science": "Ms. Kavita P",
      "S.S. (Social Studies)": "Mr.Kakade M",
      "Computer": "Ms.Varsha K",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VI T",
    classTeacher: "Ms. Kavita P",
    subjects: {
      "English": "Mr.Pravin K",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Didi",
      "Math": "Ms. Anita C",
      "Science": "Ms. Kavita P",
      "S.S. (Social Studies)": "Mr.Kakade M",
      "Computer": "Ms.Varsha K",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Mental Ability": "Mr. Pranav",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VI D",
    classTeacher: "Mr.Pravin K",
    subjects: {
      "English": "Mr.Pravin K",
      "Hindi": "Mr.Janardhan",
      "Marathi": "Didi",
      "Math": "Ms. Anita C",
      "Science": "Ms. Kavita P",
      "S.S. (Social Studies)": "Mr.Kakade M",
      "Computer": "Ms.Varsha K",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE VII
  {
    grade: "VII O",
    classTeacher: "Ms.Purvi S",
    subjects: {
      "English": "Mr.Pravin K",
      "Hindi": "Mr.Sunil S",
      "Marathi": "Ms.Nandini W",
      "Math": "Ms. Anita C",
      "Science": "Mr. Manjule",
      "S.S. (Social Studies)": "Ms.Purvi S",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VII T",
    classTeacher: "Mr. Satish",
    subjects: {
      "English": "Mr. Satish",
      "Hindi": "Mr.Sunil S",
      "Marathi": "Ms.Nandini W",
      "Math": "Mr.Suraj T",
      "Science": "Ms. Kavita P",
      "S.S. (Social Studies)": "Ms.Purvi S",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Mental Ability": "Mr. Pranav",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VII D",
    classTeacher: "Ms. Anita C",
    subjects: {
      "English": "Mr.Pravin K",
      "Hindi": "Mr.Sunil S",
      "Marathi": "Ms.Nandini W",
      "Math": "Ms. Anita C",
      "Science": "Ms. Sarin S",
      "S.S. (Social Studies)": "Ms.Purvi S",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Pranav",
      "Arts": "Mr. Borse",
      "Craft": "Mr. Borse",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },

  // GRADE VIII
  {
    grade: "VIII O",
    classTeacher: "Mr. Akash M",
    subjects: {
      "English": "Mr. Satish",
      "Hindi": "Mr.Somnath S",
      "Marathi": "Ms.Nandini W",
      "Math": "Mr. Akash M",
      "Science": "Ms. Sarin S",
      "S.S. (Social Studies)": "Ms.Purvi S",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Manjule",
      "Arts": "Mr. Mangesh",
      "Craft": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VIII T",
    classTeacher: "Mr.Kamlesh",
    subjects: {
      "English": "Mr.Kamlesh",
      "Hindi": "Mr.Somnath S",
      "Marathi": "Ms.Nandini W",
      "Math": "Mr. Akash M",
      "Science": "Mr. Rupesh A",
      "S.S. (Social Studies)": "Ms.Purvi S",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Manjule",
      "Arts": "Mr. Mangesh",
      "Craft": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Mental Ability": "Mr. Pranav",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  {
    grade: "VIII D",
    classTeacher: "Mr. Rupesh A",
    subjects: {
      "English": "Mr. Satish",
      "Hindi": "Mr.Somnath S",
      "Marathi": "Ms.Nandini W",
      "Math": "Mr. Akash M",
      "Science": "Mr. Rupesh A",
      "S.S. (Social Studies)": "Mr. Amol",
      "Computer": "Mr.Uday P",
      "GK": "Mr. Manjule",
      "Arts": "Mr. Mangesh",
      "Craft": "Mr. Mangesh",
      "Music": "Mr. Yunus & Mr. Sagar",
      "Drama": "Mr. Kiran",
      "Lib": "Ms Sujata",
      "Dance": "Mr. Aditya"
    }
  },
  // GRADE IX
  {
    grade: "IX O",
    classTeacher: "Mr. Suraj T.",
    subjects: {
      "English": "Mr. Somnath S.",
      "Hindi": "Mr. Sunil S.",
      "Computer": "Mr.Uday P",
      "Math": "Mr. Suraj T.",
      "S.S. (Social Studies)": "Mr. Amol K.",
      "Biology": "Mr. Rupesh A.",
      "Physics": "Mr. Akash M.",
      "Chemistry": "Ms. Sarin S."
    }
  },
  {
    grade: "IX T",
    classTeacher: "Mr. Somnath S.",
    subjects: {
      "English": "Mr. Somnath S.",
      "Hindi": "Mr. Sunil S.",
      "Computer": "Mr.Uday P",
      "Math": "Mr. Suraj T.",
      "S.S. (Social Studies)": "Mr. Amol K.",
      "Biology": "Mr. Rupesh A.",
      "Physics": "Mr. Akash M.",
      "Chemistry": "Ms. Sarin S."
    }
  },
  // GRADE X
  {
    grade: "X O",
    classTeacher: "Mr. Amol K.",
    subjects: {
      "English": "Mr. Somnath S.",
      "Hindi": "Mr. Sunil S.",
      "Computer": "Mr.Uday P",
      "Math": "Mr. Suraj T.",
      "S.S. (Social Studies)": "Mr. Amol K.",
      "Biology": "Mr. Rupesh A.",
      "Physics": "Mr. Akash M.",
      "Chemistry": "Ms. Sarin S."
    }
  },
  {
    grade: "X T",
    classTeacher: "Mr. Sunil S.",
    subjects: {
      "English": "Mr. Somnath S.",
      "Hindi": "Mr. Sunil S.",
      "Computer": "Mr.Uday P",
      "Math": "Mr. Suraj T.",
      "S.S. (Social Studies)": "Mr. Amol K.",
      "Biology": "Mr. Rupesh A.",
      "Physics": "Mr. Akash M.",
      "Chemistry": "Ms. Sarin S."
    }
  }
];

export const EMPTY_TEACHER_ALLOTMENTS: TeacherAllotment[] = SAMPLE_TEACHER_ALLOTMENTS.map(a => ({
  grade: a.grade,
  classTeacher: "",
  subjects: {}
}));

export const TEACHER_ALLOTMENTS: TeacherAllotment[] = SAMPLE_TEACHER_ALLOTMENTS;

// Helper to determine which gradeGroup (from WEEKLY_WORKLOADS) a specific grade (e.g., "III O") belongs to
export function getGradeGroup(gradeStr: string): string {
  const parts = gradeStr.trim().split(" ");
  const mainGrade = parts[0].toUpperCase(); // "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
  
  if (mainGrade === "I" || mainGrade === "II") return "I & II";
  if (mainGrade === "III") return "III";
  if (mainGrade === "IV" || mainGrade === "V") return "IV & V";
  if (mainGrade === "VI") return "VI";
  if (mainGrade === "VII" || mainGrade === "VIII") return "VII & VIII";
  if (mainGrade === "IX") return "IX";
  if (mainGrade === "X" || mainGrade === "XO") return "X";
  return "I & II"; // fallback
}

export function getSubjectsForGrade(gradeStr: string): string[] {
  const upper = gradeStr.toUpperCase();
  // Grade IX or X
  if (upper.includes("IX") || upper.includes("X")) {
    return ["English", "Hindi", "Computer", "Math", "S.S. (Social Studies)", "Biology", "Physics", "Chemistry"];
  }
  // Grade VI to VIII (VI, VII, VIII)
  if (upper.includes("VI") || upper.includes("VII") || upper.includes("VIII")) {
    return ["Computer", "English", "Hindi", "Marathi", "Math", "S.S. (Social Studies)", "Science"];
  }
  // Grade I to V (I, II, III, IV, V)
  if (upper.includes("I") || upper.includes("II") || upper.includes("III") || upper.includes("IV") || upper.includes("V")) {
    return ["Computer", "Science", "English", "Hindi", "Marathi", "Math"];
  }
  // Fallback default
  return ["Computer", "English", "Hindi", "Marathi", "Math", "S.S. (Social Studies)", "Science", "Science (Bio,Phy,Chem)"];
}

export interface TeacherWorkloadReport {
  teacherName: string;
  assignedClasses: {
    grade: string;
    subject: string;
    weeklySessions: number;
  }[];
  totalWorkload: number;
}

// Compute workload report for all unique teachers using dynamic allotments
export function computeTeachersWorkloads(allotmentsList: TeacherAllotment[] = TEACHER_ALLOTMENTS): TeacherWorkloadReport[] {
  const reports: { [teacher: string]: TeacherWorkloadReport } = {};

  allotmentsList.forEach(allotment => {
    const gradeGroup = getGradeGroup(allotment.grade);
    
    // Class Teacher workload: We can give Ms./Mr. 1 direct workload session for CT periods
    const ctPeriodWorkload = 1; // CT always gets 1 session from CT subject workload
    const ctTeacherName = allotment.classTeacher;
    if (ctTeacherName && ctTeacherName.trim()) {
      if (!reports[ctTeacherName]) {
        reports[ctTeacherName] = { teacherName: ctTeacherName, assignedClasses: [], totalWorkload: 0 };
      }
      reports[ctTeacherName].assignedClasses.push({
        grade: allotment.grade,
        subject: "CT (Class Teacher Period)",
        weeklySessions: ctPeriodWorkload
      });
      reports[ctTeacherName].totalWorkload += ctPeriodWorkload;
    }

    Object.entries(allotment.subjects || {}).forEach(([subject, teacherStr]) => {
      if (!teacherStr || !teacherStr.trim()) return;
      // Split in case of composite teacher entries like "Mr. Yunus & Mr. Sagar" -> assign to both or keep combined
      const individualTeachers = teacherStr.split(" & ");
      individualTeachers.forEach(teacherName => {
        const trimmedTeacher = teacherName.trim();
        if (!trimmedTeacher) return;

        // Find standard workload for this subject in this grade group
        const matchingSubjectMapping = WEEKLY_WORKLOADS.find(w => w.subject === subject);
        const weeklySessions = matchingSubjectMapping ? (matchingSubjectMapping.grades[gradeGroup] || 0) : 0;

        if (weeklySessions === 0) return;

        if (!reports[trimmedTeacher]) {
          reports[trimmedTeacher] = { teacherName: trimmedTeacher, assignedClasses: [], totalWorkload: 0 };
        }

        // Add class allotment
        reports[trimmedTeacher].assignedClasses.push({
          grade: allotment.grade,
          subject: subject,
          weeklySessions: weeklySessions
        });
        reports[trimmedTeacher].totalWorkload += weeklySessions;
      });
    });
  });

  return Object.values(reports).sort((a, b) => b.totalWorkload - a.totalWorkload);
}
