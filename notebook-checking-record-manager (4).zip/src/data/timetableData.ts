// Samata International School Timetable Database (Academic Year 2026-27)
// Faithful to the uploaded physical schedule sheets with structural splits between Grade I-V and VI-X.

export interface TimetableSlot {
  periodNo: number; // 1 to 8
  time: string; // e.g., "8.55 am to 9.30 am"
  // Subjects from Monday to Saturday
  subjects: {
    Monday: string;
    Tuesday: string;
    Wednesday: string;
    Thursday: string;
    Friday: string;
    Saturday?: string; // Saturdays are not present for Grades I-V
  };
}

export interface ClassTimetable {
  classId: string; // e.g. "class_vi_o"
  className: string; // e.g. "Grade VI Orchid"
  isPrimary: boolean; // True for Grades I-V (no Saturday classes, earlier lunch), False for VI-X
  classTeacher: string;
  periods: TimetableSlot[];
}

// ------------------------------------------------------------------
// HIGH-FIDELITY RAW GRIDS POPULATED FROM SCHOOL TIME-TABLE SHEETS
// ------------------------------------------------------------------

export const TIMETABLES_RAW_DATA: { [classId: string]: TimetableSlot[] } = {
  // === GRADE VI ORCHID ===
  class_vi_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "SS", Tuesday: "SS", Wednesday: "Music", Thursday: "Music", Friday: "SS", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Art", Tuesday: "Hindi", Wednesday: "SS", Thursday: "SS", Friday: "Library", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Math", Tuesday: "English", Wednesday: "Computer", Thursday: "Swimming G", Friday: "Hindi", Saturday: "Math" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Marathi", Tuesday: "Math", Wednesday: "Math", Thursday: "Swimming G", Friday: "Math", Saturday: "Hindi" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "English", Tuesday: "Swimming B", Wednesday: "Dance", Thursday: "English", Friday: "English", Saturday: "Science" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Science", Tuesday: "Swimming B", Wednesday: "English", Thursday: "Science", Friday: "Science", Saturday: "English" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "GK", Tuesday: "Science", Wednesday: "Hindi", Thursday: "Marathi", Friday: "Drama", Saturday: "Marathi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Hindi", Tuesday: "CT", Wednesday: "Marathi", Thursday: "Math", Friday: "Computer", Saturday: "Math" } }
  ],
  // === GRADE VI TULIP ===
  class_vi_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Science", Thursday: "Science", Friday: "Science", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Hindi", Tuesday: "MA", Wednesday: "Music", Thursday: "Art", Friday: "Music", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Marathi", Tuesday: "Computer", Wednesday: "Hindi", Thursday: "Swimming G", Friday: "English", Saturday: "MA" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "SS", Tuesday: "English", Wednesday: "Marathi", Thursday: "Swimming G", Friday: "Hindi", Saturday: "Library" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Math", Tuesday: "Swimming B", Wednesday: "Math", Thursday: "Math", Friday: "Math", Saturday: "Math" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Computer", Tuesday: "Swimming B", Wednesday: "Dance", Thursday: "Marathi", Friday: "SS", Saturday: "SS" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "English", Tuesday: "SS", Wednesday: "SS", Thursday: "English", Friday: "CT", Saturday: "English" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "GK", Tuesday: "Marathi", Wednesday: "English", Thursday: "Hindi", Friday: "Drama", Saturday: "Hindi" } }
  ],
  // === GRADE VI DAISY ===
  class_vi_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "English", Thursday: "English", Friday: "English", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Dance", Tuesday: "Music", Wednesday: "Math", Thursday: "Marathi", Friday: "Math", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Computer", Tuesday: "Math", Wednesday: "SS", Thursday: "Swimming G", Friday: "Art", Saturday: "Music" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Science", Tuesday: "Marathi", Wednesday: "Science", Thursday: "Swimming G", Friday: "Math", Saturday: "Science" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Marathi", Tuesday: "Swimming B", Wednesday: "Marathi", Thursday: "Hindi", Friday: "Science", Saturday: "Library" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Math", Tuesday: "Swimming B", Wednesday: "SS", Thursday: "SS", Friday: "Drama", Saturday: "Hindi" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Hindi", Tuesday: "English", Wednesday: "Science", Thursday: "Math", Friday: "Hindi", Saturday: "Hindi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "SS", Tuesday: "GK", Wednesday: "Computer", Thursday: "CT", Friday: "Math", Saturday: "SS" } }
  ],

  // === GRADE VII ORCHID ===
  class_vii_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "SS", Tuesday: "SS", Wednesday: "SS", Thursday: "SS", Friday: "SS", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Science", Tuesday: "Dance", Wednesday: "Hindi", Thursday: "Science", Friday: "Computer", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Music", Tuesday: "Science", Wednesday: "English", Thursday: "English", Friday: "Computer", Saturday: "Art" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Math", Thursday: "Marathi", Friday: "English", Saturday: "Math" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Swimming B", Tuesday: "Hindi", Wednesday: "Sports", Thursday: "Hindi", Friday: "Swimming G", Saturday: "Science" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Swimming B", Tuesday: "English", Wednesday: "Marathi", Thursday: "Math", Friday: "Swimming G", Saturday: "Math" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Hindi", Tuesday: "Marathi", Wednesday: "Science", Thursday: "Drama", Friday: "Hindi", Saturday: "Library" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "English", Tuesday: "Math", Wednesday: "GK", Thursday: "CT", Friday: "Marathi", Saturday: "English" } }
  ],
  // === GRADE VII TULIP ===
  class_vii_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "English", Thursday: "English", Friday: "English", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Science", Tuesday: "Math", Wednesday: "Science", Thursday: "Science", Friday: "Science", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Hindi", Tuesday: "Science", Wednesday: "Computer", Thursday: "Computer", Friday: "Hindi", Saturday: "Marathi" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Math", Tuesday: "Marathi", Wednesday: "Math", Thursday: "Math", Friday: "Math", Saturday: "MA" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Swimming B", Tuesday: "SS", Wednesday: "Sports", Thursday: "SS", Friday: "Swimming G", Saturday: "Art" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Swimming B", Tuesday: "Music", Wednesday: "MA", Thursday: "Marathi", Friday: "Swimming G", Saturday: "SS" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "SS", Tuesday: "Dance", Wednesday: "Drama", Thursday: "Hindi", Friday: "Marathi", Saturday: "Hindi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "English", Tuesday: "Hindi", Wednesday: "CT", Thursday: "GK", Friday: "SS", Saturday: "Library" } }
  ],
  // === GRADE VII DAISY ===
  class_vii_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Math", Thursday: "Math", Friday: "Math", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "English", Thursday: "Marathi", Friday: "Hindi", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Science", Tuesday: "Hindi", Wednesday: "Library", Thursday: "Hindi", Friday: "Marathi", Saturday: "Computer" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "SS", Tuesday: "SS", Wednesday: "Science", Thursday: "SS", Friday: "Computer", Saturday: "SS" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Swimming B", Tuesday: "Dance", Wednesday: "Sports", Thursday: "Science", Friday: "Swimming G", Saturday: "English" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Swimming B", Tuesday: "Marathi", Wednesday: "Music", Thursday: "English", Friday: "Swimming G", Saturday: "Art" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Math", Tuesday: "Science", Wednesday: "Math", Thursday: "Science", Friday: "English", Saturday: "GK" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Hindi", Tuesday: "SS", Wednesday: "Drama", Thursday: "CT", Friday: "Hindi", Saturday: "Marathi" } }
  ],

  // === GRADE VIII ORCHID ===
  class_viii_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Marathi", Thursday: "Math", Friday: "GK", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "Computer", Thursday: "English", Friday: "Art", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "SS", Tuesday: "Computer", Wednesday: "English", Thursday: "Science", Friday: "English", Saturday: "English" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "SS", Thursday: "Library", Friday: "Hindi", Saturday: "Music" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Hindi", Tuesday: "Math", Wednesday: "Swimming B", Thursday: "Hindi", Friday: "Swimming G", Saturday: "SS" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Sports", Tuesday: "SS", Wednesday: "Swimming B", Thursday: "SS", Friday: "Swimming G", Saturday: "Math" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Marathi", Tuesday: "Hindi", Wednesday: "Math", Thursday: "Marathi", Friday: "Math", Saturday: "Marathi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Science", Tuesday: "Dance", Wednesday: "Science", Thursday: "Drama", Friday: "CT", Saturday: "Hindi" } }
  ],
  // === GRADE VIII TULIP ===
  class_viii_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "Science", Thursday: "English", Friday: "English", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "SS", Tuesday: "SS", Wednesday: "SS", Thursday: "Science", Friday: "MA", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Science", Tuesday: "Math", Wednesday: "Math", Thursday: "Math", Friday: "SS", Saturday: "Art" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Computer", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Science", Friday: "MA", Saturday: "Computer" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "SS", Tuesday: "Music", Wednesday: "Swimming B", Thursday: "Drama", Friday: "Swimming G", Saturday: "Math" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Sports", Tuesday: "English", Wednesday: "Swimming B", Thursday: "Library", Friday: "Swimming G", Saturday: "Marathi" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Hindi", Tuesday: "GK", Wednesday: "Dance", Thursday: "English", Friday: "Hindi", Saturday: "Hindi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Marathi", Tuesday: "Science", Wednesday: "Marathi", Thursday: "Marathi", Friday: "CT", Saturday: "Math" } }
  ],
  // === GRADE VIII DAISY ===
  class_viii_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Science", Thursday: "Science", Friday: "Science", Saturday: "Super Saturday" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Math", Thursday: "Math", Friday: "Math", Saturday: "Super Saturday" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "English", Tuesday: "Marathi", Wednesday: "Marathi", Thursday: "Marathi", Friday: "Math", Saturday: "Hindi" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Dance", Tuesday: "English", Wednesday: "Drama", Thursday: "English", Friday: "English", Saturday: "English" } },
    { periodNo: 5, time: "11.45 am to 12.25 pm", subjects: { Monday: "Computer", Tuesday: "Hindi", Wednesday: "Swimming B", Thursday: "SS", Friday: "Swimming G", Saturday: "Art" } },
    { periodNo: 6, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Sports", Tuesday: "SS", Wednesday: "Swimming B", Thursday: "CT", Friday: "Swimming G", Saturday: "Computer" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "SS", Tuesday: "Math", Wednesday: "Hindi", Thursday: "Hindi", Friday: "Library", Saturday: "SS" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Hindi", Tuesday: "Marathi", Wednesday: "SS", Thursday: "English", Friday: "GK", Saturday: "Music" } }
  ],

  // === GRADE I ORCHID ===
  class_i_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "WW", Thursday: "Science", Friday: "Science" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Marathi", Tuesday: "Marathi", Wednesday: "WW", Thursday: "Drama", Friday: "English" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Math", Tuesday: "Swimming", Wednesday: "Math", Thursday: "Math", Friday: "Sports" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "SS", Tuesday: "Swimming", Wednesday: "Music", Thursday: "English", Friday: "Sports" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "English", Tuesday: "Math", Wednesday: "English", Thursday: "Marathi", Friday: "Math" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "Computer", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Computer", Tuesday: "English", Wednesday: "Library", Thursday: "Marathi", Friday: "CT" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Art", Tuesday: "Craft", Wednesday: "Dance", Thursday: "Science", Friday: "GK" } }
  ],
  // === GRADE I TULIP ===
  class_i_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "WW", Thursday: "Hindi", Friday: "Drama" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "WW", Thursday: "Science", Friday: "Science" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "English", Tuesday: "SS", Wednesday: "English", Thursday: "Music", Friday: "Sports" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Math", Thursday: "Math", Friday: "Sports" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Computer", Tuesday: "English", Wednesday: "Marathi", Thursday: "English", Friday: "English" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Marathi", Tuesday: "Marathi", Wednesday: "Hindi", Thursday: "Science", Friday: "Math" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Library", Tuesday: "Craft", Wednesday: "Swimming", Thursday: "Dance", Friday: "CT" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "GK", Tuesday: "Computer", Wednesday: "Swimming", Thursday: "Marathi", Friday: "Art" } }
  ],
  // === GRADE I DAISY ===
  class_i_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "WW", Thursday: "Math", Friday: "Math" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "English", Tuesday: "SS", Wednesday: "WW", Thursday: "Computer", Friday: "Computer" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Dance", Tuesday: "Craft", Wednesday: "Music", Thursday: "Drama", Friday: "Sports" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Library", Tuesday: "English", Wednesday: "Science", Thursday: "Science", Friday: "Sports" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Hindi", Friday: "Science" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Marathi", Thursday: "English", Friday: "English" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Marathi", Tuesday: "Marathi", Wednesday: "English", Thursday: "Swimming", Friday: "Art" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "GK", Wednesday: "Math", Thursday: "Swimming", Friday: "Marathi" } }
  ],

  // === GRADE II ORCHID ===
  class_ii_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "GK", Tuesday: "CT", Wednesday: "WW", Thursday: "Marathi", Friday: "Marathi" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "SS", Tuesday: "Math", Wednesday: "WW", Thursday: "English", Friday: "Math" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Computer", Tuesday: "English", Wednesday: "Sports", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Marathi", Tuesday: "Marathi", Wednesday: "Sports", Thursday: "Music", Friday: "Drama" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Science", Thursday: "Science", Friday: "Craft" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Math", Tuesday: "Library", Wednesday: "English", Thursday: "Math", Friday: "Science" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "English", Tuesday: "Computer", Wednesday: "Math", Thursday: "English", Friday: "Swimming" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "Art", Thursday: "Dance", Friday: "Swimming" } }
  ],
  // === GRADE II TULIP ===
  class_ii_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "English", Wednesday: "WW", Thursday: "English", Friday: "English" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Computer", Tuesday: "Computer", Wednesday: "WW", Thursday: "Math", Friday: "Marathi" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Sports", Thursday: "Science", Friday: "Swimming" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "Sports", Thursday: "Hindi", Friday: "Swimming" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Marathi", Tuesday: "Marathi", Wednesday: "Drama", Thursday: "Math", Friday: "Hindi" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "SS", Tuesday: "Math", Wednesday: "Art", Thursday: "Marathi", Friday: "Music" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Math", Tuesday: "Library", Wednesday: "Science", Thursday: "GK", Friday: "Math" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "Science", Wednesday: "English", Thursday: "Craft", Friday: "Dance" } }
  ],

  // === GRADE III ORCHID ===
  class_iii_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Swimming B", Tuesday: "Science", Wednesday: "WW", Thursday: "Science", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Swimming B", Tuesday: "Math", Wednesday: "WW", Thursday: "Math", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Marathi", Tuesday: "Music", Wednesday: "English", Thursday: "English", Friday: "English" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Computer", Tuesday: "English", Wednesday: "Art", Thursday: "Marathi", Friday: "Marathi" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Science", Tuesday: "GK", Wednesday: "Science", Thursday: "English", Friday: "Science" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Hindi", Tuesday: "Craft", Wednesday: "Math", Thursday: "Computer", Friday: "Math" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Dance", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Math", Tuesday: "CT", Wednesday: "Marathi", Thursday: "Math", Friday: "Library" } }
  ],
  // === GRADE III TULIP ===
  class_iii_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Swimming B", Tuesday: "Marathi", Wednesday: "WW", Thursday: "Marathi", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Swimming B", Tuesday: "Hindi", Wednesday: "WW", Thursday: "Science", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "Math", Thursday: "Computer", Friday: "Math" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Hindi", Tuesday: "Science", Wednesday: "Hindi", Thursday: "Math", Friday: "Library" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Math", Tuesday: "Craft", Wednesday: "Marathi", Thursday: "GK", Friday: "Marathi" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "English", Tuesday: "English", Wednesday: "English", Thursday: "English", Friday: "English" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Science", Tuesday: "Music", Wednesday: "Science", Thursday: "Art", Friday: "Science" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Dance", Tuesday: "Computer", Wednesday: "CT", Thursday: "Hindi", Friday: "Hindi" } }
  ],
  // === GRADE III DAISY ===
  class_iii_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Swimming B", Tuesday: "Computer", Wednesday: "WW", Thursday: "Computer", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Swimming B", Tuesday: "Craft", Wednesday: "WW", Thursday: "Library", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Science", Tuesday: "Marathi", Wednesday: "Marathi", Thursday: "Marathi", Friday: "Marathi" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Math", Tuesday: "Dance", Wednesday: "Math", Thursday: "Science", Friday: "Hindi" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Hindi", Friday: "Math" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "GK", Tuesday: "Math", Wednesday: "Science", Thursday: "Math", Friday: "Science" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "English", Tuesday: "Science", Wednesday: "English", Thursday: "English", Friday: "English" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "English", Wednesday: "Math", Thursday: "Art", Friday: "Music" } }
  ],

  // === GRADE IV ORCHID ===
  class_iv_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "English", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Math", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "Math", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Marathi", Tuesday: "Science", Wednesday: "Math", Thursday: "Science", Friday: "Math" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Science", Tuesday: "Math", Wednesday: "Dance", Thursday: "Hindi", Friday: "Science" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Music", Tuesday: "English", Wednesday: "English", Thursday: "Marathi", Friday: "English" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Math", Tuesday: "Computer", Wednesday: "GK", Thursday: "Math", Friday: "Hindi" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Hindi", Tuesday: "Craft", Wednesday: "Computer", Thursday: "Library", Friday: "Marathi" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "Hindi", Wednesday: "Science", Thursday: "Music", Friday: "Art" } }
  ],
  // === GRADE IV TULIP ===
  class_iv_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Hindi", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "Science", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Math", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "Hindi", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "English", Tuesday: "MA", Wednesday: "Dance", Thursday: "Math", Friday: "Computer" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Science", Tuesday: "English", Wednesday: "Computer", Thursday: "English", Friday: "Math" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Marathi", Tuesday: "Science", Wednesday: "Math", Thursday: "Music", Friday: "Science" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Music", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Marathi", Friday: "English" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Math", Tuesday: "Marathi", Wednesday: "Art", Thursday: "English", Friday: "MA" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "Library", Wednesday: "Science", Thursday: "GK", Friday: "Craft" } }
  ],
  // === GRADE IV DAISY ===
  class_iv_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "English", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "English", Friday: "Swimming G" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Marathi", Tuesday: "Swimming B", Wednesday: "WW", Thursday: "Marathi", Friday: "Swimming G" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Science", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Math", Tuesday: "Hindi", Wednesday: "Math", Thursday: "Math", Friday: "Computer" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Dance", Tuesday: "English", Wednesday: "English", Thursday: "Science", Friday: "English" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Library", Tuesday: "Math", Wednesday: "Marathi", Thursday: "Music", Friday: "Math" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Music", Tuesday: "Art", Wednesday: "GK", Thursday: "Math", Friday: "Science" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "Craft", Wednesday: "Hindi", Thursday: "Computer", Friday: "Math" } }
  ],

  // === GRADE V ORCHID ===
  class_v_o: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "WW", Thursday: "Math", Friday: "Math" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Music", Tuesday: "Computer", Wednesday: "WW", Thursday: "Music", Friday: "English" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Swimming B", Tuesday: "Dance", Wednesday: "Marathi", Thursday: "Swimming G", Friday: "Art" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Swimming B", Tuesday: "Marathi", Wednesday: "English", Thursday: "Swimming G", Friday: "English" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Hindi", Tuesday: "Math", Wednesday: "Hindi", Thursday: "Library", Friday: "Hindi" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "Science", Thursday: "Science", Friday: "Science" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Computer", Tuesday: "Hindi", Wednesday: "Math", Thursday: "Math", Friday: "Craft" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "CT", Tuesday: "English", Wednesday: "English", Thursday: "Marathi", Friday: "GK" } }
  ],
  // === GRADE V TULIP ===
  class_v_t: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Hindi", Tuesday: "Hindi", Wednesday: "WW", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Computer", Tuesday: "Marathi", Wednesday: "WW", Thursday: "Science", Friday: "Music" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Swimming B", Tuesday: "Math", Wednesday: "English", Thursday: "Swimming G", Friday: "Math" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Swimming B", Tuesday: "Science", Wednesday: "Science", Thursday: "Swimming G", Friday: "Science" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "MA", Tuesday: "MA", Wednesday: "Math", Thursday: "Math", Friday: "Craft" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Dance", Tuesday: "English", Wednesday: "English", Thursday: "English", Friday: "Computer" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "Science", Tuesday: "GK", Wednesday: "Art", Thursday: "Music", Friday: "English" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Marathi", Tuesday: "CT", Wednesday: "Math", Thursday: "Library", Friday: "Marathi" } }
  ],
  // === GRADE V DAISY ===
  class_v_d: [
    { periodNo: 1, time: "8.55 am to 9.30 am", subjects: { Monday: "Science", Tuesday: "Science", Wednesday: "WW", Thursday: "Science", Friday: "Science" } },
    { periodNo: 2, time: "9.30 am to 10.10 am", subjects: { Monday: "Math", Tuesday: "Math", Wednesday: "WW", Thursday: "Math", Friday: "Math" } },
    { periodNo: 3, time: "10.25 am to 11.05 am", subjects: { Monday: "Swimming B", Tuesday: "Marathi", Wednesday: "Math", Thursday: "Swimming G", Friday: "Music" } },
    { periodNo: 4, time: "11.05 am to 11.45 am", subjects: { Monday: "Swimming B", Tuesday: "Hindi", Wednesday: "Hindi", Thursday: "Swimming G", Friday: "Craft" } },
    { periodNo: 5, time: "12.25 pm to 1.05 pm", subjects: { Monday: "Library", Tuesday: "GK", Wednesday: "English", Thursday: "English", Friday: "Math" } },
    { periodNo: 6, time: "1.05 pm to 1.45 pm", subjects: { Monday: "Math", Tuesday: "Dance", Wednesday: "Art", Thursday: "Hindi", Friday: "Hindi" } },
    { periodNo: 7, time: "1.45 pm to 2.20 pm", subjects: { Monday: "English", Tuesday: "English", Wednesday: "Marathi", Thursday: "Computer", Friday: "Computer" } },
    { periodNo: 8, time: "2.20 pm to 2.55 pm", subjects: { Monday: "Marathi", Tuesday: "Music", Wednesday: "Science", Thursday: "CT", Friday: "English" } }
  ]
};

// ------------------------------------------------------------------
// UTILITY FUNCTIONS TO RESOLVE DYNAMIC TEACHERS AND WORKLOADS
// ------------------------------------------------------------------

/**
 * Resolves the display teacher name for a specific subject in a class
 * directly from the teacher allotments mapping.
 * Special cases like CT are resolved to the Class Teacher itself.
 */
export function resolveTeacherForSubject(
  className: string,
  subject: string,
  allotments: any[]
): string {
  // Normalize className to compare with allotment (e.g. "Grade VI Orchid" -> grade "VI O", "Grade I Tulip" -> grade "I T")
  const normGrade = className
    .replace("Grade ", "")
    .trim()
    .replace("Orchid", "O")
    .replace("Tulip", "T")
    .replace("Daisy", "D")
    .replace("O", "O")
    .replace("T", "T")
    .replace("D", "D");

  const allotment = allotments.find(
    (a) => a.grade.toLowerCase().replace(" ", "") === normGrade.toLowerCase().replace(" ", "")
  );

  if (!allotment) return "";

  // Normalize subject to match allotment keys
  let lookupSubject = subject.trim();
  const upperSub = lookupSubject.toUpperCase();

  // Explicit check for individual SS teachers for Grade X
  if (upperSub.includes("AMOL")) {
    return "Mr. Amol";
  }
  if (upperSub.includes("KAKAD") || upperSub.includes("KAKADE")) {
    return "Mr.Kakade M";
  }

  const parts = normGrade.split(" ");
  const gradeStr = parts[0].toUpperCase();
  const isPrimary = ["I", "II", "III", "IV", "V"].includes(gradeStr);

  if (upperSub === "SS" || upperSub === "S.S." || upperSub === "S. S.") {
    if (isPrimary) {
      lookupSubject = "Soft Skills";
    } else {
      lookupSubject = "S.S. (Social Studies)";
    }
  } else if (upperSub.includes("SOCIAL STUDIES") || upperSub === "SOCIAL SCIENCE") {
    lookupSubject = "S.S. (Social Studies)";
  } else if (upperSub === "SCIENCE") {
    if (allotment.subjects && !allotment.subjects["Science"] && allotment.subjects["Science (Bio,Phy,Chem)"]) {
      lookupSubject = "Science (Bio,Phy,Chem)";
    }
  }

  // Special periods
  if (lookupSubject === "CT" || lookupSubject === "Meditation" || lookupSubject.includes("Class Teacher")) {
    return allotment.classTeacher || "Class Teacher";
  }

  // WW or FF (Foundational Course)
  if (lookupSubject === "WW" || lookupSubject === "WW/FF" || lookupSubject === "FF") {
    return allotment.classTeacher || "Class Teacher";
  }

  // Look up standard subject mapping
  const mappedTeacher = allotment.subjects[lookupSubject];
  if (mappedTeacher) return mappedTeacher;

  // Partial match helper (e.g. "Arts" vs "Arts")
  const keys = Object.keys(allotment.subjects);
  const matchedKey = keys.find((k) => {
    const kNorm = k.toLowerCase().replace(/[^a-z0-9]/g, "");
    const subNorm = lookupSubject.toLowerCase().replace(/[^a-z0-9]/g, "");
    return kNorm.startsWith(subNorm) || subNorm.startsWith(kNorm) || kNorm.includes(subNorm) || subNorm.includes(kNorm);
  });
  if (matchedKey) return allotment.subjects[matchedKey];

  return "";
}

/**
 * Generates the full detailed timetable list (combining Raw Subjects with Active Teacher Allotments)
 */
export function generateFullSchoolTimetables(allotments: any[]): ClassTimetable[] {
  const result: ClassTimetable[] = [];

  Object.entries(TIMETABLES_RAW_DATA).forEach(([classId, periodsRaw]) => {
    // Translate classId to Class Name
    const rawClassKey = classId.replace("class_", "");
    const parts = rawClassKey.split("_"); // e.g. ["vi", "o"] or ["i", "o"]
    
    const gradeRoman = parts[0].toUpperCase();
    const branchWord = parts[1] === "o" ? "Orchid" : parts[1] === "t" ? "Tulip" : "Daisy";
    const className = `Grade ${gradeRoman} ${branchWord}`;

    const isPrimary = ["I", "II", "III", "IV", "V"].includes(gradeRoman);

    // Resolve Class Teacher
    const normGrade = `${gradeRoman} ${parts[1].toUpperCase()}`;
    const allotment = allotments.find(
      (a) => a.grade.toLowerCase().replace(" ", "") === normGrade.toLowerCase().replace(" ", "")
    );
    const classTeacher = allotment ? allotment.classTeacher : "";

    result.push({
      classId,
      className,
      isPrimary,
      classTeacher,
      periods: periodsRaw
    });
  });

  return result.sort((a, b) => a.className.localeCompare(b.className));
}

export interface TeacherAgendaSlot {
  day: string;
  periodNo: number;
  time: string;
  className: string;
  classId: string;
  subject: string;
}

/**
 * Compiles a teacher's personalized timetable (agenda) sorted chronologically day-wise
 * by looking up all matches in the active school-wide schedule.
 */
export function getTeacherWeeklyTimetable(
  teacherName: string,
  allotments: any[],
  fullTimetables: ClassTimetable[]
): { [day: string]: TeacherAgendaSlot[] } {
  const agenda: { [day: string]: TeacherAgendaSlot[] } = {
    Monday: [],
    Tuesday: [],
    Wednesday: [],
    Thursday: [],
    Friday: [],
    Saturday: []
  };

  if (!teacherName) return agenda;

  const tLower = teacherName.toLowerCase().trim();

  fullTimetables.forEach((ct) => {
    ct.periods.forEach((p) => {
      Object.entries(p.subjects).forEach(([day, subject]) => {
        if (!subject) return;

        // Find which teacher teaches this subject in this class
        const displayTeacher = resolveTeacherForSubject(ct.className, subject, allotments);
        if (displayTeacher && displayTeacher.toLowerCase().includes(tLower)) {
          agenda[day].push({
            day,
            periodNo: p.periodNo,
            time: p.time,
            className: ct.className,
            classId: ct.classId,
            subject: subject
          });
        }
      });
    });
  });

  // Sort each day's list chronologically by periodNo
  Object.keys(agenda).forEach((day) => {
    agenda[day].sort((a, b) => a.periodNo - b.periodNo);
  });

  return agenda;
}
