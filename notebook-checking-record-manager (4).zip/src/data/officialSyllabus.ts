export interface SyllabusItem {
  subject: string;
  topics: string[];
}

export const OFFICIAL_SYLLABUS_BANK: { [grade: string]: SyllabusItem[] } = {};

export const APRIL_SYLLABUS_BANK: { [grade: string]: SyllabusItem[] } = {
  "Grade I": [
    { subject: "English", topics: ["Ls. 1 New Friends", "Poem: At School"] },
    { subject: "Hindi", topics: ["स्वर और व्यंजन", "बारहखडी"] },
    { subject: "Marathi", topics: ["स्वर -अ ते ई"] },
    { subject: "EVS", topics: ["Ch. 1 Living and Non Living Things"] },
    { subject: "Math", topics: ["Ch. 1- Numbers up to 9", "Tables 1 to 4"] },
    { subject: "Computer", topics: ["Ch. 1 Computer Wonderland"] }
  ],
  "Grade II": [
    { subject: "English", topics: ["Ls. 1 The Magical Pearl", "Poem: The Jumblies"] },
    { subject: "Hindi", topics: ["नीमा की दादी", "घर"] },
    { subject: "Marathi", topics: ["1.अ -कार (दोन अक्षरी)", "2.अ - कार (तीन अक्षरी)", "3.अ -कार (चार अक्षरी)"] },
    { subject: "EVS", topics: ["Ch. 1 Types of Plant", "Ch. 2 Plants - Our Friends"] },
    { subject: "Math", topics: ["Ch.1 Numbers upto 200", "Tables 1 to 10"] },
    { subject: "Computer", topics: ["Ch. 1 Decoding Computers"] }
  ],
  "Grade III": [
    { subject: "English", topics: ["Lesson: 1. Aladin and the Magic Lamp", "Grammar: 1. Nouns 2. Common and Proper Nouns 3. Singular and Plural 4. Nouns: Gender 5. Possessive Nouns"] },
    { subject: "Hindi", topics: ["Lesson: 1) सीखो 2) चींटी", "Grammar: संज्ञा"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - १.सँडविच पाठ क्र - २.माझा वाढदिवस", "Grammar: अंक - १ ते २०"] },
    { subject: "EVS", topics: ["Ch. 1 Living and Non Living Things", "Ch. 2 Plants and Their Parts"] },
    { subject: "Math", topics: ["Ch. 1 Numbers Beyond 999", "Tables 1 to 10"] },
    { subject: "Computer", topics: ["Ch. 1 The Hardware and Software Safari"] }
  ],
  "Grade IV": [
    { subject: "English", topics: ["Ls. 1 Kaguya", "Grammar: 1. Nouns 2. Common and Proper Nouns"] },
    { subject: "Hindi", topics: ["Lesson: 1) चिड़िया का गीत 2) बगीचे का घोंघा", "Grammar: संज्ञा"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र -१. आकाशातल्या चंद्रा पाठ क्र - २. घराचा डबा", "Grammar: नाम, अंक - १ ते ३०"] },
    { subject: "EVS", topics: ["Ch. 1 Plants: The Producers", "Ch. 2 Adaptation in Plants"] },
    { subject: "Math", topics: ["Ch. 1 Numbers Beyond 9999", "Tables 1 to 12"] },
    { subject: "Computer", topics: ["Ch. 1 Managing Files and Folders"] }
  ],
  "Grade V": [
    { subject: "English", topics: ["Lesson: 1. Chuskit Goes to School 2. A Pocketful of Sympathy", "Grammar: 1. Nouns and Their Types 2. Singular and Plural Nouns", "Writing Skills: 1. Making a Poster"] },
    { subject: "Hindi", topics: ["Lesson: 1) किरन 2) न्याय की कुर्सी", "Grammar: संज्ञा"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र -१. रोप लावूया पाठ क्र -२. मला काही नाही द्या", "Grammar: अंक -१ ते ४०"] },
    { subject: "EVS", topics: ["Ch. 1 Growing Plants", "Ch. 2 Animals: Habitat and Adaptations"] },
    { subject: "Math", topics: ["Ch.1. Numbers", "Tables 2 to 15"] },
    { subject: "Computer", topics: ["Ch. 1 Personalising Windows 10"] }
  ],
  "Grade VI": [
    { subject: "English", topics: ["Literature: 1) A Bottle of Dew", "Grammar: 1) Nouns and Their Kinds 2) Nouns: Singular and Plural", "Composition: Letter Writing"] },
    { subject: "Hindi", topics: ["Lesson: 1) मातृभूमि 2) गोल", "Grammar: संज्ञा"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - १. आई (कविता)", "Grammar: नाम, अंक - १ ते ५०"] },
    { subject: "Science", topics: ["Ch. 1 Exploring the Marvels of Science", "Ch. 2 Diversity in the Living World"] },
    { subject: "Math", topics: ["Ch. 1 Patterns in Mathematics", "Ch. 2 Lines and Angles", "Tables 2 to 18"] },
    { subject: "S.S. (Social Studies)", topics: ["Geography - Ch. 1 Locating Places on Earth", "History - Ch. 4 Timeline and Sources of History"] },
    { subject: "Computer", topics: ["Ch. 1 Exploring Digital Services"] }
  ],
  "Grade VII": [
    { subject: "English", topics: ["Literature: 1) The Day The River Spoke", "Grammar: 1) Nouns: Their Kinds 2) Articles", "Composition: Letter Writing"] },
    { subject: "Hindi", topics: ["Lesson: 1) माँ, कह एक कहानी (कविता) 2) तीन बुद्धिमान (लोककथा)", "Grammar: अनुच्छेद लेखन"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - १. प्रमाण (कविता)", "Grammar: नाम व प्रकार, अंक - १ ते ५०"] },
    { subject: "Science", topics: ["Ch. 2 Acids, Bases, Neutral", "Ch. 3 Electricity"] },
    { subject: "Math", topics: ["Ch. 1 Large Numbers", "Ch. 2 Arithmetic Expression (Half)", "Tables 2 to 20"] },
    { subject: "S.S. (Social Studies)", topics: ["Geography - Ch.1 Geographical Diversity of India", "Civics - Ch.4 New Beginnings: Cities and States"] },
    { subject: "Computer", topics: ["Ch. 1 Digital Defenders"] }
  ],
  "Grade VIII": [
    { subject: "English", topics: ["Literature: 1. The Wit that Won Hearts 2. A Concrete Example", "Grammar: 1. Parts of Speech 2. Word Formation", "Writing Skills: Writing a Letter"] },
    { subject: "Hindi", topics: ["Lesson: 1) स्वदेश (कविता) 2) दो गौरैया (कहानी)"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - १. भारतमाते असा तिरंगा (कविता)", "Grammar: नाम व प्रकार, अंक - १ ते ५०"] },
    { subject: "Science", topics: ["Ch. 1 Exploring the Investigative World of Science", "Ch. 2 The Invisible Living World: Beyond our Naked Eye"] },
    { subject: "Math", topics: ["Ch. 1 A Square and A Cube", "Ch. 2 Power Play", "Tables 2 to 20"] },
    { subject: "S.S. (Social Studies)", topics: ["History - Ch- 1 Reshaping India's Political Map"] },
    { subject: "Computer", topics: ["Ch. 1 Popular E-services"] }
  ],
  "Grade IX": [
    { subject: "English", topics: ["Grammar: 1. Tenses 2. Reported Speech", "Writing Skills: Writing a Letter"] },
    { subject: "Hindi", topics: ["पत्रलेखन", "संवाद लेखन", "अर्थ के दृष्टि से वाक्य के भेद"] },
    { subject: "Biology", topics: ["Biology - Ch.1 The Fundamental Unit of Life"] },
    { subject: "Physics", topics: ["Physics - Ch. 1 Motion"] },
    { subject: "Chemistry", topics: ["Chemistry - Ch. Is Matter Around Us Pure?"] },
    { subject: "Math", topics: ["Ch. 1 Co-ordinate Geometry", "Ch. 5 Lines and Angle"] },
    { subject: "S.S. (Social Studies)", topics: ["Geography - Ch- 2 Landforms", "Geography - Ch- 3 Dynamic Atmosphere"] },
    { subject: "Computer", topics: ["Communication Skills"] }
  ],
  "Grade X": [
    { subject: "English", topics: ["First Flight: 1. Nelson Mandela: Long Walk to Freedom 2. A Tiger in the Zoo", "Grammar: 1. Tense"] },
    { subject: "Hindi", topics: ["बड़े भाई साहब (स्पर्श)", "हरिहर काका (संचयन)", "अनुच्छेद लेखन", "औपचारिक पत्र"] },
    { subject: "Biology", topics: ["Biology - Ch.5 Life Processes"] },
    { subject: "Physics", topics: ["Physics - Ch. 11 Electricity"] },
    { subject: "Chemistry", topics: ["Chemistry - Ch. 2 Acids, Bases and Salts"] },
    { subject: "Math", topics: ["Ch. 2 Polynomials", "Ch. 6 Triangle"] },
    { subject: "S.S. (Social Studies)", topics: ["Economics - Development", "Geography - Ch-1 Resources and Development", "History - Ch- 3 Making of the Global World", "Political Science - Power Sharing, Federalism"] },
    { subject: "Computer", topics: ["Communication Skills II"] }
  ]
};

export const JUNE_SYLLABUS_BANK: { [grade: string]: SyllabusItem[] } = {
  "Grade I": [
    { subject: "English", topics: ["L-2 Zibu and Zizo", "Grammar: 1. Letters of the English Alphabet 2. Naming Words 3. Common and Proper Naming Words 4. One and Many"] },
    { subject: "Hindi", topics: ["Lesson: 1) बारहखडी 2) बिना मात्रा वाले शब्द", "Grammar: -"] },
    { subject: "Marathi", topics: ["Lesson: स्वर -उ ऊ ए ऐ ओ औ अं अः", "Grammar: १ ते १० अंक"] },
    { subject: "EVS", topics: ["Ch. 2 Our Surrounding", "Ch. 3 Plant World"] },
    { subject: "Math", topics: ["Ch.2 Addition up to 9", "Ch.3 Subtraction up to 9", "Tables 1 to 6"] },
    { subject: "Computer", topics: ["Ch. 2: Intelligent Machines"] }
  ],
  "Grade II": [
    { subject: "English", topics: ["L-2 Where is my Pet?", "Grammar: 1. Naming Words 2. Common and Proper Naming Words. 3. One and Many 4. Naming Words,Gender"] },
    { subject: "Hindi", topics: ["Lesson: 1) घर 2)माला की चाँदी की पायल 3) चींटा", "Grammar: अनुच्छेद लेखन"] },
    { subject: "Marathi", topics: ["Lesson: १. आ - कार २. इ - कार ३. ई - कार ४. उ - कार", "Grammar: १ ते २० अंक"] },
    { subject: "EVS", topics: ["Ch. 3 Wild Animals", "Ch. 4 Animal Our Friends"] },
    { subject: "Math", topics: ["Ch.2 Addition", "Ch.3 Subtraction", "Tables 1 to 11"] },
    { subject: "Computer", topics: ["Ch. 2:Robot in Action"] }
  ],
  "Grade III": [
    { subject: "English", topics: ["Grammar: 4. Nouns: Gender 5. Possessive Nouns 6. Pronouns 7. Verbs"] },
    { subject: "Hindi", topics: ["Lesson: 1) सीखो पुनरावृत्ति 2) चींटी पुनरावृत्ति 3) कितने पैर? 4) बया हमारी चिड़िया रानी", "Grammar: संज्ञा, गिनती"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - ३. मनीमाऊ पाठ क्र - ४. झेंडावंदन", "Grammar: निबंध लेखन"] },
    { subject: "EVS", topics: ["Ch. 2 Plants and their Parts", "Ch. 3 Birds"] },
    { subject: "Math", topics: ["Ch.2 Addition", "Ch.3 Subtraction", "Tables 1 to 16"] },
    { subject: "Computer", topics: ["Ch. 2: Navigating Windows 10"] }
  ],
  "Grade IV": [
    { subject: "English", topics: ["My Early Home", "Grammar: Gender, Possessive Nouns, Collective Nouns, Countable and Uncountable Nouns, Pronouns, Verbs, Tenses -Simple Present, Simple Past and Simple Future", "Writing - Informal Letter"] },
    { subject: "Hindi", topics: ["Lesson: 1) चिड़िया का गीत पुनरावृत्ति 2) बगीचे का घोंघा पुनरावृत्ति 3) नीम 4) हमारा आहार", "Grammar: संज्ञा, गिनती"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र - ३. पावसात भिजूया पाठ क्र - ४. हिरवा घोडा", "Grammar: १. नाम २. निबंध लेखन"] },
    { subject: "EVS", topics: ["Ch. 2 Adaptation in Plants", "Ch. 3 Reproduction in Animals"] },
    { subject: "Math", topics: ["Remaining Numbers Beyond 9999", "Addition and Subtraction", "Tables 1 to 17"] },
    { subject: "Computer", topics: ["Ch. 2: The Internet Adventure"] }
  ],
  "Grade V": [
    { subject: "English", topics: ["Lesson: 1 .Thunder Cake", "Grammar: 1.Gender, Possessive Nouns, Pronouns and Their Types, Verbs", "Writing - Formal Letter"] },
    { subject: "Hindi", topics: ["Lesson: 1. किरण कविता पुनरावृत्ति 2. न्याय की कुर्सी पुनरावृत्ति 3. चाँद का कुरता कविता 4. साड़केन", "Grammar: 1. हिंदी वर्णमाला स्वर व्यंजन 2. शब्द के भेद"] },
    { subject: "Marathi", topics: ["Lesson: पाठ क्र -३. आसू आणि हसू पाठ क्र -४. शेकोटी नृत्य", "Grammar: निबंध लेखन"] },
    { subject: "EVS", topics: ["Ch. 2 Animals: Habitat and Adaptations", "Ch. 3 Human Skeletal System"] },
    { subject: "Math", topics: ["Ch. 2 - Operations on Large Numbers", "Ch. 3 - Introduction of Prime Numbers", "Tables 11 to 30"] },
    { subject: "Computer", topics: ["Ch. 2:Exploring the Digital World"] }
  ],
  "Grade VI": [
    { subject: "English", topics: ["Lesson/Chapter: 1.The Raven and The Fox ( Poem ) 2.Rama to The Rescue", "Grammar: Nouns : Gender, Nouns : Case", "Composition : 1.Writing Paragraph"] },
    { subject: "Hindi", topics: ["Lesson/Chapter: 1. मातृभूमि पुनरावृत्ति (कविता) 2. गोल 3. पहली बूंद 4. वर्ण के प्रकार स्वर व्यंजन 5. वर्ण विच्छेद", "Grammar: -"] },
    { subject: "Marathi", topics: ["Lesson/Chapter: पाठ क्र - २. थोर शास्त्रज्ञ - लुई पाश्चर (आनंदवन) पाठ क्र - ३. कुष्ठसेवेचा आरंभ"] },
    { subject: "Science", topics: ["Ch. 2 Diversity in the Living World", "Ch. 3 Mindful Eating: A Path to a Healthy Body"] },
    { subject: "Math", topics: ["Ch-2 Lines and Angles", "Tables 11 to 20"] },
    { subject: "S.S. (Social Studies)", topics: ["Ch. 4 Timeline and Sources of History", "Ch. 9 Family and Community"] },
    { subject: "Computer", topics: ["Ch. 2:The Slide Magic"] }
  ],
  "Grade VII": [
    { subject: "English", topics: ["Lesson/Chapter: 1.Try Again ( Poem ) 2 .Three Days to See", "Grammar: 1.Adjectives 2. More On Adjectives"] },
    { subject: "Hindi", topics: ["Lesson/Chapter: 3) फूल और काँटा", "Grammar: सर्वनाम, विशेषण, चित्र - वर्णन"] },
    { subject: "Marathi", topics: ["Lesson/Chapter: पाठ क्र - २.जय जय महाराष्ट्र माझा पाठ क्र - ३.गोपाळची साक्ष"] },
    { subject: "Science", topics: ["Ch. 3 Electricity: Circuits and their Components"] },
    { subject: "Math", topics: ["Ch-2 Arithmetic Expression", "Tables 11 to 25"] },
    { subject: "S.S. (Social Studies)", topics: ["Ch. 5 The Rise of Empires", "Ch. 9 From the Rulers to the Ruled: Types of Governments", "Ch. 11 From Barter to Money"] },
    { subject: "Computer", topics: ["Ch. 2: Function Junction in Excel"] }
  ],
  "Grade VIII": [
    { subject: "English", topics: ["Lesson/Chapter: 1.Wisdom Paves the Way 2.A Tale of Valour", "Grammar: Creative Writing - 1. Formal Letter"] },
    { subject: "Hindi", topics: ["Lesson/Chapter: 1) स्वदेश 2) दो गौरैया 3) एक आशीर्वाद (किवता)", "Grammar: विशेषण, विशेषण के प्रकार, अंक"] },
    { subject: "Marathi", topics: ["Lesson/Chapter: पाठ क्र - २. माझे कष्ट वाया जाणार नाहीत शिकवण (कविता) पाठ क्र - ४. रामदासांची"] },
    { subject: "Science", topics: ["Ch. 5 Exploring Forces"] },
    { subject: "Math", topics: ["Ch.1 Squares and Cubes", "Ch. 2 Power Play", "Tables 1 to 30"] },
    { subject: "S.S. (Social Studies)", topics: ["Ch.1 Natural Resources", "Ch.2 Reshaping Indias Political Map", "Ch.5 Universal Franchise and India's Electoral System"] },
    { subject: "Computer", topics: ["Ch. 2: Log on to Access"] }
  ],
  "Grade IX": [
    { subject: "English", topics: ["Literature: 1. Bharat Our Land 2.The Pot Maker 3.Gift of Grace: Honoring Our Vocations", "Creative Writing - 1.Descriptive Paragraph Writing"] },
    { subject: "Hindi", topics: ["Lesson: 1) दो बैलों की कथा (प्रेमचंद) 2) क्या लिखूँ? (पदुमलाल पुन्नालाल बख्शी) 3) पद (रैदास)", "Grammar: व्याकरण : समास, मुहावरे"] },
    { subject: "Biology", topics: ["Biology - Ch. 1 The Fundamental Unit of Life"] },
    { subject: "Physics", topics: ["Physics - Ch. 1 Motion"] },
    { subject: "Chemistry", topics: ["Chemistry - Ch Is Matter Around Us Pure?"] },
    { subject: "Math", topics: ["Ch. Lines and Angles", "Ch.2 Introduction to Linear Polynomial"] },
    { subject: "S.S. (Social Studies)", topics: ["Ch. 2 Reshaping the Earth", "Ch. 4 Early Human", "Ch. 6 Democracy"] },
    { subject: "Computer", topics: ["Part B- Unit I Introduction to IT and ITeS Industry"] }
  ],
  "Grade X": [
    { subject: "English", topics: ["Literature: 1.The Thief's Story 2. Midnight Visitor 3. A Tiger in the Zoo 4. Two Stories about Flying", "Creative Writing - 1.Formal Letter 2.Analytical Paragraph Writing"] },
    { subject: "Hindi", topics: ["Lesson: स्पर्श (पद्य) - 3) मनुष्यता 4) पर्वत प्रदेश में पावस", "स्पर्श (गद्य) - 2) डायरी का एक पन्ना", "Grammar: औपचारिक पत्रलेखन, सूचना लेखन"] },
    { subject: "Biology", topics: ["Biology - Ch. 6 Control and Coordination"] },
    { subject: "Physics", topics: ["Physics - Ch 12. Magnetic Effect of Electric Current"] },
    { subject: "Chemistry", topics: ["Chemistry - Ch 2 Acids, Bases and Salts"] },
    { subject: "Math", topics: ["Ch.3 Pair of Linear Equations", "Ch. 6 Triangle", "Ch. 8 Introduction to Trigonometry"] },
    { subject: "S.S. (Social Studies)", topics: ["History - Ch-2 Nationalism in India", "Geography - Ch-2 Wildlife Resources Ch-3 Water Resources", "Economics - Ch 2. Sectors of the Indian Economy", "Democratic Politics - Ch 2. Federalism"] },
    { subject: "Computer", topics: ["Part B - 1: Digital Documentation (Advanced)"] }
  ]
};
