export type NotebookStatus = 'unchecked' | 'checked' | 'incomplete' | 'missing';

export interface ClassStudent {
  id: string;
  name: string;
  rollNumber: string;
}

export interface SchoolClass {
  id: string;
  name: string; // e.g., "Class 6-A"
  grade: string; // e.g., "6"
  students: ClassStudent[];
}

export interface MonthlyTask {
  id: string;
  classId: string;
  subject: string; // e.g., "Mathematics"
  month: string; // e.g., "June 2026"
  title: string; // e.g., "Chapter 1 Exercise Notebook"
  description: string;
  dueDate: string; // YYYY-MM-DD
  createdBy?: string;
  createdAt?: string;
}

export interface CheckingRecord {
  id: string; // studentId + "_" + taskId
  studentId: string;
  taskId: string;
  status: NotebookStatus;
  notes: string;
  lastUpdatedAt: string; // ISO string
}

export interface ActivityLog {
  id: string;
  studentName: string;
  className: string;
  subject: string;
  taskTitle: string;
  status: NotebookStatus;
  timestamp: string;
}

export interface AcademicTest {
  id: string;
  classId: string;
  subject: string;
  month: string;
  taskId: string; // Associated monthly syllabus task/chapter
  testName: string; // e.g., "Unit Test 1" or "Chapter 1 Quiz"
  testDate: string; // YYYY-MM-DD
  maxMarks: number; // e.g., 10 to 30 marks
}

export interface StudentTestMark {
  id: string; // testId + "_" + studentId
  testId: string;
  studentId: string;
  marksObtained: number | ''; // input score, e.g. 0 to 30
  isAbsent: boolean;
  remarks: string;
  lastUpdatedAt: string;
}

export interface UserSession {
  username: string;
  name: string;
  role: 'admin' | 'teacher' | 'management';
  avatarUrl?: string;
}

export interface ManagementReview {
  id: string; // `${teacherName}_${month}` or unique id
  teacherName: string;
  month: string;
  isVerified: boolean;
  verifiedBy: string; // 'Vice Principal' or 'Principal'
  verifiedAt?: string;
  generalComment: string;
  notebookStatusComment: string;
  syllabusStatusComment: string;
  testRecordComment: string;
}

export interface AuthenticationAuditLog {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'teacher' | 'management';
  biometricType: 'thumb' | 'face';
  timestamp: string;
  deviceId: string;
  status: 'SUCCESS' | 'FAILED';
  ipAddress?: string;
  deviceDetails?: string;
}


