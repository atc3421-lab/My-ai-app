import React, { useState, useEffect, useRef } from 'react';
import { SchoolClass, MonthlyTask, CheckingRecord, ActivityLog, NotebookStatus, AcademicTest, StudentTestMark, UserSession, AuthenticationAuditLog, ManagementReview } from './types';
import { 
  DEFAULT_CLASSES, 
  DEFAULT_TASKS, 
  DEFAULT_RECORDS, 
  DEFAULT_SUBJECTS, 
  INITIAL_LOGS 
} from './data/mockData';
import { TeacherAllotment, EMPTY_TEACHER_ALLOTMENTS, SAMPLE_TEACHER_ALLOTMENTS } from './data/teacherData';
import { OFFICIAL_SYLLABUS_BANK, SyllabusItem } from './data/officialSyllabus';

// Component imports
import DashboardStats from './components/DashboardStats';
import ManagementVerification from './components/ManagementVerification';
import CheckingMatrix from './components/CheckingMatrix';
import MonthlyPlanner from './components/MonthlyPlanner';
import ClassRosterManager from './components/ClassRosterManager';
import ParentStudentLookup from './components/ParentStudentLookup';
import TeacherWorkloads from './components/TeacherWorkloads';
import TestRecordRegistry from './components/TestRecordRegistry';
import GoogleWorkspacePanel from './components/GoogleWorkspacePanel';
import SchoolTimetables from './components/SchoolTimetables';
import AcademicAuditCalendar from './components/AcademicAuditCalendar';
import SyllabusCompletionTab, { SyllabusTopicState } from './components/SyllabusCompletionTab';
import NotificationCenter from './components/NotificationCenter';
import TeacherProductivitySuite from './components/TeacherProductivitySuite';
import BiometricAuditLogView from './components/BiometricAuditLogView';

import { 
  Layers, 
  LayoutDashboard, 
  ClipboardCheck, 
  CalendarRange, 
  UsersRound, 
  SearchCode,
  RotateCcw,
  BookOpen,
  Github,
  GraduationCap,
  Award,
  Cloud,
  Calendar,
  Key,
  Wifi,
  WifiOff,
  ShieldCheck,
  Lock,
  Sparkles,
  Camera,
  Fingerprint,
  HelpCircle,
  AlertCircle,
  Info,
  Download,
  FileSpreadsheet,
  LogOut,
  Smartphone,
  QrCode,
  Copy,
  Check,
  Loader2,
  AlertTriangle,
  Palette
} from 'lucide-react';

interface SchoolTheme {
  id: string;
  name: string;
  emoji: string;
  description: string;
  class: string;
  bgOrb1: string;
  bgOrb2: string;
  bgOrb3: string;
}

const SCHOOL_THEMES: SchoolTheme[] = [
  {
    id: 'cosmic',
    name: 'Midnight Slate',
    emoji: '🌌',
    description: 'Deep navy, indigo & emerald accents',
    class: 'theme-cosmic',
    bgOrb1: 'bg-indigo-600/15',
    bgOrb2: 'bg-blue-500/10',
    bgOrb3: 'bg-emerald-500/10',
  },
  {
    id: 'emerald',
    name: 'Emerald Forest',
    emoji: '🌿',
    description: 'Prestige forest green & zesty highlights',
    class: 'theme-emerald',
    bgOrb1: 'bg-emerald-600/20',
    bgOrb2: 'bg-teal-500/15',
    bgOrb3: 'bg-green-500/10',
  },
  {
    id: 'amethyst',
    name: 'Royal Amethyst',
    emoji: '🔮',
    description: 'Midnight violets & royal lavender',
    class: 'theme-amethyst',
    bgOrb1: 'bg-purple-600/20',
    bgOrb2: 'bg-fuchsia-500/15',
    bgOrb3: 'bg-indigo-500/10',
  },
  {
    id: 'crimson',
    name: 'Burgundy Crimson',
    emoji: '🍷',
    description: 'Burgundy, crimson & warm bronze',
    class: 'theme-crimson',
    bgOrb1: 'bg-rose-600/20',
    bgOrb2: 'bg-pink-500/15',
    bgOrb3: 'bg-red-500/10',
  },
  {
    id: 'sunset',
    name: 'Warm Sunset Glow',
    emoji: '🌅',
    description: 'Golden bronze & copper sunset vibes',
    class: 'theme-sunset',
    bgOrb1: 'bg-amber-500/15',
    bgOrb2: 'bg-orange-600/10',
    bgOrb3: 'bg-yellow-500/10',
  },
  {
    id: 'ivory',
    name: 'Classic Ivory',
    emoji: '☀️',
    description: 'High contrast clean light mode',
    class: 'theme-ivory',
    bgOrb1: 'bg-slate-300/10',
    bgOrb2: 'bg-blue-200/15',
    bgOrb3: 'bg-indigo-200/10',
  },
];

const themeCss = `
  /* --- EMERALD GREEN THEME OVERRIDES --- */
  body.theme-emerald,
  .theme-emerald {
    background-color: #022c22 !important;
    color: #ecfdf5 !important;
  }
  .theme-emerald .bg-slate-950 {
    background-color: #011c14 !important;
  }
  .theme-emerald .bg-slate-920,
  .theme-emerald .bg-slate-900 {
    background-color: #022c22 !important;
  }
  .theme-emerald .bg-slate-900\\/60,
  .theme-emerald .bg-slate-950\\/45 {
    background-color: rgba(2, 44, 34, 0.7) !important;
  }
  .theme-emerald .border-white\\/10,
  .theme-emerald .border-white\\/5 {
    border-color: rgba(16, 185, 129, 0.2) !important;
  }
  .theme-emerald .text-indigo-400,
  .theme-emerald .text-indigo-305,
  .theme-emerald .text-indigo-300,
  .theme-emerald .text-indigo-205 {
    color: #10b981 !important;
  }
  .theme-emerald .bg-indigo-500 {
    background-color: #10b981 !important;
  }
  .theme-emerald .text-emerald-300 {
    color: #34d399 !important;
  }
  .theme-emerald .text-slate-400 {
    color: #a7f3d0 !important;
  }
  .theme-emerald .bg-slate-950\\/50 {
    background-color: rgba(1, 28, 20, 0.5) !important;
  }

  /* --- ROYAL AMETHYST THEME OVERRIDES --- */
  body.theme-amethyst,
  .theme-amethyst {
    background-color: #12072b !important;
    color: #f7f4fd !important;
  }
  .theme-amethyst .bg-slate-950 {
    background-color: #090317 !important;
  }
  .theme-amethyst .bg-slate-920,
  .theme-amethyst .bg-slate-900 {
    background-color: #13072b !important;
  }
  .theme-amethyst .bg-slate-900\\/60,
  .theme-amethyst .bg-slate-950\\/45 {
    background-color: rgba(19, 7, 43, 0.7) !important;
  }
  .theme-amethyst .border-white\\/10,
  .theme-amethyst .border-white\\/5 {
    border-color: rgba(139, 92, 246, 0.2) !important;
  }
  .theme-amethyst .text-indigo-400,
  .theme-amethyst .text-indigo-305,
  .theme-amethyst .text-indigo-300,
  .theme-amethyst .text-indigo-205 {
    color: #a78bfa !important;
  }
  .theme-amethyst .bg-indigo-500 {
    background-color: #8b5cf6 !important;
  }
  .theme-amethyst .text-emerald-300 {
    color: #c084fc !important;
  }
  .theme-amethyst .text-slate-400 {
    color: #ddd6fe !important;
  }
  .theme-amethyst .bg-slate-950\\/50 {
    background-color: rgba(9, 3, 23, 0.5) !important;
  }

  /* --- BURGUNDY CRIMSON THEME OVERRIDES --- */
  body.theme-crimson,
  .theme-crimson {
    background-color: #1f010b !important;
    color: #fff1f2 !important;
  }
  .theme-crimson .bg-slate-950 {
    background-color: #0f0005 !important;
  }
  .theme-crimson .bg-slate-920,
  .theme-crimson .bg-slate-900 {
    background-color: #1f010b !important;
  }
  .theme-crimson .bg-slate-900\\/60,
  .theme-crimson .bg-slate-950\\/45 {
    background-color: rgba(31, 1, 11, 0.7) !important;
  }
  .theme-crimson .border-white\\/10,
  .theme-crimson .border-white\\/5 {
    border-color: rgba(244, 63, 94, 0.2) !important;
  }
  .theme-crimson .text-indigo-400,
  .theme-crimson .text-indigo-305,
  .theme-crimson .text-indigo-300,
  .theme-crimson .text-indigo-205 {
    color: #fb7185 !important;
  }
  .theme-crimson .bg-indigo-500 {
    background-color: #f43f5e !important;
  }
  .theme-crimson .text-emerald-300 {
    color: #fda4af !important;
  }
  .theme-crimson .text-slate-400 {
    color: #fecdd3 !important;
  }
  .theme-crimson .bg-slate-950\\/50 {
    background-color: rgba(15, 0, 5, 0.5) !important;
  }

  /* --- WARM SUNSET GLOW THEME OVERRIDES --- */
  body.theme-sunset,
  .theme-sunset {
    background-color: #1a0c02 !important;
    color: #fffbeb !important;
  }
  .theme-sunset .bg-slate-950 {
    background-color: #0d0601 !important;
  }
  .theme-sunset .bg-slate-920,
  .theme-sunset .bg-slate-900 {
    background-color: #1a0c02 !important;
  }
  .theme-sunset .bg-slate-900\\/60,
  .theme-sunset .bg-slate-950\\/45 {
    background-color: rgba(26, 12, 2, 0.7) !important;
  }
  .theme-sunset .border-white\\/10,
  .theme-sunset .border-white\\/5 {
    border-color: rgba(245, 158, 11, 0.2) !important;
  }
  .theme-sunset .text-indigo-400,
  .theme-sunset .text-indigo-305,
  .theme-sunset .text-indigo-300,
  .theme-sunset .text-indigo-205 {
    color: #f59e0b !important;
  }
  .theme-sunset .bg-indigo-500 {
    background-color: #f59e0b !important;
  }
  .theme-sunset .text-emerald-300 {
    color: #fbbf24 !important;
  }
  .theme-sunset .text-slate-400 {
    color: #fde68a !important;
  }
  .theme-sunset .bg-slate-950\\/50 {
    background-color: rgba(13, 6, 1, 0.5) !important;
  }

  /* --- CLASSIC IVORY (POLISHED LIGHT MODE) OVERRIDES --- */
  body.theme-ivory {
    background-color: #f8fafc !important;
    color: #0f172a !important;
  }
  .theme-ivory.min-h-screen,
  .theme-ivory {
    background-color: #f1f5f9 !important;
    color: #0f172a !important;
  }
  .theme-ivory .bg-slate-950 {
    background-color: #e2e8f0 !important;
  }
  .theme-ivory .bg-slate-920,
  .theme-ivory .bg-slate-900 {
    background-color: #ffffff !important;
  }
  .theme-ivory .bg-slate-900\\/60,
  .theme-ivory .bg-slate-950\\/45,
  .theme-ivory .bg-slate-900\\/40,
  .theme-ivory .bg-slate-950\\/30,
  .theme-ivory .bg-slate-950\\/25,
  .theme-ivory .bg-slate-950\\/20,
  .theme-ivory .bg-slate-950\\/50,
  .theme-ivory .bg-slate-950\\/10 {
    background-color: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -2px rgba(0,0,0,0.05) !important;
  }
  .theme-ivory .text-slate-100,
  .theme-ivory .text-slate-205,
  .theme-ivory .text-slate-200,
  .theme-ivory .text-slate-300,
  .theme-ivory .text-slate-350,
  .theme-ivory .text-white {
    color: #0f172a !important;
  }
  .theme-ivory .text-slate-400 {
    color: #334155 !important;
  }
  .theme-ivory .text-slate-500 {
    color: #475569 !important;
  }
  .theme-ivory .border-white\\/5,
  .theme-ivory .border-white\\/10,
  .theme-ivory .border-white\\/15,
  .theme-ivory .border-white\\/20 {
    border-color: #cbd5e1 !important;
  }
  .theme-ivory select,
  .theme-ivory input,
  .theme-ivory textarea {
    background-color: #ffffff !important;
    color: #0f172a !important;
    border: 1px solid #cbd5e1 !important;
  }
  .theme-ivory .text-indigo-400,
  .theme-ivory .text-indigo-305,
  .theme-ivory .text-indigo-300,
  .theme-ivory .text-indigo-205 {
    color: #4f46e5 !important;
  }
  .theme-ivory .bg-white\\/5 {
    background-color: #f1f5f9 !important;
  }
  .theme-ivory .bg-white\\/10 {
    background-color: #e2e8f0 !important;
  }
  .theme-ivory .bg-indigo-500 {
    background-color: #4f46e5 !important;
  }
  .theme-ivory .shadow-indigo-500\\/20 {
    box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.1) !important;
  }
  .theme-ivory .hover\\:bg-white\\/5:hover {
    background-color: #f1f5f9 !important;
  }
  .theme-ivory .text-emerald-300,
  .theme-ivory .text-emerald-400,
  .theme-ivory .text-emerald-350 {
    color: #10b981 !important;
  }
  .theme-ivory .bg-slate-920,
  .theme-ivory .bg-slate-1000 {
    background-color: #f8fafc !important;
  }
  .theme-ivory .shadow-md,
  .theme-ivory .shadow-xl,
  .theme-ivory .shadow-2xl {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05) !important;
  }
`;

export default function App() {
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    if (typeof localStorage !== 'undefined' && localStorage.getItem('nb_bypass_online_check') === 'true') {
      return true;
    }
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });
  const [showExportMenu, setShowExportMenu] = useState<boolean>(false);
  const [showMobileModal, setShowMobileModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  
  const [currentThemeId, setCurrentThemeId] = useState<string>(() => {
    return localStorage.getItem('nb_theme_theme_id') || 'cosmic';
  });
  const [showThemeMenu, setShowThemeMenu] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('nb_theme_theme_id', currentThemeId);
  }, [currentThemeId]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    SCHOOL_THEMES.forEach(t => {
      document.body.classList.remove(t.class);
      document.documentElement.classList.remove(t.class);
    });
    const activeTheme = SCHOOL_THEMES.find(t => t.id === currentThemeId) || SCHOOL_THEMES[0];
    document.body.classList.add(activeTheme.class);
    document.documentElement.classList.add(activeTheme.class);
  }, [currentThemeId]);

  const [currentUser, setCurrentUser] = useState<UserSession | null>(() => {
    const saved = localStorage.getItem('nb_user_session');
    if (saved) {
      try {
        const u = JSON.parse(saved) as UserSession;
        if (u.name && (u.name.toLowerCase().includes('vaidehi') || u.username.toLowerCase().includes('vaidehi'))) {
          u.name = 'Ms.Vaishali';
          u.username = 'Ms.Vaishali';
        }
        if (u.name && (u.name.toLowerCase().includes('amit') || u.username.toLowerCase().includes('amit'))) {
          u.name = 'Mr. Akash M';
          u.username = 'Mr. Akash M';
        }
        if (u.role === 'teacher') {
          const savedAvatar = localStorage.getItem(`nb_teacher_avatar_${u.username}`);
          if (savedAvatar) {
            u.avatarUrl = savedAvatar;
          }
        }
        localStorage.setItem('nb_user_session', JSON.stringify(u));
        return u;
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState<string>(() => {
    const saved = localStorage.getItem('nb_user_session');
    if (saved) {
      try {
        const u = JSON.parse(saved) as UserSession;
        if (u.name && (u.name.toLowerCase().includes('vaidehi') || u.username.toLowerCase().includes('vaidehi'))) {
          return 'timetable';
        }
        if (u.name && (u.name.toLowerCase().includes('amit') || u.username.toLowerCase().includes('amit'))) {
          return 'timetable';
        }
        return u.role === 'teacher' ? 'timetable' : 'dashboard';
      } catch (e) {
        return 'dashboard';
      }
    }
    return 'dashboard';
  });

  const [checkingStatusFilter, setCheckingStatusFilter] = useState<'all' | 'checked' | 'incomplete' | 'missing' | 'pending' | 'unchecked'>('all');

  // Auth Form States
  const [loginRole, setLoginRole] = useState<'admin' | 'teacher' | 'management'>('admin');
  const [loginUsername, setLoginUsername] = useState('admin');
  const [loginPassword, setLoginPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSystemAdminLocal, setIsSystemAdminLocal] = useState<boolean>(() => localStorage.getItem('nb_is_system_admin_local') === 'true');

  // Device context tools for biometric audit logs
  const getDeviceSignature = () => {
    const ua = navigator.userAgent;
    let details = 'macOS Workstation';
    if (ua.includes('Macintosh')) details = 'macOS Desktop';
    else if (ua.includes('Windows')) details = 'Windows PC';
    else if (ua.includes('iPhone')) details = 'Apple iPhone';
    else if (ua.includes('Android')) details = 'Android Device';
    else if (ua.includes('Linux')) details = 'Linux Workstation';
    
    if (ua.includes('Chrome')) details += ' (Chrome Browser)';
    else if (ua.includes('Safari')) details += ' (Safari Browser)';
    else if (ua.includes('Firefox')) details += ' (Firefox Browser)';
    else if (ua.includes('Edge')) details += ' (Edge Browser)';
    return details;
  };

  const getSimulatedDeviceId = () => {
    let devId = localStorage.getItem('nb_simulated_device_id');
    if (!devId) {
      const hex = '0123456789ABCDEF';
      let randomId = 'SEC-HW-';
      for (let i = 0; i < 12; i++) {
        randomId += hex[Math.floor(Math.random() * 16)];
        if (i === 3 || i === 7) randomId += '-';
      }
      localStorage.setItem('nb_simulated_device_id', randomId);
      devId = randomId;
    }
    return devId;
  };

  // Biometric successful events state
  const [biometricAuditLogs, setBiometricAuditLogs] = useState<AuthenticationAuditLog[]>(() => {
    const saved = localStorage.getItem('nb_biometric_audit_logs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback below
      }
    }
    const mocks: AuthenticationAuditLog[] = [
      {
        id: 'BIO-AUD-9201',
        username: 'admin',
        name: 'School Administrator',
        role: 'admin',
        biometricType: 'thumb',
        timestamp: '2026-06-13T09:12:44.201Z',
        deviceId: 'SEC-HW-DA71-483A-DF11',
        status: 'SUCCESS',
        ipAddress: '192.168.1.101',
        deviceDetails: 'macOS Desktop (Chrome Browser)'
      },
      {
        id: 'BIO-AUD-8172',
        username: 'Mr. Amol',
        name: 'Mr. Amol',
        role: 'teacher',
        biometricType: 'face',
        timestamp: '2026-06-13T14:35:10.054Z',
        deviceId: 'SEC-HW-AA02-817F-8812',
        status: 'SUCCESS',
        ipAddress: '192.168.1.105',
        deviceDetails: 'Windows PC (Edge Browser)'
      },
      {
        id: 'BIO-AUD-7462',
        username: 'Vice Principal',
        name: 'Vice Principal (Academic Audit)',
        role: 'management',
        biometricType: 'thumb',
        timestamp: '2026-06-14T07:44:23.118Z',
        deviceId: 'SEC-HW-FF81-912A-1100',
        status: 'SUCCESS',
        ipAddress: '172.20.10.2',
        deviceDetails: 'Apple iPhone (Safari Browser)'
      }
    ];
    return mocks;
  });

  // Save biometric audits to localStorage
  useEffect(() => {
    localStorage.setItem('nb_biometric_audit_logs', JSON.stringify(biometricAuditLogs));
  }, [biometricAuditLogs]);

  // Biometric Sandbox login features
  const [biometricModalOpen, setBiometricModalOpen] = useState(false);
  const [biometricHelpOpen, setBiometricHelpOpen] = useState(false);
  const [biometricType, setBiometricType] = useState<'thumb' | 'face'>('thumb');
  const [bioRole, setBioRole] = useState<'admin' | 'teacher' | 'management'>('admin');
  const [bioTeacher, setBioTeacher] = useState<string>('Mr. Amol');
  const [bioScannerState, setBioScannerState] = useState<'idle' | 'scanning' | 'matched' | 'error'>('idle');
  const [bioProgress, setBioProgress] = useState(0);
  const [bioStatusText, setBioStatusText] = useState('Position scanner to start...');
  const [bioCameraStream, setBioCameraStream] = useState<MediaStream | null>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  const startCameraStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 } });
      setBioCameraStream(stream);
    } catch (e) {
      console.log("Webcam stream access not available, using simulated visual match overlay framework.", e);
    }
  };

  const openBiometricModal = (type: 'thumb' | 'face') => {
    setBiometricType(type);
    setBioRole(loginRole);
    // If faculty, find a teacher or default to Mr. Amol
    const currentName = loginUsername || 'Mr. Amol';
    setBioTeacher(currentName);
    setBioScannerState('idle');
    setBioProgress(0);
    setBioStatusText(type === 'thumb' ? 'Ready to place finger on biometric sensor.' : 'Ready to begin face recognition template alignment.');
    setBiometricModalOpen(true);
  };

  const closeBiometricModal = () => {
    if (bioCameraStream) {
      bioCameraStream.getTracks().forEach(track => track.stop());
      setBioCameraStream(null);
    }
    setBiometricModalOpen(false);
  };

  useEffect(() => {
    if (biometricModalOpen && biometricType === 'face' && bioScannerState === 'scanning') {
      startCameraStream();
    } else {
      if (bioCameraStream) {
        bioCameraStream.getTracks().forEach(track => track.stop());
        setBioCameraStream(null);
      }
    }
  }, [biometricModalOpen, biometricType, bioScannerState]);

  useEffect(() => {
    if (videoRef.current && bioCameraStream) {
      videoRef.current.srcObject = bioCameraStream;
      videoRef.current.play().catch(err => console.log("Video playback warning:", err));
    }
  }, [bioCameraStream]);

  // Biometric scan active progress simulation
  useEffect(() => {
    let interval: any = null;
    if (biometricModalOpen && bioScannerState === 'scanning') {
      interval = setInterval(() => {
        setBioProgress(prev => {
          const next = prev + 5;
          if (next >= 100) {
            clearInterval(interval);
            setBioScannerState('matched');
            setBioStatusText('Signature Matched: Identity Authenticated Successfully!');
            
            // Record successful biometric login to logs database
            const resolvedUsername = bioRole === 'admin' 
              ? 'admin' 
              : bioRole === 'teacher' 
                ? bioTeacher 
                : (bioTeacher.toLowerCase().includes('vp') || bioTeacher.toLowerCase().includes('vice') ? 'vp' : 'principal');
            
            const resolvedName = bioRole === 'admin' 
              ? 'School Administrator' 
              : bioRole === 'teacher' 
                ? bioTeacher 
                : (bioTeacher.toLowerCase().includes('vp') || bioTeacher.toLowerCase().includes('vice')
                  ? 'Vice Principal (Academic Audit)'
                  : 'Principal (Governing Board)');

            const newAuditLog: AuthenticationAuditLog = {
              id: `BIO-AUD-${Math.floor(Math.random() * 9000) + 1000}`,
              username: resolvedUsername,
              name: resolvedName,
              role: bioRole,
              biometricType,
              timestamp: new Date().toISOString(),
              deviceId: getSimulatedDeviceId(),
              status: 'SUCCESS',
              ipAddress: `192.168.1.${Math.floor(Math.random() * 150) + 101}`,
              deviceDetails: getDeviceSignature()
            };
            setBiometricAuditLogs(prev => [newAuditLog, ...prev]);

            // Auto sign in after a small delay
            setTimeout(() => {
              // Sign in logic
              let session: UserSession;
              let defaultTab = 'dashboard';
              
              if (bioRole === 'admin') {
                session = {
                  username: 'admin',
                  name: 'School Administrator',
                  role: 'admin'
                };
                defaultTab = 'dashboard';
                localStorage.setItem('nb_is_system_admin_local', 'true');
                setIsSystemAdminLocal(true);
              } else if (bioRole === 'teacher') {
                session = {
                  username: bioTeacher,
                  name: bioTeacher,
                  role: 'teacher'
                };
                defaultTab = 'timetable';
              } else {
                const isVP = bioTeacher.toLowerCase().includes('vp') || bioTeacher.toLowerCase().includes('vice');
                session = {
                  username: isVP ? 'vp' : 'principal',
                  name: isVP ? 'Vice Principal (Academic Audit)' : 'Principal (Governing Board)',
                  role: 'management'
                };
                defaultTab = 'management_verify';
              }
              
              setCurrentUser(session);
              localStorage.setItem('nb_user_session', JSON.stringify(session));
              setActiveTab(defaultTab);
              setBiometricModalOpen(false);
              
              // Clean camera
              if (bioCameraStream) {
                bioCameraStream.getTracks().forEach(track => track.stop());
                setBioCameraStream(null);
              }
            }, 1000);
            return 100;
          }
          
          // Progressive labels
          if (next < 25) {
            setBioStatusText(biometricType === 'thumb' ? 'Connecting dermal matrix sensor...' : 'Accessing retina camera frame...');
          } else if (next < 55) {
            setBioStatusText(biometricType === 'thumb' ? 'Checking friction ridge depth and loops...' : 'Analyzing nodal points, facial posture, and eye tracking...');
          } else if (next < 85) {
            setBioStatusText('Verifying security hashes with local sandboxed server database...');
          } else {
            setBioStatusText('Match key detected! Initializing secure user desk dashboard...');
          }
          return next;
        });
      }, 75);
    } else {
      setBioProgress(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [biometricModalOpen, bioScannerState, bioRole, bioTeacher, biometricType]);

  // User passwords mapping state
  const [userPasswords, setUserPasswords] = useState<{ [username: string]: string }>(() => {
    const saved = localStorage.getItem('nb_user_passwords');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return {};
      }
    }
    return {};
  });

  // Save passwords changes
  useEffect(() => {
    localStorage.setItem('nb_user_passwords', JSON.stringify(userPasswords));
  }, [userPasswords]);

  const [showTeacherSuggestions, setShowTeacherSuggestions] = useState(false);

  // Password Change Modal States
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmPassInput, setConfirmPassInput] = useState('');
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');

  // Synchronisation states for the header indicator and multi-device coordination
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [lastSynced, setLastSynced] = useState<Date | null>(() => {
    const saved = localStorage.getItem('nb_last_synced_time');
    return saved ? new Date(saved) : null;
  });

  // Helper to merge client and server data collections, preserving newer client edits
  const mergeClientAndServerCollections = (clientItems: any[], serverItems: any[], matchKey: string = "id") => {
    const map = new Map<string, any>();
    
    // Seed with server items
    if (Array.isArray(serverItems)) {
      serverItems.forEach((item: any) => {
        if (item && item[matchKey]) map.set(item[matchKey], item);
      });
    }

    // Merge in client items based on newer timestamp or overwrite
    if (Array.isArray(clientItems)) {
      clientItems.forEach((clientItem: any) => {
        if (!clientItem || !clientItem[matchKey]) return;
        const existing = map.get(clientItem[matchKey]);
        if (!existing) {
          map.set(clientItem[matchKey], clientItem);
        } else {
          const clientTimeStr = clientItem.lastUpdatedAt || clientItem.updatedAt;
          const serverTimeStr = existing.lastUpdatedAt || existing.updatedAt;
          if (clientTimeStr && serverTimeStr) {
            const clientTime = new Date(clientTimeStr).getTime();
            const existingTime = new Date(serverTimeStr).getTime();
            if (clientTime >= existingTime) {
              map.set(clientItem[matchKey], clientItem);
            }
          } else if (serverTimeStr && !clientTimeStr) {
            // Keep server item
          } else {
            map.set(clientItem[matchKey], { ...existing, ...clientItem });
          }
        }
      });
    }

    return Array.from(map.values());
  };

  // Pull source-of-truth from server on startup before setting up default mocks
  const pullInitialStateFromServer = async (): Promise<boolean> => {
    isSyncingRef.current = true;
    setIsSyncing(true);
    setSyncError(null);
    try {
      const response = await fetch('/api/sync-state');
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.state) {
          const s = result.state;
          console.log("[PWA Mount] Successfully retrieved initial server state from Cloud Run:", s);

          let hasServerData = false;

          if (Array.isArray(s.classes) && s.classes.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_classes') || '[]');
            const merged = mergeClientAndServerCollections(local, s.classes);
            setClasses(merged);
            localStorage.setItem('nb_classes', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.tasks) && s.tasks.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_tasks') || '[]');
            const merged = mergeClientAndServerCollections(local, s.tasks);
            setTasks(merged);
            localStorage.setItem('nb_tasks', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.records) && s.records.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_records') || '[]');
            const merged = mergeClientAndServerCollections(local, s.records);
            setRecords(merged);
            localStorage.setItem('nb_records', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.academicTests) && s.academicTests.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_academic_tests') || '[]');
            const merged = mergeClientAndServerCollections(local, s.academicTests);
            setAcademicTests(merged);
            localStorage.setItem('nb_academic_tests', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.testMarks) && s.testMarks.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_test_marks') || '[]');
            const merged = mergeClientAndServerCollections(local, s.testMarks);
            setTestMarks(merged);
            localStorage.setItem('nb_test_marks', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.subjects) && s.subjects.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_subjects') || '[]');
            const merged = Array.from(new Set([...local, ...s.subjects]));
            setSubjects(merged);
            localStorage.setItem('nb_subjects', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.allotments) && s.allotments.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_teacher_allotments') || '[]');
            const merged = mergeClientAndServerCollections(local, s.allotments, "grade");
            
            // Apply migration for teacher names
            let migrated = false;
            let parsedAllots = merged.map((a: any) => {
              let updated = { ...a };
              if (updated.classTeacher === 'Ms.Vaidehi') {
                updated.classTeacher = 'Ms.Vaishali';
                migrated = true;
              }
              if (updated.classTeacher === 'Mr.Uday P.') {
                updated.classTeacher = 'Mr.Uday P';
                migrated = true;
              }
              if (updated.grade === 'X O' || updated.grade === 'X T') {
                if (updated.subjects && updated.subjects['Math'] !== 'Mr. Akash M') {
                  updated.subjects['Math'] = 'Mr. Akash M';
                  migrated = true;
                }
              }
              if (updated.subjects) {
                const updatedSubjects = { ...updated.subjects };
                Object.keys(updatedSubjects).forEach(subK => {
                  if (updatedSubjects[subK] === 'Ms.Vaidehi') {
                    updatedSubjects[subK] = 'Ms.Vaishali';
                    migrated = true;
                  }
                  if (updatedSubjects[subK] === 'Mr.Uday P.') {
                    updatedSubjects[subK] = 'Mr.Uday P';
                    migrated = true;
                  }
                });
                updated.subjects = updatedSubjects;
              }
              return updated;
            });

            setAllotments(parsedAllots);
            localStorage.setItem('nb_teacher_allotments', JSON.stringify(parsedAllots));
            hasServerData = true;
            if (migrated) {
              setTimeout(() => {
                syncStateWithServer({ allotments: parsedAllots });
              }, 500);
            }
          }
          if (Array.isArray(s.syllabusTopicStates) && s.syllabusTopicStates.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_syllabus_topic_states') || '[]');
            const merged = mergeClientAndServerCollections(local, s.syllabusTopicStates);
            setSyllabusTopicStates(merged);
            localStorage.setItem('nb_syllabus_topic_states', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.managementReviews) && s.managementReviews.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_management_reviews') || '[]');
            const merged = mergeClientAndServerCollections(local, s.managementReviews);
            setManagementReviews(merged);
            localStorage.setItem('nb_management_reviews', JSON.stringify(merged));
            hasServerData = true;
          }
          if (Array.isArray(s.activityLogs) && s.activityLogs.length > 0) {
            const local = JSON.parse(localStorage.getItem('nb_logs') || '[]');
            const merged = mergeClientAndServerCollections(local, s.activityLogs);
            setActivityLogs(merged);
            localStorage.setItem('nb_logs', JSON.stringify(merged));
          }

          const now = new Date();
          setLastSynced(now);
          localStorage.setItem('nb_last_synced_time', now.toISOString());

          if (hasServerData) {
            console.log("[PWA Mount] Bootstrapped successfully from server.");
            return true;
          }
        }
      }
    } catch (e: any) {
      console.warn("[PWA Mount] Fetch of initial server state took a timeout or was offline. Falling back to localStorage.", e);
      setSyncError(e.message || "Offline mount fallback");
    } finally {
      isSyncingRef.current = false;
      setIsSyncing(false);
    }
    return false;
  };

  // Core application states
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [tasks, setTasks] = useState<MonthlyTask[]>([]);
  const [records, setRecords] = useState<CheckingRecord[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [subjects, setSubjects] = useState<string[]>([]);
  const [academicTests, setAcademicTests] = useState<AcademicTest[]>([]);
  const [testMarks, setTestMarks] = useState<StudentTestMark[]>([]);
  const [allotments, setAllotments] = useState<TeacherAllotment[]>([]);
  const [syllabusBank, setSyllabusBank] = useState<{ [grade: string]: SyllabusItem[] }>({});
  const [syllabusTopicStates, setSyllabusTopicStates] = useState<SyllabusTopicState[]>(() => {
    const saved = localStorage.getItem('nb_syllabus_topic_states');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [];
  });
  const [managementReviews, setManagementReviews] = useState<ManagementReview[]>(() => {
    const saved = localStorage.getItem('nb_management_reviews');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { return []; }
    }
    return [];
  });

  // Jump helper for cross-component triggers
  const [quickJumpConfig, setQuickJumpConfig] = useState<{classId: string, subject: string} | null>(null);

  // Core synchronization locks & queues to protect serial sequential updates
  const isSyncingRef = useRef(false);
  const pendingSyncRef = useRef<any>(null);

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // limit size to 2.5MB to preserve local storage limits
    if (file.size > 2.5 * 1024 * 1024) {
      alert("Image file size is too large. Please upload an image smaller than 2.5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      if (currentUser && currentUser.role === 'teacher') {
        const username = currentUser.username;
        localStorage.setItem(`nb_teacher_avatar_${username}`, base64);
        
        const updated = { ...currentUser, avatarUrl: base64 };
        setCurrentUser(updated);
        localStorage.setItem('nb_user_session', JSON.stringify(updated));
      }
    };
    reader.onerror = () => {
      alert("Failed to parse the selected file.");
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarDelete = () => {
    if (currentUser && currentUser.role === 'teacher') {
      const username = currentUser.username;
      localStorage.removeItem(`nb_teacher_avatar_${username}`);
      
      // Update session state without avatarUrl
      const updated = { ...currentUser };
      delete updated.avatarUrl;
      setCurrentUser(updated);
      localStorage.setItem('nb_user_session', JSON.stringify(updated));
    }
  };

  // Load initial states from localStorage or mock data
  useEffect(() => {
    const bootstrap = async () => {
      // 1. First probe the server for any existing synchronized data state
      const hasCloudStateFetched = await pullInitialStateFromServer();
      if (hasCloudStateFetched) {
        console.log("[PWA Mount] Bootstrapping completed instantly with real cloud data.");
        return;
      }

      // 2. Failsafe: No cloud state / offline fallback, seed or read local
      const localClasses = localStorage.getItem('nb_classes');
      const localTasks = localStorage.getItem('nb_tasks');
      const localRecords = localStorage.getItem('nb_records');
      const localLogs = localStorage.getItem('nb_logs');
      const localSubjects = localStorage.getItem('nb_subjects');
      const localTests = localStorage.getItem('nb_academic_tests');
      const localTestMarks = localStorage.getItem('nb_test_marks');
      const localAllotments = localStorage.getItem('nb_teacher_allotments');
      const localSyllabusTopicStates = localStorage.getItem('nb_syllabus_topic_states');

      const containsOldMocks = !localClasses;

      // Since the syllabus bank is now empty, we ensure localStorage and state are overwritten with empty OFFICIAL_SYLLABUS_BANK
      setSyllabusBank(OFFICIAL_SYLLABUS_BANK);
      localStorage.setItem('nb_syllabus_bank', JSON.stringify(OFFICIAL_SYLLABUS_BANK));

      const hasLegacyTeachers = !localAllotments;

      if (localAllotments && !containsOldMocks && !hasLegacyTeachers) {
        let parsed = JSON.parse(localAllotments);
        const isAllEmpty = !parsed || parsed.length === 0 || parsed.every((a: any) => !a.classTeacher || a.classTeacher.trim() === '');
        if (isAllEmpty) {
          setAllotments(SAMPLE_TEACHER_ALLOTMENTS);
          localStorage.setItem('nb_teacher_allotments', JSON.stringify(SAMPLE_TEACHER_ALLOTMENTS));
        } else {
          // Migrate "Ms.Vaidehi" to "Ms.Vaishali", and "Mr.Uday P." to "Mr.Uday P" in stored allotments if present
          let migrated = false;
          parsed = parsed.map((a: any) => {
            let updated = { ...a };
            if (updated.classTeacher === 'Ms.Vaidehi') {
              updated.classTeacher = 'Ms.Vaishali';
              migrated = true;
            }
            if (updated.classTeacher === 'Mr.Uday P.') {
              updated.classTeacher = 'Mr.Uday P';
              migrated = true;
            }
            if (updated.grade === 'X O' || updated.grade === 'X T') {
              if (updated.subjects && updated.subjects['Math'] !== 'Mr. Akash M') {
                updated.subjects['Math'] = 'Mr. Akash M';
                migrated = true;
              }
            }
            if (updated.subjects) {
              const updatedSubjects = { ...updated.subjects };
              Object.keys(updatedSubjects).forEach(subK => {
                if (updatedSubjects[subK] === 'Ms.Vaidehi') {
                  updatedSubjects[subK] = 'Ms.Vaishali';
                  migrated = true;
                }
                if (updatedSubjects[subK] === 'Mr.Uday P.') {
                  updatedSubjects[subK] = 'Mr.Uday P';
                  migrated = true;
                }
              });
              updated.subjects = updatedSubjects;
            }
            return updated;
          });
          if (migrated) {
            localStorage.setItem('nb_teacher_allotments', JSON.stringify(parsed));
          }
          setAllotments(parsed);
        }
      } else {
        setAllotments(SAMPLE_TEACHER_ALLOTMENTS);
        localStorage.setItem('nb_teacher_allotments', JSON.stringify(SAMPLE_TEACHER_ALLOTMENTS));
      }

      if (localClasses && localTasks && localRecords && localLogs && localSubjects && !containsOldMocks) {
        let parsedClasses = JSON.parse(localClasses);
        let parsedTasks = JSON.parse(localTasks);
        let parsedRecords = JSON.parse(localRecords);
        let parsedLogs = JSON.parse(localLogs);

        setClasses(parsedClasses);
        setTasks(parsedTasks);
        setRecords(parsedRecords);
        setActivityLogs(parsedLogs);
        setSubjects(JSON.parse(localSubjects));
        if (localSyllabusTopicStates) {
          try {
            setSyllabusTopicStates(JSON.parse(localSyllabusTopicStates));
          } catch (e) {
            console.warn("Failed to parse localSyllabusTopicStates", e);
          }
        }
      } else {
        // Seed default mock structure
        setClasses(DEFAULT_CLASSES);
        setTasks(DEFAULT_TASKS);
        setRecords(DEFAULT_RECORDS);
        setActivityLogs(INITIAL_LOGS);
        setSubjects(DEFAULT_SUBJECTS);

        // Save to localStorage
        localStorage.setItem('nb_classes', JSON.stringify(DEFAULT_CLASSES));
        localStorage.setItem('nb_tasks', JSON.stringify(DEFAULT_TASKS));
        localStorage.setItem('nb_records', JSON.stringify(DEFAULT_RECORDS));
        localStorage.setItem('nb_logs', JSON.stringify(INITIAL_LOGS));
        localStorage.setItem('nb_subjects', JSON.stringify(DEFAULT_SUBJECTS));
      }

      // Load or seed tests state
      const containsOldTests = !localTests || !localTestMarks;

      if (localTests && localTestMarks && !containsOldTests) {
        setAcademicTests(JSON.parse(localTests));
        setTestMarks(JSON.parse(localTestMarks));
      } else {
        const initialTests: AcademicTest[] = [];
        const initialTestMarks: StudentTestMark[] = [];
        
        const seedClasses = containsOldMocks || !localClasses ? DEFAULT_CLASSES : JSON.parse(localClasses);
        const seedTasks = containsOldMocks || !localTasks ? DEFAULT_TASKS : JSON.parse(localTasks);

        const activeMonths = ["June 2026", "July 2026"];

        activeMonths.forEach((month, mIdx) => {
          seedClasses.forEach((cls: any, cIdx: number) => {
            // Find first 2 tasks for this class and month to register corresponding tests
            const clsTasks = seedTasks.filter((t: any) => t.classId === cls.id && t.month === month);
            if (clsTasks.length > 0) {
              const sampleTasks = clsTasks.slice(0, 2);
              sampleTasks.forEach((task: any, tIdx: number) => {
                const testId = `test_${month.replace(" ", "_").toLowerCase()}_${cls.id}_${task.subject.toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
                initialTests.push({
                  id: testId,
                  classId: cls.id,
                  subject: task.subject,
                  month: month,
                  taskId: task.id,
                  testName: `${month.split(" ")[0]} Evaluation: ${task.subject} Monthly Assessment`,
                  testDate: month === 'April 2026' ? '2026-04-25' : month === 'June 2026' ? '2026-06-25' : month === 'July 2026' ? '2026-07-25' : '2026-08-25',
                  maxMarks: 25
                });

                // Seed marks for all students in the class
                cls.students.forEach((s: any, idx: number) => {
                  const isApril = month === "April 2026";
                  const shouldLeaveEmpty = !isApril && (month === "June 2026" || month === "July 2026" || month === "August 2026") && (idx % 3 === 0);

                  initialTestMarks.push({
                    id: `${testId}_${s.id}`,
                    testId: testId,
                    studentId: s.id,
                    marksObtained: shouldLeaveEmpty ? '' : Math.floor(Math.random() * 8) + 17,
                    isAbsent: idx % 12 === 0 && !shouldLeaveEmpty,
                    remarks: idx % 12 === 0 && !shouldLeaveEmpty ? 'Absent on evaluation day' : 'Checked & verified answer book',
                    lastUpdatedAt: "2026-06-16T00:00:00.000Z"
                  });
                });
              });
            }
          });
        });

        setAcademicTests(initialTests);
        setTestMarks(initialTestMarks);
        localStorage.setItem('nb_academic_tests', JSON.stringify(initialTests));
        localStorage.setItem('nb_test_marks', JSON.stringify(initialTestMarks));
      }
    };
    bootstrap();
  }, []);

  // Federated Server Sync Engine supporting multi-device real-time sync for tests, marks & checks
  const syncStateWithServer = async (overrides: {
    classes?: SchoolClass[];
    tasks?: MonthlyTask[];
    records?: CheckingRecord[];
    academicTests?: AcademicTest[];
    testMarks?: StudentTestMark[];
    subjects?: string[];
    allotments?: TeacherAllotment[];
    syllabusTopicStates?: SyllabusTopicState[];
    managementReviews?: ManagementReview[];
    overwrite?: boolean;
  } = {}) => {
    // If a sync is already in progress, queue and merge this request's overrides, and return.
    // This prevents concurrent fetch calls and associated database save race-conditions.
    if (isSyncingRef.current) {
      console.log("[PWA Sync] Sync currently in progress. Merging/Queueing this request.");
      pendingSyncRef.current = {
        ...pendingSyncRef.current,
        ...overrides,
        overwrite: (pendingSyncRef.current?.overwrite) || overrides.overwrite || false
      };
      return;
    }

    isSyncingRef.current = true;
    setIsSyncing(true);
    setSyncError(null);

    try {
      // Merge current call overrides with any previously queued overrides
      const runOverrides = {
        ...pendingSyncRef.current,
        ...overrides
      };
      pendingSyncRef.current = null; // Clear queue for active run

      const localClasses = runOverrides.classes || JSON.parse(localStorage.getItem('nb_classes') || '[]');
      const localTasks = runOverrides.tasks || JSON.parse(localStorage.getItem('nb_tasks') || '[]');
      const localRecords = runOverrides.records || JSON.parse(localStorage.getItem('nb_records') || '[]');
      const localTests = runOverrides.academicTests || JSON.parse(localStorage.getItem('nb_academic_tests') || '[]');
      const localTestMarks = runOverrides.testMarks || JSON.parse(localStorage.getItem('nb_test_marks') || '[]');
      const localSubjects = runOverrides.subjects || JSON.parse(localStorage.getItem('nb_subjects') || '[]');
      const localAllotments = runOverrides.allotments || JSON.parse(localStorage.getItem('nb_teacher_allotments') || '[]');
      const localSyllabusTopicStates = runOverrides.syllabusTopicStates || JSON.parse(localStorage.getItem('nb_syllabus_topic_states') || '[]');
      const localManagementReviews = runOverrides.managementReviews || JSON.parse(localStorage.getItem('nb_management_reviews') || '[]');
      const localLogs = JSON.parse(localStorage.getItem('nb_logs') || '[]');

      const response = await fetch('/api/sync-state', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          classes: localClasses,
          tasks: localTasks,
          records: localRecords,
          academicTests: localTests,
          testMarks: localTestMarks,
          subjects: localSubjects,
          allotments: localAllotments,
          syllabusTopicStates: localSyllabusTopicStates,
          managementReviews: localManagementReviews,
          activityLogs: localLogs,
          overwrite: runOverrides.overwrite || false
        })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success && result.state) {
          const s = result.state;
          console.log("[PWA Sync] Successfully received federated state from server:", s);

          if (Array.isArray(s.classes)) {
            const local = JSON.parse(localStorage.getItem('nb_classes') || '[]');
            const merged = mergeClientAndServerCollections(local, s.classes);
            setClasses(merged);
            localStorage.setItem('nb_classes', JSON.stringify(merged));
          }
          if (Array.isArray(s.tasks)) {
            const local = JSON.parse(localStorage.getItem('nb_tasks') || '[]');
            const merged = mergeClientAndServerCollections(local, s.tasks);
            setTasks(merged);
            localStorage.setItem('nb_tasks', JSON.stringify(merged));
          }
          if (Array.isArray(s.records)) {
            const local = JSON.parse(localStorage.getItem('nb_records') || '[]');
            const merged = mergeClientAndServerCollections(local, s.records);
            setRecords(merged);
            localStorage.setItem('nb_records', JSON.stringify(merged));
          }
          if (Array.isArray(s.academicTests)) {
            const local = JSON.parse(localStorage.getItem('nb_academic_tests') || '[]');
            const merged = mergeClientAndServerCollections(local, s.academicTests);
            setAcademicTests(merged);
            localStorage.setItem('nb_academic_tests', JSON.stringify(merged));
          }
          if (Array.isArray(s.testMarks)) {
            const local = JSON.parse(localStorage.getItem('nb_test_marks') || '[]');
            const merged = mergeClientAndServerCollections(local, s.testMarks);
            setTestMarks(merged);
            localStorage.setItem('nb_test_marks', JSON.stringify(merged));
          }
          if (Array.isArray(s.subjects)) {
            const local = JSON.parse(localStorage.getItem('nb_subjects') || '[]');
            const merged = Array.from(new Set([...local, ...s.subjects]));
            setSubjects(merged);
            localStorage.setItem('nb_subjects', JSON.stringify(merged));
          }
          if (Array.isArray(s.allotments)) {
            if (s.allotments.length > 0) {
              const local = JSON.parse(localStorage.getItem('nb_teacher_allotments') || '[]');
              const merged = mergeClientAndServerCollections(local, s.allotments, "grade");
              
              // Apply migration for teacher names
              let migrated = false;
              let parsedAllots = merged.map((a: any) => {
                let updated = { ...a };
                if (updated.classTeacher === 'Ms.Vaidehi') {
                  updated.classTeacher = 'Ms.Vaishali';
                  migrated = true;
                }
                if (updated.classTeacher === 'Mr.Uday P.') {
                  updated.classTeacher = 'Mr.Uday P';
                  migrated = true;
                }
                if (updated.grade === 'X O' || updated.grade === 'X T') {
                  if (updated.subjects && updated.subjects['Math'] !== 'Mr. Akash M') {
                    updated.subjects['Math'] = 'Mr. Akash M';
                    migrated = true;
                  }
                }
                if (updated.subjects) {
                  const updatedSubjects = { ...updated.subjects };
                  Object.keys(updatedSubjects).forEach(subK => {
                    if (updatedSubjects[subK] === 'Ms.Vaidehi') {
                      updatedSubjects[subK] = 'Ms.Vaishali';
                      migrated = true;
                    }
                    if (updatedSubjects[subK] === 'Mr.Uday P.') {
                      updatedSubjects[subK] = 'Mr.Uday P';
                      migrated = true;
                    }
                  });
                  updated.subjects = updatedSubjects;
                }
                return updated;
              });

              setAllotments(parsedAllots);
              localStorage.setItem('nb_teacher_allotments', JSON.stringify(parsedAllots));
              if (migrated) {
                syncStateWithServer({ allotments: parsedAllots });
              }
            } else if (s.allotments.length === 0) {
              console.log("[PWA Sync] Server allotments list is empty! Restoring from pre-seeded SAMPLE_TEACHER_ALLOTMENTS.");
              setAllotments(SAMPLE_TEACHER_ALLOTMENTS);
              localStorage.setItem('nb_teacher_allotments', JSON.stringify(SAMPLE_TEACHER_ALLOTMENTS));
              // Push allotments state immediately to heal the server DB
              syncStateWithServer({ allotments: SAMPLE_TEACHER_ALLOTMENTS });
            }
          }
          if (Array.isArray(s.syllabusTopicStates)) {
            const local = JSON.parse(localStorage.getItem('nb_syllabus_topic_states') || '[]');
            const merged = mergeClientAndServerCollections(local, s.syllabusTopicStates);
            setSyllabusTopicStates(merged);
            localStorage.setItem('nb_syllabus_topic_states', JSON.stringify(merged));
          }
          if (Array.isArray(s.managementReviews)) {
            const local = JSON.parse(localStorage.getItem('nb_management_reviews') || '[]');
            const merged = mergeClientAndServerCollections(local, s.managementReviews);
            setManagementReviews(merged);
            localStorage.setItem('nb_management_reviews', JSON.stringify(merged));
          }
          if (Array.isArray(s.activityLogs)) {
            const local = JSON.parse(localStorage.getItem('nb_logs') || '[]');
            const merged = mergeClientAndServerCollections(local, s.activityLogs);
            setActivityLogs(merged);
            localStorage.setItem('nb_logs', JSON.stringify(merged));
          }

          const now = new Date();
          setLastSynced(now);
          localStorage.setItem('nb_last_synced_time', now.toISOString());
          console.log(`[Sync] Cloud State synchronised successfully at ${now.toLocaleTimeString()}.`);
        } else {
          setSyncError("Invalid server response schema");
        }
      } else {
        setSyncError(`Server responded with HTTP status ${response.status}`);
      }
    } catch (err: any) {
      console.warn("[PWA Sync] Network error during full federated state sync:", err);
      setSyncError(err.message || "Network / timeout error");
    } finally {
      isSyncingRef.current = false;
      setIsSyncing(false);
      // Run the deferred queued sync immediately if user interactions happened during previous fetch transit
      if (pendingSyncRef.current !== null) {
        console.log("[PWA Sync] Triggering catch-up sync for queued overrides.");
        setTimeout(() => {
          syncStateWithServer();
        }, 150);
      }
    }
  };

  // Run full automatic synchronization, periodic polling every 15 seconds, and on tab focus/active state
  useEffect(() => {
    // 1. Initial delayed sync on mount
    const timer = setTimeout(() => {
      syncStateWithServer();
    }, 1000);

    // 2. Periodic polling every 15 seconds for instant multi-device propagation
    const interval = setInterval(() => {
      syncStateWithServer();
    }, 15000);

    // 3. Immediate sync on window focus / tab visibility change
    const handleFocusAndVisibility = () => {
      if (document.visibilityState === 'visible') {
        console.log('[PWA Sync] Window focused or active. Pulling fresh data.');
        syncStateWithServer();
      }
    };

    window.addEventListener('focus', handleFocusAndVisibility);
    document.addEventListener('visibilitychange', handleFocusAndVisibility);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
      window.removeEventListener('focus', handleFocusAndVisibility);
      document.removeEventListener('visibilitychange', handleFocusAndVisibility);
    };
  }, []);

  // Synchronizers to local storage state
  const saveState = (
    newClasses: SchoolClass[], 
    newTasks: MonthlyTask[], 
    newRecords: CheckingRecord[], 
    newLogs: ActivityLog[], 
    newSubjects: string[],
    newManagementReviews?: ManagementReview[]
  ) => {
    // Detect which check records were updated or added
    const changedRecords = newRecords.filter(newRec => {
      const existing = records.find(r => r.id === newRec.id);
      return !existing || existing.status !== newRec.status || existing.notes !== newRec.notes;
    });

    setClasses(newClasses);
    setTasks(newTasks);
    setRecords(newRecords);
    setActivityLogs(newLogs);
    setSubjects(newSubjects);
    if (newManagementReviews) {
      setManagementReviews(newManagementReviews);
      localStorage.setItem('nb_management_reviews', JSON.stringify(newManagementReviews));
    }

    localStorage.setItem('nb_classes', JSON.stringify(newClasses));
    localStorage.setItem('nb_tasks', JSON.stringify(newTasks));
    localStorage.setItem('nb_records', JSON.stringify(newRecords));
    localStorage.setItem('nb_logs', JSON.stringify(newLogs));
    localStorage.setItem('nb_subjects', JSON.stringify(newSubjects));

    // Push state update to server
    syncStateWithServer({
      classes: newClasses,
      tasks: newTasks,
      records: newRecords,
      subjects: newSubjects,
      managementReviews: newManagementReviews || managementReviews
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('nb_user_session');
    localStorage.removeItem('nb_is_system_admin_local');
    setIsSystemAdminLocal(false);
    setActiveTab('dashboard');
  };

  const activeAllotSource = allotments.length > 0 ? allotments : SAMPLE_TEACHER_ALLOTMENTS;
  const allTeachersList = Array.from(new Set(
    activeAllotSource.flatMap(allot => {
      const names = [allot.classTeacher];
      if (allot.subjects) {
        Object.values(allot.subjects).forEach(subT => {
          if (subT && typeof subT === 'string') {
            const strVal = subT as string;
            strVal.split(' & ').forEach(subTTrim => {
              names.push(subTTrim.trim());
            });
          }
        });
      }
      return names;
    })
  )).filter(name => {
    if (!name || typeof name !== 'string') return false;
    const trimmed = name.trim();
    return trimmed.length > 0 && 
           trimmed !== 'Staff Teacher' && 
           trimmed !== 'Didi' && 
           trimmed !== 'V P' && 
           trimmed !== 'English';
  }).map((n: any) => String(n).trim()).sort();

  const handleQuickSelectRole = (role: 'admin' | 'teacher' | 'management') => {
    let session: UserSession;
    let defaultTab = 'dashboard';
    
    if (role === 'admin') {
      session = {
        username: 'admin',
        name: 'School Administrator',
        role: 'admin'
      };
      defaultTab = 'dashboard';
    } else if (role === 'teacher') {
      session = {
        username: 'Mr. Amol',
        name: 'Mr. Amol',
        role: 'teacher'
      };
      defaultTab = 'timetable';
    } else {
      session = {
        username: 'vp',
        name: 'Vice Principal (Academic Audit)',
        role: 'management'
      };
      defaultTab = 'management_verify';
    }
    
    setCurrentUser(session);
    localStorage.setItem('nb_user_session', JSON.stringify(session));
    setActiveTab(defaultTab);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (loginRole === 'admin') {
      const storedPass = userPasswords['admin'] || 'admin123';
      if (loginUsername.toLowerCase().trim() === 'admin' && (loginPassword === storedPass || loginPassword === 'admin')) {
        const session: UserSession = {
          username: 'admin',
          name: 'School Administrator',
          role: 'admin'
        };
        setCurrentUser(session);
        localStorage.setItem('nb_user_session', JSON.stringify(session));
        localStorage.setItem('nb_is_system_admin_local', 'true');
        setIsSystemAdminLocal(true);
        setActiveTab('dashboard');
      } else {
        setErrorMsg('Invalid administrative credentials. Enter correct password configuration.');
      }
    } else if (loginRole === 'management') {
      const uName = loginUsername.trim();
      const lookupName = uName.toLowerCase() === 'vice principal' || uName.toLowerCase() === 'vp' ? 'vp' : 'principal';
      const defaultPass = lookupName === 'vp' ? 'vp123' : 'principal123';
      const storedPass = userPasswords[lookupName] || defaultPass;
      
      if (loginPassword === storedPass || loginPassword === defaultPass) {
        const session: UserSession = {
          username: lookupName,
          name: lookupName === 'vp' ? 'Vice Principal (Academic Audit)' : 'Principal (Governing Board)',
          role: 'management'
        };
        setCurrentUser(session);
        localStorage.setItem('nb_user_session', JSON.stringify(session));
        setActiveTab('management_verify');
      } else {
        setErrorMsg(`Invalid management passcode for ${uName}. Check security password.`);
      }
    } else {
      // Teacher role
      const teacherKey = loginUsername.trim();
      if (!teacherKey) {
        setErrorMsg('Please select or type a valid faculty name.');
        return;
      }
      const storedPass = userPasswords[teacherKey] || 'teacher123';
      if (loginPassword === storedPass) {
        const savedAvatar = localStorage.getItem(`nb_teacher_avatar_${teacherKey}`) || '';
        const session: UserSession = {
          username: teacherKey,
          name: teacherKey,
          role: 'teacher',
          avatarUrl: savedAvatar || undefined
        };
        setCurrentUser(session);
        localStorage.setItem('nb_user_session', JSON.stringify(session));
        setActiveTab('timetable'); // auto route to Timetables & Lectures Hub
      } else {
        setErrorMsg(`Invalid faculty password. Enter the secure passcode for "${teacherKey}".`);
      }
    }
  };

  const handleUpdateAllotments = (newAllotments: TeacherAllotment[]) => {
    setAllotments(newAllotments);
    localStorage.setItem('nb_teacher_allotments', JSON.stringify(newAllotments));
    syncStateWithServer({ allotments: newAllotments });
  };

  // Master Exporter for workbook record sheets
  const handleUniversalFullCSVExport = () => {
    let csvContent = "\ufeff"; // BOM for Excel UTF-8 compliance
    csvContent += "Class/Grade,Roll No,Student Name,Subject,Month,Task Title,Due Date,Status,Teacher Remarks\n";

    classes.forEach(clazz => {
      clazz.students.forEach(student => {
        const classTasks = tasks.filter(t => t.classId === clazz.id);
        classTasks.forEach(task => {
          const rec = records.find(r => r.studentId === student.id && r.taskId === task.id) || { status: 'unchecked', notes: '' };
          const status = rec.status ? rec.status.toUpperCase() : "UNCHECKED";
          const notes = rec.notes ? rec.notes.replace(/"/g, '""') : "";
          const escapedSubject = task.subject.replace(/"/g, '""');
          const escapedTitle = task.title.replace(/"/g, '""');
          
          csvContent += `"${clazz.name}","${student.rollNumber}","${student.name}","${escapedSubject}","${task.month}","${escapedTitle}","${task.dueDate}","${status}","${notes}"\n`;
        });
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `notebook_checking_full_school_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAcademicMarksCSVExport = () => {
    let csvContent = "\ufeff"; // BOM for Excel UTF-8 compliance
    csvContent += "Class/Grade,Roll No,Student Name,Subject,Month,Test Title,Max Marks,Obtained Marks\n";

    classes.forEach(clazz => {
      const classTests = academicTests.filter(t => t.classId === clazz.id);
      classTests.forEach(test => {
        clazz.students.forEach(student => {
          const mark = testMarks.find(m => m.studentId === student.id && m.testId === test.id);
          const score = mark ? mark.marksObtained : "N/A";
          
          csvContent += `"${clazz.name}","${student.rollNumber}","${student.name}","${test.subject}","${test.month}","${test.testName}","${test.maxMarks}","${score}"\n`;
        });
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `academic_marks_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleJSONStateBackupExport = () => {
    const backupData = {
      appId: "samata-notebook-checking-system",
      backupTime: new Date().toISOString(),
      classes,
      tasks,
      records,
      academicTests,
      testMarks,
      subjects,
      allotments,
      activityLogs: localStorage.getItem('nb_logs') ? JSON.parse(localStorage.getItem('nb_logs') || '[]') : []
    };

    const str = JSON.stringify(backupData, null, 2);
    const blob = new Blob([str], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `notebook_academic_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Reset entirely to sample data
  const handleResetToMocks = () => {
    if (confirm('Revert all school lists, planned topics, and checked portfolios back to pre-seeded sample data? Your customizations will be cleared.')) {
      saveState(DEFAULT_CLASSES, DEFAULT_TASKS, DEFAULT_RECORDS, INITIAL_LOGS, DEFAULT_SUBJECTS);
      
      // Clean up tests
      const initialTests: AcademicTest[] = [];
      const initialTestMarks: StudentTestMark[] = [];
      if (DEFAULT_CLASSES.length > 0) {
        const firstClass = DEFAULT_CLASSES[0];
        const matchTask = DEFAULT_TASKS.find(t => t.classId === firstClass.id) || DEFAULT_TASKS[0];
        const test1Id = 'test_sample_1';
        initialTests.push({
          id: test1Id,
          classId: firstClass.id,
          subject: matchTask ? matchTask.subject : 'Mathematics',
          month: 'June 2026',
          taskId: matchTask ? matchTask.id : 'task_1',
          testName: 'Syllabus Assessment: Chapter 1 Diagnostic Test',
          testDate: '2026-06-08',
          maxMarks: 25
        });

        firstClass.students.forEach((s, idx) => {
          initialTestMarks.push({
            id: `${test1Id}_${s.id}`,
            testId: test1Id,
            studentId: s.id,
            marksObtained: (idx % 8 === 0) ? '' : Math.floor(Math.random() * 11) + 14,
            isAbsent: idx % 8 === 0,
            remarks: idx % 8 === 0 ? 'Absent' : 'Checked & verified answer book',
            lastUpdatedAt: new Date().toISOString()
          });
        });
      }
      setAcademicTests(initialTests);
      setTestMarks(initialTestMarks);
      setAllotments(SAMPLE_TEACHER_ALLOTMENTS);
      localStorage.setItem('nb_academic_tests', JSON.stringify(initialTests));
      localStorage.setItem('nb_test_marks', JSON.stringify(initialTestMarks));
      localStorage.setItem('nb_teacher_allotments', JSON.stringify(SAMPLE_TEACHER_ALLOTMENTS));

      setActiveTab('dashboard');
    }
  };

  // Academic tests coordination handlers
  const handleAddTest = (newTest: AcademicTest) => {
    const updated = [...academicTests, newTest];
    setAcademicTests(updated);
    localStorage.setItem('nb_academic_tests', JSON.stringify(updated));
    syncStateWithServer({ academicTests: updated });
  };

  const handleDeleteTest = (testId: string) => {
    const updatedTests = academicTests.filter(t => t.id !== testId);
    const updatedMarks = testMarks.filter(m => m.testId !== testId);
    setAcademicTests(updatedTests);
    setTestMarks(updatedMarks);
    localStorage.setItem('nb_academic_tests', JSON.stringify(updatedTests));
    localStorage.setItem('nb_test_marks', JSON.stringify(updatedMarks));
    syncStateWithServer({ academicTests: updatedTests, testMarks: updatedMarks });
  };

  const handleUpdateMarks = (testId: string, updatedMarksList: StudentTestMark[]) => {
    const base = testMarks.filter(m => m.testId !== testId);
    const updatedAll = [...base, ...updatedMarksList];
    setTestMarks(updatedAll);
    localStorage.setItem('nb_test_marks', JSON.stringify(updatedAll));
    syncStateWithServer({ testMarks: updatedAll });
  };

  // Tab jump navigator
  const handleQuickLocate = (classId: string, subject: string) => {
    setQuickJumpConfig({ classId, subject });
    setActiveTab('records');
  };

  // --- ACTIONS: CLASSES MANAGEMENT ---
  const handleAddClass = (name: string, grade: string) => {
    const newClass: SchoolClass = {
      id: 'class_' + Date.now(),
      name,
      grade,
      students: []
    };
    const updatedClasses = [...classes, newClass];
    saveState(updatedClasses, tasks, records, activityLogs, subjects);
  };

  const handleDeleteClass = (classId: string) => {
    const updatedClasses = classes.filter(c => c.id !== classId);
    // clean orphaned tasks
    const updatedTasks = tasks.filter(t => t.classId !== classId);
    // clean orphaned records
    const classStudentIds = classes.find(c => c.id === classId)?.students.map(s => s.id) || [];
    const updatedRecords = records.filter(r => !classStudentIds.includes(r.studentId));
    
    saveState(updatedClasses, updatedTasks, updatedRecords, activityLogs, subjects);
  };

  const handleAddStudent = (classId: string, name: string, rollNumber: string) => {
    const newStudent = {
      id: 'stud_' + Date.now(),
      name,
      rollNumber
    };
    const updatedClasses = classes.map(cls => {
      if (cls.id === classId) {
        return {
          ...cls,
          students: [...cls.students, newStudent]
        };
      }
      return cls;
    });
    saveState(updatedClasses, tasks, records, activityLogs, subjects);
  };

  const handleRemoveStudent = (classId: string, studentId: string) => {
    const updatedClasses = classes.map(cls => {
      if (cls.id === classId) {
        return {
          ...cls,
          students: cls.students.filter(s => s.id !== studentId)
        };
      }
      return cls;
    });
    // clean records
    const updatedRecords = records.filter(r => r.studentId !== studentId);
    saveState(updatedClasses, tasks, updatedRecords, activityLogs, subjects);
  };

  const handleEditStudent = (classId: string, studentId: string, name: string, rollNumber: string) => {
    const updatedClasses = classes.map(cls => {
      if (cls.id === classId) {
        return {
          ...cls,
          students: cls.students.map(student => {
            if (student.id === studentId) {
              return { ...student, name, rollNumber };
            }
            return student;
          })
        };
      }
      return cls;
    });
    saveState(updatedClasses, tasks, records, activityLogs, subjects);
  };

  const handleWipeAllStudents = () => {
    const updatedClasses = classes.map(cls => ({
      ...cls,
      students: []
    }));
    setTestMarks([]);
    localStorage.setItem('nb_test_marks', JSON.stringify([]));
    saveState(updatedClasses, tasks, [], [], subjects);
  };

  const handleBulkImportStudents = (classId: string, names: string[]) => {
    const cls = classes.find(c => c.id === classId);
    if (!cls) return;

    const baseIndex = cls.students.length;
    const newStudents = names.map((name, idx) => {
      const rollNumber = String(baseIndex + idx + 1).padStart(2, '0');
      return {
        id: 'stud_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        name: name.trim(),
        rollNumber
      };
    });

    const updatedClasses = classes.map(c => {
      if (c.id === classId) {
        return {
          ...c,
          students: [...c.students, ...newStudents]
        };
      }
      return c;
    });

    saveState(updatedClasses, tasks, records, activityLogs, subjects);
  };

  // --- ACTIONS: WORK MONTHLY PLANS ---
  const handleAddTask = (newTaskPayload: Omit<MonthlyTask, 'id'>) => {
    const newTask: MonthlyTask = {
      ...newTaskPayload,
      id: 'task_' + Date.now(),
      createdBy: currentUser?.role || 'management',
      createdAt: new Date().toISOString()
    };
    const updatedTasks = [...tasks, newTask];
    saveState(classes, updatedTasks, records, activityLogs, subjects);
  };

  const handleDeleteTask = (taskId: string) => {
    const updatedTasks = tasks.filter(t => t.id !== taskId);
    const updatedRecords = records.filter(r => r.taskId !== taskId);
    saveState(classes, updatedTasks, updatedRecords, activityLogs, subjects);
  };

  const handleClearSyllabusTasks = (classId: string | 'all', month: string) => {
    let tasksToKeep: MonthlyTask[];
    let tasksToRem: MonthlyTask[];
    if (classId === 'all') {
      tasksToKeep = tasks.filter(t => t.month !== month);
      tasksToRem = tasks.filter(t => t.month === month);
    } else {
      tasksToKeep = tasks.filter(t => !(t.classId === classId && t.month === month));
      tasksToRem = tasks.filter(t => t.classId === classId && t.month === month);
    }
    const remTaskIds = tasksToRem.map(t => t.id);
    const updatedRecords = records.filter(r => !remTaskIds.includes(r.taskId));
    saveState(classes, tasksToKeep, updatedRecords, activityLogs, subjects);
  };

  const handleUpdateSyllabusBank = (newBank: { [grade: string]: SyllabusItem[] }) => {
    setSyllabusBank(newBank);
    localStorage.setItem('nb_syllabus_bank', JSON.stringify(newBank));
  };

  const handleAddSubject = (newSub: string) => {
    if (subjects.includes(newSub)) return;
    const updatedSubjects = [...subjects, newSub];
    saveState(classes, tasks, records, activityLogs, updatedSubjects);
  };

  // --- ACTIONS: NOTEBOOK CHECKING MATRIX ---
  const handleUpdateRecord = (studentId: string, taskId: string, status: NotebookStatus, notes: string) => {
    // Generate/retrieve student details & info for stream log entries
    let studentName = 'Someone';
    let className = 'Class';
    const cellClass = classes.find(c => c.students.some(s => s.id === studentId));
    if (cellClass) {
      className = cellClass.name;
      const stud = cellClass.students.find(s => s.id === studentId);
      if (stud) studentName = stud.name;
    }

    const task = tasks.find(t => t.id === taskId);
    const subject = task ? task.subject : 'General Work';
    const taskTitle = task ? task.title : 'Monthly Task';

    const recordId = `${studentId}_${taskId}`;
    const existingIdx = records.findIndex(r => r.studentId === studentId && r.taskId === taskId);
    
    let updatedRecords = [...records];
    const timestamp = new Date().toISOString();

    if (existingIdx > -1) {
      updatedRecords[existingIdx] = {
        ...updatedRecords[existingIdx],
        status,
        notes,
        lastUpdatedAt: timestamp
      };
    } else {
      updatedRecords.push({
        id: recordId,
        studentId,
        taskId,
        status,
        notes,
        lastUpdatedAt: timestamp
      });
    }

    // Append to live feed activity logs
    const newLog: ActivityLog = {
      id: 'log_' + Date.now() + Math.random().toString(36).substr(2, 5),
      studentName,
      className,
      subject,
      taskTitle,
      status,
      timestamp
    };
    const updatedLogs = [newLog, ...activityLogs].slice(0, 50); // cap logs list at 50

    saveState(classes, tasks, updatedRecords, updatedLogs, subjects);
  };

  const handleClearRecord = (studentId: string, taskId: string) => {
    const updatedRecords = records.filter(r => !(r.studentId === studentId && r.taskId === taskId));
    saveState(classes, tasks, updatedRecords, activityLogs, subjects);
  };

  const handleUpdateMultipleRecords = (updates: { studentId: string; taskId: string; status: NotebookStatus; notes: string }[]) => {
    let updatedRecords = [...records];
    const timestamp = new Date().toISOString();
    let newLogs: ActivityLog[] = [];

    updates.forEach(upd => {
      const { studentId, taskId, status, notes } = upd;

      // Find student and task details
      let studentName = 'Someone';
      let className = 'Class';
      const cellClass = classes.find(c => c.students.some(s => s.id === studentId));
      if (cellClass) {
        className = cellClass.name;
        const stud = cellClass.students.find(s => s.id === studentId);
        if (stud) studentName = stud.name;
      }

      const task = tasks.find(t => t.id === taskId);
      const subject = task ? task.subject : 'General Work';
      const taskTitle = task ? task.title : 'Monthly Task';

      const recordId = `${studentId}_${taskId}`;
      const existingIdx = updatedRecords.findIndex(r => r.studentId === studentId && r.taskId === taskId);

      if (existingIdx > -1) {
        updatedRecords[existingIdx] = {
          ...updatedRecords[existingIdx],
          status,
          notes,
          lastUpdatedAt: timestamp
        };
      } else {
        updatedRecords.push({
          id: recordId,
          studentId,
          taskId,
          status,
          notes,
          lastUpdatedAt: timestamp
        });
      }
    });

    if (updates.length > 0) {
      if (updates.length <= 5) {
        updates.forEach(upd => {
          const { studentId, taskId, status } = upd;
          let studentName = 'Someone';
          let className = 'Class';
          const cellClass = classes.find(c => c.students.some(s => s.id === studentId));
          if (cellClass) {
            className = cellClass.name;
            const stud = cellClass.students.find(s => s.id === studentId);
            if (stud) studentName = stud.name;
          }
          const task = tasks.find(t => t.id === taskId);
          const subject = task ? task.subject : 'General Work';
          const taskTitle = task ? task.title : 'Monthly Task';

          newLogs.push({
            id: 'log_' + Date.now() + Math.random().toString(36).substr(2, 5),
            studentName,
            className,
            subject,
            taskTitle,
            status,
            timestamp
          });
        });
      } else {
        // Single bulk action log for performance of logs view
        const sampleTask = tasks.find(t => t.id === updates[0].taskId);
        const taskTitle = sampleTask ? sampleTask.title : 'Monthly Task';
        const subject = sampleTask ? sampleTask.subject : 'General Work';
        newLogs.push({
          id: 'log_bulk_' + Date.now() + Math.random().toString(36).substr(2, 5),
          studentName: `All ${updates.length} Students`,
          className: classes.find(c => c.students.some(s => s.id === updates[0].studentId))?.name || 'Class',
          subject,
          taskTitle,
          status: updates[0].status,
          timestamp
        });
      }
    }

    const updatedLogs = [...newLogs, ...activityLogs].slice(0, 50);
    saveState(classes, tasks, updatedRecords, updatedLogs, subjects);
  };

  const handleClearMultipleRecords = (clears: { studentId: string; taskId: string }[]) => {
    const clearKeys = new Set(clears.map(c => `${c.studentId}_${c.taskId}`));
    const updatedRecords = records.filter(r => !clearKeys.has(`${r.studentId}_${r.taskId}`));
    saveState(classes, tasks, updatedRecords, activityLogs, subjects);
  };

  if (!isOnline) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col items-center justify-center p-6 relative overflow-hidden">
        {/* Background Mesh Orbs */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-red-600/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-[150px] pointer-events-none" />
        
        <div className="relative z-10 max-w-md w-full bg-slate-900/85 border border-white/10 rounded-3xl p-8 backdrop-blur-xl shadow-2xl text-center space-y-6">
          <div className="h-16 w-16 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-red-500/5">
            <WifiOff className="w-8 h-8" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-black text-white tracking-tight">Internet Connection Required</h1>
            <p className="text-rose-400 font-bold text-xs uppercase tracking-wider">No Offline Access Enabled</p>
          </div>
          
          <p className="text-slate-400 text-sm leading-relaxed">
            This school grades audit and syllabus tracker requires an active internet connection to securely interact with the database. 
            Offline mode is disabled. Please restore connectivity to access the system.
          </p>
          
          <div className="pt-2 space-y-2">
            <button 
              onClick={() => {
                setIsOnline(navigator.onLine);
                if (navigator.onLine) {
                  syncStateWithServer();
                }
              }}
              className="w-full py-3 bg-indigo-500 hover:bg-indigo-600 hover:shadow-indigo-500/20 text-white font-extrabold text-sm rounded-xl transition-all cursor-pointer shadow-lg flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Retry Connection
            </button>
            
            <button 
              onClick={() => {
                setIsOnline(true);
                localStorage.setItem('nb_bypass_online_check', 'true');
              }}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-705 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              Ignore Connection Alert & Proceed
            </button>

            <p className="text-[10px] text-slate-500 mt-3 font-semibold">
              Please connect your device to Wi-Fi or cellular data networks.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col justify-center items-center p-4 relative overflow-hidden">
        
        {/* Background Mesh Orbs */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-600/15 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-[150px] pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-emerald-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="w-full max-w-md bg-white/5 backdrop-blur-2xl rounded-3xl p-8 border border-white/10 shadow-2xl space-y-6 relative z-10 transition-all duration-300 animate-fade-in">
          
          <div className="text-center space-y-2">
            <div className="h-14 w-14 bg-indigo-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-indigo-500/20">
              <BookOpen className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-extrabold text-2xl tracking-tight text-white mb-0.5">Samata School Portal</h2>
              <p className="text-slate-400 text-xs font-semibold">Faculty Scoresheet & Evaluation Desk</p>
            </div>
          </div>

          <div className="space-y-4">
            
            {/* Simulation Link Configurator */}
            <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-3.5 text-center space-y-1">
              <span className="text-[10px] text-indigo-300 font-black tracking-wider uppercase block">🌐 Quick Sandbox Credentials</span>
              <p className="text-[11px] text-slate-350 font-medium">
                Click to autofill mock passwords and IDs instantly.
              </p>
              <div className="flex flex-wrap justify-center gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={() => {
                    setLoginRole('admin');
                    setLoginUsername('admin');
                    setLoginPassword(userPasswords['admin'] || 'admin123');
                    setErrorMsg('');
                  }}
                  className="px-2.5 py-1 bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/45 rounded-lg text-[9px] font-extrabold text-indigo-200 cursor-pointer"
                >
                  ⚙️ Admin ID
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginRole('teacher');
                    setLoginUsername('Mr. Amol');
                    setLoginPassword(userPasswords['Mr. Amol'] || 'teacher123');
                    setErrorMsg('');
                  }}
                  className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/45 rounded-lg text-[9px] font-extrabold text-emerald-200 cursor-pointer"
                >
                  🎓 Mr. Amol
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLoginRole('management');
                    setLoginUsername('Vice Principal');
                    setLoginPassword('vp123');
                    setErrorMsg('');
                  }}
                  className="px-2.5 py-1 bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/45 rounded-lg text-[9px] font-extrabold text-sky-200 cursor-pointer"
                >
                  🏛️ VP / Principal
                </button>
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl px-4 py-2 text-rose-300 text-xs font-bold text-center">
                {errorMsg}
              </div>
            )}

            {/* Role Switcher */}
            <div className="grid grid-cols-3 gap-1.5 bg-slate-950 p-1 rounded-xl border border-white/5">
              <button
                type="button"
                onClick={() => {
                  setLoginRole('admin');
                  setLoginUsername('admin');
                  setLoginPassword('');
                  setErrorMsg('');
                }}
                className={`py-2 px-1 text-center rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                  loginRole === 'admin' ? 'bg-indigo-500 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Admin
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoginRole('teacher');
                  if (allTeachersList.length > 0) {
                    setLoginUsername(allTeachersList[0]);
                  }
                  setLoginPassword('');
                  setErrorMsg('');
                }}
                className={`py-2 px-1 text-center rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                  loginRole === 'teacher' ? 'bg-indigo-500 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Faculty
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoginRole('management');
                  setLoginUsername('Vice Principal');
                  setLoginPassword('vp123');
                  setErrorMsg('');
                }}
                className={`py-2 px-1 text-center rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                  loginRole === 'management' ? 'bg-indigo-500 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Management
              </button>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              
              {/* Username Input or Select based on role */}
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 font-sans">
                  {loginRole === 'admin' ? 'Admin ID' : loginRole === 'management' ? 'Management Role' : 'Identify Faculty Name'}
                </label>
                
                {loginRole === 'admin' ? (
                  <input
                    type="text"
                    required
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="Enter admin username"
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all font-mono"
                  />
                ) : loginRole === 'management' ? (
                  <select
                    value={loginUsername}
                    onChange={(e) => {
                      setLoginUsername(e.target.value);
                      if (e.target.value === 'Vice Principal') {
                        setLoginPassword('vp123');
                      } else {
                        setLoginPassword('principal123');
                      }
                    }}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
                  >
                    <option value="Vice Principal">Vice Principal (Academic Audit)</option>
                    <option value="Principal">Principal (Governing Board)</option>
                  </select>
                ) : (
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={loginUsername}
                      onChange={(e) => {
                        setLoginUsername(e.target.value);
                        setShowTeacherSuggestions(true);
                      }}
                      onFocus={() => setShowTeacherSuggestions(true)}
                      onBlur={() => {
                        // Delay slightly so onMouseDown catches select first
                        setTimeout(() => setShowTeacherSuggestions(false), 200);
                      }}
                      placeholder="Type faculty name (suggestions update list)..."
                      className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-indigo-500 transition-all"
                    />
                    
                    {showTeacherSuggestions && (
                      <div className="absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-slate-950 border border-white/10 rounded-xl shadow-2xl z-55 divide-y divide-white/5 scrollbar-thin">
                        {(() => {
                          const query = loginUsername.trim().toLowerCase();
                          const filtered = allTeachersList.filter(t => 
                            t.toLowerCase().includes(query)
                          );
                          
                          if (filtered.length > 0) {
                            return filtered.map(tName => (
                              <button
                                key={tName}
                                type="button"
                                onMouseDown={() => {
                                  setLoginUsername(tName);
                                  setShowTeacherSuggestions(false);
                                }}
                                className="w-full text-left px-3.5 py-2 text-xs font-bold text-slate-200 hover:bg-indigo-500 hover:text-white transition-all cursor-pointer block"
                              >
                                {tName}
                              </button>
                            ));
                          } else {
                            return (
                              <div className="px-3.5 py-2 text-xs text-slate-500 italic bg-slate-950">
                                No matching faculty found. Complete typing new name.
                              </div>
                            );
                          }
                        })()}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 font-sans">Security Password</label>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>

              {/* Submit Buttons */}
              <button
                type="submit"
                className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-black py-3.5 px-4 rounded-xl text-xs transition-all tracking-wider uppercase cursor-pointer hover:shadow-lg shadow-indigo-500/20 active:scale-95 font-sans"
              >
                Unlock Scoresheets & Login
              </button>

              {/* Secure Biometric Quick Pass */}
              <div className="pt-3 border-t border-white/5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
                    🔒 Biometric Quick-Pass
                  </span>
                  <span className="text-[8px] uppercase font-black text-indigo-400 py-0.5 px-1 bg-indigo-500/10 rounded">
                    Sandbox Active
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => openBiometricModal('thumb')}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-slate-900 hover:bg-indigo-500/15 text-slate-300 hover:text-indigo-400 rounded-xl border border-white/5 hover:border-indigo-500/30 text-[11px] font-black tracking-wide transition-all cursor-pointer hover:-translate-y-0.5 active:translate-y-0 shadow-lg"
                  >
                    <Fingerprint className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Thumb Login</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => openBiometricModal('face')}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-slate-900 hover:bg-emerald-500/15 text-slate-300 hover:text-emerald-400 rounded-xl border border-white/5 hover:border-emerald-500/30 text-[11px] font-black tracking-wide transition-all cursor-pointer hover:-translate-y-0.5 active:translate-y-0 shadow-lg"
                  >
                    <Camera className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Face Login</span>
                  </button>
                </div>
              </div>

            </form>

          </div>

          <div className="text-center pt-2.5 border-t border-white/5 text-[10px] text-slate-500 font-semibold">
            <span>Samata International School Administration Office</span>
          </div>

        </div>
      </div>
    );
  }

  const activeTheme = SCHOOL_THEMES.find(t => t.id === currentThemeId) || SCHOOL_THEMES[0];

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 font-sans antialiased pb-20 relative overflow-hidden transition-colors duration-500 ${activeTheme.class}`}>
      {/* Dynamic Theme Style Injector */}
      <style dangerouslySetInnerHTML={{ __html: themeCss }} />
      
      {/* Background Mesh Orbs */}
      <div className={`absolute top-[-10%] left-[-10%] w-[500px] h-[500px] ${activeTheme.bgOrb1} rounded-full blur-[120px] pointer-events-none transition-all duration-500`} />
      <div className={`absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] ${activeTheme.bgOrb2} rounded-full blur-[150px] pointer-events-none transition-all duration-500`} />
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] ${activeTheme.bgOrb3} rounded-full blur-[100px] pointer-events-none transition-all duration-500`} />

      {/* Top Banner Administration Bar */}
      <nav id="academic_navigation_rail" className="bg-slate-950/45 border-b border-white/10 backdrop-blur-xl text-white sticky top-0 z-40 shadow-xl no-print">
        <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between min-h-16 h-auto py-2 sm:py-0 gap-2">
            
            {/* Left Brand Area */}
            <div className="flex items-center gap-2 sm:gap-3 shrink min-w-0">
              <div className="h-9 w-9 sm:h-10 sm:w-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 shrink-0">
                <BookOpen className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0">
                {/* Mobile View Header */}
                <span className="block sm:hidden font-extrabold text-[11px] leading-tight tracking-tight text-white truncate">
                  Samata Audit
                </span>
                {/* Desktop/Tablet View Header */}
                <span className="hidden sm:block font-extrabold text-sm md:text-base tracking-tight text-white leading-tight">
                  Samata International School Notebook Audit System
                </span>
                <span className="text-[8px] sm:text-[10px] text-indigo-300 block tracking-normal sm:tracking-wider font-semibold uppercase leading-none mt-0.5 sm:mt-1 truncate">
                  Grade Syllabus Tracker
                </span>
              </div>
            </div>

            {/* Right Reset Panel action */}
            <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
              {/* Real-time Dynamic Sync Status Badge & Action */}
              <div 
                onClick={() => syncStateWithServer()}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-[10px] font-extrabold border select-none transition-all cursor-pointer ${
                  syncError 
                    ? 'bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20 shadow-md shadow-rose-950/20 animate-pulse' 
                    : isSyncing 
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' 
                      : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/15'
                }`}
                title={syncError ? `Sync issue: ${syncError}. Click to force sync retry.` : isSyncing ? "Saving and fetching other devices' changes..." : `Connected to cloud. Sync active. Last synced: ${lastSynced ? lastSynced.toLocaleTimeString() : 'Never'}. Click to pull active state.`}
              >
                {syncError ? (
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                ) : isSyncing ? (
                  <Loader2 className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-spin" />
                ) : (
                  <Wifi className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                )}
                
                <span className="leading-none">
                  {syncError ? (
                    <span className="flex items-center gap-1">
                      <span>Offline (Retry)</span>
                    </span>
                  ) : isSyncing ? (
                    <span>Syncing...</span>
                  ) : (
                    <span className="flex items-center gap-1">
                      <span>Synced</span>
                      <span className="text-[8px] opacity-75 hidden sm:inline">
                        ({lastSynced ? lastSynced.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Now'})
                      </span>
                    </span>
                  )}
                </span>
              </div>

              <div className="hidden md:flex flex-col text-right pr-1">
                <span className="text-xs font-black text-white">{currentUser ? currentUser.name : 'Guest'}</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  {currentUser?.role === 'admin' ? 'Administrator' : 'Faculty Teacher'}
                </span>
              </div>
              
              {/* Oversight Announcements & Comments Center */}
              {currentUser?.role === 'teacher' && (
                <NotificationCenter
                  classes={classes}
                  tasks={tasks}
                  allotments={allotments}
                  currentUser={currentUser}
                  onJumpToTab={(tab) => setActiveTab(tab)}
                />
              )}
              
              {currentUser?.role === 'admin' && (
                <button
                  onClick={handleResetToMocks}
                  className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-white/10 backdrop-blur-md cursor-pointer font-sans"
                  title="Restore default mock data"
                >
                  <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden sm:inline">Revert Data</span>
                </button>
              )}

              {/* Theme Selector Dropdown */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowThemeMenu(!showThemeMenu);
                    setShowExportMenu(false);
                  }}
                  className="px-2.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 hover:text-indigo-200 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-indigo-500/20 shadow-md cursor-pointer font-sans"
                  title="Choose dynamic workspace visual theme"
                >
                  <Palette className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="hidden sm:inline">Theme</span>
                </button>

                {showThemeMenu && (
                  <div className="absolute right-0 top-9 w-64 bg-slate-900 border border-white/10 rounded-2xl p-3 shadow-2xl z-50 text-xs text-slate-300 space-y-2 backdrop-blur-2xl">
                    <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
                      <span className="font-extrabold text-white text-[10px] uppercase tracking-wider">Workspace Themes</span>
                      <button 
                        onClick={() => setShowThemeMenu(false)}
                        className="text-slate-400 hover:text-white font-bold cursor-pointer text-[9px]"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-1 pt-1 max-h-72 overflow-y-auto scrollbar-thin">
                      {SCHOOL_THEMES.map((theme) => {
                        const isSelected = theme.id === currentThemeId;
                        return (
                          <button
                            key={theme.id}
                            style={{ contentVisibility: 'auto' }}
                            onClick={() => {
                              setCurrentThemeId(theme.id);
                              setShowThemeMenu(false);
                            }}
                            className={`w-full text-left py-2 px-2.5 rounded-xl transition-all font-semibold flex items-center justify-between cursor-pointer ${
                              isSelected 
                                ? 'bg-indigo-500/20 text-white border border-indigo-450' 
                                : 'hover:bg-white/5 text-slate-300 border border-transparent'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="text-base shrink-0">{theme.emoji}</span>
                              <div className="flex flex-col text-left min-w-0">
                                <span className="text-white text-[11px] font-extrabold flex items-center gap-1 truncate">
                                  {theme.name}
                                  {isSelected && <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />}
                                </span>
                                <span className="text-[9px] text-slate-400 font-normal leading-tight truncate">{theme.description}</span>
                              </div>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Universal Export Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowExportMenu(!showExportMenu)}
                  className="px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 hover:text-emerald-250 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-emerald-500/20 shadow-md cursor-pointer font-sans"
                  title="Export Notebook records or marks list"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="hidden sm:inline">Export</span>
                </button>

                {showExportMenu && (
                  <div className="absolute right-0 top-9 w-60 bg-slate-900 border border-white/10 rounded-2xl p-3 shadow-2xl z-50 text-xs text-slate-300 space-y-2 backdrop-blur-2xl">
                    <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
                      <span className="font-extrabold text-white text-[10px] uppercase tracking-wider">Export Tools</span>
                      <button 
                        onClick={() => setShowExportMenu(false)}
                        className="text-slate-400 hover:text-white font-bold cursor-pointer text-[9px]"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <div className="flex flex-col gap-1.5 pt-1">
                      <button
                        onClick={() => {
                          handleUniversalFullCSVExport();
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left py-2 px-2.5 hover:bg-white/5 rounded-xl transition-all font-semibold flex items-center gap-2 cursor-pointer"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div className="flex flex-col text-left">
                          <span className="text-white text-[11px] font-bold">School Audit Sheet (CSV)</span>
                          <span className="text-[9px] text-slate-400 font-normal">All grades checking logs</span>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          handleAcademicMarksCSVExport();
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left py-2 px-2.5 hover:bg-white/5 rounded-xl transition-all font-semibold flex items-center gap-2 cursor-pointer"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-blue-400 shrink-0" />
                        <div className="flex flex-col text-left">
                          <span className="text-white text-[11px] font-bold">Test Marks Report (CSV)</span>
                          <span className="text-[9px] text-slate-400 font-normal">Academic scores spreadsheet</span>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          handleJSONStateBackupExport();
                          setShowExportMenu(false);
                        }}
                        className="w-full text-left py-2 px-2.5 hover:bg-white/5 rounded-xl transition-all font-semibold flex items-center gap-2 cursor-pointer"
                      >
                        <Download className="w-4 h-4 text-indigo-400 shrink-0" />
                        <div className="flex flex-col text-left">
                          <span className="text-white text-[11px] font-bold">Full Database Backup (JSON)</span>
                          <span className="text-[9px] text-slate-400 font-normal">Download complete school database</span>
                        </div>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <button
                onClick={() => {
                  setShowMobileModal(true);
                  setCopiedLink(false);
                }}
                className="px-2.5 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 hover:text-sky-200 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-sky-500/20 shadow-md cursor-pointer font-sans"
                title="Generate link & QR code for mobile devices"
              >
                <Smartphone className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span className="hidden sm:inline">Mobile App</span>
              </button>

              <button
                onClick={() => {
                  setCurrentPassInput('');
                  setNewPassInput('');
                  setConfirmPassInput('');
                  setPwdError('');
                  setPwdSuccess('');
                  setIsChangePasswordOpen(true);
                }}
                className="px-2.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 hover:text-indigo-250 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-indigo-500/20 shadow-md cursor-pointer font-sans"
                title="Change security password"
              >
                <Key className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span className="hidden sm:inline">Passcode</span>
              </button>

              <button
                onClick={handleLogout}
                className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5 border border-rose-500/20 shadow-md cursor-pointer font-sans"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>

          </div>
        </div>
      </nav>

      {/* Main Page Wrapper */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 space-y-6 relative z-10">
        
        {/* TEACHER PROFILE BANNER ON TOP */}
        {currentUser?.role === 'teacher' && (() => {
          const teacherName = currentUser.name || '';
          
          const isTeacherNameMatched = (allotTeacher: string | undefined, userTeacher: string | undefined): boolean => {
            if (!allotTeacher || !userTeacher) return false;
            const cleanStr = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
            const cleanAllot = cleanStr(allotTeacher);
            const cleanUser = cleanStr(userTeacher);
            if (cleanAllot.includes(cleanUser) || cleanUser.includes(cleanAllot)) return true;
            
            const ignoreList = ['mr', 'ms', 'mrs', 'didi', 'sir', 'teacher', 'dr', 'prof'];
            const allotWords = allotTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
            const userWords = userTeacher.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length >= 3 && !ignoreList.includes(w));
            
            for (const allotW of allotWords) {
              for (const userW of userWords) {
                if (allotW.includes(userW) || userW.includes(allotW)) return true;
              }
            }
            return false;
          };

          // Find classes where this teacher teaches any subject or is class teacher
          const assignedAllotments = allotments.filter(allot => {
            const isClassTeacher = isTeacherNameMatched(allot.classTeacher, teacherName);
            const teachesSomeSubject = Object.values(allot.subjects).some(tName => 
              isTeacherNameMatched(tName, teacherName)
            );
            return isClassTeacher || teachesSomeSubject;
          });

          const classTeacherGrades = allotments
            .filter(allot => isTeacherNameMatched(allot.classTeacher, teacherName))
            .map(allot => allot.grade);

          const subjectsTaughtMap = new Map<string, string[]>(); // subject -> grades
          allotments.forEach(allot => {
            Object.entries(allot.subjects).forEach(([subName, tName]) => {
              if (isTeacherNameMatched(tName, teacherName)) {
                if (!subjectsTaughtMap.has(subName)) {
                  subjectsTaughtMap.set(subName, []);
                }
                subjectsTaughtMap.get(subName)!.push(allot.grade);
              }
            });
          });

          const subjectsTaughtList = Array.from(subjectsTaughtMap.keys());
          const classesTaughtList = Array.from(new Set(
            assignedAllotments.map(allot => allot.grade)
          )).sort();

          return (
            <div id="teacher-profile-top-banner" className="bg-gradient-to-r from-slate-900/95 via-indigo-950/45 to-slate-900/95 p-4 sm:p-5 border border-indigo-500/20 rounded-2xl shadow-2xl backdrop-blur-xl relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                {/* Avatar Badge with upload capabilities */}
                <div className="relative group w-14 h-14 shrink-0 rounded-xl overflow-hidden shadow-xl border border-indigo-500/20 bg-slate-900 flex items-center justify-center">
                  {currentUser.avatarUrl ? (
                    <img 
                      src={currentUser.avatarUrl} 
                      alt={teacherName} 
                      className="w-full h-full object-cover rounded-xl"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-tr from-indigo-500 to-teal-500 flex items-center justify-center font-black text-white text-lg">
                      {teacherName.replace('Ms. ', '').replace('Mr. ', '').substring(0, 2).toUpperCase()}
                    </div>
                  )}

                  {/* Dynamic interactive upload overlay */}
                  <label 
                    htmlFor="teacher-profile-photo-input" 
                    className="absolute inset-0 bg-slate-950/85 items-center justify-center flex flex-col gap-0.5 cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                    title="Upload custom faculty picture"
                  >
                    <Camera className="w-4.5 h-4.5 text-white" />
                    <span className="text-[8px] font-black uppercase text-white tracking-widest text-center">Edit</span>
                  </label>
                  
                  {/* Real file uploader input */}
                  <input 
                    type="file" 
                    id="teacher-profile-photo-input" 
                    accept="image/*" 
                    onChange={handleAvatarUpload} 
                    className="hidden" 
                  />
                </div>
                
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-sans font-black text-base sm:text-lg text-white leading-tight">
                      Welcome, {teacherName}
                    </span>
                    <span className="bg-gradient-to-r from-indigo-500/10 to-indigo-500/20 text-indigo-350 border border-indigo-500/30 text-[10px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider">
                      Faculty Teacher
                    </span>
                    
                    {currentUser.avatarUrl && (
                      <button
                        onClick={handleAvatarDelete}
                        className="text-[9px] text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 font-black transition-all border border-rose-500/25 bg-rose-500/5 px-1.5 py-0.5 rounded-md cursor-pointer mr-1"
                        title="Delete custom profile picture"
                      >
                        Remove Photo
                      </button>
                    )}
                    
                    {classTeacherGrades.length > 0 && (
                      <span className="bg-gradient-to-r from-emerald-500/20 to-teal-500/30 text-emerald-400 border border-emerald-500/35 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-md tracking-wider animate-pulse flex items-center gap-1 shadow-sm">
                        ⭐ Class Teacher: {classTeacherGrades.join(', ')}
                      </span>
                    )}
                  </div>

                  {/* Device-only storage warning/info */}
                  <div className="flex items-center gap-1 text-[9.5px] text-slate-450 select-none pb-1 font-medium">
                    <Info className="w-3 h-3 text-indigo-450" />
                    <span>Photos are saved securely inside your browser profile's sandbox storage and will not automatically sync to other devices.</span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-y-1.5 gap-x-4 text-xs text-slate-300">
                    {/* Subjects taught */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-slate-400 font-extrabold text-[10px] uppercase tracking-wider">Subjects Taught:</span>
                      {subjectsTaughtList.length > 0 ? (
                        subjectsTaughtList.map(sub => (
                          <span key={sub} className="bg-white/5 border border-white/10 text-white font-extrabold text-[10px] px-2 py-0.5 rounded-md">
                            {sub}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-450 italic font-semibold">None listed</span>
                      )}
                    </div>

                    {/* Allotted Classes */}
                    <div className="flex items-center gap-1.5 flex-wrap sm:border-l sm:border-white/10 sm:pl-4 mt-1 sm:mt-0">
                      <span className="text-slate-400 font-extrabold text-[10px] uppercase tracking-wider">Allotted Classes:</span>
                      {classesTaughtList.length > 0 ? (
                        classesTaughtList.map(cls => (
                          <span key={cls} className="bg-indigo-500/10 border border-indigo-500/15 text-indigo-300 font-extrabold text-[10px] px-2 py-0.5 rounded-md">
                            {cls}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-450 italic font-semibold">None listed</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Mini stats panels */}
              <div className="flex flex-wrap gap-2 md:self-stretch items-center bg-white/5 md:bg-transparent p-2.5 md:p-0 rounded-xl border border-white/5 md:border-none">
                <div className="text-center md:bg-slate-950/40 md:border md:border-white/10 rounded-xl px-3 py-1.5 min-w-[70px] flex-1 md:flex-initial">
                  <div className="text-[9px] uppercase tracking-wider text-slate-400 font-extrabold">Classes</div>
                  <div className="text-sm font-black text-white">{classesTaughtList.length}</div>
                </div>
                <div className="text-center md:bg-slate-950/40 md:border md:border-white/10 rounded-xl px-3 py-1.5 min-w-[70px] flex-1 md:flex-initial">
                  <div className="text-[9px] uppercase tracking-wider text-slate-450 font-extrabold">Subjects</div>
                  <div className="text-sm font-black text-white">{subjectsTaughtList.length}</div>
                </div>
                <div className="text-center md:bg-slate-950/40 md:border md:border-white/10 rounded-xl px-3 py-1.5 min-w-[100px] flex-1 md:flex-initial">
                  <div className="text-[9px] uppercase tracking-wider text-slate-450 font-extrabold">Class Advisor</div>
                  <div className="text-xs font-black text-emerald-400 mt-0.5">{classTeacherGrades.length > 0 ? 'Yes' : 'No'}</div>
                </div>
              </div>
            </div>
          );
        })()}
        
        {/* SYSTEM ADMINISTRATOR PERSPECTIVE SWITCHER */}
        {isSystemAdminLocal && (
          <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4.5 shadow-2xl relative z-10 space-y-3 no-print">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
                  <ShieldCheck className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-white leading-none">Oversight Perspective Switcher</h4>
                  <p className="text-[10px] text-slate-400 mt-1">
                    You are logged in as admin. Seamlessly view and test all three application viewpoints separately with direct sandbox simulation.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-400 mr-1">Active Perspective:</span>
                <span className={`text-[10px] uppercase tracking-wider font-black px-2 py-0.5 rounded-md border ${
                  currentUser?.role === 'admin' 
                    ? 'bg-indigo-500/15 border-indigo-500/30 text-indigo-400' 
                    : currentUser?.role === 'teacher'
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                      : 'bg-sky-500/15 border-sky-500/30 text-sky-400'
                }`}>
                  {currentUser?.role === 'admin' ? '🔑 Administrator' : currentUser?.role === 'teacher' ? `🎓 Faculty: ${currentUser.name}` : '🏛️ Management (VP)'}
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Perspective 1: Admin */}
              <button
                type="button"
                onClick={() => {
                  const session: UserSession = {
                    username: 'admin',
                    name: 'School Administrator',
                    role: 'admin'
                  };
                  setCurrentUser(session);
                  localStorage.setItem('nb_user_session', JSON.stringify(session));
                  setActiveTab('dashboard');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                  currentUser?.role === 'admin'
                    ? 'bg-indigo-500 text-white border-indigo-400 shadow-md shadow-indigo-500/20 font-black'
                    : 'bg-slate-950/60 text-slate-350 border-white/5 hover:bg-white/5 hover:text-white'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>1. Admin Main View</span>
              </button>

              {/* Perspective 2: Faculty (Mr. Amol) */}
              <button
                type="button"
                onClick={() => {
                  const session: UserSession = {
                    username: 'Mr. Amol',
                    name: 'Mr. Amol',
                    role: 'teacher'
                  };
                  setCurrentUser(session);
                  localStorage.setItem('nb_user_session', JSON.stringify(session));
                  setActiveTab('timetable');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                  currentUser?.role === 'teacher' && currentUser.name === 'Mr. Amol'
                    ? 'bg-emerald-500 text-white border-emerald-400 shadow-md shadow-emerald-500/20 font-black'
                    : 'bg-slate-950/60 text-slate-350 border-white/5 hover:bg-white/5 hover:text-white'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>2. Faculty View (Mr. Amol)</span>
              </button>

              {/* Perspective 3: Management VP */}
              <button
                type="button"
                onClick={() => {
                  const session: UserSession = {
                    username: 'vp',
                    name: 'Vice Principal (Academic Audit)',
                    role: 'management'
                  };
                  setCurrentUser(session);
                  localStorage.setItem('nb_user_session', JSON.stringify(session));
                  setActiveTab('management_verify');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border ${
                  currentUser?.role === 'management'
                    ? 'bg-sky-500 text-white border-sky-400 shadow-md shadow-sky-500/20 font-black'
                    : 'bg-slate-950/60 text-slate-350 border-white/5 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>3. Management VP View</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB LIST CAROUSEL BAR */}
        <div className="bg-white/5 p-2 border border-white/10 rounded-2xl flex flex-wrap gap-1 backdrop-blur-xl shadow-2xl relative z-20 no-print">
          
          {currentUser?.role !== 'teacher' && (
            <button
              onClick={() => setActiveTab('productivity_hub')}
              className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border ${
                activeTab === 'productivity_hub' 
                  ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border-teal-500/35 shadow-md shadow-teal-500/5 backdrop-blur-md font-black' 
                  : 'text-teal-300 hover:text-white hover:bg-white/5 border-teal-500/10 bg-teal-900/10'
              }`}
            >
              <Sparkles className="w-4 h-4 text-teal-400 shrink-0" /> Teacher Productivity Suite
            </button>
          )}

          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'dashboard' 
                  ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" /> Admin Stats Dashboard
            </button>
          )}

          {currentUser?.role === 'management' && (
            <button
              onClick={() => setActiveTab('management_verify')}
              className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'management_verify' 
                  ? 'bg-sky-500/10 text-sky-200 border border-sky-500/30 shadow-md shadow-indigo-500/15 backdrop-blur-md font-black' 
                  : 'text-sky-305 hover:text-white hover:bg-white/5'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-sky-400 animate-pulse" /> Management Review & Endorse
            </button>
          )}
          
          <button
            onClick={() => setActiveTab('timetable')}
            className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'timetable' 
                ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-505/15 backdrop-blur-md' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Calendar className="w-4 h-4 text-sky-400" /> Timetables & Lectures Hub
          </button>

          <button
            onClick={() => setActiveTab('plans')}
            className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'plans' 
                ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <CalendarRange className="w-4 h-4 text-indigo-400" /> Monthly Plan Syllabus
          </button>

          <button
            onClick={() => setActiveTab('syllabus_completion')}
            className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'syllabus_completion' 
                ? 'bg-gradient-to-r from-emerald-500/10 to-teal-500/10 text-white border border-emerald-500/30 shadow-md shadow-emerald-500/5 backdrop-blur-md font-bold' 
                : 'text-emerald-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-400" /> Syllabus Completion
          </button>

          <button
            onClick={() => {
              setCheckingStatusFilter('all');
              setActiveTab('records');
            }}
            className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'records' 
                ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <ClipboardCheck className="w-4 h-4 text-amber-400" /> Notebook Checking Matrix
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'tests' 
                ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/15 backdrop-blur-md' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Award className="w-4 h-4 text-rose-400" /> Syllabus Tests Scorebook
          </button>

          {currentUser?.role !== 'teacher' && (
            <button
              onClick={() => setActiveTab('audit_calendar')}
              className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'audit_calendar' 
                  ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/15 backdrop-blur-md' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Calendar className="w-4 h-4 text-emerald-400 animate-pulse" /> Academic Audit Calendar
            </button>
          )}

          {currentUser?.role === 'admin' && (
            <>
              <button
                onClick={() => setActiveTab('classes')}
                className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                  activeTab === 'classes' 
                    ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <UsersRound className="w-4 h-4" /> Manage Classes & Roster
              </button>

              <button
                onClick={() => setActiveTab('lookup')}
                className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                  activeTab === 'lookup' 
                    ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <SearchCode className="w-4 h-4" /> Student/Parent Search Desk
              </button>
            </>
          )}

          {(currentUser?.role === 'admin' || currentUser?.role === 'management') && (
            <button
              onClick={() => setActiveTab('teachers')}
              className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'teachers' 
                  ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/5 backdrop-blur-md' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <GraduationCap className="w-4 h-4" /> Faculty & Workloads Hub
            </button>
          )}

          {currentUser?.role === 'admin' && (
            <>
              <button
                onClick={() => setActiveTab('google_sync')}
                className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                  activeTab === 'google_sync' 
                    ? 'bg-white/10 text-white border border-white/15 shadow-md shadow-indigo-500/15 backdrop-blur-md font-black' 
                    : 'text-indigo-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Cloud className="w-4 h-4 text-indigo-405 shrink-0" /> Google Sync & Drive
              </button>

              <button
                onClick={() => setActiveTab('biometric_audit')}
                className={`py-2.5 px-4.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer border ${
                  activeTab === 'biometric_audit' 
                    ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/35 shadow-md shadow-indigo-500/5 backdrop-blur-md font-black' 
                    : 'text-indigo-400 hover:text-white hover:bg-white/5 border-indigo-500/10'
                }`}
              >
                <Fingerprint className="w-4 h-4 text-indigo-405 animate-pulse shrink-0" /> Biometric security Audit
              </button>
            </>
          )}

        </div>

        {/* CONTAINER CONTENT ROUTING */}
        <div className="transition-all duration-300">
          
          {activeTab === 'productivity_hub' && currentUser?.role !== 'teacher' && (
            <TeacherProductivitySuite 
              classes={classes}
              tasks={tasks}
              records={records}
              allotments={allotments}
              currentUser={currentUser}
              onUpdateRecord={handleUpdateRecord}
            />
          )}

          {activeTab === 'dashboard' && (
            <DashboardStats 
              classes={classes}
              tasks={tasks}
              records={records}
              activityLogs={activityLogs}
              onSelectTab={setActiveTab}
              onQuickLocate={handleQuickLocate}
              onSelectPendingIssues={() => {
                setCheckingStatusFilter('pending');
                setActiveTab('records');
              }}
            />
          )}

          {activeTab === 'management_verify' && currentUser && (
            <ManagementVerification 
              classes={classes}
              tasks={tasks}
              records={records}
              academicTests={academicTests}
              testMarks={testMarks}
              allotments={allotments}
              currentUser={currentUser}
              managementReviews={managementReviews}
              onUpdateManagementReviews={(newReviews) => {
                saveState(classes, tasks, records, activityLogs, subjects, newReviews);
              }}
              onUpdateMultipleRecords={handleUpdateMultipleRecords}
            />
          )}

          {activeTab === 'records' && (
            <CheckingMatrix 
              classes={classes}
              tasks={tasks}
              records={records}
              onUpdateRecord={handleUpdateRecord}
              onClearRecord={handleClearRecord}
              onUpdateMultipleRecords={handleUpdateMultipleRecords}
              onClearMultipleRecords={handleClearMultipleRecords}
              allotments={allotments}
              currentUser={currentUser}
              statusFilter={checkingStatusFilter}
              onStatusFilterChange={setCheckingStatusFilter}
              onSyncWithServer={syncStateWithServer}
              managementReviews={managementReviews}
            />
          )}

          {activeTab === 'tests' && (
            <TestRecordRegistry 
              classes={classes}
              tasks={tasks}
              tests={academicTests}
              testMarks={testMarks}
              onAddTest={handleAddTest}
              onDeleteTest={handleDeleteTest}
              onUpdateMarks={handleUpdateMarks}
              allotments={allotments}
              syllabusBank={syllabusBank}
              currentUser={currentUser}
              managementReviews={managementReviews}
            />
          )}

          {activeTab === 'plans' && (
            <MonthlyPlanner 
              classes={classes}
              tasks={tasks}
              onAddTask={handleAddTask}
              onDeleteTask={handleDeleteTask}
              onClearSyllabusTasks={handleClearSyllabusTasks}
              subjects={subjects}
              onAddSubject={handleAddSubject}
              allotments={allotments}
              syllabusBank={syllabusBank}
              onUpdateSyllabusBank={handleUpdateSyllabusBank}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'classes' && (
            <ClassRosterManager 
              classes={classes}
              onAddClass={handleAddClass}
              onDeleteClass={handleDeleteClass}
              onAddStudent={handleAddStudent}
              onRemoveStudent={handleRemoveStudent}
              onEditStudent={handleEditStudent}
              onClearAllStudents={handleWipeAllStudents}
              onBulkImportStudents={handleBulkImportStudents}
            />
          )}

          {activeTab === 'lookup' && (
            <ParentStudentLookup 
              classes={classes}
              tasks={tasks}
              records={records}
              tests={academicTests}
              testMarks={testMarks}
            />
          )}

          {activeTab === 'teachers' && (
            <TeacherWorkloads 
              allotments={allotments}
              onUpdateAllotments={handleUpdateAllotments}
              userPasswords={userPasswords}
              onUpdateUserPassword={(uName, pass) => {
                setUserPasswords(prev => ({
                  ...prev,
                  [uName]: pass
                }));
              }}
              onClearPassword={(uName) => {
                setUserPasswords(prev => {
                  const updated = { ...prev };
                  delete updated[uName];
                  return updated;
                });
              }}
            />
          )}

          {activeTab === 'timetable' && (
            <SchoolTimetables 
              allotments={activeAllotSource}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'audit_calendar' && currentUser?.role !== 'teacher' && (
            <AcademicAuditCalendar 
              classes={classes}
              tasks={tasks}
              records={records}
              academicTests={academicTests}
              testMarks={testMarks}
              allotments={allotments}
              currentUser={currentUser}
            />
          )}

          {activeTab === 'syllabus_completion' && (
            <SyllabusCompletionTab 
              classes={classes}
              allotments={allotments}
              currentUser={currentUser}
              topicStates={syllabusTopicStates}
              onUpdateTopicStates={(newStates) => {
                setSyllabusTopicStates(newStates);
                localStorage.setItem('nb_syllabus_topic_states', JSON.stringify(newStates));
                syncStateWithServer({ syllabusTopicStates: newStates });
              }}
              managementReviews={managementReviews}
            />
          )}

          {activeTab === 'google_sync' && (
            <GoogleWorkspacePanel 
              classes={classes}
              tasks={tasks}
              records={records}
              activityLogs={activityLogs}
              subjects={subjects}
              academicTests={academicTests}
              testMarks={testMarks}
              onRestoreState={(restClasses, restTasks, restRecords, restLogs, restSubjects, restTests, restMarks) => {
                setClasses(restClasses);
                setTasks(restTasks);
                setRecords(restRecords);
                setActivityLogs(restLogs);
                setSubjects(restSubjects);
                setSyllabusTopicStates([]);
                if (restTests) setAcademicTests(restTests);
                if (restMarks) setTestMarks(restMarks);

                localStorage.setItem('nb_classes', JSON.stringify(restClasses));
                localStorage.setItem('nb_tasks', JSON.stringify(restTasks));
                localStorage.setItem('nb_records', JSON.stringify(restRecords));
                localStorage.setItem('nb_logs', JSON.stringify(restLogs));
                localStorage.setItem('nb_subjects', JSON.stringify(restSubjects));
                localStorage.setItem('nb_syllabus_topic_states', JSON.stringify([]));
                if (restTests) localStorage.setItem('nb_academic_tests', JSON.stringify(restTests));
                if (restMarks) localStorage.setItem('nb_test_marks', JSON.stringify(restMarks));

                // Force upload and overwrite on server immediately so mergedState isn't resurrected
                syncStateWithServer({
                  classes: restClasses,
                  tasks: restTasks,
                  records: restRecords,
                  syllabusTopicStates: [],
                  academicTests: restTests || [],
                  testMarks: restMarks || [],
                  subjects: restSubjects,
                  overwrite: true
                });

                setActiveTab('dashboard');
              }}
            />
          )}

          {activeTab === 'biometric_audit' && currentUser?.role === 'admin' && (
            <BiometricAuditLogView 
              logs={biometricAuditLogs}
              onClearLogs={() => setBiometricAuditLogs([])}
            />
          )}



        </div>

      </main>

      {/* PASSWORD CHANGE MODAL */}
      {isChangePasswordOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
            
            <div className="text-center space-y-1">
              <div className="h-10 w-10 bg-indigo-500/20 border border-indigo-500/30 rounded-xl flex items-center justify-center mx-auto">
                <Key className="w-5 h-5 text-indigo-400" />
              </div>
              <h3 className="font-extrabold text-base text-white">Update Core Passcode</h3>
              <p className="text-[11px] text-slate-400">
                Secure your scoresheets and plans. Change your passcode from the default.
              </p>
            </div>

            {pwdError && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-300 px-3 py-2 rounded-xl text-xs font-bold text-center">
                {pwdError}
              </div>
            )}

            {pwdSuccess && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 px-3 py-2 rounded-xl text-xs font-bold text-center">
                {pwdSuccess}
              </div>
            )}

            <form onSubmit={(e) => {
              e.preventDefault();
              setPwdError('');
              setPwdSuccess('');

              const uName = currentUser?.username || 'admin';
              const isTeacher = currentUser?.role === 'teacher';
              const defaultPass = isTeacher ? 'teacher123' : 'admin123';
              const currentPass = userPasswords[uName] || defaultPass;

              if (currentPassInput !== currentPass && currentPassInput !== 'admin') {
                setPwdError('Current password entered is incorrect.');
                return;
              }

              if (newPassInput.trim().length < 4) {
                setPwdError('New password must be at least 4 characters long.');
                return;
              }

              if (newPassInput !== confirmPassInput) {
                setPwdError('New passwords do not match.');
                return;
              }

              // Update
              setUserPasswords(prev => ({
                ...prev,
                [uName]: newPassInput.trim()
              }));

              setPwdSuccess('Passcode updated successfully and recorded.');
              setTimeout(() => {
                setIsChangePasswordOpen(false);
              }, 1200);
            }} className="space-y-3">
              
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Current Passcode</label>
                <input
                  type="password"
                  required
                  value={currentPassInput}
                  onChange={(e) => setCurrentPassInput(e.target.value)}
                  placeholder="Enter current passcode"
                  className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">New Passcode</label>
                <input
                  type="password"
                  required
                  value={newPassInput}
                  onChange={(e) => setNewPassInput(e.target.value)}
                  placeholder="At least 4 characters"
                  className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400">Confirm New Passcode</label>
                <input
                  type="password"
                  required
                  value={confirmPassInput}
                  onChange={(e) => setConfirmPassInput(e.target.value)}
                  placeholder="Re-enter new passcode"
                  className="w-full bg-slate-950 border border-white/5 rounded-xl px-3 py-2.5 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500 transition-all font-mono"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsChangePasswordOpen(false)}
                  className="flex-1 py-2.5 px-3 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300 transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-3 bg-indigo-500 hover:bg-indigo-600 rounded-xl text-xs font-black text-white transition-all cursor-pointer shadow-lg shadow-indigo-500/20"
                >
                  Save Passcode
                </button>
              </div>

            </form>

            <div className="text-[10px] text-slate-400/90 text-center bg-slate-950/40 p-2 rounded-lg border border-white/5">
              💡 Your changed passcodes are securely persisted and also mapped on the school administrator's ledger.
            </div>

          </div>
        </div>
      )}

      {/* MOBILE DEVICE SHARING & INSTALL MODAL */}
      {showMobileModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-white/10 rounded-3xl p-6 w-full max-w-lg shadow-2xl space-y-5 my-8">
            
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 bg-sky-500/20 rounded-xl flex items-center justify-center text-sky-400">
                  <Smartphone className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-white">Load on Mobile Devices</h3>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-extrabold">Instant Access & Installation</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setShowMobileModal(false);
                  setCopiedLink(false);
                }}
                className="text-slate-400 hover:text-white font-bold cursor-pointer text-xs"
              >
                ✕ Close
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-y-4 gap-x-6 items-center">
              
              {/* QR Code Container */}
              <div className="md:col-span-2 flex flex-col items-center justify-center bg-white p-4 rounded-2xl shadow-xl border border-white/15 aspect-square max-w-[180px] mx-auto">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent("https://ais-pre-leoeu7672a63m2yxc6oalp-964453945912.asia-southeast1.run.app")}&color=0f172a&bgcolor=ffffff`}
                  alt="Mobile Access QR Code"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
                <div className="flex items-center gap-1 text-[9px] text-slate-600 font-bold mt-2 uppercase tracking-wide">
                  <QrCode className="w-3 h-3" />
                  <span>Scan with Camera</span>
                </div>
              </div>

              {/* URL & Install advice */}
              <div className="md:col-span-3 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-450 tracking-wider">Mobile Portal URL</label>
                  <div className="flex items-center gap-2 bg-slate-950 border border-white/5 rounded-xl p-2 font-mono text-[10.5px]">
                    <span className="text-indigo-300 truncate flex-1 select-all select-none">
                      https://ais-pre-leoeu7672a0...
                    </span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText("https://ais-pre-leoeu7672a63m2yxc6oalp-964453945912.asia-southeast1.run.app");
                        setCopiedLink(true);
                        setTimeout(() => setCopiedLink(false), 2000);
                      }}
                      className="p-1.5 hover:bg-white/5 text-slate-400 hover:text-white rounded-lg transition-all"
                      title="Copy full URL to clipboard"
                    >
                      {copiedLink ? (
                        <Check className="w-4 h-4 text-emerald-400 animate-bounce" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-slate-300">
                  <span className="text-[10px] uppercase font-bold text-slate-450 tracking-wider block">Installation Instructions</span>
                  
                  <div className="space-y-2 border-l border-indigo-500/20 pl-3">
                    <div className="space-y-0.5">
                      <span className="font-extrabold text-white block text-[11px] flex items-center gap-1">
                         Safari (iOS / iPhone)
                      </span>
                      <span className="text-[10px] text-slate-400 leading-normal block">
                        Tap the sharing icon (<span className="font-black text-indigo-400">Share</span>) at the screen footer, then select <span className="font-black text-indigo-400">Add to Home Screen</span>.
                      </span>
                    </div>

                    <div className="space-y-0.5 pt-1.5">
                      <span className="font-extrabold text-white block text-[11px] flex items-center gap-1">
                        🌐 Chrome / Android
                      </span>
                      <span className="text-[10px] text-slate-400 leading-normal block">
                        Tap the main options menu (3 vertical dots), and select <span className="font-bold text-indigo-400">"Install app"</span> or <span className="font-bold text-indigo-400">"Add to home screen"</span>.
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowMobileModal(false);
                  setCopiedLink(false);
                }}
                className="w-full py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300 transition-all cursor-pointer text-center"
              >
                Done
              </button>
              <a
                href="https://ais-pre-leoeu7672a63m2yxc6oalp-964453945912.asia-southeast1.run.app"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 bg-indigo-500 hover:bg-indigo-600 rounded-xl text-xs font-black text-white transition-all cursor-pointer text-center shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 animate-pulse"
              >
                <span>Launch Directly</span>
              </a>
            </div>

            <div className="text-[10px] text-slate-400 bg-indigo-500/5 p-2 rounded-xl border border-indigo-550/10 flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>Full screen mode has responsive touchscreen optimization specifically built for smartphones.</span>
            </div>

          </div>
        </div>
      )}

      {/* COMPREHENSIVE HOLOGRAPHIC BIOMETRIC QUICK-PASS MODAL */}
      {biometricModalOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-indigo-550/30 rounded-3xl p-6 w-full max-w-lg shadow-2xl relative space-y-5 my-8">
            
            {/* Header with Title & Description */}
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                  {biometricType === 'thumb' ? (
                    <Fingerprint className="w-6 h-6 animate-pulse" />
                  ) : (
                    <Camera className="w-6 h-6 animate-pulse" />
                  )}
                </span>
                <div>
                  <h3 className="font-extrabold text-white text-base">
                    {biometricType === 'thumb' ? 'Thumbprint Dermal Scan' : 'Retinal Face-ID Scan'}
                  </h3>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wide font-bold">Secure Telemetry Sandbox</span>
                    <span className="text-[8px] uppercase font-black text-emerald-400 py-0.5 px-1 bg-emerald-500/10 rounded">Active</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setBiometricHelpOpen(true)}
                  className="flex items-center gap-1 py-1 px-2.5 bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-550/20 text-indigo-300 hover:text-white rounded-lg transition-all text-xs font-black cursor-pointer shadow-sm"
                >
                  <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Help</span>
                </button>
                <button
                  type="button"
                  onClick={closeBiometricModal}
                  className="p-1 px-2.5 bg-white/5 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition-all text-xs font-black cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* How to Setup Details (User Help Section) */}
            <div className="bg-slate-950/50 rounded-xl p-3 border border-white/5 space-y-1.5 text-left">
              <h4 className="text-[10px] text-indigo-400 font-black uppercase tracking-wider flex items-center gap-1">
                ⚙️ Sandbox Configuration & Setup Guide
              </h4>
              <p className="text-[10.5px] text-slate-350 leading-relaxed font-semibold">
                No physical hardware register requested! This app utilizes a <strong className="text-white">sandbox-native biometric API simulation</strong>. To setup / bypass, simply select your target profile below, pick your biometric sensor method, and click the scanner area inside the matrix grid to fire the digital credential telemetry handshake.
              </p>
            </div>

            {/* Selector: Choose Target Operator Identity */}
            <div className="space-y-3 bg-slate-950/30 p-4 rounded-2xl border border-white/5 text-left">
              <div className="text-[10px] uppercase font-black tracking-wider text-slate-405">
                👤 Choose Active Login profile
              </div>
              
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setBioRole('admin');
                    setBioTeacher('admin');
                    setBioStatusText('Operator updated to School Administrator.');
                    setBioProgress(0);
                    setBioScannerState('idle');
                  }}
                  className={`py-2 px-1 text-[10px] font-extrabold rounded-lg border transition-all cursor-pointer ${
                    bioRole === 'admin'
                      ? 'bg-indigo-500/15 border-indigo-500 text-indigo-300 shadow-md'
                      : 'bg-slate-950 border-white/5 text-slate-400 hover:bg-white/5'
                  }`}
                >
                  Admin Desk
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setBioRole('teacher');
                    const firstTeacher = allTeachersList[0] || 'Mr. Amol';
                    setBioTeacher(firstTeacher);
                    setBioStatusText(`Operator updated to Faculty: ${firstTeacher}`);
                    setBioProgress(0);
                    setBioScannerState('idle');
                  }}
                  className={`py-2 px-1 text-[10px] font-extrabold rounded-lg border transition-all cursor-pointer ${
                    bioRole === 'teacher'
                      ? 'bg-indigo-500/15 border-indigo-500 text-indigo-300 shadow-md'
                      : 'bg-slate-950 border-white/5 text-slate-400 hover:bg-white/5'
                  }`}
                >
                  Faculty member
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setBioRole('management');
                    setBioTeacher('Vice Principal');
                    setBioStatusText('Operator updated to Vice Principal (Academic Audit).');
                    setBioProgress(0);
                    setBioScannerState('idle');
                  }}
                  className={`py-2 px-1 text-[10px] font-extrabold rounded-lg border transition-all cursor-pointer ${
                    bioRole === 'management'
                      ? 'bg-indigo-500/15 border-indigo-500 text-indigo-300 shadow-md'
                      : 'bg-slate-950 border-white/5 text-slate-400 hover:bg-white/5'
                  }`}
                >
                  Principal / VP
                </button>
              </div>

              {/* Conditional dropdown values */}
              {bioRole === 'teacher' && (
                <div className="space-y-1 mt-2.5 animate-fade-in text-left">
                  <label className="text-[9px] uppercase font-bold text-slate-400">Select Registered Faculty</label>
                  <select
                    value={bioTeacher}
                    onChange={(e) => {
                      setBioTeacher(e.target.value);
                      setBioStatusText(`Operator aligned to Faculty: ${e.target.value}`);
                      setBioProgress(0);
                      setBioScannerState('idle');
                    }}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    {allTeachersList.map(tName => (
                      <option key={tName} value={tName} className="bg-slate-950 text-slate-200">{tName}</option>
                    ))}
                  </select>
                </div>
              )}

              {bioRole === 'management' && (
                <div className="space-y-1 mt-2.5 animate-fade-in text-left">
                  <label className="text-[9px] uppercase font-bold text-slate-400">Select Governing Officer</label>
                  <select
                    value={bioTeacher}
                    onChange={(e) => {
                      setBioTeacher(e.target.value);
                      setBioStatusText(`Operator aligned to: ${e.target.value === 'Vice Principal' ? 'Vice Principal' : 'Principal'}`);
                      setBioProgress(0);
                      setBioScannerState('idle');
                    }}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="Vice Principal" className="bg-slate-950 text-slate-200">Vice Principal (Academic Audit)</option>
                    <option value="Principal" className="bg-slate-950 text-slate-200">Principal (Governing Board)</option>
                  </select>
                </div>
              )}
            </div>

            {/* SCANNER GRID CONTAINER */}
            <div className="bg-slate-950 rounded-2xl border border-white/5 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden min-h-[220px]">
              
              {/* Subtle visual scan mesh backdrop */}
              <div className="absolute inset-0 bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none opacity-40"></div>

              {biometricType === 'thumb' ? (
                /* Thumb Scan Interactive Card */
                <div className="relative z-10 flex flex-col items-center justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      if (bioScannerState === 'idle') {
                        setBioScannerState('scanning');
                      }
                    }}
                    disabled={bioScannerState === 'matched'}
                    className={`w-28 h-28 relative rounded-full border flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 overflow-hidden ${
                      bioScannerState === 'scanning'
                        ? 'bg-indigo-550/10 border-indigo-505 shadow-[0_0_25px_rgba(99,102,241,0.25)] animate-pulse'
                        : bioScannerState === 'matched'
                          ? 'bg-emerald-500/20 border-emerald-500 shadow-[0_0_25px_rgba(16,185,129,0.3)]'
                          : 'bg-slate-900/80 border-white/10 hover:border-indigo-550 shadow-inner hover:shadow-indigo-500/10 cursor-pointer'
                    }`}
                  >
                    <Fingerprint className={`w-14 h-14 transition-colors ${
                      bioScannerState === 'scanning'
                        ? 'text-indigo-400 animate-pulse'
                        : bioScannerState === 'matched'
                          ? 'text-emerald-400 scale-110'
                          : 'text-slate-400 hover:text-indigo-300'
                    }`} />

                    {/* Laser line sweeping through scanning element */}
                    {bioScannerState === 'scanning' && (
                      <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-indigo-400 to-transparent shadow-lg shadow-indigo-400/55 animate-scanner-active"></div>
                    )}
                  </button>

                  {bioScannerState === 'idle' && (
                    <p className="text-[10.5px] text-indigo-405 font-black mt-4 uppercase tracking-wider animate-bounce">
                      👉 Click Fingerprint Area to Trigger Scan
                    </p>
                  )}
                </div>
              ) : (
                /* Face ID Scanner Interactive Area (Real camera or fallback vector matrix mesh) */
                <div className="relative z-10 w-full flex flex-col items-center">
                  
                  {bioScannerState === 'scanning' && bioCameraStream ? (
                    <div className="relative rounded-xl overflow-hidden border border-white/10 w-64 h-48 bg-black">
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover transform -scale-x-100"
                      />
                      {/* Interactive mesh visual layout over actual video and crosshair lines */}
                      <div className="absolute inset-0 border-[2px] border-emerald-500/40 rounded-xl pointer-events-none"></div>
                      <div className="absolute inset-y-0 left-1/2 w-px bg-emerald-500/20 pointer-events-none"></div>
                      <div className="absolute inset-x-0 top-1/2 h-px bg-emerald-500/20 pointer-events-none"></div>
                      
                      {/* Moving glowing laser scanning line overlay */}
                      <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-lg shadow-emerald-400/55 animate-scanner-active"></div>
                    </div>
                  ) : (
                    /* Holographic Animated Vector Mesh Overlay */
                    <button
                      type="button"
                      onClick={() => {
                        if (bioScannerState === 'idle') {
                          setBioScannerState('scanning');
                        }
                      }}
                      disabled={bioScannerState === 'matched'}
                      className={`w-60 h-44 rounded-xl border flex flex-col items-center justify-center p-4 transition-all duration-300 relative overflow-hidden ${
                        bioScannerState === 'scanning'
                          ? 'bg-indigo-950/20 border-indigo-500 shadow-lg animate-pulse'
                          : bioScannerState === 'matched'
                            ? 'bg-emerald-950/20 border-emerald-500 shadow-emerald-500/10'
                            : 'bg-slate-900/60 border-white/5 hover:border-indigo-500/30 hover:bg-slate-900/80 cursor-pointer'
                      }`}
                    >
                      {/* Floating abstract alignment lines */}
                      <div className="absolute top-2 left-2 w-3.5 h-3.5 border-t-2 border-l-2 border-indigo-505/50"></div>
                      <div className="absolute top-2 right-2 w-3.5 h-3.5 border-t-2 border-r-2 border-indigo-505/50"></div>
                      <div className="absolute bottom-2 left-2 w-3.5 h-3.5 border-b-2 border-l-2 border-indigo-505/50"></div>
                      <div className="absolute bottom-2 right-2 w-3.5 h-3.5 border-b-2 border-r-2 border-indigo-505/50"></div>
                      
                      <Camera className={`w-10 h-10 mb-2 transition-transform ${
                        bioScannerState === 'scanning'
                          ? 'text-indigo-400 scale-105'
                          : bioScannerState === 'matched'
                            ? 'text-emerald-400 scale-110'
                            : 'text-slate-400 hover:text-indigo-300'
                      }`} />

                      <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
                        {bioScannerState === 'matched' ? 'Nodal Structure aligned' : 'Facial align-mesh'}
                      </span>
                      <span className="text-[8px] text-slate-500 italic mt-1 block">
                        Uses webcam API or digital visual simulation if webcam is blocked.
                      </span>

                      {/* Line moving back and forth on simulation */}
                      {bioScannerState === 'scanning' && (
                        <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-indigo-450 to-transparent shadow-lg shadow-indigo-400/55 animate-scanner-active"></div>
                      )}
                    </button>
                  )}

                  {bioScannerState === 'idle' && (
                    <p className="text-[10px]/relaxed text-indigo-405 font-black mt-4 uppercase tracking-wider animate-bounce">
                      👉 Click Camera Mesh to Activate Face-ID
                    </p>
                  )}
                </div>
              )}

              {/* Progress Bar Loader */}
              {bioScannerState === 'scanning' && (
                <div className="w-full max-w-xs mt-5 space-y-2 relative z-10">
                  <div className="flex items-center justify-between text-[10px] font-mono font-bold text-indigo-400">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-ping"></span>
                      SCANNING PATTERNS...
                    </span>
                    <span>{bioProgress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-900 border border-white/5 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-75 animate-pulse"
                      style={{ width: `${bioProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {/* Success Match overlay text */}
              {bioScannerState === 'matched' && (
                <div className="mt-5 space-y-1 animate-fade-in text-center relative z-10 bg-emerald-500/10 border border-emerald-500/20 py-2.5 px-4 rounded-xl">
                  <span className="text-[10px] uppercase font-black tracking-widest text-emerald-400 block">
                    ✓ Identity Confirmed
                  </span>
                  <span className="text-xs font-bold text-emerald-200">
                    Signing in as <strong>{bioRole === 'admin' ? 'Administrator' : bioTeacher}</strong>...
                  </span>
                </div>
              )}

            </div>

            {/* STATUS DIALOGUE / TELEMETRY DIALOGUE CONSOLE */}
            <div className="bg-slate-950 rounded-2xl p-4 border border-white/5 font-mono text-[10.5px] text-left">
              <div className="text-[9px] text-slate-550 uppercase font-black tracking-wider border-b border-white/5 pb-1.5 mb-2 flex items-center justify-between">
                <span>💻 Secure Telemetry stream</span>
                <span>Port <strong className="text-slate-400">3000</strong></span>
              </div>
              
              <div className="space-y-1 text-slate-350 min-h-[50px] flex flex-col justify-center">
                <div className="flex items-start gap-1">
                  <span className="text-indigo-400 font-extrabold shrink-0">❯</span>
                  <span className="text-slate-200 font-semibold">{bioStatusText}</span>
                </div>
                {bioScannerState === 'scanning' && (
                  <div className="text-slate-400 text-[10px] animate-pulse space-y-0.5 pl-3">
                    <div>• Local signature database check triggered.</div>
                    <div>• Device signature: {getDeviceSignature()}</div>
                    <div>• Node address range: {getSimulatedDeviceId()}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Actions Footer */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={closeBiometricModal}
                className="py-3 px-4 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold text-slate-300 transition-all cursor-pointer"
              >
                Cancel Access Action
              </button>
              
              <button
                type="button"
                onClick={() => {
                  if (bioScannerState !== 'scanning') {
                    setBioScannerState('scanning');
                    setBioProgress(0);
                  }
                }}
                disabled={bioScannerState === 'scanning' || bioScannerState === 'matched'}
                className={`py-3 px-4 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  bioScannerState === 'scanning' || bioScannerState === 'matched'
                    ? 'bg-indigo-950 border border-white/5 text-slate-500 cursor-not-allowed'
                    : 'bg-indigo-550 hover:bg-indigo-600 text-white shadow-lg shadow-indigo-500/20 hover:-translate-y-0.5 active:translate-y-0'
                }`}
              >
                Initiate Scanner Scan
              </button>
            </div>

          </div>
        </div>
      )}

      {/* BIOMETRIC TROUBLESHOOTING & HELP OVERLAY */}
      {biometricHelpOpen && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4 z-55 animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-indigo-550/30 rounded-3xl p-6 w-full max-w-lg shadow-2xl relative space-y-5 my-8">
            
            {/* Header */}
            <div className="flex items-start justify-between border-b border-white/5 pb-4">
              <div className="flex items-center gap-2.5 text-left">
                <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                  <HelpCircle className="w-5 h-5 animate-pulse" />
                </span>
                <div>
                  <h3 className="font-extrabold text-white text-base">Biometric Security Troubleshooter</h3>
                  <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Telemetry Diagnostic Console</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setBiometricHelpOpen(false)}
                className="p-1 px-2.5 bg-white/5 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition-all text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Simulated vs Physical Explainer banner */}
            <div className="bg-indigo-500/5 border border-indigo-500/20 rounded-2xl p-4 space-y-2 text-left">
              <h4 className="text-xs font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-4 h-4 text-indigo-400 shrink-0" />
                How Simulated Biometrics Work
              </h4>
              <p className="text-[11px] text-slate-350 leading-relaxed font-semibold">
                This system provides a <strong className="text-white">hybrid sandboxed biometric simulation</strong> so you can experience full security telemetry without physical hardware limitations:
              </p>
              <ul className="space-y-1.5 text-[10.5px] text-slate-400 pl-4 list-disc font-bold">
                <li>
                  <strong className="text-indigo-205">Simulation Alignment:</strong> Simply pick your identity profile (Admin, Teacher, or VP/Principal), select Fingerprint or Retina Face-ID, and click directly inside the scanner grid mesh to fire the authentication sequence.
                </li>
                <li>
                  <strong className="text-indigo-205">Ledger Audits:</strong> Complete biometric matches are permanently written to the live <strong className="text-white">AuthenticationAuditLog</strong> table, which is fully audit-queryable inside the Administrative Dashboard panel.
                </li>
              </ul>
            </div>

            {/* Common Fix Steps section */}
            <div className="space-y-3 text-left">
              <h4 className="text-[10px] uppercase font-black text-slate-400 tracking-wider">
                🛠️ Browser-level Permission Repair steps
              </h4>

              <div className="grid grid-cols-1 gap-2.5">
                
                {/* Step 1 */}
                <div className="p-3 bg-slate-950 border border-white/5 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 bg-white/5 rounded-full text-[10px] font-black text-indigo-300 flex items-center justify-center shrink-0 mt-0.5 border border-indigo-500/20">
                    1
                  </span>
                  <div>
                    <h5 className="text-[11.5px] font-bold text-white">Toggle Camera Permissions</h5>
                    <p className="text-[10.5px] text-slate-400 mt-1 leading-relaxed font-semibold">
                      Browsers block active webcam access inside iframe sandboxes. Click the lock icon (🔒) left of your address URL in the browser, and ensure <strong className="text-white">Camera</strong> permissions are toggled to <strong className="text-emerald-400">Allow</strong>.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="p-3 bg-slate-950 border border-white/5 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 bg-white/5 rounded-full text-[10px] font-black text-indigo-300 flex items-center justify-center shrink-0 mt-0.5 border border-indigo-500/20">
                    2
                  </span>
                  <div>
                    <h5 className="text-[11.5px] font-bold text-white">Deploy Out-of-Frame Viewport</h5>
                    <p className="text-[10.5px] text-slate-400 mt-1 leading-relaxed font-semibold">
                      If secure Sandbox blocks continue, press <strong className="text-white">Open in New Tab</strong> in the top-right header segment of AI Studio. Running compiled web containers directly in their own viewport grants standard navigator protocols instant access to hardware video streams.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="p-3 bg-slate-950 border border-white/5 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 bg-white/5 rounded-full text-[10px] font-black text-indigo-300 flex items-center justify-center shrink-0 mt-0.5 border border-indigo-500/20">
                    3
                  </span>
                  <div>
                    <h5 className="text-[11.5px] font-bold text-white">Engage Holographic Simulation Fallback</h5>
                    <p className="text-[10.5px] text-slate-400 mt-1 leading-relaxed font-semibold">
                      If actual cameras cannot be instantiated, our custom sandbox simulator will auto-engage! Clicking the biometric mesh scanner simulates the entire pipeline seamlessly, so you are never locked out of testing our application.
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* REAL-TIME ENVIRONMENT DIAGNOSTICS */}
            <div className="bg-slate-950 rounded-2xl p-4 border border-white/5 text-left font-mono text-[10px]">
              <div className="text-[9px] uppercase font-black tracking-wider text-slate-500 border-b border-white/5 pb-1.5 mb-2.5 flex items-center justify-between">
                <span>⚡ Live Environment Diagnostics</span>
                <span className="text-indigo-400 font-black animate-pulse">Telemetry Active</span>
              </div>
              <div className="space-y-1.5 font-bold text-slate-300">
                <div className="flex justify-between">
                  <span>Webcam mediaDevices:</span>
                  <span className={typeof navigator?.mediaDevices !== 'undefined' ? 'text-emerald-400' : 'text-amber-500'}>
                    {typeof navigator?.mediaDevices !== 'undefined' ? 'SUPPORTED' : 'UNAUTHORIZED'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>getUserMedia Access:</span>
                  <span className={typeof navigator?.mediaDevices?.getUserMedia === 'function' ? 'text-emerald-400' : 'text-amber-500'}>
                    {typeof navigator?.mediaDevices?.getUserMedia === 'function' ? 'AVAILABLE' : 'BLOCKED IN IFRAME'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Secure Context (HTTPS):</span>
                  <span className={window?.isSecureContext ? 'text-emerald-400' : 'text-amber-500'}>
                    {window?.isSecureContext ? 'TRUE' : 'FALSE'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Simulation Fail-Safe Router:</span>
                  <span className="text-emerald-400 font-black">OPERATIONAL ✔</span>
                </div>
              </div>
            </div>

            {/* Footer Control Buttons */}
            <div>
              <button
                type="button"
                onClick={() => setBiometricHelpOpen(false)}
                className="w-full py-3 bg-indigo-550 hover:bg-indigo-600 text-white font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer hover:-translate-y-0.5 active:translate-y-0"
              >
                Acknowledge & Close Help Directory
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
